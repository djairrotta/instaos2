
-- Table to track all content URLs/shortcodes ever processed, even if later deleted
CREATE TABLE public.processed_content_log (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  shortcode text NOT NULL,
  source_url text,
  content_type text DEFAULT 'reel',
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Unique constraint to prevent duplicates
CREATE UNIQUE INDEX idx_processed_content_user_shortcode ON public.processed_content_log (user_id, shortcode);

-- Index for fast lookups
CREATE INDEX idx_processed_content_shortcode ON public.processed_content_log (shortcode);

-- Enable RLS
ALTER TABLE public.processed_content_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own processed_content_log"
ON public.processed_content_log
FOR ALL
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);
