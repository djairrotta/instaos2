-- ============================================================
-- MIGRATION: Content Strategy Planner
-- Run in Supabase SQL Editor
-- ============================================================

CREATE TABLE IF NOT EXISTS public.content_strategies (
  id              UUID        NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id         UUID        NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name            TEXT        NOT NULL,
  summary         TEXT,
  weeks           INTEGER     NOT NULL DEFAULT 4,
  posts_per_week  INTEGER     NOT NULL DEFAULT 5,
  distribution    JSONB       NOT NULL DEFAULT '{"reel":3,"carrossel":2,"post":0}',
  pillars         JSONB       NOT NULL DEFAULT '[]',
  weekly_themes   JSONB       NOT NULL DEFAULT '[]',
  posts           JSONB       NOT NULL DEFAULT '[]',
  insights        JSONB       NOT NULL DEFAULT '[]',
  prompt_used     TEXT,
  status          TEXT        NOT NULL DEFAULT 'draft'
    CHECK (status IN ('draft','active','archived')),
  start_date      DATE,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.content_strategies ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own strategies" ON public.content_strategies
  FOR ALL TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_content_strategies_user
  ON public.content_strategies(user_id, created_at DESC);

-- Trigger to auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;

DROP TRIGGER IF EXISTS content_strategies_updated_at ON public.content_strategies;
CREATE TRIGGER content_strategies_updated_at
  BEFORE UPDATE ON public.content_strategies
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
