
-- Table for allowed DM senders (whitelist)
CREATE TABLE public.allowed_senders (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  ig_username TEXT NOT NULL,
  note TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Unique constraint per user
ALTER TABLE public.allowed_senders ADD CONSTRAINT unique_sender_per_user UNIQUE (user_id, ig_username);

-- Enable RLS
ALTER TABLE public.allowed_senders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own allowed_senders"
ON public.allowed_senders
FOR ALL
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);
