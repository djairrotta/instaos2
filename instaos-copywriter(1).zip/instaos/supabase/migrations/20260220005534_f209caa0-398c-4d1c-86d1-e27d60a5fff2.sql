-- Add relevance filtering columns to reels_competidores
ALTER TABLE public.reels_competidores 
ADD COLUMN IF NOT EXISTS relevance_status text NOT NULL DEFAULT 'pending',
ADD COLUMN IF NOT EXISTS relevance_score numeric DEFAULT 0,
ADD COLUMN IF NOT EXISTS relevance_reason text;

-- Add niche_keywords to system_config concept (no schema change needed, uses existing table)

-- Create index for filtering by relevance
CREATE INDEX IF NOT EXISTS idx_reels_competidores_relevance ON public.reels_competidores(relevance_status);

-- Also add to meus_reels for consistency
ALTER TABLE public.meus_reels
ADD COLUMN IF NOT EXISTS relevance_status text NOT NULL DEFAULT 'approved',
ADD COLUMN IF NOT EXISTS relevance_score numeric DEFAULT 0,
ADD COLUMN IF NOT EXISTS relevance_reason text;