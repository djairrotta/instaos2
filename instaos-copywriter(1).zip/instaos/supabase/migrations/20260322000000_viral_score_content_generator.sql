-- ============================================================
-- MIGRATION: Viral Score + Content Generator support
-- Run this in Supabase SQL Editor
-- ============================================================

-- 1. Add viral analysis fields to reels_competidores
ALTER TABLE public.reels_competidores
  ADD COLUMN IF NOT EXISTS viral_score INTEGER DEFAULT 0,
  ADD COLUMN IF NOT EXISTS hook_type TEXT,
  ADD COLUMN IF NOT EXISTS adapted_hook TEXT,
  ADD COLUMN IF NOT EXISTS estimated_reach TEXT DEFAULT 'baixo',
  ADD COLUMN IF NOT EXISTS best_format TEXT DEFAULT 'reel',
  ADD COLUMN IF NOT EXISTS viral_analysis JSONB;

-- 2. Add viral analysis fields to meus_reels
ALTER TABLE public.meus_reels
  ADD COLUMN IF NOT EXISTS viral_score INTEGER DEFAULT 0,
  ADD COLUMN IF NOT EXISTS hook_type TEXT,
  ADD COLUMN IF NOT EXISTS adapted_hook TEXT,
  ADD COLUMN IF NOT EXISTS estimated_reach TEXT DEFAULT 'baixo',
  ADD COLUMN IF NOT EXISTS best_format TEXT DEFAULT 'reel',
  ADD COLUMN IF NOT EXISTS viral_analysis JSONB;

-- 3. Add carousel and reel script to generated_content
ALTER TABLE public.generated_content
  ADD COLUMN IF NOT EXISTS carousel_slides JSONB,
  ADD COLUMN IF NOT EXISTS reel_script JSONB,
  ADD COLUMN IF NOT EXISTS adapted_hook TEXT,
  ADD COLUMN IF NOT EXISTS viral_score INTEGER DEFAULT 0,
  ADD COLUMN IF NOT EXISTS source_reel_id UUID,
  ADD COLUMN IF NOT EXISTS source_owner TEXT;

-- 4. Update publish_queue to store structured content
ALTER TABLE public.publish_queue
  ADD COLUMN IF NOT EXISTS carousel_slides JSONB,
  ADD COLUMN IF NOT EXISTS reel_script JSONB,
  ADD COLUMN IF NOT EXISTS viral_score INTEGER DEFAULT 0,
  ADD COLUMN IF NOT EXISTS source_reel_id UUID;

-- 5. Index for fast viral score queries
CREATE INDEX IF NOT EXISTS idx_reels_comp_viral_score
  ON public.reels_competidores (viral_score DESC);

CREATE INDEX IF NOT EXISTS idx_meus_reels_viral_score
  ON public.meus_reels (viral_score DESC);

CREATE INDEX IF NOT EXISTS idx_generated_content_type_date
  ON public.generated_content (agent_type, created_at DESC);

-- 6. Helper view: top viral competitor reels
CREATE OR REPLACE VIEW public.top_viral_reels AS
  SELECT
    rc.id,
    rc.owner_username,
    rc.caption,
    rc.url,
    rc.viral_score,
    rc.hook_type,
    rc.adapted_hook,
    rc.best_format,
    rc.estimated_reach,
    rc.views,
    rc.likes,
    rc.comments,
    rc.eng_rate,
    rc.content_type,
    rc.hook_analysis,
    rc.post_date,
    c.name AS competitor_name
  FROM public.reels_competidores rc
  LEFT JOIN public.competidores c ON rc.competidor_id = c.id
  WHERE rc.viral_score IS NOT NULL AND rc.viral_score > 0
  ORDER BY rc.viral_score DESC;

-- 7. Helper function: save viral analysis result
CREATE OR REPLACE FUNCTION public.save_viral_analysis(
  p_reel_id UUID,
  p_table TEXT,  -- 'reels_competidores' or 'meus_reels'
  p_score INTEGER,
  p_hook_type TEXT,
  p_adapted_hook TEXT,
  p_reach TEXT,
  p_format TEXT,
  p_analysis JSONB
) RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  IF p_table = 'reels_competidores' THEN
    UPDATE public.reels_competidores SET
      viral_score    = p_score,
      hook_type      = p_hook_type,
      adapted_hook   = p_adapted_hook,
      estimated_reach = p_reach,
      best_format    = p_format,
      viral_analysis = p_analysis
    WHERE id = p_reel_id;
  ELSIF p_table = 'meus_reels' THEN
    UPDATE public.meus_reels SET
      viral_score    = p_score,
      hook_type      = p_hook_type,
      adapted_hook   = p_adapted_hook,
      estimated_reach = p_reach,
      best_format    = p_format,
      viral_analysis = p_analysis
    WHERE id = p_reel_id;
  END IF;
END;
$$;

-- 8. Grant access
GRANT EXECUTE ON FUNCTION public.save_viral_analysis TO authenticated;
GRANT SELECT ON public.top_viral_reels TO authenticated;
