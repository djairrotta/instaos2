-- Table to store Instagram Business API credentials per user
CREATE TABLE public.instagram_credentials (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  ig_user_id TEXT, -- Instagram Business Account ID
  ig_username TEXT,
  page_id TEXT, -- Facebook Page ID linked to IG
  access_token TEXT NOT NULL, -- Long-lived access token
  token_expires_at TIMESTAMP WITH TIME ZONE,
  permissions TEXT[] DEFAULT '{}', -- granted permissions
  is_connected BOOLEAN DEFAULT false,
  last_verified_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id)
);

ALTER TABLE public.instagram_credentials ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own instagram_credentials"
ON public.instagram_credentials FOR ALL
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

CREATE TRIGGER update_instagram_credentials_updated_at
BEFORE UPDATE ON public.instagram_credentials
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Table to track publishing queue with approval workflow
CREATE TABLE public.publish_queue (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  content_type TEXT NOT NULL DEFAULT 'post', -- post, reel, carousel, story
  caption TEXT,
  media_urls JSONB DEFAULT '[]', -- URLs of media to publish
  video_url TEXT, -- for reels
  status TEXT NOT NULL DEFAULT 'pending_approval', -- pending_approval, approved, publishing, published, failed
  scheduled_at TIMESTAMP WITH TIME ZONE, -- optional scheduled time
  published_at TIMESTAMP WITH TIME ZONE,
  ig_media_id TEXT, -- returned after publishing
  ig_permalink TEXT, -- URL on Instagram
  error_message TEXT,
  source_content_id UUID, -- reference to generated_content if applicable
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.publish_queue ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own publish_queue"
ON public.publish_queue FOR ALL
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

CREATE TRIGGER update_publish_queue_updated_at
BEFORE UPDATE ON public.publish_queue
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();