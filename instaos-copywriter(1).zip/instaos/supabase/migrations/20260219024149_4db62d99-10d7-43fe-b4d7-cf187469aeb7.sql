
-- Add cron schedule columns to pipeline_config
ALTER TABLE public.pipeline_config 
  ADD COLUMN IF NOT EXISTS cron_enabled BOOLEAN NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS cron_schedule TEXT NOT NULL DEFAULT '0 6 * * *',
  ADD COLUMN IF NOT EXISTS cron_last_run TIMESTAMP WITH TIME ZONE,
  ADD COLUMN IF NOT EXISTS cron_job_id BIGINT;
