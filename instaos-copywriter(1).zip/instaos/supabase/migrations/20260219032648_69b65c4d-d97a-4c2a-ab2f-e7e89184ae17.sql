-- Add viral analysis columns to meus_reels
ALTER TABLE public.meus_reels ADD COLUMN IF NOT EXISTS viral_points text;
ALTER TABLE public.meus_reels ADD COLUMN IF NOT EXISTS psychological_triggers text;

-- Add viral analysis columns to reels_competidores
ALTER TABLE public.reels_competidores ADD COLUMN IF NOT EXISTS viral_points text;
ALTER TABLE public.reels_competidores ADD COLUMN IF NOT EXISTS psychological_triggers text;