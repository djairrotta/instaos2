
-- Tabela de competidores
CREATE TABLE public.competidores (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  page_url TEXT NOT NULL,
  niche TEXT,
  status BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Tabela de meus reels
CREATE TABLE public.meus_reels (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  caption TEXT,
  owner_username TEXT,
  url TEXT,
  thumbnail_url TEXT,
  video_url TEXT,
  transcript TEXT,
  hook_analysis TEXT,
  views INTEGER DEFAULT 0,
  likes INTEGER DEFAULT 0,
  comments INTEGER DEFAULT 0,
  eng_rate NUMERIC(5,2) DEFAULT 0,
  post_date TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Tabela de reels dos competidores
CREATE TABLE public.reels_competidores (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  competidor_id UUID REFERENCES public.competidores(id) ON DELETE CASCADE,
  caption TEXT,
  owner_username TEXT,
  url TEXT,
  thumbnail_url TEXT,
  video_url TEXT,
  transcript TEXT,
  hook_analysis TEXT,
  views INTEGER DEFAULT 0,
  likes INTEGER DEFAULT 0,
  comments INTEGER DEFAULT 0,
  eng_rate NUMERIC(5,2) DEFAULT 0,
  post_date TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Tabela de estratégias de conteúdo geradas
CREATE TABLE public.estrategias (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  key_takeaway TEXT,
  top_videos JSONB,
  winning_patterns JSONB,
  hook_ideas JSONB,
  raw_report TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Tabela de configurações do pipeline
CREATE TABLE public.pipeline_config (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  instagram_username TEXT NOT NULL DEFAULT '',
  scrape_provider TEXT NOT NULL DEFAULT 'apify',
  my_reels_limit INTEGER NOT NULL DEFAULT 15,
  competitor_reels_limit INTEGER NOT NULL DEFAULT 5,
  my_reels_months_filter INTEGER NOT NULL DEFAULT 3,
  competitor_weeks_filter INTEGER NOT NULL DEFAULT 2,
  ai_model TEXT NOT NULL DEFAULT 'google/gemini-2.5-flash',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Disable RLS for now (single user app)
ALTER TABLE public.competidores ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.meus_reels ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reels_competidores ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.estrategias ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pipeline_config ENABLE ROW LEVEL SECURITY;

-- Allow all access for now (will add auth later)
CREATE POLICY "Allow all access to competidores" ON public.competidores FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all access to meus_reels" ON public.meus_reels FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all access to reels_competidores" ON public.reels_competidores FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all access to estrategias" ON public.estrategias FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all access to pipeline_config" ON public.pipeline_config FOR ALL USING (true) WITH CHECK (true);

-- Insert default config
INSERT INTO public.pipeline_config (instagram_username) VALUES ('filipeyabok.ia');

-- Trigger for updated_at
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_competidores_updated_at BEFORE UPDATE ON public.competidores FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_pipeline_config_updated_at BEFORE UPDATE ON public.pipeline_config FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
