-- ============================================================
-- MIGRATION: Architect + Research + Formats + Checkpoints
-- Run in Supabase SQL Editor
-- ============================================================

-- 1. architect_sessions — Architect discovery workflow sessions
CREATE TABLE IF NOT EXISTS public.architect_sessions (
  id            UUID        NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id       UUID        NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  phase         TEXT        NOT NULL DEFAULT 'discovery',
  question_index INTEGER    NOT NULL DEFAULT 0,
  answers       JSONB       NOT NULL DEFAULT '{}',
  status        TEXT        NOT NULL DEFAULT 'active'
    CHECK (status IN ('active','complete','abandoned')),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.architect_sessions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users manage own arch sessions" ON public.architect_sessions
  FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- 2. custom_squads — Squads created by the Architect
CREATE TABLE IF NOT EXISTS public.custom_squads (
  id               UUID        NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id          UUID        NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name             TEXT        NOT NULL,
  purpose          TEXT,
  platforms        TEXT[]      DEFAULT '{}',
  formats          TEXT[]      DEFAULT '{}',
  performance_mode TEXT        NOT NULL DEFAULT 'economic'
    CHECK (performance_mode IN ('high','economic')),
  agents           TEXT[]      DEFAULT '{}',
  autonomy         TEXT        NOT NULL DEFAULT 'interactive'
    CHECK (autonomy IN ('interactive','autonomous')),
  has_references   BOOLEAN     NOT NULL DEFAULT false,
  reference_urls   TEXT[]      DEFAULT '{}',
  status           TEXT        NOT NULL DEFAULT 'active',
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.custom_squads ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users manage own squads" ON public.custom_squads
  FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- 3. research_briefs — Domain research outputs
CREATE TABLE IF NOT EXISTS public.research_briefs (
  id          UUID        NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id     UUID        NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  topic       TEXT        NOT NULL,
  niche       TEXT,
  time_range  TEXT,
  depth       TEXT        NOT NULL DEFAULT 'medium',
  brief       TEXT,
  angles      JSONB       DEFAULT '[]',
  status      TEXT        NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending','completed','failed')),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.research_briefs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users manage own briefs" ON public.research_briefs
  FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE INDEX IF NOT EXISTS idx_research_briefs_user ON public.research_briefs(user_id, created_at DESC);

-- 4. pipeline_runs — Runs with autonomy mode + checkpoint tracking
CREATE TABLE IF NOT EXISTS public.pipeline_runs (
  id           UUID        NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id      UUID        NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  squad_id     UUID        REFERENCES public.custom_squads(id),
  run_id       TEXT        NOT NULL,
  squad_name   TEXT        NOT NULL DEFAULT 'instaos-viral-factory',
  autonomy     TEXT        NOT NULL DEFAULT 'interactive'
    CHECK (autonomy IN ('interactive','autonomous')),
  status       TEXT        NOT NULL DEFAULT 'running'
    CHECK (status IN ('running','completed','failed','checkpoint','paused')),
  current_step INTEGER     DEFAULT 0,
  total_steps  INTEGER     DEFAULT 0,
  step_label   TEXT,
  agents_state JSONB,
  output       JSONB,
  started_at   TIMESTAMPTZ DEFAULT now(),
  completed_at TIMESTAMPTZ,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.pipeline_runs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users manage own runs" ON public.pipeline_runs
  FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE INDEX IF NOT EXISTS idx_pipeline_runs_user ON public.pipeline_runs(user_id, created_at DESC);

-- 5. checkpoint_queue — Interactive pipeline checkpoints waiting for user
CREATE TABLE IF NOT EXISTS public.checkpoint_queue (
  id           UUID        NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id      UUID        NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  run_id       TEXT        NOT NULL,
  step_id      TEXT        NOT NULL,
  step_label   TEXT,
  checkpoint_type TEXT     NOT NULL DEFAULT 'approve'
    CHECK (checkpoint_type IN ('approve','select','skip')),
  output_preview JSONB,           -- agent output to show user
  options      JSONB,             -- for 'select' type: list of items
  status       TEXT        NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending','approved','rejected','feedback_given')),
  user_feedback TEXT,
  feedback_cycle INTEGER   NOT NULL DEFAULT 0,
  max_feedback_cycles INTEGER NOT NULL DEFAULT 2,
  approved_at  TIMESTAMPTZ,
  expires_at   TIMESTAMPTZ DEFAULT (now() + interval '24 hours'),
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.checkpoint_queue ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users manage own checkpoints" ON public.checkpoint_queue
  FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE INDEX IF NOT EXISTS idx_checkpoint_queue_pending ON public.checkpoint_queue(user_id, status)
  WHERE status = 'pending';

-- 6. Add format fields to agent_configs (if not already there from previous migration)
ALTER TABLE public.agent_configs
  ADD COLUMN IF NOT EXISTS preferred_formats TEXT[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS autonomy TEXT DEFAULT 'interactive'
    CHECK (autonomy IN ('interactive','autonomous','inherit'));

-- 7. Views
CREATE OR REPLACE VIEW public.pending_checkpoints AS
  SELECT
    cq.*,
    pr.squad_name,
    pr.autonomy
  FROM public.checkpoint_queue cq
  LEFT JOIN public.pipeline_runs pr ON pr.run_id = cq.run_id
  WHERE cq.status = 'pending'
  ORDER BY cq.created_at ASC;

GRANT SELECT ON public.pending_checkpoints TO authenticated;

-- Helper: count pending checkpoints for user
CREATE OR REPLACE FUNCTION public.count_pending_checkpoints(p_user_id UUID)
RETURNS INTEGER LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE v INTEGER;
BEGIN
  SELECT COUNT(*) INTO v FROM public.checkpoint_queue
  WHERE user_id = p_user_id AND status = 'pending';
  RETURN COALESCE(v, 0);
END;
$$;
GRANT EXECUTE ON FUNCTION public.count_pending_checkpoints TO authenticated;
