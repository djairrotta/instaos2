-- Add content_type column to meus_reels
ALTER TABLE public.meus_reels 
ADD COLUMN content_type text NOT NULL DEFAULT 'reel';

-- Add content_type column to reels_competidores
ALTER TABLE public.reels_competidores 
ADD COLUMN content_type text NOT NULL DEFAULT 'reel';

-- Add image_urls column for carousel slides
ALTER TABLE public.meus_reels 
ADD COLUMN image_urls jsonb DEFAULT '[]'::jsonb;

ALTER TABLE public.reels_competidores 
ADD COLUMN image_urls jsonb DEFAULT '[]'::jsonb;

-- Add indexes for content_type filtering
CREATE INDEX idx_meus_reels_content_type ON public.meus_reels(content_type);
CREATE INDEX idx_reels_competidores_content_type ON public.reels_competidores(content_type);