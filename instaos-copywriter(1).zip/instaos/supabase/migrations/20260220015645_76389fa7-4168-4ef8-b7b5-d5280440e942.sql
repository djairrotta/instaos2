
ALTER TABLE public.reels_competidores
  DROP CONSTRAINT reels_competidores_competidor_id_fkey,
  ADD CONSTRAINT reels_competidores_competidor_id_fkey
    FOREIGN KEY (competidor_id) REFERENCES public.competidores(id) ON DELETE CASCADE;
