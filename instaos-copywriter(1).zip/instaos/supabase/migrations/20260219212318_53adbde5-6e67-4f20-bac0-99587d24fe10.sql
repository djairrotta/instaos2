
-- Table to track last processed DM cursor per user
CREATE TABLE public.dm_poll_state (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  last_cursor TEXT,
  last_poll_at TIMESTAMP WITH TIME ZONE,
  processed_thread_ids TEXT[] DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id)
);

ALTER TABLE public.dm_poll_state ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own dm_poll_state"
ON public.dm_poll_state FOR ALL
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

CREATE TRIGGER update_dm_poll_state_updated_at
BEFORE UPDATE ON public.dm_poll_state
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
