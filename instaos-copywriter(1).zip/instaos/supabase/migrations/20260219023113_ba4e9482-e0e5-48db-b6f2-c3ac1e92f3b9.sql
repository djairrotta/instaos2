
-- Tabela de histórico de conteúdos gerados por IA
CREATE TABLE public.generated_content (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  generation_type TEXT NOT NULL, -- video, reel, carrossel, post, story
  agent_type TEXT NOT NULL, -- script_writer, caption_writer, carousel_planner, story_creator
  provider TEXT NOT NULL, -- groq, openrouter
  model TEXT NOT NULL,
  prompt TEXT NOT NULL,
  result TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.generated_content ENABLE ROW LEVEL SECURITY;

-- RLS policy
CREATE POLICY "Users manage own generated_content"
  ON public.generated_content
  FOR ALL
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Index for faster queries
CREATE INDEX idx_generated_content_user_date ON public.generated_content (user_id, created_at DESC);
