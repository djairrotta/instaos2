ALTER TABLE public.agent_configs ADD COLUMN custom_prompt_2 text DEFAULT NULL;
ALTER TABLE public.agent_configs ADD COLUMN custom_prompt_3 text DEFAULT NULL;