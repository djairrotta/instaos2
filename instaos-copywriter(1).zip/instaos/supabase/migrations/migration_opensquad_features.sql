-- ============================================================
-- MIGRATION: Full OpenSquad feature parity
-- ============================================================

-- 1. Sherlock investigations
CREATE TABLE IF NOT EXISTS public.sherlock_investigations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  profile_urls TEXT[] NOT NULL DEFAULT '{}',
  mode TEXT NOT NULL DEFAULT 'profile_5_10',
  status TEXT NOT NULL DEFAULT 'running' CHECK (status IN ('running','completed','failed')),
  profiles JSONB,
  consolidated TEXT,
  error TEXT,
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.sherlock_investigations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users manage own investigations" ON public.sherlock_investigations FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- 2. Viral angles
CREATE TABLE IF NOT EXISTS public.viral_angles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  source_reel_id UUID,
  source_caption TEXT,
  source_owner TEXT,
  content_summary TEXT,
  angles JSONB NOT NULL DEFAULT '[]',
  recommended_angle INTEGER,
  recommendation_reason TEXT,
  selected_angle JSONB,
  status TEXT NOT NULL DEFAULT 'pending_selection' CHECK (status IN ('pending_selection','selected','rejected','expired')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.viral_angles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users manage own viral angles" ON public.viral_angles FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- 3. Tone of voice
CREATE TABLE IF NOT EXISTS public.tone_of_voice (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  profile_name TEXT,
  niche TEXT,
  approved_sample TEXT,
  approved_style TEXT,
  tone_rules TEXT,
  vocabulary_use TEXT,
  vocabulary_avoid TEXT,
  active_tones TEXT[] DEFAULT ARRAY['revelador','comparativo','passo_a_passo','pergunta_incomoda','tendencia_oportunidade','checklist_diagnostico'],
  six_tones JSONB,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.tone_of_voice ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users manage own tone" ON public.tone_of_voice FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- 4. Tone of voice approvals history
CREATE TABLE IF NOT EXISTS public.tone_of_voice_approvals (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  tone_id TEXT NOT NULL,
  tone_name TEXT,
  topic TEXT,
  approved_text TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.tone_of_voice_approvals ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users manage own approvals" ON public.tone_of_voice_approvals FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- 5. Best practices catalog
CREATE TABLE IF NOT EXISTS public.best_practices (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'platform',
  platform TEXT,
  content TEXT NOT NULL,
  when_to_use TEXT,
  version TEXT NOT NULL DEFAULT '1.0.0',
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 6. Run versions (incremental output versioning)
CREATE TABLE IF NOT EXISTS public.run_versions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  run_id TEXT NOT NULL,
  squad_name TEXT NOT NULL,
  step_id TEXT NOT NULL,
  version INTEGER NOT NULL DEFAULT 1,
  output JSONB,
  output_text TEXT,
  status TEXT NOT NULL DEFAULT 'created',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.run_versions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users manage own versions" ON public.run_versions FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.next_version(p_run_id TEXT, p_step_id TEXT)
RETURNS INTEGER LANGUAGE plpgsql AS $$
DECLARE v INTEGER;
BEGIN
  SELECT COALESCE(MAX(version), 0) + 1 INTO v FROM public.run_versions WHERE run_id = p_run_id AND step_id = p_step_id;
  RETURN v;
END;
$$;
GRANT EXECUTE ON FUNCTION public.next_version TO authenticated;
