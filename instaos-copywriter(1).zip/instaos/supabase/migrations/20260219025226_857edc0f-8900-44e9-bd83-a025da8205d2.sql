-- Add profile columns to competidores
ALTER TABLE public.competidores
ADD COLUMN bio text,
ADD COLUMN followers_count integer DEFAULT 0,
ADD COLUMN following_count integer DEFAULT 0,
ADD COLUMN posts_count integer DEFAULT 0,
ADD COLUMN profile_pic_url text,
ADD COLUMN predominant_content_type text,
ADD COLUMN avg_posts_per_week numeric DEFAULT 0,
ADD COLUMN last_profile_update timestamp with time zone;