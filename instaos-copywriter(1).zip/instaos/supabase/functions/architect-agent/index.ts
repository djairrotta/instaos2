import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const ARCHITECT_SYSTEM = `Você é o Arquiteto — especialista em design de squads multi-agentes para criação de conteúdo no Instagram.

## Identidade
Pensador sistêmico estratégico. Transforma necessidades em configurações otimizadas de agentes. Paciente com usuários não-técnicos, sempre explica decisões em linguagem simples. Acredita que o melhor squad é o mais simples que resolve o problema.

## Princípios Fundamentais
1. YAGNI — nunca crie agentes que não são estritamente necessários
2. Cada agente tem UMA responsabilidade clara
3. Pipelines têm checkpoints em cada decisão do usuário
4. Pesquise o domínio ANTES de desenhar os agentes
5. Todo squad de conteúdo PRECISA de um agente revisor
6. Máximo 4 perguntas de discovery — respeite o tempo do usuário
7. Squads de conteúdo sempre incluem tom de voz no contexto

## Formato de Resposta
Responda em JSON estruturado conforme a fase atual do workflow.`;

async function callAI(supaUrl: string, serviceKey: string, context: string): Promise<string> {
  const res = await fetch(`${supaUrl}/functions/v1/generate-content`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${serviceKey}` },
    body: JSON.stringify({
      agent: "content_strategist",
      context: ARCHITECT_SYSTEM + "\n\n" + context,
      provider: "openrouter",
      model: "google/gemini-2.5-flash-preview-05-20",
    }),
  });
  const d = await res.json();
  return d.result || "";
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: cors });

  try {
    const SUPA_URL = Deno.env.get("SUPABASE_URL")!;
    const SUPA_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(SUPA_URL, SUPA_KEY);

    const auth = req.headers.get("Authorization") || "";
    const { data: { user } } = await supabase.auth.getUser(auth.replace("Bearer ", ""));
    if (!user) throw new Error("Auth required");

    const body = await req.json();
    const { action = "start" } = body;

    // ── START: begin discovery phase ───────────────────────────────────────
    if (action === "start") {
      // Create a new squad session
      const { data: session, error } = await supabase
        .from("architect_sessions")
        .insert({
          user_id: user.id,
          phase: "discovery",
          question_index: 0,
          answers: {},
          status: "active",
        })
        .select()
        .single();
      if (error) throw error;

      return new Response(JSON.stringify({
        success: true,
        sessionId: session.id,
        phase: "discovery",
        questionIndex: 0,
        message: "👋 Olá! Sou o Arquiteto — vou criar um squad de agentes personalizado para você.\n\nPrimeira pergunta:\n\n**1. O que esse squad deve fazer?** Descreva o resultado final que você quer.\n\n*(Exemplo: \"Quero um squad que analisa posts jurídicos no Instagram, extrai os ganchos mais virais e cria carrosséis adaptados para o meu perfil de advogado\")*",
        options: null,
      }), { headers: { ...cors, "Content-Type": "application/json" } });
    }

    // ── ANSWER: process user answer and advance ────────────────────────────
    if (action === "answer") {
      const { sessionId, answer } = body;
      if (!sessionId || !answer) throw new Error("sessionId and answer required");

      const { data: session } = await supabase
        .from("architect_sessions")
        .select("*")
        .eq("id", sessionId)
        .eq("user_id", user.id)
        .single();
      if (!session) throw new Error("Session not found");

      const answers = session.answers || {};
      const qi = session.question_index || 0;

      // Save answer for this question
      answers[`q${qi}`] = answer;

      let nextMessage = "";
      let nextOptions: string[] | null = null;
      let nextPhase = "discovery";
      let nextQi = qi + 1;

      if (qi === 0) {
        // Q1 answered: purpose. Now ask about platform/audience
        nextMessage = "**2. Para quais plataformas/formatos esse squad vai produzir conteúdo?**\n\n(Você pode escolher múltiplos — responda com os números separados por espaço, ex: \"1 2 3\")";
        nextOptions = [
          "1. Instagram Feed (carrosséis e posts)",
          "2. Instagram Reels (vídeos curtos)",
          "3. Instagram Stories (sequências 24h)",
          "4. LinkedIn (posts profissionais)",
          "5. WhatsApp (broadcasts)",
          "6. YouTube Shorts",
          "7. YouTube (vídeos longos)",
          "8. Múltiplas plataformas (todas acima)",
        ];
      } else if (qi === 1) {
        // Q2 answered: platforms. Now ask performance mode
        nextMessage = "**3. Qual nível de qualidade você quer?**";
        nextOptions = [
          "1. 🏆 Alta Performance — análise profunda, múltiplos agentes em paralelo, revisão completa. Resultado premium, mais tokens.",
          "2. ⚡ Econômico — pipeline enxuto, criação direta, revisão leve. Execução rápida, qualidade boa, menos tokens.",
        ];
      } else if (qi === 2) {
        // Q3 answered: performance mode. Now ask about references
        nextMessage = "**4. Você tem perfis de referência para analisar?** (opcional)\n\nPosso investigar perfis reais do Instagram para extrair padrões, hooks e estruturas que funcionam no seu nicho.\n\nCole 1-3 @usernames ou URLs do Instagram, ou responda **\"pular\"** para continuar sem investigação.";
        nextOptions = null;
      } else if (qi === 3) {
        // Q4 answered: references. Now generate the squad
        nextPhase = "generating";
        nextQi = qi;

        await supabase.from("architect_sessions").update({
          answers, phase: "generating", question_index: nextQi,
        }).eq("id", sessionId);

        // Generate the squad config
        const squadConfig = await generateSquad(supaUrl, SUPA_KEY, answers, user.id, supabase);

        return new Response(JSON.stringify({
          success: true,
          sessionId,
          phase: "complete",
          squadConfig,
          message: `✅ Squad criado! **${squadConfig.name}** com ${squadConfig.agents.length} agentes configurados.\n\nOs agentes foram salvos nas configurações. Acesse **🤖 Agentes** para revisar e personalizar.`,
        }), { headers: { ...cors, "Content-Type": "application/json" } });
      }

      await supabase.from("architect_sessions").update({
        answers, phase: nextPhase, question_index: nextQi,
      }).eq("id", sessionId);

      return new Response(JSON.stringify({
        success: true,
        sessionId,
        phase: nextPhase,
        questionIndex: nextQi,
        message: nextMessage,
        options: nextOptions,
      }), { headers: { ...cors, "Content-Type": "application/json" } });
    }

    // ── LIST sessions ──────────────────────────────────────────────────────
    if (action === "list") {
      const { data } = await supabase
        .from("architect_sessions")
        .select("id,phase,status,created_at,answers")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(10);
      return new Response(JSON.stringify({ success: true, sessions: data || [] }), {
        headers: { ...cors, "Content-Type": "application/json" },
      });
    }

    throw new Error(`Unknown action: ${action}`);
  } catch (e) {
    console.error("architect-agent:", e);
    return new Response(JSON.stringify({ success: false, error: (e as Error).message }), {
      status: 500, headers: { ...cors, "Content-Type": "application/json" },
    });
  }
});

// ── Squad generator ─────────────────────────────────────────────────────────
async function generateSquad(supaUrl: string, serviceKey: string, answers: any, userId: string, supabase: any) {
  const purpose      = answers.q0 || "";
  const platformsRaw = answers.q1 || "1";
  const perfMode     = answers.q2 || "1";
  const references   = answers.q3 || "pular";

  const isHighPerf   = perfMode.includes("1") || perfMode.toLowerCase().includes("alta");
  const platforms    = parsePlatforms(platformsRaw);
  const hasRefs      = references.toLowerCase() !== "pular" && references.length > 3;

  // Map platform codes to format slugs
  const FORMAT_MAP: Record<string, string> = {
    instagram_feed: "instagram-feed",
    instagram_reels: "instagram-reels",
    instagram_stories: "instagram-stories",
    linkedin: "linkedin-post",
    whatsapp: "whatsapp-broadcast",
    youtube_shorts: "youtube-shorts",
    youtube_long: "youtube-script",
  };

  const primaryFormat = platforms[0] ? FORMAT_MAP[platforms[0]] || "instagram-feed" : "instagram-feed";

  // Build agent configs based on performance mode and platforms
  const agentConfigs: any[] = [];

  // Analysis agents (parallel)
  agentConfigs.push({
    agent_type: "hook_analyst",
    tier: "fast",
    provider: "openrouter",
    model: "google/gemini-2.5-flash-preview-05-20",
    execution_mode: "parallel",
    parallel_group: "analysis",
    is_active: true,
    persona: `Especialista em ganchos virais para ${platforms.map(formatPlatformLabel).join(", ")}. ${isHighPerf ? "Análise profunda com múltiplos critérios." : "Análise focada no gancho principal."}`,
    principles: `1. O gancho é o único elemento que decide se o post existe\n2. Analisar contra as constraints específicas do formato ${primaryFormat}\n3. ${isHighPerf ? "Identificar power words e mecanismo psicológico completo" : "Identificar o gancho principal e tipo"}`,
    custom_prompt: null,
    custom_prompt_2: null,
    custom_prompt_3: null,
  });

  agentConfigs.push({
    agent_type: "viral_analyst",
    tier: "fast",
    provider: "openrouter",
    model: "google/gemini-2.5-flash-preview-05-20",
    execution_mode: "sequential",
    parallel_group: null,
    is_active: true,
    persona: `Consolidador de análise viral para ${purpose.slice(0, 100)}`,
    principles: `1. Score final baseado em métricas + qualidade do gancho\n2. Retornar JSON estruturado sempre\n3. Adaptar gancho para o contexto: ${purpose.slice(0, 80)}`,
    custom_prompt: null,
    custom_prompt_2: null,
    custom_prompt_3: null,
  });

  // Generation agents based on platforms
  for (const platform of platforms.slice(0, isHighPerf ? 3 : 1)) {
    const fmt = FORMAT_MAP[platform];
    const agentType = platform.includes("reel") || platform.includes("short") ? "script_writer" : "carousel_planner";

    agentConfigs.push({
      agent_type: agentType,
      tier: "powerful",
      provider: "openrouter",
      model: "anthropic/claude-opus-4",
      execution_mode: "sequential",
      parallel_group: null,
      is_active: true,
      persona: `Criador de conteúdo especializado em ${formatPlatformLabel(platform)} para: ${purpose.slice(0, 100)}`,
      principles: `1. Sempre aplicar constraints do formato ${fmt}\n2. Preservar estrutura psicológica do gancho adaptado\n3. Tom: ${purpose.includes("jurídic") || purpose.includes("advog") ? "educativo, direto, acessível — advogado falando com amigo" : "adequado ao nicho"}`,
      custom_prompt: null,
      custom_prompt_2: null,
      custom_prompt_3: null,
    });
  }

  // Reviewer (always included)
  agentConfigs.push({
    agent_type: "relevance_classifier",
    tier: "economic",
    provider: "openrouter",
    model: "meta-llama/llama-4-scout",
    execution_mode: "sequential",
    parallel_group: null,
    is_active: true,
    persona: `Revisor de qualidade para conteúdo de ${platforms.map(formatPlatformLabel).join(", ")}`,
    principles: `1. Score >= 7/10 para aprovar\n2. Feedback específico e acionável — nunca vago\n3. Verificar constraints do formato ${primaryFormat}\n4. Máximo 3 ciclos de revisão antes de escalar ao usuário`,
    custom_prompt: null,
    custom_prompt_2: null,
    custom_prompt_3: null,
  });

  // Save all agent configs to DB
  for (const agentCfg of agentConfigs) {
    await supabase.from("agent_configs").upsert({
      user_id: userId,
      ...agentCfg,
    }, { onConflict: "user_id,agent_type" });
  }

  // Save squad record
  const squadName = `Squad: ${purpose.slice(0, 60)}${purpose.length > 60 ? "..." : ""}`;
  const { data: squad } = await supabase.from("custom_squads").insert({
    user_id: userId,
    name: squadName,
    purpose,
    platforms,
    formats: platforms.map((p: string) => FORMAT_MAP[p]).filter(Boolean),
    performance_mode: isHighPerf ? "high" : "economic",
    agents: agentConfigs.map(a => a.agent_type),
    autonomy: "interactive",
    has_references: hasRefs,
    reference_urls: hasRefs ? references.split(/[\s,]+/).filter((s: string) => s.length > 3) : [],
    status: "active",
  }).select().single();

  return {
    id: squad?.id,
    name: squadName,
    platforms,
    formats: platforms.map((p: string) => FORMAT_MAP[p]).filter(Boolean),
    performanceMode: isHighPerf ? "high" : "economic",
    agents: agentConfigs.map(a => ({ type: a.agent_type, tier: a.tier })),
    autonomy: "interactive",
  };
}

function parsePlatforms(raw: string): string[] {
  const map: Record<string, string> = {
    "1": "instagram_feed", "2": "instagram_reels", "3": "instagram_stories",
    "4": "linkedin", "5": "whatsapp", "6": "youtube_shorts", "7": "youtube_long",
    "8": "instagram_feed",
  };
  const nums = raw.match(/\d/g) || ["1"];
  if (nums.includes("8")) return ["instagram_feed", "instagram_reels", "linkedin", "whatsapp"];
  return [...new Set(nums.map(n => map[n]).filter(Boolean))];
}

function formatPlatformLabel(p: string): string {
  const labels: Record<string, string> = {
    instagram_feed: "Instagram Feed", instagram_reels: "Instagram Reels",
    instagram_stories: "Instagram Stories", linkedin: "LinkedIn",
    whatsapp: "WhatsApp", youtube_shorts: "YouTube Shorts", youtube_long: "YouTube",
  };
  return labels[p] || p;
}
