import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const now = new Date().toISOString();

    // Find scheduled items that are due
    const { data: dueItems, error } = await supabase
      .from("publish_queue")
      .select("id, user_id")
      .eq("status", "scheduled")
      .lte("scheduled_at", now);

    if (error) throw error;
    if (!dueItems || dueItems.length === 0) {
      return new Response(JSON.stringify({ success: true, processed: 0 }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    console.log(`⏰ Found ${dueItems.length} scheduled items due for publishing`);

    let processed = 0;
    let failed = 0;

    for (const item of dueItems) {
      try {
        // Mark as approved so the publish function can process it
        await supabase.from("publish_queue").update({ status: "approved" }).eq("id", item.id);

        // Get user's Instagram credentials
        const { data: creds } = await supabase
          .from("instagram_credentials")
          .select("*")
          .eq("user_id", item.user_id)
          .eq("is_connected", true)
          .single();

        if (!creds) {
          console.log(`⚠️ No Instagram credentials for user ${item.user_id}, keeping as approved`);
          processed++;
          continue;
        }

        // Call the publish function internally
        // Get queue item details for notification
        const { data: queueDetail } = await supabase
          .from("publish_queue")
          .select("caption, content_type")
          .eq("id", item.id)
          .single();

        const publishRes = await fetch(`${SUPABASE_URL}/functions/v1/publish-instagram`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
          },
          body: JSON.stringify({ action: "publish", queueId: item.id }),
        });

        const publishData = await publishRes.json();
        const contentLabel = queueDetail?.content_type || "post";
        const captionPreview = queueDetail?.caption?.slice(0, 50) || "Sem legenda";

        if (publishData.success) {
          console.log(`✅ Auto-published item ${item.id}`);
          processed++;
          // Send success WhatsApp notification
          await fetch(`${SUPABASE_URL}/functions/v1/send-whatsapp-notification`, {
            method: "POST",
            headers: { "Content-Type": "application/json", "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
            body: JSON.stringify({
              action: "notify",
              userId: item.user_id,
              message: `✅ *Publicação realizada com sucesso!*\n\n📱 Tipo: ${contentLabel}\n📝 Legenda: ${captionPreview}...\n🔗 Link: ${publishData.permalink || "N/A"}\n\n_IG OS v3 • Auto-publish_`,
            }),
          }).catch(e => console.log("WhatsApp notify error (non-critical):", e));
        } else {
          console.error(`❌ Failed to publish item ${item.id}: ${publishData.error}`);
          failed++;
          // Send failure WhatsApp notification
          await fetch(`${SUPABASE_URL}/functions/v1/send-whatsapp-notification`, {
            method: "POST",
            headers: { "Content-Type": "application/json", "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
            body: JSON.stringify({
              action: "notify",
              userId: item.user_id,
              message: `❌ *Falha na publicação agendada*\n\n📱 Tipo: ${contentLabel}\n📝 Legenda: ${captionPreview}...\n⚠️ Erro: ${publishData.error || "Erro desconhecido"}\n\n_Verifique a fila de publicação no IG OS v3._`,
            }),
          }).catch(e => console.log("WhatsApp notify error (non-critical):", e));
        }
      } catch (itemError) {
        console.error(`❌ Error processing item ${item.id}:`, itemError);
        await supabase.from("publish_queue").update({
          status: "failed",
          error_message: itemError instanceof Error ? itemError.message : "Auto-publish failed",
        }).eq("id", item.id);
        failed++;
        // Send failure notification
        await fetch(`${SUPABASE_URL}/functions/v1/send-whatsapp-notification`, {
          method: "POST",
          headers: { "Content-Type": "application/json", "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
          body: JSON.stringify({
            action: "notify",
            userId: item.user_id,
            message: `❌ *Erro crítico na publicação agendada*\n\n⚠️ ${itemError instanceof Error ? itemError.message : "Erro desconhecido"}\n\n_Verifique a fila de publicação no IG OS v3._`,
          }),
        }).catch(e => console.log("WhatsApp notify error (non-critical):", e));
      }
    }

    return new Response(JSON.stringify({ success: true, processed, failed, total: dueItems.length }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("scheduled-publish error:", error);
    return new Response(JSON.stringify({
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
