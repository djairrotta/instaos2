import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    let SESSION_ID = Deno.env.get("INSTAGRAM_SESSION_ID");

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    // Get params from body
    let user_id: string | null = null;
    let deepScan = false;
    let targetUsernames: string[] = [];
    let targetThreadIds: string[] = [];
    try {
      const body = await req.json();
      user_id = body.user_id || null;
      deepScan = body.deep_scan || false;
      targetUsernames = (body.target_usernames || []).map((u: string) => u.replace(/^@/, "").toLowerCase());
      targetThreadIds = (body.target_thread_ids || []).map((id: string) => id.toString());
    } catch { /* cron may send empty body */ }

    // If no user_id, get first user with allowed_senders configured
    if (!user_id) {
      const { data: sender } = await supabase
        .from("allowed_senders")
        .select("user_id")
        .limit(1)
        .single();
      user_id = sender?.user_id || null;
    }

    if (!user_id) throw new Error("No user_id found");

    // Check system_config for user-updated session ID (takes priority)
    const { data: configSession } = await supabase
      .from("system_config")
      .select("config_value")
      .eq("user_id", user_id)
      .eq("config_key", "instagram_session_id")
      .maybeSingle();

    if (configSession?.config_value) {
      SESSION_ID = configSession.config_value;
      console.log("📋 Using session ID from system_config");
    }

    if (!SESSION_ID) throw new Error("INSTAGRAM_SESSION_ID not configured");

    console.log(`📨 Polling Instagram DMs for user ${user_id}${deepScan ? ` (DEEP SCAN${targetUsernames.length ? ` for: ${targetUsernames.join(", ")}` : ""}${targetThreadIds.length ? ` threads: ${targetThreadIds.join(", ")}` : ""})` : ""}`);

    // Load deep scan settings from system_config
    let dsSettings = {
      max_inbox_pages: 15,
      max_thread_pages: 30,
      delay_between_pages_min: 3,
      delay_between_pages_max: 7,
      delay_between_threads_min: 2,
      delay_between_threads_max: 5,
      delay_between_links_min: 1,
      delay_between_links_max: 3,
      time_limit_seconds: 350,
    };
    if (deepScan) {
      const { data: dsConfig } = await supabase
        .from("system_config")
        .select("config_value")
        .eq("user_id", user_id)
        .eq("config_key", "deep_scan_settings")
        .maybeSingle();
      if (dsConfig?.config_value) {
        try {
          dsSettings = { ...dsSettings, ...JSON.parse(dsConfig.config_value) };
          console.log(`⚙️ Deep Scan settings loaded: pages=${dsSettings.max_inbox_pages}, threadPages=${dsSettings.max_thread_pages}, delays=${dsSettings.delay_between_pages_min}-${dsSettings.delay_between_pages_max}s`);
        } catch { /* use defaults */ }
      }
    }

    // Get poll state
    const { data: pollState } = await supabase
      .from("dm_poll_state")
      .select("*")
      .eq("user_id", user_id)
      .maybeSingle();

    const processedThreadIds: string[] = pollState?.processed_thread_ids || [];
    // For normal poll, only process messages newer than last poll
    const lastPollTimestamp = pollState?.last_poll_at ? Math.floor(new Date(pollState.last_poll_at).getTime() / 1000) : 0;

    // Deep scan resume: load saved cursor to continue from where we left off
    let deepScanResumeCursor: string | undefined;
    if (deepScan) {
      const { data: resumeData } = await supabase
        .from("system_config")
        .select("config_value")
        .eq("user_id", user_id)
        .eq("config_key", "deep_scan_cursor")
        .maybeSingle();
      if (resumeData?.config_value) {
        try {
          const parsed = JSON.parse(resumeData.config_value);
          deepScanResumeCursor = parsed.inbox_cursor;
          console.log(`🔄 Resuming deep scan from saved cursor (page ~${parsed.page || "?"})`);
        } catch { /* start fresh */ }
      }
    }

    // Helper to save incremental progress
    const saveProgress = async (ids: string[], cursor?: string, page?: number) => {
      const trimmedIds = ids.slice(deepScan ? -5000 : -500);
      await supabase.from("dm_poll_state").upsert({
        user_id,
        last_poll_at: new Date().toISOString(),
        processed_thread_ids: trimmedIds,
      }, { onConflict: "user_id" });
      // Save deep scan cursor for resume
      if (deepScan && cursor) {
        await supabase.from("system_config").upsert({
          user_id,
          config_key: "deep_scan_cursor",
          config_value: JSON.stringify({ inbox_cursor: cursor, page: page || 0, updated_at: new Date().toISOString() }),
        }, { onConflict: "user_id,config_key" });
      }
    };

    // Build cookie string - support both full cookie string and sessionid-only
    const cookieStr = SESSION_ID!.includes("=") 
      ? SESSION_ID!  // Full cookie string from browser
      : `sessionid=${SESSION_ID}`;  // Just sessionid value
    
    // Extract csrftoken from cookies if available
    const csrfMatch = cookieStr.match(/csrftoken=([^;]+)/);
    const csrfToken = csrfMatch ? csrfMatch[1] : "";

    // Extract ds_user_id from cookies if available  
    const dsUserMatch = cookieStr.match(/ds_user_id=([^;]+)/);
    const dsUserId = dsUserMatch ? dsUserMatch[1] : "";

    console.log(`🍪 Cookie format: ${SESSION_ID!.includes("=") ? "full string" : "sessionid only"}, csrftoken: ${csrfToken ? "present" : "missing"}, ds_user_id: ${dsUserId ? "present" : "missing"}`);

    // Helper: common IG headers
    const igHeaders = {
      "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
      "Cookie": cookieStr,
      "X-IG-App-ID": "936619743392459",
      "X-ASBD-ID": "129477",
      "X-IG-WWW-Claim": "0",
      "X-CSRFToken": csrfToken,
      "X-Requested-With": "XMLHttpRequest",
      "Accept": "*/*",
      "Sec-Fetch-Site": "same-origin",
      "Sec-Fetch-Mode": "cors",
      "Sec-Fetch-Dest": "empty",
      "Referer": "https://www.instagram.com/direct/inbox/",
    };

    // Helper: random delay to mimic human behavior
    const humanDelay = (minMs: number, maxMs: number) => 
      new Promise(r => setTimeout(r, minMs + Math.random() * (maxMs - minMs)));

    // Helper: retry-aware fetch for Instagram API (handles 429)
    const igFetch = async (url: string, retries = 3): Promise<Response> => {
      for (let attempt = 0; attempt < retries; attempt++) {
        const res = await fetch(url, { headers: igHeaders, redirect: "manual" });
        if (res.status === 429) {
          const waitSec = 30 + attempt * 30; // 30s, 60s, 90s
          console.warn(`⚠️ 429 Too Many Requests — waiting ${waitSec}s before retry ${attempt + 1}/${retries}`);
          await humanDelay(waitSec * 1000, waitSec * 1000 + 5000);
          continue;
        }
        return res;
      }
      throw new Error("Instagram retornou 429 (Too Many Requests) após múltiplas tentativas. Aguarde alguns minutos e tente novamente.");
    };

    // Helper to fetch inbox page
    const fetchInboxPage = async (cursor?: string) => {
      let url = "https://www.instagram.com/api/v1/direct_v2/inbox/?persistentBadging=true&folder=&limit=10&thread_message_limit=5";
      if (cursor) url += `&cursor=${encodeURIComponent(cursor)}`;
      const res = await igFetch(url);
      if (res.status >= 300 && res.status < 400) {
        throw new Error("Cookie expirado — o Instagram redirecionou para login. Atualize os cookies completos.");
      }
      if (!res.ok) {
        const errText = await res.text();
        if (res.status === 401 || res.status === 403) throw new Error("Session expired — please update cookies");
        if (errText.includes("checkpoint_required")) {
          const checkpointMatch = errText.match(/"checkpoint_url"\s*:\s*"([^"]+)"/);
          const checkpointUrl = checkpointMatch ? checkpointMatch[1].replace(/\\u0026/g, "&").replace(/\\\//g, "/") : null;
          throw new Error(`CHECKPOINT_REQUIRED: O Instagram está exigindo verificação de segurança na conta. ${checkpointUrl ? `Acesse: ${checkpointUrl}` : "Abra o Instagram no navegador e complete a verificação."} Depois tente novamente.`);
        }
        throw new Error(`Instagram API error: ${res.status} - ${errText.slice(0, 200)}`);
      }
      return await res.json();
    };

    // Helper to fetch messages in a thread
    // Normal poll: fetches the latest 20 messages to catch new ones beyond inbox preview
    // Deep scan: paginates through all messages
    // onBatch callback enables incremental processing during deep scan pagination
    const fetchThreadMessages = async (threadId: string, existingItems: any[], onBatch?: (items: any[]) => Promise<void>): Promise<any[]> => {
      const allItems: any[] = [];
      const seenIds = new Set<string>();

      // Always fetch thread detail to get latest messages (inbox preview only has ~5)
      await humanDelay(
        deepScan ? dsSettings.delay_between_threads_min * 1000 : 1000,
        deepScan ? dsSettings.delay_between_threads_max * 1000 : 2000
      );
      const initRes = await igFetch(`https://www.instagram.com/api/v1/direct_v2/threads/${threadId}/?limit=20`);
      if (initRes.ok) {
        const initData = await initRes.json();
        const thread = initData?.thread;
        if (thread) {
          const initialBatch: any[] = [];
          for (const item of (thread.items || [])) {
            if (!seenIds.has(item.item_id)) {
              allItems.push(item);
              seenIds.add(item.item_id);
              initialBatch.push(item);
            }
          }

          // Process initial batch incrementally during deep scan
          if (deepScan && onBatch && initialBatch.length > 0) {
            await onBatch(initialBatch);
          }

          // For deep scan, continue paginating
          if (deepScan) {
            let hasOlder = thread.has_older || false;
            let cursor = thread.oldest_cursor;
            let pageCount = 0;
            const MAX_THREAD_PAGES = dsSettings.max_thread_pages;

            console.log(`   📄 [DEEP] Starting thread pagination: ${allItems.length} initial msgs, has_older=${hasOlder}, cursor=${cursor ? "present" : "none"}, max_pages=${MAX_THREAD_PAGES}`);
            // Log initial item_types
            const initTypeCounts: Record<string, number> = {};
            for (const it of allItems) { const t = it.item_type || "unknown"; initTypeCounts[t] = (initTypeCounts[t] || 0) + 1; }
            console.log(`   📄 [DEEP] Initial item_types: ${JSON.stringify(initTypeCounts)}`);

            while (hasOlder && cursor && pageCount < MAX_THREAD_PAGES) {
              // Check time limit during pagination to save progress
              if (Date.now() - dmStartTime > DM_TIME_LIMIT_MS) {
                console.log(`   ⏱️ [DEEP] Time limit reached during pagination at page ${pageCount}`);
                break;
              }
              await humanDelay(dsSettings.delay_between_pages_min * 1000, dsSettings.delay_between_pages_max * 1000);
              const url = `https://www.instagram.com/api/v1/direct_v2/threads/${threadId}/?limit=20&cursor=${encodeURIComponent(cursor)}&direction=older`;
              const res = await igFetch(url);
              if (!res.ok) {
                console.log(`   ⚠️ [DEEP] Page ${pageCount + 1} failed: ${res.status}`);
                break;
              }
              const data = await res.json();
              const threadData = data?.thread;
              if (!threadData) break;
              const items = threadData.items || [];
              if (items.length === 0) break;
              const pageBatch: any[] = [];
              for (const item of items) {
                if (!seenIds.has(item.item_id)) {
                  allItems.push(item);
                  seenIds.add(item.item_id);
                  pageBatch.push(item);
                }
              }

              // Process this page's items immediately
              if (onBatch && pageBatch.length > 0) {
                await onBatch(pageBatch);
              }

              hasOlder = threadData.has_older || false;
              cursor = threadData.oldest_cursor;
              pageCount++;
              if (pageCount % 10 === 0) {
                // Log progress + running item_type distribution
                const runTypeCounts: Record<string, number> = {};
                for (const it of allItems) { const t = it.item_type || "unknown"; runTypeCounts[t] = (runTypeCounts[t] || 0) + 1; }
                console.log(`   📄 [DEEP] Progress: ${allItems.length} msgs after ${pageCount} pages, types: ${JSON.stringify(runTypeCounts)}`);
                // Save progress periodically
                if (onBatch) {
                  await saveProgress(newProcessedIds);
                  console.log(`   💾 [DEEP] Progress saved at page ${pageCount}`);
                }
              }
            }
            console.log(`   📄 [DEEP] Done: ${allItems.length} total messages (${pageCount + 1} pages, hasOlder=${hasOlder})`);
          }
        }
      } else {
        // Fallback to inbox preview items
        for (const item of existingItems) {
          if (!seenIds.has(item.item_id)) {
            allItems.push(item);
            seenIds.add(item.item_id);
          }
        }
      }

      if (!deepScan && allItems.length > 0) {
        console.log(`   📄 Fetched ${allItems.length} recent messages for thread`);
      }

      return allItems;
    };

    // Check for cached thread_ids from previous scan (skip inbox pagination)
    if (deepScan && targetUsernames.length > 0 && targetThreadIds.length === 0) {
      const { data: cachedThreads } = await supabase.from("system_config")
        .select("config_value")
        .eq("user_id", user_id)
        .eq("config_key", "deep_scan_cached_threads")
        .maybeSingle();
      if (cachedThreads?.config_value) {
        try {
          const cached = JSON.parse(cachedThreads.config_value);
          // Only use cache if same target_usernames
          const cachedTargets = (cached.target_usernames || []).sort().join(",");
          const currentTargets = [...targetUsernames].sort().join(",");
          if (cachedTargets === currentTargets && cached.thread_ids?.length > 0) {
            targetThreadIds = cached.thread_ids;
            console.log(`⚡ Using cached thread_ids: ${targetThreadIds.join(", ")} (skipping inbox pagination)`);
          }
        } catch { /* ignore */ }
      }
    }

    // Fetch threads - by ID if provided, otherwise paginate inbox
    let allThreads: any[] = [];
    let cacheFallbackTriggered = false;
    const dmStartTime = Date.now();
    const DM_TIME_LIMIT_MS = deepScan ? dsSettings.time_limit_seconds * 1000 : 30000;

    const fetchInboxThreads = async (): Promise<any[]> => {
      const inboxThreads: any[] = [];
      const MAX_INBOX_PAGES = deepScan ? dsSettings.max_inbox_pages : 1;
      let inboxCursor: string | undefined = deepScanResumeCursor;

      for (let page = 0; page < MAX_INBOX_PAGES; page++) {
        if (deepScan && page > 0 && Date.now() - dmStartTime > DM_TIME_LIMIT_MS) {
          console.log("⏱️ Time limit reached during inbox pagination");
          break;
        }

        if (page > 0 || inboxCursor) {
          await humanDelay(dsSettings.delay_between_pages_min * 1000, dsSettings.delay_between_pages_max * 1000);
        }

        const inboxData = await fetchInboxPage(inboxCursor);
        const threads = inboxData?.inbox?.threads || [];
        inboxThreads.push(...threads);
        console.log(`📬 Page ${page + 1}: ${threads.length} threads (total: ${inboxThreads.length})`);

        if (!inboxData?.inbox?.has_older || !inboxData?.inbox?.oldest_cursor) break;
        inboxCursor = inboxData.inbox.oldest_cursor;

        if (deepScan) {
          await saveProgress(processedThreadIds, inboxCursor, page + 1);
        }
      }

      // If deep_scan with target usernames, filter threads and cache thread_ids
      if (deepScan && targetUsernames.length > 0) {
        const allInboxUsernames = new Set<string>();
        inboxThreads.forEach(thread => {
          (thread.users || []).forEach((u: any) => {
            if (u.username) allInboxUsernames.add(u.username.toLowerCase());
          });
        });
        console.log(`📋 All inbox usernames (${allInboxUsernames.size}): ${[...allInboxUsernames].join(", ")}`);
        console.log(`🎯 Looking for: ${targetUsernames.join(", ")}`);

        const filteredThreads = inboxThreads.filter(thread => {
          const threadUsers = (thread.users || []).map((u: any) => u.username?.toLowerCase());
          return targetUsernames.some(t => threadUsers.includes(t));
        });
        console.log(`🎯 Filtered to ${filteredThreads.length} threads matching`);

        // Cache found thread_ids so retries can skip inbox pagination
        if (filteredThreads.length > 0) {
          const foundThreadIds = filteredThreads.map(t => t.thread_id).filter(Boolean);
          await supabase.from("system_config").upsert({
            user_id,
            config_key: "deep_scan_cached_threads",
            config_value: JSON.stringify({
              target_usernames: targetUsernames,
              thread_ids: foundThreadIds,
              cached_at: new Date().toISOString()
            }),
          }, { onConflict: "user_id,config_key" });
          console.log(`💾 Cached ${foundThreadIds.length} thread_id(s) for retry: ${foundThreadIds.join(", ")}`);
        }

        return filteredThreads;
      }

      return inboxThreads;
    };

    if (targetThreadIds.length > 0) {
      // Fetch specific threads directly by ID — no inbox pagination needed
      console.log(`🎯 Fetching ${targetThreadIds.length} specific thread(s) by ID`);
      let failedThreadFetches = 0;

      for (const threadId of targetThreadIds) {
        await humanDelay(1000, 2000);
        const res = await igFetch(`https://www.instagram.com/api/v1/direct_v2/threads/${threadId}/?limit=20`);

        if (res.ok) {
          const data = await res.json();
          if (data?.thread) {
            allThreads.push(data.thread);
            const users = (data.thread.users || []).map((u: any) => u.username).join(", ");
            console.log(`✅ Thread ${threadId} loaded (users: ${users})`);
            continue;
          }
        }

        failedThreadFetches++;
        console.warn(`⚠️ Failed to fetch thread ${threadId}: ${res.status}`);
      }

      // If all cached thread IDs fail, fallback to inbox pagination and refresh cache
      if (allThreads.length === 0 && failedThreadFetches > 0) {
        console.warn("⚠️ All cached thread_ids failed. Falling back to inbox pagination...");
        cacheFallbackTriggered = true;

        await supabase.from("system_config").upsert({
          user_id,
          config_key: "deep_scan_cached_threads",
          config_value: JSON.stringify({
            target_usernames: targetUsernames,
            thread_ids: [],
            invalidated_at: new Date().toISOString(),
            reason: "all_cached_threads_failed"
          }),
        }, { onConflict: "user_id,config_key" });

        allThreads = await fetchInboxThreads();
      }
    } else {
      allThreads = await fetchInboxThreads();
    }

    console.log(`📬 Processing ${allThreads.length} threads`);

    // Load allowed senders
    const { data: allowedSenders } = await supabase
      .from("allowed_senders")
      .select("ig_username, is_active")
      .eq("user_id", user_id)
      .eq("is_active", true);

    const allowedUsernames = new Set(
      (allowedSenders || []).map((s: any) => s.ig_username.toLowerCase())
    );

    // Load niche keywords for relevance filtering
    const { data: nicheConfig } = await supabase
      .from("system_config")
      .select("config_value")
      .eq("user_id", user_id)
      .eq("config_key", "niche_keywords")
      .maybeSingle();

    const nicheKeywords: string[] = nicheConfig?.config_value
      ? nicheConfig.config_value.split(",").map((k: string) => k.trim().toLowerCase())
      : [];

    console.log(`🏷️ Niche keywords: ${nicheKeywords.length > 0 ? nicheKeywords.join(", ") : "none (all content accepted)"}`);


    let totalProcessed = 0;
    let totalLinks = 0;
    const newProcessedIds: string[] = [...processedThreadIds];
    const results: any[] = [];

    // Pre-load existing URLs to avoid expensive HTTP calls for already_exists
    const { data: existingReels } = await supabase
      .from("reels_competidores")
      .select("url")
      .eq("user_id", user_id);
    // Extract shortcodes for comparison (URLs may differ: /reel/X vs /p/X)
    const extractShortcode = (url: string) => {
      const match = url.match(/\/(p|reel|tv)\/([^/?]+)/);
      return match ? match[2] : url;
    };
    const existingCodes = new Set((existingReels || []).map((r: any) => extractShortcode(r.url || "")).filter(Boolean));

    // Load processed content log (includes deleted items to prevent re-download)
    const { data: processedLog } = await supabase
      .from("processed_content_log")
      .select("shortcode")
      .eq("user_id", user_id);
    const processedCodes = new Set((processedLog || []).map((r: any) => r.shortcode).filter(Boolean));
    // Merge both sets
    for (const code of processedCodes) existingCodes.add(code);
    console.log(`📋 Known content: ${existingCodes.size} shortcodes (${processedCodes.size} from log)`);

    const { data: existingComps } = await supabase
      .from("competidores")
      .select("name")
      .eq("user_id", user_id);
    const existingCompNames = new Set((existingComps || []).map((c: any) => c.name?.toLowerCase()).filter(Boolean));

    // dmStartTime and DM_TIME_LIMIT_MS already declared above
    
    let stoppedEarly = false;

    // Helper to check if user requested stop
    const checkStopRequested = async (): Promise<boolean> => {
      if (!deepScan) return false;
      try {
        const { data } = await supabase.from("system_config")
          .select("config_value")
          .eq("user_id", user_id)
          .eq("config_key", "deep_scan_stop")
          .maybeSingle();
        return data?.config_value === "true";
      } catch { return false; }
    };

    let hitTimeLimit = false;
    // DEBUG counters
    let dbgSkippedProcessed = 0, dbgSkippedTimestamp = 0, dbgSkippedSender = 0;
    let dbgSkippedNoText = 0, dbgSkippedNoLinks = 0, dbgSkippedExisting = 0;
    // Global item_type distribution tracker
    const globalTypeCounts: Record<string, number> = {};
    let totalItemsScanned = 0;

    for (const thread of allThreads) {
      if (Date.now() - dmStartTime > DM_TIME_LIMIT_MS) {
        console.log("⏱️ DM time limit reached, moving to next phase...");
        hitTimeLimit = true;
        stoppedEarly = true;
        break;
      }
      // Check stop flag every thread
      if (deepScan && await checkStopRequested()) {
        console.log("🛑 Deep Scan stopped by user request");
        stoppedEarly = true;
        break;
      }
      const threadId = thread.thread_id;
      const threadUsers = (thread.users || []).map((u: any) => u.username?.toLowerCase()).filter(Boolean);

      // ========== ITEM PROCESSING FUNCTION (used both inline and as batch callback) ==========
      const processItems = async (items: any[]) => {
        for (const item of items) {
          const t = item.item_type || "unknown";
          globalTypeCounts[t] = (globalTypeCounts[t] || 0) + 1;
          totalItemsScanned++;

          const itemKey = `${threadId}_${item.item_id}`;
          if (processedThreadIds.includes(itemKey)) {
            dbgSkippedProcessed++;
            continue;
          }

          // For normal poll, skip messages older than last poll timestamp
          if (!deepScan && lastPollTimestamp > 0) {
            const itemTimestamp = item.timestamp ? Math.floor(Number(item.timestamp) / 1000000) : 0;
            if (itemTimestamp > 0 && itemTimestamp < lastPollTimestamp) {
              dbgSkippedTimestamp++;
              newProcessedIds.push(itemKey);
              continue;
            }
          }

          const senderId = item.user_id?.toString();
          const senderUser = (thread.users || []).find((u: any) => u.pk?.toString() === senderId);
          const senderUsername = senderUser?.username?.toLowerCase() || "";

          const isSelf = thread.viewer_id?.toString() === senderId;
          // In deep scan, skip allowed_senders filter for target threads
          if (!deepScan && !isSelf && allowedUsernames.size > 0 && !allowedUsernames.has(senderUsername)) {
            dbgSkippedSender++;
            newProcessedIds.push(itemKey);
            continue;
          }

          let text = "";
          if (item.item_type === "text") {
            text = item.text || "";
          } else if (item.item_type === "link") {
            text = item.link?.text || "";
          } else if (item.item_type === "clip") {
            const clipUrl = item.clip?.clip?.code;
            if (clipUrl) text = `https://www.instagram.com/reel/${clipUrl}/`;
          } else if (item.item_type === "felix_share") {
            const videoCode = item.felix_share?.video?.code;
            if (videoCode) text = `https://www.instagram.com/p/${videoCode}/`;
          } else if (item.item_type === "media_share") {
            const postCode = item.media_share?.code;
            if (postCode) text = `https://www.instagram.com/p/${postCode}/`;
          } else if (item.item_type === "direct_media_share") {
            const postCode = item.direct_media_share?.code || item.direct_media_share?.media?.code;
            if (postCode) text = `https://www.instagram.com/p/${postCode}/`;
          } else if (item.item_type === "reel_share") {
            const reelCode = item.reel_share?.media?.code || item.reel_share?.code;
            if (reelCode) text = `https://www.instagram.com/reel/${reelCode}/`;
          } else if (item.item_type === "story_share") {
            const storyUrl = item.story_share?.media?.code;
            const storyUser = item.story_share?.media?.user?.username;
            if (storyUrl && storyUser) {
              text = `https://www.instagram.com/stories/${storyUser}/${item.story_share.media.pk}/`;
            }
          } else if (item.item_type === "xma" || item.item_type === "xma_media_share" || item.item_type === "xma_reel_share") {
            const xmaShare = item.xma_media_share;
            const xmaUrl = xmaShare?.preview_url || xmaShare?.target_url || "";
            const xmaText = item.text || "";
            const xmaShareData = item.xma_share_item_data;
            const xmaPreviewUrl = xmaShareData?.preview_url || xmaShareData?.target_url || "";
            
            if (xmaUrl && xmaUrl.includes("instagram.com")) {
              text = xmaUrl;
            } else if (xmaPreviewUrl && xmaPreviewUrl.includes("instagram.com")) {
              text = xmaPreviewUrl;
            } else if (xmaText && xmaText.includes("instagram.com")) {
              text = xmaText;
            }
            
            if (!text && Array.isArray(xmaShare)) {
              for (const xma of xmaShare) {
                const url = xma?.preview_url || xma?.target_url || "";
                if (url.includes("instagram.com")) { text = url; break; }
              }
            }
            
            if (!text) {
              const code = xmaShare?.code || item.clip?.clip?.code || xmaShareData?.code;
              if (code) text = `https://www.instagram.com/p/${code}/`;
            }
            
            if (!text) {
              const xmaField = item.xma;
              if (xmaField) {
                const xmaArr = Array.isArray(xmaField) ? xmaField : [xmaField];
                for (const x of xmaArr) {
                  const targetUrl = x?.target_url || x?.preview_url || x?.header_icon_url || "";
                  const previewUrl = x?.preview_url_info?.url || "";
                  const contentUrl = x?.content_url || "";
                  if (targetUrl.includes("instagram.com")) { text = targetUrl; break; }
                  if (previewUrl.includes("instagram.com")) { text = previewUrl; break; }
                  if (contentUrl.includes("instagram.com")) { text = contentUrl; break; }
                  const anyUrl = targetUrl || previewUrl || contentUrl;
                  if (anyUrl) {
                    const codeMatch = anyUrl.match(/\/(p|reel|tv)\/([^/?]+)/);
                    if (codeMatch) { text = `https://www.instagram.com/${codeMatch[1]}/${codeMatch[2]}/`; break; }
                  }
                }
              }
            }
          }

          // ========== UNIVERSAL FALLBACK: deep-scan any unhandled item for shortcodes ==========
          if (!text) {
            const itemJson = JSON.stringify(item);
            const codeMatches = itemJson.match(/\/(p|reel|tv)\/([a-zA-Z0-9_-]{6,})/g);
            if (codeMatches && codeMatches.length > 0) {
              const firstMatch = codeMatches[0].match(/\/(p|reel|tv)\/([a-zA-Z0-9_-]{6,})/);
              if (firstMatch) {
                text = `https://www.instagram.com/${firstMatch[1]}/${firstMatch[2]}/`;
                if (dbgSkippedNoText <= 3) {
                  console.log(`🔧 [FALLBACK] Recovered ${firstMatch[1]}/${firstMatch[2]} from item_type=${item.item_type}`);
                }
              }
            }
            if (!text) {
              const codeFieldMatch = itemJson.match(/"code"\s*:\s*"([a-zA-Z0-9_-]{6,})"/);
              if (codeFieldMatch) {
                text = `https://www.instagram.com/p/${codeFieldMatch[1]}/`;
                if (dbgSkippedNoText <= 3) {
                  console.log(`🔧 [FALLBACK-CODE] Recovered code=${codeFieldMatch[1]} from item_type=${item.item_type}`);
                }
              }
            }
          }

          if (!text) {
            dbgSkippedNoText++;
            if (dbgSkippedNoText <= 5) {
              const itemType = item.item_type || "unknown";
              const topKeys = Object.keys(item).filter(k => !["item_id","user_id","timestamp","client_context","show_forward_attribution","is_shh_mode","hide_in_thread"].includes(k)).join(",");
              const xmaField = item.xma;
              const xmaDetail = xmaField ? (Array.isArray(xmaField) ? xmaField.map((x: any, i: number) => `[${i}]keys=${Object.keys(x).join(",")},target=${(x.target_url||"").substring(0,120)},preview=${(x.preview_url||"").substring(0,120)},content=${(x.content_url||"").substring(0,120)},title=${(x.title_text||"").substring(0,60)},subtitle=${(x.subtitle_text||"").substring(0,60)}`).join(" | ") : `keys=${Object.keys(xmaField).join(",")},target=${(xmaField.target_url||"").substring(0,120)}`) : "no_xma_field";
              const mediaShare = item.media_share ? `code=${item.media_share.code},type=${item.media_share.media_type}` : "none";
              const directMedia = item.direct_media_share ? `code=${item.direct_media_share.code},type=${item.direct_media_share.media_type},keys=${Object.keys(item.direct_media_share).slice(0,10).join(",")}` : "none";
              const clipInfo = item.clip ? `code=${item.clip?.clip?.code}` : "none";
              console.log(`🔬 [UNHANDLED] type=${itemType}, keys=[${topKeys}], media_share=${mediaShare}, direct_media=${directMedia}, clip=${clipInfo}, xma=${xmaDetail}`);
            }
            newProcessedIds.push(itemKey);
            continue;
          }

          const links = extractInstagramLinks(text);
          if (links.length === 0) {
            dbgSkippedNoLinks++;
            newProcessedIds.push(itemKey);
            continue;
          }

          // Skip links that already exist in DB (fast local check)
          const newLinks = links.filter(l => {
            if (l.type === "profile") {
              const username = l.url.match(/instagram\.com\/([a-zA-Z0-9_.]+)/)?.[1]?.toLowerCase();
              return username ? !existingCompNames.has(username) : true;
            }
            const code = extractShortcode(l.url);
            return !existingCodes.has(code);
          });

          if (newLinks.length === 0) {
            dbgSkippedExisting++;
            newProcessedIds.push(itemKey);
            totalProcessed++;
            continue;
          }

          console.log(`🔗 Found ${newLinks.length} NEW link(s) from @${senderUsername}: ${newLinks.map(l => l.type).join(", ")}`);

          for (const link of newLinks) {
            await humanDelay(dsSettings.delay_between_links_min * 1000, dsSettings.delay_between_links_max * 1000);
            try {
              const processRes = await fetch(`${SUPABASE_URL}/functions/v1/process-instagram-link`, {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                  "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
                },
                body: JSON.stringify({
                  url: link.url,
                  type: link.type,
                  user_id,
                }),
              });

              const result = await processRes.json();
              results.push({ link: link.url, type: link.type, ...result });
              totalLinks++;
              console.log(`✅ Processed ${link.type}: ${result.action || "ok"}`);

              // Log processed content to prevent re-download even after deletion
              if (link.type !== "profile") {
                const code = extractShortcode(link.url);
                if (code) {
                  await supabase.from("processed_content_log").upsert({
                    user_id,
                    shortcode: code,
                    source_url: link.url,
                    content_type: link.type,
                  }, { onConflict: "user_id,shortcode" }).then(() => {
                    existingCodes.add(code);
                  });
                }
              }
            } catch (err) {
              console.error(`❌ Error processing ${link.url}:`, err);
              results.push({ link: link.url, type: link.type, error: String(err) });
            }
          }

          newProcessedIds.push(itemKey);
          totalProcessed++;
        }
      };

      // For deep scan: use incremental processing (onBatch callback)
      // For normal poll: process after fetching
      if (deepScan) {
        console.log(`🔍 [INCREMENTAL] Starting incremental processing for thread users=[${threadUsers.join(",")}]`);
        const items = await fetchThreadMessages(threadId, thread.items || [], processItems);
        console.log(`🔍 [INCREMENTAL] Thread done: ${items.length} total items, ${totalLinks} links found so far`);
      } else {
        const items = await fetchThreadMessages(threadId, thread.items || []);
        // DEBUG: log thread details
        const typeCounts: Record<string, number> = {};
        for (const it of items) {
          const t = it.item_type || "unknown";
          typeCounts[t] = (typeCounts[t] || 0) + 1;
        }
        console.log(`🔍 [TYPES] Thread users=[${threadUsers.join(",")}], ${items.length} items: ${JSON.stringify(typeCounts)}`);
        for (let di = 0; di < Math.min(5, items.length); di++) {
          const sample = items[di];
          const topKeys = Object.keys(sample).filter(k => !["item_id","user_id","timestamp","client_context","show_forward_attribution","is_shh_mode","hide_in_thread"].includes(k)).join(",");
          console.log(`🔍 [ITEM ${di}] type=${sample.item_type}, keys=[${topKeys}], text=${(sample.text || "").substring(0, 100)}`);
        }
        await processItems(items);
      }

      // Incremental save after each thread so data isn't lost on timeout
      if (deepScan && totalLinks > 0) {
        await saveProgress(newProcessedIds);
        console.log(`💾 Progress saved: ${totalProcessed} msgs, ${totalLinks} links`);
      }
    }

    // DEBUG summary
    console.log(`🔍 [DEBUG] Filter summary: processedId=${dbgSkippedProcessed}, timestamp=${dbgSkippedTimestamp}, sender=${dbgSkippedSender}, noText=${dbgSkippedNoText}, noLinks=${dbgSkippedNoLinks}, existing=${dbgSkippedExisting}`);
    console.log(`🔍 [DEBUG] lastPollTimestamp=${lastPollTimestamp}, allowedUsernames=[${[...allowedUsernames].join(",")}], processedThreadIds.length=${processedThreadIds.length}`);
    console.log(`📊 [ITEM_TYPE_SUMMARY] Total items scanned: ${totalItemsScanned}, Distribution: ${JSON.stringify(globalTypeCounts)}`);
    // Log percentage breakdown
    const sortedTypes = Object.entries(globalTypeCounts).sort((a, b) => b[1] - a[1]);
    for (const [type, count] of sortedTypes) {
      const pct = totalItemsScanned > 0 ? ((count / totalItemsScanned) * 100).toFixed(1) : "0";
      console.log(`   📊 ${type}: ${count} (${pct}%)`);
    }

    // Final save
    const trimmedIds = newProcessedIds.slice(deepScan ? -5000 : -500);
    await supabase.from("dm_poll_state").upsert({
      user_id,
      last_poll_at: new Date().toISOString(),
      processed_thread_ids: trimmedIds,
    }, { onConflict: "user_id" });

    // Clear deep scan cursor on successful completion (not stopped early)
    if (deepScan && !stoppedEarly) {
      await supabase.from("system_config").upsert({
        user_id,
        config_key: "deep_scan_cursor",
        config_value: JSON.stringify({ inbox_cursor: null, completed_at: new Date().toISOString() }),
      }, { onConflict: "user_id,config_key" });
      console.log("✅ Deep scan completed fully — cursor cleared");
    }

    console.log(`📊 Poll complete: ${totalProcessed} messages checked, ${totalLinks} NEW links processed`);

    // ========== AUTO-RETRY FLAG: signal to client that deep scan should continue ==========
    const autoRetryTriggered = deepScan && hitTimeLimit && !await checkStopRequested();
    if (autoRetryTriggered) {
      console.log("🔄 Deep scan hit time limit — signaling client for auto-retry");
    }

    // ========== AUTO-SCRAPE COMPETITOR PROFILES ==========
    let profilesScraped = 0;
    {
      try {
        console.log("👤 Checking for competitors missing profile data...");

        // Find competitors with no profile data (followers_count = 0 or null)
        const { data: incompleteComps } = await supabase
          .from("competidores")
          .select("id, name, page_url")
          .eq("user_id", user_id)
          .eq("status", true)
          .or("followers_count.is.null,followers_count.eq.0");

        for (const comp of (incompleteComps || [])) {
          try {
            console.log(`👤 Scraping profile for @${comp.name}...`);
            const profileRes = await fetch(`${SUPABASE_URL}/functions/v1/process-instagram-link`, {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
              },
              body: JSON.stringify({
                url: comp.page_url || `https://www.instagram.com/${comp.name}/`,
                type: "profile",
                user_id,
              }),
            });
            const profileData = await profileRes.json();
            if (profileData?.success !== false) {
              profilesScraped++;
              console.log(`✅ Profile scraped for @${comp.name}`);
            } else {
              console.warn(`⚠️ Profile scrape failed for @${comp.name}:`, profileData.error);
            }
          } catch (profErr) {
            console.error(`❌ Error scraping profile for @${comp.name}:`, profErr);
          }
        }

        if (profilesScraped > 0) {
          console.log(`👤 ${profilesScraped} competitor profiles updated`);
        }
      } catch (profileErr) {
        console.error("❌ Profile scraping error:", profileErr);
      }
    }

    // ========== AUTO-GENERATE IDEAS ==========
    let ideasGenerated = 0;
    if (totalLinks > 0) {
      try {
        console.log("💡 Auto-generating ideas based on new content...");

        // Gather context from DB for idea generation
        const { data: comps } = await supabase.from("competidores")
          .select("name, niche, bio, followers_count")
          .eq("user_id", user_id).eq("status", true).limit(10);

        const { data: reels } = await supabase.from("reels_competidores")
          .select("caption, hook_analysis, views, eng_rate, content_type, owner_username")
          .eq("user_id", user_id).order("created_at", { ascending: false }).limit(15);

        const { data: myReels } = await supabase.from("meus_reels")
          .select("caption, hook_analysis, views, eng_rate, content_type")
          .eq("user_id", user_id).order("views", { ascending: false }).limit(10);

        const { data: strats } = await supabase.from("estrategias")
          .select("title, key_takeaway")
          .eq("user_id", user_id).order("created_at", { ascending: false }).limit(3);

        let context = "Gere 5 ideias criativas de conteúdo para Instagram baseado nos seguintes dados:\n\n";
        if (comps?.length) {
          context += "COMPETIDORES:\n" + comps.map(c => `- @${c.name} (${c.niche || "sem nicho"}, ${c.followers_count || 0} seguidores): ${c.bio || ""}`).join("\n") + "\n\n";
        }
        if (reels?.length) {
          context += "CONTEÚDOS RECENTES DOS COMPETIDORES:\n" + reels.map(r => `- [${r.content_type}] @${r.owner_username}: ${(r.caption || "").slice(0, 80)} (${r.views || 0} views, eng: ${Number(r.eng_rate || 0).toFixed(1)}%)`).join("\n") + "\n\n";
        }
        if (myReels?.length) {
          context += "MEUS TOP CONTEÚDOS:\n" + myReels.map(r => `- [${r.content_type}] ${(r.caption || "").slice(0, 80)} (${r.views || 0} views, eng: ${Number(r.eng_rate || 0).toFixed(1)}%) Hook: ${(r.hook_analysis || "").slice(0, 60)}`).join("\n") + "\n\n";
        }
        if (strats?.length) {
          context += "ÚLTIMAS ESTRATÉGIAS:\n" + strats.map(s => `- ${s.title}: ${s.key_takeaway || ""}`).join("\n") + "\n\n";
        }
        context += `\nPara CADA ideia retorne em JSON array com objetos: { "title": "título curto", "description": "descrição de 2-3 frases", "format": "reel|post|carrossel|story", "hook": "gancho sugerido" }\nRetorne APENAS o JSON array, sem markdown.`;

        // Check for custom agent config
        const { data: agentCfg } = await supabase.from("agent_configs")
          .select("provider, model, custom_prompt")
          .eq("user_id", user_id).eq("agent_type", "idea_generator").maybeSingle();

        const genRes = await fetch(`${SUPABASE_URL}/functions/v1/generate-content`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
          },
          body: JSON.stringify({
            agent: "idea_generator",
            context,
            provider: agentCfg?.provider || "groq",
            model: agentCfg?.model || "llama-3.3-70b-versatile",
            custom_prompt: agentCfg?.custom_prompt || undefined,
          }),
        });

        const genData = await genRes.json();
        if (genData?.success && genData.result) {
          // Parse ideas and save to MinIO
          let newIdeas: any[] = [];
          try {
            const cleaned = genData.result.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
            const parsed = JSON.parse(cleaned);
            newIdeas = (Array.isArray(parsed) ? parsed : []).map((item: any, i: number) => ({
              id: `auto-${Date.now()}-${i}`,
              title: item.title || `Ideia ${i + 1}`,
              description: item.description || "",
              format: item.format || "reel",
              hook: item.hook || "",
              createdAt: new Date().toISOString(),
              source: "auto-dm",
            }));
          } catch {
            newIdeas = [{
              id: `auto-${Date.now()}`,
              title: "Ideia auto-gerada",
              description: genData.result.slice(0, 300),
              format: "reel",
              hook: "",
              createdAt: new Date().toISOString(),
              source: "auto-dm",
            }];
          }

          // Load existing ideas from MinIO and merge
          const ideasPath = `ideas/${user_id}/ideas.json`;
          let existingIdeas: any[] = [];
          try {
            const getRes = await fetch(`${SUPABASE_URL}/functions/v1/save-to-minio`, {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
              },
              body: JSON.stringify({ action: "get", path: ideasPath }),
            });
            const getData = await getRes.json();
            if (getData?.success && getData.content) {
              existingIdeas = JSON.parse(getData.content);
            }
          } catch { /* no existing ideas */ }

          const mergedIdeas = [...newIdeas, ...existingIdeas];

          // Save merged ideas to MinIO
          await fetch(`${SUPABASE_URL}/functions/v1/save-to-minio`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
            },
            body: JSON.stringify({ action: "save", path: ideasPath, data: mergedIdeas }),
          });

          ideasGenerated = newIdeas.length;
          console.log(`💡 ${ideasGenerated} ideias auto-geradas e salvas no MinIO`);
        }
      } catch (ideaErr) {
        console.error("❌ Erro na geração automática de ideias:", ideaErr);
      }
    }

    // ========== AUTO-CLASSIFY PENDING REELS ==========
    let reelsClassified = 0;
    {
      try {
        const { data: pendingReels } = await supabase
          .from("reels_competidores")
          .select("id")
          .eq("user_id", user_id)
          .eq("relevance_status", "pending")
          .order("created_at", { ascending: false })
          .limit(50);

        if (pendingReels?.length) {
          console.log(`🏷️ Classifying ${pendingReels.length} pending reels...`);
          // Process in parallel batches of 5 for speed
          for (let i = 0; i < pendingReels.length; i += 5) {
            const batch = pendingReels.slice(i, i + 5);
            const results = await Promise.allSettled(
              batch.map(reel => classifyRelevance(supabase, SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, reel.id, user_id!, nicheKeywords))
            );
            reelsClassified += results.filter(r => r.status === "fulfilled").length;
          }
          console.log(`🏷️ ${reelsClassified} reels classified`);
        }
      } catch (classErr) {
        console.error("❌ Classification error:", classErr);
      }
    }

    // ========== AUTO AI ANALYSIS ON NEW REELS ==========
    let reelsAnalyzed = 0;
    let strategyGenerated = false;
    {
      try {
        console.log("🤖 Running AI analysis on unanalyzed reels...");

        // Get reels that haven't been analyzed yet (any status)
        const { data: unanalyzedReels } = await supabase
          .from("reels_competidores")
          .select("id, caption, url, video_url, content_type, thumbnail_url, image_urls, owner_username, views, likes, comments, eng_rate")
          .eq("user_id", user_id)
          .is("hook_analysis", null)
          .order("created_at", { ascending: false })
          .limit(10);

        for (const reel of (unanalyzedReels || [])) {
          try {
            // Hook analysis from caption
            if (reel.caption) {
              const hookRes = await fetch(`${SUPABASE_URL}/functions/v1/analyze-content`, {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                  "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
                },
                body: JSON.stringify({
                  action: "hook_analysis",
                  content: reel.caption,
                  contentType: reel.content_type || "reel",
                }),
              });
              const hookData = await hookRes.json();
              if (hookData?.success && hookData.result) {
                await supabase.from("reels_competidores").update({
                  hook_analysis: hookData.result,
                }).eq("id", reel.id);
              }
            }

            // Viral analysis from caption + hook
            if (reel.caption) {
              const viralRes = await fetch(`${SUPABASE_URL}/functions/v1/analyze-content`, {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                  "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
                },
                body: JSON.stringify({
                  action: "viral_analysis",
                  content: reel.caption,
                  contentType: reel.content_type || "reel",
                }),
              });
              const viralData = await viralRes.json();
              if (viralData?.success && viralData.result) {
                const result = viralData.result;
                let viralPoints = "";
                let triggers = "";

                // Try JSON parse first (analyze-content returns JSON format)
                try {
                  const parsed = JSON.parse(result);
                  viralPoints = parsed.viral_points || "";
                  triggers = parsed.psychological_triggers || "";
                } catch {
                  // Fallback: try regex extraction from text format
                  viralPoints = result.match(/PONTOS VIRAIS[:\s]*([\s\S]*?)(?=GATILHOS|$)/i)?.[1]?.trim() || result;
                  triggers = result.match(/GATILHOS[:\s]*([\s\S]*?)$/i)?.[1]?.trim() || "";
                }

                await supabase.from("reels_competidores").update({
                  viral_points: viralPoints,
                  psychological_triggers: triggers || null,
                }).eq("id", reel.id);
              }
            }

            reelsAnalyzed++;
            console.log(`✅ Analyzed reel ${reel.id} (@${reel.owner_username})`);
          } catch (analyzeErr) {
            console.error(`⚠️ Analysis failed for reel ${reel.id}:`, analyzeErr);
          }
        }

        console.log(`🤖 ${reelsAnalyzed} reels analyzed with AI`);

        // ========== AUTO STRATEGY REPORT ==========
        if (reelsAnalyzed > 0) {
          try {
            console.log("📊 Generating strategy report from analyzed content...");

            // Gather all approved reels for strategy
            const { data: approvedReels } = await supabase
              .from("reels_competidores")
              .select("caption, hook_analysis, views, likes, comments, eng_rate, content_type, owner_username, url, post_date, viral_points, psychological_triggers")
              .eq("user_id", user_id)
              .eq("relevance_status", "approved")
              .order("views", { ascending: false })
              .limit(20);

            const { data: myReelsForStrat } = await supabase
              .from("meus_reels")
              .select("caption, hook_analysis, views, likes, comments, eng_rate, content_type")
              .eq("user_id", user_id)
              .order("views", { ascending: false })
              .limit(10);

            // Get pipeline config for username
            const { data: pipeCfg } = await supabase
              .from("pipeline_config")
              .select("instagram_username")
              .eq("user_id", user_id)
              .maybeSingle();

            const username = pipeCfg?.instagram_username || "user";

            const myReelsContext = (myReelsForStrat || []).map((r: any, i: number) =>
              `${i+1}. [${r.content_type}] Views: ${r.views} | Eng: ${Number(r.eng_rate).toFixed(1)}% | Hook: ${(r.hook_analysis || "").slice(0, 100)} | Caption: ${(r.caption || "").slice(0, 100)}`
            ).join("\n");

            const compReelsContext = (approvedReels || []).map((r: any, i: number) =>
              `${i+1}. [${r.content_type}] @${r.owner_username} | Views: ${r.views} | Eng: ${Number(r.eng_rate).toFixed(1)}% | Hook: ${(r.hook_analysis || "").slice(0, 100)} | Caption: ${(r.caption || "").slice(0, 100)} | Pontos: ${(r.viral_points || "").slice(0, 80)}`
            ).join("\n");

            // Check for custom strategist agent
            const { data: stratAgent } = await supabase.from("agent_configs")
              .select("provider, model, custom_prompt")
              .eq("user_id", user_id).eq("agent_type", "content_strategist").maybeSingle();

            const stratRes = await fetch(`${SUPABASE_URL}/functions/v1/analyze-content`, {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
              },
              body: JSON.stringify({
                action: "strategy_report",
                content: myReelsContext || "Sem dados dos meus reels ainda",
                competitorReelsData: compReelsContext,
                username,
                model: stratAgent?.model || "google/gemini-2.5-flash",
                custom_prompt: stratAgent?.custom_prompt || undefined,
              }),
            });

            const stratData = await stratRes.json();
            if (stratData?.success && stratData.result) {
              // Parse strategy JSON
              let parsed: any = {};
              try {
                const cleaned = stratData.result.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
                parsed = JSON.parse(cleaned);
              } catch {
                parsed = { key_takeaway: stratData.result.slice(0, 500) };
              }

              // Insert into estrategias
              await supabase.from("estrategias").insert({
                user_id,
                title: `Estratégia Auto — ${new Date().toLocaleDateString("pt-BR")}`,
                key_takeaway: parsed.key_takeaway || null,
                top_videos: parsed.top_competitor_videos || null,
                winning_patterns: parsed.winning_patterns || null,
                hook_ideas: parsed.hook_ideas || null,
                raw_report: stratData.result,
              });

              strategyGenerated = true;
              console.log("📊 Strategy report auto-generated and saved!");
            }
          } catch (stratErr) {
            console.error("❌ Strategy generation failed:", stratErr);
          }
        }
      } catch (analysisErr) {
        console.error("❌ Auto-analysis error:", analysisErr);
      }
    }

    return new Response(JSON.stringify({
      success: true,
      messages_checked: totalProcessed,
      links_processed: totalLinks,
      profiles_scraped: profilesScraped,
      reels_classified: reelsClassified,
      ideas_generated: ideasGenerated,
      reels_analyzed: reelsAnalyzed,
      strategy_generated: strategyGenerated,
      stopped_early: stoppedEarly,
      auto_retry_triggered: autoRetryTriggered,
      cache_fallback: cacheFallbackTriggered,
      results,
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("poll-instagram-dms error:", error);
    return new Response(JSON.stringify({
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

// ========== Helpers ==========

interface InstagramLink {
  url: string;
  type: "profile" | "reel" | "post" | "story";
}

function extractInstagramLinks(text: string): InstagramLink[] {
  const links: InstagramLink[] = [];
  const urlRegex = /https?:\/\/(?:www\.)?instagram\.com\/[^\s)"\]]+/gi;
  const matches = text.match(urlRegex) || [];

  for (const url of matches) {
    const clean = url.replace(/[.,;!?)}\]]+$/, "");
    if (/\/reel\//i.test(clean)) {
      links.push({ url: clean, type: "reel" });
    } else if (/\/stories\//i.test(clean)) {
      links.push({ url: clean, type: "story" });
    } else if (/\/p\//i.test(clean)) {
      links.push({ url: clean, type: "post" });
    } else {
      const username = clean.match(/instagram\.com\/([a-zA-Z0-9_.]+)/);
      if (username && !["explore", "accounts", "direct", "reels"].includes(username[1])) {
        links.push({ url: clean, type: "profile" });
      }
    }
  }

  // Also check for @username mentions
  const mentionRegex = /@([a-zA-Z0-9_.]{1,30})/g;
  let match;
  while ((match = mentionRegex.exec(text)) !== null) {
    const username = match[1];
    if (!links.some(l => l.type === "profile" && l.url.includes(username))) {
      links.push({ url: `https://www.instagram.com/${username}/`, type: "profile" });
    }
  }

  return links;
}

// ========== Relevance Classification ==========

async function classifyRelevance(
  supabase: any,
  supabaseUrl: string,
  serviceRoleKey: string,
  reelId: string,
  userId: string,
  nicheKeywords: string[]
) {
  // Get the reel data
  const { data: reel } = await supabase
    .from("reels_competidores")
    .select("caption, owner_username, hook_analysis")
    .eq("id", reelId)
    .single();

  if (!reel) return;

  const caption = (reel.caption || "").toLowerCase();
  const hookAnalysis = (reel.hook_analysis || "").toLowerCase();
  const allText = `${caption} ${hookAnalysis} ${reel.owner_username || ""}`;

  // Step 1: Quick keyword check
  if (nicheKeywords.length > 0) {
    const keywordMatch = nicheKeywords.some(k => allText.includes(k));
    if (keywordMatch) {
      await supabase.from("reels_competidores").update({
        relevance_status: "approved",
        relevance_score: 80,
        relevance_reason: "Palavra-chave do nicho encontrada na caption",
      }).eq("id", reelId);
      console.log(`🏷️ Reel ${reelId} auto-approved by keyword match`);
      return;
    }
  }

  // Step 2: AI classification using agent config
  // Load relevance_classifier agent config
  const { data: classifierConfig } = await supabase
    .from("agent_configs")
    .select("provider, model, custom_prompt")
    .eq("user_id", userId)
    .eq("agent_type", "relevance_classifier")
    .maybeSingle();

  const provider = classifierConfig?.provider || "lovable";
  const model = classifierConfig?.model || "google/gemini-2.5-flash-lite";
  const customPrompt = classifierConfig?.custom_prompt || null;

  // Load user's niche context
  const { data: nicheContext } = await supabase
    .from("system_config")
    .select("config_value")
    .eq("user_id", userId)
    .eq("config_key", "niche_description")
    .maybeSingle();

  const nicheDesc = nicheContext?.config_value || "direito, advocacia, jurídico, leis, tribunal, justiça";

  const systemPrompt = customPrompt || `Você é um classificador de relevância de conteúdo. O usuário trabalha no nicho de: ${nicheDesc}. Palavras-chave do nicho: ${nicheKeywords.join(", ") || "direito, advocacia, jurídico, lei, tribunal, justiça, advogado, OAB, processo, contrato"}.

Analise a caption do conteúdo e retorne APENAS um JSON com:
{"relevant": true/false, "score": 0-100, "reason": "motivo curto em português"}

Se o conteúdo NÃO é relacionado ao nicho do usuário, retorne relevant=false.`;

  try {
    // Route to the correct provider
    let aiResBody: any = null;

    if (provider === "lovable") {
      const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
      if (!LOVABLE_API_KEY) {
        console.log(`⏳ Reel ${reelId} left as pending (no LOVABLE_API_KEY)`);
        return;
      }
      const aiRes = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: { "Authorization": `Bearer ${LOVABLE_API_KEY}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          model,
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: `Caption: ${(reel.caption || "").slice(0, 500)}\nAutor: @${reel.owner_username || "desconhecido"}` }
          ],
        }),
      });
      if (!aiRes.ok) { console.error(`AI classification failed: ${aiRes.status}`); return; }
      aiResBody = await aiRes.json();
    } else {
      // Use generate-content edge function for other providers
      const genRes = await fetch(`${supabaseUrl}/functions/v1/generate-content`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": `Bearer ${Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")}` },
        body: JSON.stringify({
          agent: "relevance_classifier",
          context: `Caption: ${(reel.caption || "").slice(0, 500)}\nAutor: @${reel.owner_username || "desconhecido"}`,
          provider,
          model,
          custom_prompt: systemPrompt,
        }),
      });
      const genData = await genRes.json();
      if (!genData?.success) { console.error(`AI classification failed via generate-content`); return; }
      // Wrap result to match expected format
      aiResBody = { choices: [{ message: { content: genData.result } }] };
    }

    const aiText = aiResBody?.choices?.[0]?.message?.content || "";

    // Parse JSON from AI response
    const jsonMatch = aiText.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      const status = parsed.relevant ? "approved" : "rejected";
      const score = Math.min(100, Math.max(0, parsed.score || 0));

      await supabase.from("reels_competidores").update({
        relevance_status: status,
        relevance_score: score,
        relevance_reason: parsed.reason || (parsed.relevant ? "Relevante ao nicho" : "Fora do nicho"),
      }).eq("id", reelId);

      console.log(`🏷️ Reel ${reelId} classified as ${status} (score: ${score}) - ${parsed.reason}`);
    }
  } catch (err) {
    console.error(`AI classification error:`, err);
  }
}
