import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const AI_GATEWAY = "https://ai.gateway.lovable.dev/v1/chat/completions";

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const body = await req.json();
    const { action, content, model, contentType, videoUrl, custom_prompt, custom_prompt_2, custom_prompt_3 } = body;
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY not configured");

    const aiModel = model || "google/gemini-2.5-flash";
    let systemPrompt = "";
    let userPrompt = "";

    if (action === "image_analysis") {
      const imageUrls: string[] = body.imageUrls || [];
      if (imageUrls.length === 0) throw new Error("imageUrls required for image_analysis");
      
      const contentTypeLabel = contentType === "carousel" ? "CARROSSEL" : "POST ESTÁTICO";
      console.log(`🖼️ Analyzing ${imageUrls.length} image(s) for ${contentTypeLabel}...`);
      
      const imageParts: any[] = [{ type: "text", text: `Analise ${contentType === "carousel" ? "este carrossel de " + imageUrls.length + " slides" : "esta imagem de post"} do Instagram.\\nCaption: ${content || "sem caption"}` }];
      
      for (const imgUrl of imageUrls.slice(0, 5)) {
        try {
          const imgRes = await fetch(imgUrl, {
            headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" },
          });
          if (!imgRes.ok) continue;
          const imgBuf = await imgRes.arrayBuffer();
          if (imgBuf.byteLength > 10 * 1024 * 1024) continue;
          const u8 = new Uint8Array(imgBuf);
          let bin = "";
          for (let i = 0; i < u8.length; i++) bin += String.fromCharCode(u8[i]);
          const b64 = btoa(bin);
          const mime = imgUrl.includes(".png") ? "image/png" : "image/jpeg";
          imageParts.push({ type: "image_url", image_url: { url: `data:${mime};base64,${b64}` } });
        } catch (e) {
          console.warn(`Failed to download image: ${e}`);
        }
      }
      
      if (imageParts.length <= 1) throw new Error("Could not download any images");
      
      let imageSystemPrompt = `**IDIOMA OBRIGATÓRIO: TODO O OUTPUT DEVE SER EM PORTUGUÊS BRASILEIRO (PT-BR).**

Você é um analista de conteúdo viral para Instagram ${contentTypeLabel}. Analise ${contentType === "carousel" ? "todos os slides do carrossel" : "a imagem do post"} em profundidade.

### SUA TAREFA:
1. **Texto na imagem**: Transcreva TODO o texto visível em cada ${contentType === "carousel" ? "slide" : "imagem"}
2. **Hook visual**: O que captura atenção imediatamente? ${contentType === "carousel" ? "Especialmente o 1º slide que aparece no feed" : ""}
3. **Elementos de design**: Cores, tipografia, layout, composição, branding
4. **Estrutura narrativa**: ${contentType === "carousel" ? "Fluxo entre slides, progressão da informação, CTA final" : "Hierarquia visual, ponto focal, direção do olhar"}
5. **Pontos virais**: O que torna visualmente compartilhável

### OUTPUT FORMAT:
**TEXTO NAS IMAGENS:**
[transcrição completa do texto em cada ${contentType === "carousel" ? "slide (Slide 1, Slide 2, etc.)" : "imagem"}]

**HOOK VISUAL:**
[análise do elemento que captura atenção primeiro]

**DESIGN E COMPOSIÇÃO:**
[cores, fontes, layout, qualidade visual]

**ESTRUTURA${contentType === "carousel" ? " DO CARROSSEL" : ""}:**
[${contentType === "carousel" ? "fluxo narrativo entre slides" : "hierarquia e composição"}]

**PONTOS VIRAIS:**
[análise do potencial viral visual]

**GATILHOS PSICOLÓGICOS:**
[quais gatilhos visuais são usados e como]`;

      // Apply custom prompts for image_analyzer agent
      if (custom_prompt?.trim()) {
        imageSystemPrompt = custom_prompt.trim();
      }
      const imgExtras: string[] = [];
      if (custom_prompt_2?.trim()) imgExtras.push(custom_prompt_2.trim());
      if (custom_prompt_3?.trim()) imgExtras.push(custom_prompt_3.trim());
      if (imgExtras.length > 0) {
        imageSystemPrompt = imageSystemPrompt + "\n\n---\n\n" + imgExtras.join("\n\n---\n\n");
      }

      const imgResponse = await fetch(AI_GATEWAY, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${LOVABLE_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: aiModel || "google/gemini-2.5-flash",
          messages: [
            { role: "system", content: imageSystemPrompt },
            { role: "user", content: imageParts },
          ],
        }),
      });

      if (!imgResponse.ok) {
        const errText = await imgResponse.text();
        console.error("Gemini image error:", imgResponse.status, errText);
        if (imgResponse.status === 429) {
          return new Response(JSON.stringify({ success: false, error: "Rate limit exceeded", fallback: true }), {
            status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        throw new Error(`Gemini image error: ${imgResponse.status}`);
      }

      const imgData = await imgResponse.json();
      const imgResult = imgData.choices?.[0]?.message?.content || "";
      console.log(`✅ Gemini image analysis: ${imgResult.length} chars`);

      return new Response(JSON.stringify({ success: true, result: imgResult, method: "gemini_image" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });

    } else if (action === "video_analysis") {
      const actualVideoUrl = videoUrl || content;
      
      if (!actualVideoUrl) throw new Error("videoUrl is required for video_analysis");
      
      console.log(`📹 Downloading video for Gemini analysis: ${actualVideoUrl.slice(0, 80)}...`);
      const videoResponse = await fetch(actualVideoUrl, {
        headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" },
      });
      if (!videoResponse.ok) throw new Error(`Failed to download video: ${videoResponse.status}`);
      
      const videoBuffer = await videoResponse.arrayBuffer();
      const videoSizeMB = (videoBuffer.byteLength / (1024 * 1024)).toFixed(2);
      console.log(`📦 Video: ${videoSizeMB}MB`);
      
      if (videoBuffer.byteLength > 20 * 1024 * 1024) {
        return new Response(JSON.stringify({ success: false, error: "Video too large (>20MB)", fallback: true }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      
      const uint8 = new Uint8Array(videoBuffer);
      let binary = "";
      for (let i = 0; i < uint8.length; i++) binary += String.fromCharCode(uint8[i]);
      const base64Video = btoa(binary);
      
      // Video transcription prompt - supports custom prompts from video_transcriber agent
      let videoSystemPrompt = `**IDIOMA OBRIGATÓRIO: TODO O OUTPUT DEVE SER EM PORTUGUÊS BRASILEIRO (PT-BR).**

You are a Video Script Breakdown Agent.  
Your task: Transcribe the raw video into a clean script.  

### OUTPUT FORMAT RULES  
- Include any notable visual elements.
- Maximum length: **2000 characters**. 
- No timestamps, no conversational commentary. Output only the final script.

### ⚠️ IDIOMA - REGRAS IMPORTANTES
**OBRIGATÓRIO - Português Brasileiro (PT-BR):**
- Todos os títulos de seções (ex: "Top Competitor Videos" → "Vídeos Top dos Concorrentes")
- Todas as análises e explicações (ex: "Why it worked" → "Por que funcionou")
- Todos os insights e recomendações
- Labels como "Hook:", "Power Words:" → "Gancho:", "Palavras-Chave:"

**MANTER NO IDIOMA ORIGINAL:**
- Transcrições de áudio/diálogo dos vídeos
- Hooks citados diretamente do vídeo (entre aspas ou backticks)
- @usernames e URLs`;

      // Apply custom prompts for video_transcriber agent
      if (custom_prompt?.trim()) {
        videoSystemPrompt = custom_prompt.trim();
      }
      const vidExtras: string[] = [];
      if (custom_prompt_2?.trim()) vidExtras.push(custom_prompt_2.trim());
      if (custom_prompt_3?.trim()) vidExtras.push(custom_prompt_3.trim());
      if (vidExtras.length > 0) {
        videoSystemPrompt = videoSystemPrompt + "\n\n---\n\n" + vidExtras.join("\n\n---\n\n");
      }

      const geminiResponse = await fetch(AI_GATEWAY, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${LOVABLE_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: aiModel || "google/gemini-2.5-flash",
          messages: [
            { role: "system", content: videoSystemPrompt },
            { 
              role: "user", 
              content: [
                { type: "text", text: `Analise este vídeo do Instagram em detalhe. Caption do post: ${content || "sem caption"}` },
                { 
                  type: "image_url", 
                  image_url: { 
                    url: `data:video/mp4;base64,${base64Video}` 
                  } 
                }
              ]
            },
          ],
        }),
      });

      if (!geminiResponse.ok) {
        const errText = await geminiResponse.text();
        console.error("Gemini video error:", geminiResponse.status, errText);
        if (geminiResponse.status === 429) {
          return new Response(JSON.stringify({ success: false, error: "Rate limit exceeded", fallback: true }), {
            status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        throw new Error(`Gemini video error: ${geminiResponse.status}`);
      }

      const geminiData = await geminiResponse.json();
      const videoResult = geminiData.choices?.[0]?.message?.content || "";
      console.log(`✅ Gemini video analysis: ${videoResult.length} chars`);

      return new Response(JSON.stringify({ success: true, result: videoResult, method: "gemini_video" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });

    } else if (action === "transcribe") {
      const typeContext = contentType === "carousel"
        ? "This is an Instagram CAROUSEL post (multiple slides)."
        : contentType === "post"
        ? "This is a static Instagram IMAGE post."
        : "This is an Instagram REEL (short video).";

      // Professor's exact transcription prompt
      systemPrompt = `**IDIOMA OBRIGATÓRIO: TODO O OUTPUT DEVE SER EM PORTUGUÊS BRASILEIRO (PT-BR).**

You are a Video Script Breakdown Agent.  
Your task: Transcribe the raw video into a clean script.  
${typeContext}

### OUTPUT FORMAT RULES  
- Include any notable visual elements.
- Maximum length: **2000 characters**. 
- No timestamps, no conversational commentary. Output only the final script.

### ⚠️ IDIOMA - REGRAS IMPORTANTES
**OBRIGATÓRIO - Português Brasileiro (PT-BR):**
- Todos os títulos de seções
- Todas as análises e explicações
- Todos os insights e recomendações
- Labels como "Hook:", "Power Words:" → "Gancho:", "Palavras-Chave:"

**MANTER NO IDIOMA ORIGINAL:**
- Transcrições de áudio/diálogo dos vídeos
- Hooks citados diretamente (entre aspas ou backticks)
- @usernames e URLs`;
      userPrompt = `Content type: ${contentType || "reel"}\\nContent to analyze:\\n${content}`;

    } else if (action === "hook_analysis") {
      // Professor's exact hook analyzer prompt
      systemPrompt = `# Overview
You are an AI agent that acts as an expert Instagram strategist and hook analyzer.

## Your Goal
Your task is to analyze the provided transcript and extract the hook. The hook is usually the first sentence or the first element of the video script that catches the viewer's attention. Most of the time it's a verbal hook, but there are visual hooks sometimes too. Extract the hook and also extract 1 to 3 power words/phrases from the hook that are likely contributing to its strong performance. These power words should stand out because they create curiosity, offer value, and appeal to the viewer's emotions or goals.

## Strict Output Format:
[the hook of the video]

Power Words: [1-3 most significant words/phrases in the first sentence]`;
      userPrompt = `Transcript:\\n${content}`;

    } else if (action === "profile_analysis") {
      const profileData = body.profileData || {};
      const reelsData = body.reelsData || [];
      
      systemPrompt = `**IDIOMA OBRIGATÓRIO: TODO O OUTPUT DEVE SER EM PORTUGUÊS BRASILEIRO (PT-BR).**

Você é um agente de IA especialista em análise competitiva de perfis do Instagram.
Analise o perfil do competidor e seus conteúdos recentes para gerar insights estratégicos.

### SUA TAREFA:
Gere uma análise completa em JSON com as seguintes seções:

{
  "score_geral": 0-100,
  "resumo": "Resumo executivo em 2-3 frases sobre a estratégia do perfil",
  "pontos_fortes": ["lista de 3-5 pontos fortes identificados"],
  "pontos_fracos": ["lista de 2-3 oportunidades de melhoria"],
  "metricas": {
    "engajamento_medio": 0,
    "melhor_tipo_conteudo": "reel|post|carousel",
    "frequencia_ideal": "X posts/semana",
    "melhor_horario": "estimativa baseada nos dados",
    "crescimento_estimado": "análise qualitativa"
  },
  "estrategia_conteudo": {
    "pilares": ["lista de 2-4 pilares de conteúdo identificados"],
    "tom_voz": "descrição do tom de voz usado",
    "publico_alvo": "estimativa do público-alvo baseada no conteúdo",
    "diferencial": "o que diferencia este perfil"
  },
  "recomendacoes": ["lista de 3-5 ações concretas para competir com este perfil"],
  "top_conteudos": [{"caption_resumo": "", "tipo": "", "engajamento": 0, "por_que_funcionou": ""}]
}

Output valid JSON only. No markdown, no code blocks.`;
      
      const profileSummary = `
PERFIL: @${profileData.name || "unknown"}
Bio: ${profileData.bio || "N/A"}
Seguidores: ${profileData.followersCount || 0}
Seguindo: ${profileData.followingCount || 0}
Posts: ${profileData.postsCount || 0}
Tipo predominante: ${profileData.predominantContentType || "N/A"}
Posts/semana: ${profileData.avgPostsPerWeek || "N/A"}

CONTEÚDOS RECENTES (${reelsData.length} itens):
${reelsData.slice(0, 15).map((r: any, i: number) => 
  `${i+1}. [${r.content_type || r.contentType || "reel"}] Views: ${r.views || 0} | Likes: ${r.likes || 0} | Comments: ${r.comments || 0} | Eng: ${r.eng_rate || r.engRate || 0}% | Caption: ${(r.caption || "").slice(0, 100)}`
).join("\\n")}`;
      
      userPrompt = profileSummary;

    } else if (action === "strategy_report") {
      // Professor's exact strategy report prompt (Estrategista de Conteúdo)
      const username = body.username || "user";
      
      systemPrompt = `**IDIOMA OBRIGATÓRIO: TODO O OUTPUT DEVE SER EM PORTUGUÊS BRASILEIRO (PT-BR).**

You're a content strategist analyzing competitor performance and translating insights into an Instagram research report for @${username}.

**CONTEXT:**
- MY REELS: @${username}'s top performing content.
- COMPETITOR REELS: Top performing content from competitors and the broader space.

**TASK:** Analyze all of the data and create a strategic report in JSON format.

**CONTENT REQUIREMENTS:**
- Top videos ranked by view count (5 total): Focus on psychological triggers and execution, not just surface-level description
- Patterns (3 patterns): Must be directly replicable for @${username}'s niche
- Hooks (10 total): Must combine (1) proven frameworks and patterns from competitors, (2) specific context from MY REELS, (3) @${username}'s voice
- Key Takeaway: Must include concrete next steps, not just philosophy

**ANALYSIS DEPTH:**
Be conversational but precise in all text fields. Focus on strategic insights with specific examples. Each explanation should be substantive and actionable.

**OUTPUT STRUCTURE (JSON):**

{
  "top_competitor_videos": [
    {
      "rank": 1,
      "hook": "Hook text here",
      "url": "https://...",
      "views": 000000,
      "posted_date": "YYYY-MM-DD",
      "creator": "@username",
      "why_it_worked": "Explanation here"
    }
  ],
  "winning_patterns": [
    {
      "pattern_name": "Pattern Name",
      "explanation": "Full explanation"
    }
  ],
  "hook_ideas": [
    {
      "hook": "Hook text exactly as spoken",
      "why_it_works": "Explanation here"
    }
  ],
  "key_takeaway": "Single paragraph summarizing the most important insights and actionable next steps"
}

Output valid JSON only. No markdown, no code blocks, just the raw JSON object.

### ⚠️ IDIOMA - REGRAS IMPORTANTES
**OBRIGATÓRIO - Português Brasileiro (PT-BR):**
- Todos os títulos de seções (ex: "Top Competitor Videos" → "Vídeos Top dos Concorrentes")
- Todas as análises e explicações (ex: "Why it worked" → "Por que funcionou")
- Todos os insights e recomendações
- Labels como "Hook:", "Power Words:" → "Gancho:", "Palavras-Chave:"

**MANTER NO IDIOMA ORIGINAL:**
- Transcrições de áudio/diálogo dos vídeos
- Hooks citados diretamente do vídeo (entre aspas ou backticks)
- @usernames e URLs`;

      userPrompt = `# MY REELS:\\n${body.myReelsData || content}\\n\\n# COMPETITOR REELS:\\n${body.competitorReelsData || ""}`;

    } else if (action === "viral_analysis") {
      // Extracts viral points and psychological triggers from transcript/analysis
      systemPrompt = `**IDIOMA OBRIGATÓRIO: TODO O OUTPUT DEVE SER EM PORTUGUÊS BRASILEIRO (PT-BR).**

Você é um especialista em psicologia de conteúdo viral para Instagram.

### SUA TAREFA:
Analise o conteúdo fornecido (transcrição, hook, caption) e extraia:
1. **Pontos Virais**: Os elementos específicos que tornam este conteúdo compartilhável e engajador
2. **Gatilhos Psicológicos**: Quais mecanismos psicológicos são usados para capturar e manter atenção

### OUTPUT FORMAT (JSON):
{
  "viral_points": "• [ponto viral 1]\\n• [ponto viral 2]\\n• [ponto viral 3]\\n...",
  "psychological_triggers": "• [gatilho 1]: [explicação curta]\\n• [gatilho 2]: [explicação curta]\\n• [gatilho 3]: [explicação curta]\\n..."
}

### GATILHOS COMUNS A IDENTIFICAR:
- Curiosidade (loop aberto, suspense)
- Urgência/Escassez (FOMO, limitação)
- Prova Social (números, autoridade)
- Identificação (dor compartilhada, "eu também")
- Contraste/Surpresa (antes/depois, expectativa quebrada)
- Reciprocidade (valor gratuito)
- Storytelling (narrativa envolvente)
- Polêmica/Controvérsia (opinião forte)
- Aspiração (resultado desejado)
- Simplicidade (hack, atalho, "fácil")

Analise profundamente e seja específico sobre COMO cada elemento é usado neste conteúdo.
Output valid JSON only. No markdown, no code blocks.`;
      
      const transcript = body.transcript || "";
      const hookAnalysis = body.hookAnalysis || "";
      const caption = body.caption || content || "";
      const cType = contentType || "reel";
      
      userPrompt = `Tipo de conteúdo: ${cType}\n\nCaption: ${caption}\n\nTranscrição/Análise:\n${transcript}\n\nAnálise de Hook:\n${hookAnalysis}`;

    } else {
      throw new Error(`Unknown action: ${action}`);
    }

    console.log(`AI request: action=${action}, model=${aiModel}, contentType=${contentType || "n/a"}, hasCustomPrompt=${!!custom_prompt?.trim()}`);

    // Apply custom prompts if provided
    let finalSystemPrompt = systemPrompt;
    if (custom_prompt?.trim()) {
      finalSystemPrompt = custom_prompt.trim();
    }
    const extras: string[] = [];
    if (custom_prompt_2?.trim()) extras.push(custom_prompt_2.trim());
    if (custom_prompt_3?.trim()) extras.push(custom_prompt_3.trim());
    if (extras.length > 0) {
      finalSystemPrompt = finalSystemPrompt + "\n\n---\n\n" + extras.join("\n\n---\n\n");
    }

    const response = await fetch(AI_GATEWAY, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: aiModel,
        messages: [
          { role: "system", content: finalSystemPrompt },
          { role: "user", content: userPrompt },
        ],
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ success: false, error: "Rate limit exceeded. Try again later." }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ success: false, error: "Credits exhausted. Add credits in Settings." }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const errText = await response.text();
      console.error("AI gateway error:", response.status, errText);
      throw new Error(`AI gateway error: ${response.status}`);
    }

    const aiData = await response.json();
    const result = aiData.choices?.[0]?.message?.content || "";

    console.log(`AI response received (${result.length} chars)`);

    return new Response(JSON.stringify({ success: true, result }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("analyze-content error:", error);
    return new Response(JSON.stringify({ success: false, error: error instanceof Error ? error.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
