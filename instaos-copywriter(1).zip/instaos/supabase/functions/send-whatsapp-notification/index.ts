import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const body = await req.json();
    const { action, userId, message, phoneNumber } = body;

    if (action === "test") {
      // Test connection with Evolution API
      const { data: keys } = await supabase
        .from("user_api_keys")
        .select("*")
        .eq("user_id", userId)
        .in("provider", ["evolution_api_url", "evolution_api_key", "whatsapp_notify_number"])
        .eq("is_active", true);

      const apiUrl = keys?.find(k => k.provider === "evolution_api_url")?.api_key;
      const apiKey = keys?.find(k => k.provider === "evolution_api_key")?.api_key;
      const number = keys?.find(k => k.provider === "whatsapp_notify_number")?.api_key;

      if (!apiUrl || !apiKey) {
        return new Response(JSON.stringify({
          success: false,
          error: "Evolution API URL e API Key não configuradas. Configure no menu Integrações > Mensageria.",
        }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      // Try to fetch instances to test connection
      try {
        const res = await fetch(`${apiUrl.replace(/\/$/, "")}/instance/fetchInstances`, {
          headers: { apikey: apiKey },
        });
        const data = await res.json();
        return new Response(JSON.stringify({
          success: true,
          instances: Array.isArray(data) ? data.length : 0,
          notifyNumber: number || "Não configurado",
        }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
      } catch (e) {
        return new Response(JSON.stringify({
          success: false,
          error: `Falha ao conectar: ${e instanceof Error ? e.message : "Erro desconhecido"}`,
        }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
    }

    if (action === "notify") {
      // Send a WhatsApp notification
      const { data: keys } = await supabase
        .from("user_api_keys")
        .select("*")
        .eq("user_id", userId)
        .in("provider", ["evolution_api_url", "evolution_api_key", "whatsapp_notify_number"])
        .eq("is_active", true);

      const apiUrl = keys?.find(k => k.provider === "evolution_api_url")?.api_key;
      const apiKey = keys?.find(k => k.provider === "evolution_api_key")?.api_key;
      const notifyNumber = phoneNumber || keys?.find(k => k.provider === "whatsapp_notify_number")?.api_key;

      if (!apiUrl || !apiKey || !notifyNumber) {
        console.log("⚠️ WhatsApp notification skipped: missing config for user", userId);
        return new Response(JSON.stringify({
          success: false,
          error: "WhatsApp não configurado",
          skipped: true,
        }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      // Get first available instance
      const instancesRes = await fetch(`${apiUrl.replace(/\/$/, "")}/instance/fetchInstances`, {
        headers: { apikey: apiKey },
      });
      const instances = await instancesRes.json();
      const instance = Array.isArray(instances) && instances.length > 0
        ? instances[0]?.instance?.instanceName || instances[0]?.instanceName
        : null;

      if (!instance) {
        console.log("⚠️ No Evolution API instance found");
        return new Response(JSON.stringify({
          success: false,
          error: "Nenhuma instância Evolution API encontrada",
        }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      // Clean phone number (remove non-digits)
      const cleanNumber = notifyNumber.replace(/\D/g, "");

      // Send text message
      const sendRes = await fetch(`${apiUrl.replace(/\/$/, "")}/message/sendText/${instance}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          apikey: apiKey,
        },
        body: JSON.stringify({
          number: cleanNumber,
          text: message,
        }),
      });

      const sendData = await sendRes.json();

      if (sendRes.ok) {
        console.log(`✅ WhatsApp notification sent to ${cleanNumber}`);
        return new Response(JSON.stringify({ success: true }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      } else {
        console.error("❌ WhatsApp send failed:", sendData);
        return new Response(JSON.stringify({
          success: false,
          error: sendData?.message || "Falha ao enviar mensagem",
        }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
    }

    throw new Error(`Unknown action: ${action}`);
  } catch (error) {
    console.error("send-whatsapp-notification error:", error);
    return new Response(JSON.stringify({
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
