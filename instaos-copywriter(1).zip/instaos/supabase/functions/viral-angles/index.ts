import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: cors });

  try {
    const SUPABASE_URL  = Deno.env.get("SUPABASE_URL")!;
    const SERVICE_KEY   = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase      = createClient(SUPABASE_URL, SERVICE_KEY);

    const authHeader = req.headers.get("Authorization") || "";
    const { data: { user } } = await supabase.auth.getUser(authHeader.replace("Bearer ", ""));
    if (!user) throw new Error("Auth required");

    const body = await req.json();
    const { action = "generate" } = body;

    // ── GENERATE 5 ANGLES ──────────────────────────────────────────────────
    if (action === "generate") {
      const {
        reelId, caption = "", hookAnalysis = "", transcript = "",
        viralPoints = [], contentType = "reel",
        ownerUsername = "", views = 0, likes = 0,
        profileName = "@djairrotta",
        profileNiche = "Advogado especialista em direito bancário",
        toneOfVoice = "",
        sherlockContext = "",       // from sherlock consolidated
        bestPracticesContext = "",  // injected best practices
      } = body;

      // Load tone of voice from DB if not provided
      let resolvedTone = toneOfVoice;
      if (!resolvedTone) {
        const { data: tov } = await supabase
          .from("tone_of_voice")
          .select("*")
          .eq("user_id", user.id)
          .eq("is_active", true)
          .maybeSingle();
        if (tov) {
          resolvedTone = `Tom aprovado: ${tov.approved_style}\nVocabulário: ${tov.vocabulary_use}\nEvitar: ${tov.vocabulary_avoid}`;
        }
      }

      // Load sherlock context from squad memory
      let resolvedSherlock = sherlockContext;
      if (!resolvedSherlock) {
        const { data: mem } = await supabase
          .from("squad_memory")
          .select("value")
          .eq("user_id", user.id)
          .eq("squad_name", "instaos-viral-factory")
          .eq("key", "sherlock_consolidated")
          .maybeSingle();
        if (mem?.value) resolvedSherlock = mem.value.consolidated || "";
      }

      // Load approved angles from memory to avoid repetition
      const { data: mem2 } = await supabase
        .from("squad_memory")
        .select("value")
        .eq("user_id", user.id)
        .eq("squad_name", "instaos-viral-factory")
        .eq("key", "approved_angles_history")
        .maybeSingle();
      const approvedHistory = mem2?.value?.angles || [];
      const recentAngles = approvedHistory.slice(-6).map((a: any) => a.type).join(", ");

      const prompt = `Você é Carlos Carrossel — Estrategista de Ângulos Virais para Instagram.

PERFIL DESTINO: ${profileName}
NICHO: ${profileNiche}
${resolvedTone ? `TOM DE VOZ APROVADO:\n${resolvedTone}` : ""}
${resolvedSherlock ? `CONTEXTO DE REFERÊNCIA (análise de perfis reais):\n${resolvedSherlock.slice(0, 600)}` : ""}
${recentAngles ? `ÂNGULOS USADOS RECENTEMENTE (evitar repetir): ${recentAngles}` : ""}

CONTEÚDO A ADAPTAR:
Tipo: ${contentType} | Autor: @${ownerUsername} | ❤️${likes} 👁️${views}
Caption: ${caption.slice(0, 400)}
${hookAnalysis ? `Hook identificado: ${hookAnalysis.slice(0, 200)}` : ""}
${transcript ? `Transcrição: ${transcript.slice(0, 300)}` : ""}
${viralPoints.length ? `Pontos virais: ${viralPoints.slice(0, 3).join(" | ")}` : ""}

TAREFA: Gere EXATAMENTE 5 ângulos virais distintos. Cada ângulo é a MESMA essência contada com uma lente emocional diferente.

TIPOS DE ÂNGULO (use todos os 5 tipos, um diferente por ângulo):
- Revelador: "X% das pessoas não sabem que..." — surpresa + curiosidade
- Comparativo: "A diferença entre quem faz X e quem não faz" — FOMO + status  
- Pergunta Incômoda: "Por que você ainda acredita que...?" — dissonância cognitiva
- Tendência+Oportunidade: "Isso mudou em 18 meses. A maioria não percebeu." — urgência
- Passo a Passo: "São N passos. Você consegue hoje mesmo." — segurança + competência

Retorne SOMENTE JSON válido:
{
  "content_summary": "resumo do conteúdo de referência em 1 linha",
  "angles": [
    {
      "id": 1,
      "title": "Nome do ângulo (2-4 palavras)",
      "type": "Revelador|Comparativo|Pergunta Incômoda|Tendência+Oportunidade|Passo a Passo",
      "emotional_trigger": "SURPRESA|FOMO|DISSONÂNCIA|URGÊNCIA|SEGURANÇA",
      "hook_draft": "Texto completo do slide 1 (2-3 linhas, usando dado específico do conteúdo)",
      "slide_structure": [
        {"slide": 2, "theme": "Tema do slide 2"},
        {"slide": 3, "theme": "Tema do slide 3"},
        {"slide": 4, "theme": "Tema do slide 4"},
        {"slide": 5, "theme": "Reflexão ou insight"},
        {"slide": 6, "theme": "CTA específico"}
      ],
      "strength": "Por que esse ângulo funciona para ${profileNiche}",
      "weakness": "Risco ou limitação desse ângulo",
      "best_format": "carrossel|reel|post"
    }
  ],
  "recommended_angle": 1,
  "recommendation_reason": "Justificativa baseada no público-alvo e histórico de aprovações"
}`;

      const genRes = await fetch(`${SUPABASE_URL}/functions/v1/generate-content`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${SERVICE_KEY}` },
        body: JSON.stringify({
          agent: "viral_analyst",
          context: prompt,
          provider: "openrouter",
          model: "google/gemini-2.5-flash-preview-05-20",
          custom_prompt: "Retorne SOMENTE JSON válido sem markdown.",
        }),
      });
      const genData = await genRes.json();
      const raw = (genData.result || "").replace(/```json|```/g, "").trim();
      let angles: any;
      try { angles = JSON.parse(raw); }
      catch (_) { throw new Error("Failed to parse angles JSON: " + raw.slice(0, 200)); }

      // Save to DB
      const { data: saved, error: saveErr } = await supabase
        .from("viral_angles")
        .insert({
          user_id: user.id,
          source_reel_id: reelId || null,
          source_caption: caption.slice(0, 500),
          source_owner: ownerUsername,
          angles: angles.angles,
          content_summary: angles.content_summary,
          recommended_angle: angles.recommended_angle,
          recommendation_reason: angles.recommendation_reason,
          selected_angle: null,
          status: "pending_selection",
        })
        .select()
        .single();

      if (saveErr) throw saveErr;

      return new Response(JSON.stringify({
        success: true,
        anglesId: saved.id,
        angles: angles.angles,
        contentSummary: angles.content_summary,
        recommendedAngle: angles.recommended_angle,
        recommendationReason: angles.recommendation_reason,
      }), { headers: { ...cors, "Content-Type": "application/json" } });
    }

    // ── SELECT ANGLE ───────────────────────────────────────────────────────
    if (action === "select") {
      const { anglesId, selectedAngleId, userAdjustments = "" } = body;
      if (!anglesId || !selectedAngleId) throw new Error("anglesId and selectedAngleId required");

      const { data: anglesRow } = await supabase
        .from("viral_angles")
        .select("*")
        .eq("id", anglesId)
        .eq("user_id", user.id)
        .single();

      if (!anglesRow) throw new Error("Angles record not found");

      const selectedAngle = anglesRow.angles.find((a: any) => a.id === selectedAngleId);
      if (!selectedAngle) throw new Error("Angle not found");

      // Apply user adjustments if any
      if (userAdjustments) {
        selectedAngle.user_adjustments = userAdjustments;
        selectedAngle.hook_draft = `${selectedAngle.hook_draft}\n[Ajuste do usuário: ${userAdjustments}]`;
      }

      await supabase
        .from("viral_angles")
        .update({ selected_angle: selectedAngle, status: "selected" })
        .eq("id", anglesId);

      // Save to memory to avoid repeating
      const { data: mem } = await supabase
        .from("squad_memory")
        .select("value")
        .eq("user_id", user.id)
        .eq("squad_name", "instaos-viral-factory")
        .eq("key", "approved_angles_history")
        .maybeSingle();

      const history = mem?.value?.angles || [];
      history.push({
        type: selectedAngle.type,
        title: selectedAngle.title,
        selectedAt: new Date().toISOString(),
      });

      await supabase.from("squad_memory").upsert({
        user_id: user.id,
        squad_name: "instaos-viral-factory",
        key: "approved_angles_history",
        value: { angles: history.slice(-20) }, // keep last 20
      }, { onConflict: "user_id,squad_name,key" });

      return new Response(JSON.stringify({
        success: true,
        selectedAngle,
        message: `Ângulo "${selectedAngle.title}" selecionado — pronto para gerar conteúdo`,
      }), { headers: { ...cors, "Content-Type": "application/json" } });
    }

    // ── GET ANGLES HISTORY ─────────────────────────────────────────────────
    if (action === "history") {
      const { data } = await supabase
        .from("viral_angles")
        .select("id, content_summary, recommended_angle, selected_angle, status, created_at, source_owner")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(20);

      return new Response(JSON.stringify({ success: true, history: data || [] }), {
        headers: { ...cors, "Content-Type": "application/json" },
      });
    }

    // ── REGENERATE ANGLES ──────────────────────────────────────────────────
    if (action === "regenerate") {
      // Same as generate but marks previous as rejected
      const { anglesId } = body;
      if (anglesId) {
        await supabase.from("viral_angles").update({ status: "rejected" }).eq("id", anglesId);
      }
      // Fall through to generate with same params
      return new Response(JSON.stringify({
        success: true,
        message: "Call action=generate again to regenerate",
      }), { headers: { ...cors, "Content-Type": "application/json" } });
    }

    throw new Error(`Unknown action: ${action}`);

  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({ success: false, error: (e as Error).message }), {
      status: 500, headers: { ...cors, "Content-Type": "application/json" },
    });
  }
});
