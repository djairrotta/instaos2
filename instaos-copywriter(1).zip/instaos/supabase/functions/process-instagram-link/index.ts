import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { url, type, user_id } = await req.json();
    if (!url || !type || !user_id) throw new Error("url, type, and user_id are required");

    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const APIFY_API_KEY = Deno.env.get("APIFY_API_KEY");

    if (!APIFY_API_KEY) throw new Error("APIFY_API_KEY not configured");

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    // ========== PROFILE: Add as competitor ==========
    if (type === "profile") {
      const username = extractUsername(url);
      if (!username) throw new Error("Could not extract username from URL");

      console.log(`👤 Processing profile: @${username}`);

      // Check if competitor already exists
      const { data: existing } = await supabase
        .from("competidores")
        .select("id, name")
        .eq("user_id", user_id)
        .eq("name", username)
        .maybeSingle();

      if (existing) {
        console.log(`Competitor @${username} already exists, updating profile...`);
      }

      // Scrape profile via Apify
      const profileRes = await fetch(
        `https://api.apify.com/v2/acts/shu8hvrXbJbY3Eb9W/run-sync-get-dataset-items?token=${APIFY_API_KEY}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            directUrls: [`https://www.instagram.com/${username}/`],
            resultsLimit: 1,
            resultsType: "details",
            searchType: "user",
          }),
        }
      );

      if (!profileRes.ok) {
        const errText = await profileRes.text();
        console.error("Apify profile error:", profileRes.status, errText);
        throw new Error(`Scraping failed: ${profileRes.status}`);
      }

      const profileItems = await profileRes.json();
      if (!profileItems.length) throw new Error("Profile not found on Instagram");

      const p = profileItems[0];
      const profileData = {
        name: username,
        page_url: `https://www.instagram.com/${username}/`,
        bio: p.biography || p.bio || null,
        followers_count: p.followersCount || p.followedByCount || null,
        following_count: p.followingCount || p.followsCount || null,
        posts_count: p.postsCount || p.mediaCount || null,
        profile_pic_url: p.profilePicUrl || p.profilePicUrlHD || null,
        niche: null,
        status: true,
        user_id,
        last_profile_update: new Date().toISOString(),
      };

      if (existing) {
        await supabase.from("competidores").update(profileData).eq("id", existing.id);
        console.log(`✅ Competitor @${username} updated`);
      } else {
        await supabase.from("competidores").insert(profileData);
        console.log(`✅ Competitor @${username} added`);
      }

      return new Response(JSON.stringify({
        success: true,
        action: existing ? "updated" : "added",
        username,
        followers: profileData.followers_count,
        posts: profileData.posts_count,
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ========== POST/REEL/STORY: Add as competitor reel ==========
    if (type === "reel" || type === "post" || type === "story") {
      console.log(`📹 Processing ${type}: ${url}`);

      // Check processed_content_log FIRST to prevent re-inserting deleted content
      const shortcodeMatch = url.match(/\/(p|reel|tv)\/([^/?]+)/);
      const shortcode = shortcodeMatch ? shortcodeMatch[2] : null;
      if (shortcode) {
        const { data: alreadyProcessed } = await supabase
          .from("processed_content_log")
          .select("id")
          .eq("user_id", user_id)
          .eq("shortcode", shortcode)
          .maybeSingle();

        if (alreadyProcessed) {
          console.log(`⏭️ Shortcode ${shortcode} already in processed_content_log, skipping`);
          return new Response(JSON.stringify({
            success: true,
            action: "already_processed",
            message: "Content was previously processed (in log)",
          }), {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
      }

      // Stories use a different URL pattern: /stories/username/storyId/
      // For stories, we try to scrape but they may expire (24h)
      const isStory = type === "story";

      // Scrape the specific post/reel/story via Apify
      const postRes = await fetch(
        `https://api.apify.com/v2/acts/shu8hvrXbJbY3Eb9W/run-sync-get-dataset-items?token=${APIFY_API_KEY}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            directUrls: [url],
            resultsLimit: 1,
            resultsType: isStory ? "stories" : "posts",
          }),
        }
      );

      if (!postRes.ok) {
        const errText = await postRes.text();
        console.error("Apify post error:", postRes.status, errText);
        throw new Error(`Scraping failed: ${postRes.status}`);
      }

      const postItems = await postRes.json();
      if (!postItems.length) {
        // Stories may have expired
        if (isStory) {
          return new Response(JSON.stringify({
            success: false,
            action: "story_expired",
            message: "Story não encontrado — pode ter expirado (24h)",
          }), {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        throw new Error("Content not found on Instagram");
      }

      const item = postItems[0];
      const ownerUsername = item.ownerUsername || extractUsernameFromStory(url) || extractUsernameFromPost(url) || "unknown";

      // Determine content type
      let contentType = type === "story" ? "story" : "post";
      if (!isStory) {
        const itemType = item.type || item.productType || "";
        if (itemType === "Sidecar" || itemType === "GraphSidecar" || item.childPosts?.length > 0) {
          contentType = "carousel";
        } else if (itemType === "Video" || itemType === "GraphVideo" || item.videoUrl || item.isVideo) {
          contentType = "reel";
        }
      }

      // Extract image URLs for carousels
      let imageUrls: string[] = [];
      if (item.childPosts) imageUrls = item.childPosts.map((c: any) => c.displayUrl || "").filter(Boolean);
      else if (item.sidecarImages) imageUrls = item.sidecarImages.map((c: any) => c.url || "").filter(Boolean);

      // Find or create the competitor
      let competitorId: string | null = null;
      const { data: existingComp } = await supabase
        .from("competidores")
        .select("id")
        .eq("user_id", user_id)
        .eq("name", ownerUsername)
        .maybeSingle();

      if (existingComp) {
        competitorId = existingComp.id;
      } else {
        const { data: newComp, error: compError } = await supabase
          .from("competidores")
          .insert({
            name: ownerUsername,
            page_url: `https://www.instagram.com/${ownerUsername}/`,
            status: true,
            user_id,
          })
          .select("id")
          .single();

        if (compError) {
          console.error("Error creating competitor:", compError);
        } else {
          competitorId = newComp.id;
          console.log(`👤 Auto-created competitor @${ownerUsername}`);
        }
      }

      // Check if this content already exists
      const postUrl = item.url || url;
      const { data: existingReel } = await supabase
        .from("reels_competidores")
        .select("id")
        .eq("user_id", user_id)
        .eq("url", postUrl)
        .maybeSingle();

      if (existingReel) {
        return new Response(JSON.stringify({
          success: true,
          action: "already_exists",
          username: ownerUsername,
          contentType,
          message: "Este conteúdo já foi salvo anteriormente",
        }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // Calculate engagement rate
      const interactions = (item.likesCount || 0) + (item.commentsCount || 0);
      const reach = item.videoViewCount || item.videoPlayCount || item.likesCount || 1;
      const engRate = Number(((interactions / reach) * 100).toFixed(2));

      // Insert the content
      const { error: insertError } = await supabase.from("reels_competidores").insert({
        user_id,
        competidor_id: competitorId,
        caption: item.caption?.slice(0, 2000) || null,
        owner_username: ownerUsername,
        url: postUrl,
        thumbnail_url: item.displayUrl || null,
        video_url: item.videoUrl || null,
        views: item.videoViewCount || item.videoPlayCount || 0,
        likes: item.likesCount || 0,
        comments: item.commentsCount || 0,
        post_date: item.timestamp || null,
        content_type: contentType,
        image_urls: imageUrls.length > 0 ? imageUrls : null,
        eng_rate: engRate,
      });

      if (insertError) throw insertError;

      // Log to processed_content_log to prevent re-download after deletion
      const insertedShortcode = postUrl.match(/\/(p|reel|tv)\/([^/?]+)/)?.[2];
      if (insertedShortcode) {
        await supabase.from("processed_content_log").upsert({
          user_id,
          shortcode: insertedShortcode,
          source_url: postUrl,
          content_type: contentType,
        }, { onConflict: "user_id,shortcode" });
      }

      console.log(`✅ ${contentType} from @${ownerUsername} saved`);

      return new Response(JSON.stringify({
        success: true,
        action: "added",
        username: ownerUsername,
        contentType,
        likes: item.likesCount || 0,
        views: item.videoViewCount || item.videoPlayCount || 0,
        comments: item.commentsCount || 0,
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    throw new Error(`Unknown type: ${type}. Supported: profile, reel, post, story`);
  } catch (error) {
    console.error("process-instagram-link error:", error);
    return new Response(JSON.stringify({
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

// ========== Helper Functions ==========

function extractUsername(url: string): string | null {
  const match = url.match(/instagram\.com\/([a-zA-Z0-9_.]+)/);
  if (match) {
    const username = match[1];
    if (["p", "reel", "reels", "stories", "explore", "accounts", "direct"].includes(username)) {
      return null;
    }
    return username;
  }
  return null;
}

function extractUsernameFromPost(url: string): string | null {
  return null;
}

function extractUsernameFromStory(url: string): string | null {
  // Stories URL format: /stories/username/storyId/
  const match = url.match(/instagram\.com\/stories\/([a-zA-Z0-9_.]+)/);
  return match ? match[1] : null;
}
