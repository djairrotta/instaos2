import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { encode as hexEncode } from "https://deno.land/std@0.168.0/encoding/hex.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

// S3-compatible signing helpers
async function hmacSha256(key: Uint8Array, message: string): Promise<Uint8Array> {
  const cryptoKey = await crypto.subtle.importKey("raw", key.buffer as ArrayBuffer, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", cryptoKey, new TextEncoder().encode(message));
  return new Uint8Array(sig);
}

async function sha256(data: string): Promise<string> {
  const hash = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(data));
  return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, "0")).join("");
}

async function getSignatureKey(key: string, dateStamp: string, region: string, service: string) {
  let kDate = await hmacSha256(new TextEncoder().encode("AWS4" + key), dateStamp);
  let kRegion = await hmacSha256(kDate, region);
  let kService = await hmacSha256(kRegion, service);
  return hmacSha256(kService, "aws4_request");
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const MINIO_ENDPOINT = Deno.env.get("MINIO_ENDPOINT");
    const MINIO_ACCESS_KEY = Deno.env.get("MINIO_ACCESS_KEY");
    const MINIO_SECRET_KEY = Deno.env.get("MINIO_SECRET_KEY");
    const MINIO_BUCKET = Deno.env.get("MINIO_BUCKET") || "ig-os-analysis";

    if (!MINIO_ENDPOINT || !MINIO_ACCESS_KEY || !MINIO_SECRET_KEY) {
      throw new Error("MinIO credentials not configured (MINIO_ENDPOINT, MINIO_ACCESS_KEY, MINIO_SECRET_KEY)");
    }

    const { action, data, path, source, contentId } = await req.json();

    // Action: save - save analysis result to MinIO
    if (action === "save") {
      if (!data || !path) throw new Error("Missing 'data' or 'path' parameter");

      const body = typeof data === "string" ? data : JSON.stringify(data, null, 2);
      const contentType = "application/json";

      // Build S3 PUT request with AWS Signature V4
      const endpoint = MINIO_ENDPOINT.replace(/\/$/, "");
      const url = `${endpoint}/${MINIO_BUCKET}/${path}`;
      const now = new Date();
      const dateStamp = now.toISOString().replace(/[-:]/g, "").split(".")[0] + "Z";
      const shortDate = dateStamp.slice(0, 8);
      const region = "us-east-1";
      const service = "s3";

      const payloadHash = await sha256(body);
      const host = new URL(endpoint).host;

      const canonicalHeaders = `content-type:${contentType}\nhost:${host}\nx-amz-content-sha256:${payloadHash}\nx-amz-date:${dateStamp}\n`;
      const signedHeaders = "content-type;host;x-amz-content-sha256;x-amz-date";

      const canonicalRequest = `PUT\n/${MINIO_BUCKET}/${path}\n\n${canonicalHeaders}\n${signedHeaders}\n${payloadHash}`;
      const credentialScope = `${shortDate}/${region}/${service}/aws4_request`;
      const stringToSign = `AWS4-HMAC-SHA256\n${dateStamp}\n${credentialScope}\n${await sha256(canonicalRequest)}`;

      const signingKey = await getSignatureKey(MINIO_SECRET_KEY, shortDate, region, service);
      const signatureBytes = await hmacSha256(signingKey, stringToSign);
      const signature = Array.from(signatureBytes).map(b => b.toString(16).padStart(2, "0")).join("");

      const authorization = `AWS4-HMAC-SHA256 Credential=${MINIO_ACCESS_KEY}/${credentialScope}, SignedHeaders=${signedHeaders}, Signature=${signature}`;

      const putRes = await fetch(url, {
        method: "PUT",
        headers: {
          "Content-Type": contentType,
          "x-amz-content-sha256": payloadHash,
          "x-amz-date": dateStamp,
          Authorization: authorization,
        },
        body,
      });

      if (!putRes.ok) {
        const errText = await putRes.text();
        console.error("MinIO PUT error:", putRes.status, errText);
        throw new Error(`MinIO upload failed: ${putRes.status}`);
      }

      console.log(`✅ Saved to MinIO: ${path} (${body.length} bytes)`);

      return new Response(JSON.stringify({
        success: true,
        path,
        size: body.length,
        url: `${endpoint}/${MINIO_BUCKET}/${path}`,
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Action: list - list files in a prefix
    if (action === "list") {
      const prefix = path || "";
      const endpoint = MINIO_ENDPOINT.replace(/\/$/, "");
      const url = `${endpoint}/${MINIO_BUCKET}?list-type=2&prefix=${encodeURIComponent(prefix)}&max-keys=1000`;
      const now = new Date();
      const dateStamp = now.toISOString().replace(/[-:]/g, "").split(".")[0] + "Z";
      const shortDate = dateStamp.slice(0, 8);
      const region = "us-east-1";
      const service = "s3";

      const payloadHash = await sha256("");
      const host = new URL(endpoint).host;
      const queryString = `list-type=2&max-keys=1000&prefix=${encodeURIComponent(prefix)}`;

      const canonicalHeaders = `host:${host}\nx-amz-content-sha256:${payloadHash}\nx-amz-date:${dateStamp}\n`;
      const signedHeaders = "host;x-amz-content-sha256;x-amz-date";

      const canonicalRequest = `GET\n/${MINIO_BUCKET}\n${queryString}\n${canonicalHeaders}\n${signedHeaders}\n${payloadHash}`;
      const credentialScope = `${shortDate}/${region}/${service}/aws4_request`;
      const stringToSign = `AWS4-HMAC-SHA256\n${dateStamp}\n${credentialScope}\n${await sha256(canonicalRequest)}`;

      const signingKey = await getSignatureKey(MINIO_SECRET_KEY, shortDate, region, service);
      const signatureBytes = await hmacSha256(signingKey, stringToSign);
      const signature = Array.from(signatureBytes).map(b => b.toString(16).padStart(2, "0")).join("");

      const authorization = `AWS4-HMAC-SHA256 Credential=${MINIO_ACCESS_KEY}/${credentialScope}, SignedHeaders=${signedHeaders}, Signature=${signature}`;

      const listRes = await fetch(url, {
        method: "GET",
        headers: {
          "x-amz-content-sha256": payloadHash,
          "x-amz-date": dateStamp,
          Authorization: authorization,
        },
      });

      if (!listRes.ok) {
        const errText = await listRes.text();
        throw new Error(`MinIO list failed: ${listRes.status} - ${errText}`);
      }

      const xmlText = await listRes.text();
      // Parse keys and sizes
      const files = [...xmlText.matchAll(/<Contents>([\s\S]*?)<\/Contents>/g)].map(m => {
        const block = m[1];
        const key = block.match(/<Key>([^<]+)<\/Key>/)?.[1] || "";
        const size = parseInt(block.match(/<Size>([^<]+)<\/Size>/)?.[1] || "0", 10);
        const lastModified = block.match(/<LastModified>([^<]+)<\/LastModified>/)?.[1] || "";
        return { key, size, lastModified };
      });

      return new Response(JSON.stringify({ success: true, files }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Action: get - download a file's content
    if (action === "get") {
      if (!path) throw new Error("Missing 'path' parameter");
      const endpoint = MINIO_ENDPOINT.replace(/\/$/, "");
      const url = `${endpoint}/${MINIO_BUCKET}/${path}`;
      const now = new Date();
      const dateStamp = now.toISOString().replace(/[-:]/g, "").split(".")[0] + "Z";
      const shortDate = dateStamp.slice(0, 8);
      const region = "us-east-1";
      const service = "s3";

      const payloadHash = await sha256("");
      const host = new URL(endpoint).host;

      const canonicalHeaders = `host:${host}\nx-amz-content-sha256:${payloadHash}\nx-amz-date:${dateStamp}\n`;
      const signedHeaders = "host;x-amz-content-sha256;x-amz-date";

      const canonicalRequest = `GET\n/${MINIO_BUCKET}/${path}\n\n${canonicalHeaders}\n${signedHeaders}\n${payloadHash}`;
      const credentialScope = `${shortDate}/${region}/${service}/aws4_request`;
      const stringToSign = `AWS4-HMAC-SHA256\n${dateStamp}\n${credentialScope}\n${await sha256(canonicalRequest)}`;

      const signingKey = await getSignatureKey(MINIO_SECRET_KEY, shortDate, region, service);
      const signatureBytes = await hmacSha256(signingKey, stringToSign);
      const signature = Array.from(signatureBytes).map(b => b.toString(16).padStart(2, "0")).join("");

      const authorization = `AWS4-HMAC-SHA256 Credential=${MINIO_ACCESS_KEY}/${credentialScope}, SignedHeaders=${signedHeaders}, Signature=${signature}`;

      const getRes = await fetch(url, {
        method: "GET",
        headers: {
          "x-amz-content-sha256": payloadHash,
          "x-amz-date": dateStamp,
          Authorization: authorization,
        },
      });

      if (!getRes.ok) {
        // Return graceful response for missing files (404) instead of throwing
        if (getRes.status === 404) {
          return new Response(JSON.stringify({ success: false, error: "not_found" }), {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        const errText = await getRes.text();
        throw new Error(`MinIO GET failed: ${getRes.status} - ${errText}`);
      }

      const contentType = getRes.headers.get("content-type") || "application/octet-stream";
      
      // For JSON files, return as JSON data
      if (path.endsWith(".json")) {
        const text = await getRes.text();
        return new Response(JSON.stringify({ success: true, content: text, contentType }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // For other files, return a base64 encoded version
      const buf = await getRes.arrayBuffer();
      const u8 = new Uint8Array(buf);
      let binary = "";
      for (let i = 0; i < u8.length; i++) binary += String.fromCharCode(u8[i]);
      const b64 = btoa(binary);

      return new Response(JSON.stringify({ success: true, content: b64, contentType, encoding: "base64" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Action: delete - delete a file
    if (action === "delete") {
      if (!path) throw new Error("Missing 'path' parameter");
      const endpoint = MINIO_ENDPOINT.replace(/\/$/, "");
      const url = `${endpoint}/${MINIO_BUCKET}/${path}`;
      const now = new Date();
      const dateStamp = now.toISOString().replace(/[-:]/g, "").split(".")[0] + "Z";
      const shortDate = dateStamp.slice(0, 8);
      const region = "us-east-1";
      const service = "s3";

      const payloadHash = await sha256("");
      const host = new URL(endpoint).host;

      const canonicalHeaders = `host:${host}\nx-amz-content-sha256:${payloadHash}\nx-amz-date:${dateStamp}\n`;
      const signedHeaders = "host;x-amz-content-sha256;x-amz-date";

      const canonicalRequest = `DELETE\n/${MINIO_BUCKET}/${path}\n\n${canonicalHeaders}\n${signedHeaders}\n${payloadHash}`;
      const credentialScope = `${shortDate}/${region}/${service}/aws4_request`;
      const stringToSign = `AWS4-HMAC-SHA256\n${dateStamp}\n${credentialScope}\n${await sha256(canonicalRequest)}`;

      const signingKey = await getSignatureKey(MINIO_SECRET_KEY, shortDate, region, service);
      const signatureBytes = await hmacSha256(signingKey, stringToSign);
      const signature = Array.from(signatureBytes).map(b => b.toString(16).padStart(2, "0")).join("");

      const authorization = `AWS4-HMAC-SHA256 Credential=${MINIO_ACCESS_KEY}/${credentialScope}, SignedHeaders=${signedHeaders}, Signature=${signature}`;

      const delRes = await fetch(url, {
        method: "DELETE",
        headers: {
          "x-amz-content-sha256": payloadHash,
          "x-amz-date": dateStamp,
          Authorization: authorization,
        },
      });

      if (!delRes.ok && delRes.status !== 204) {
        const errText = await delRes.text();
        throw new Error(`MinIO DELETE failed: ${delRes.status} - ${errText}`);
      }

      console.log(`🗑️ Deleted from MinIO: ${path}`);
      return new Response(JSON.stringify({ success: true, path }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    throw new Error(`Unknown action: ${action}. Use 'save', 'list', 'get', or 'delete'.`);
  } catch (error) {
    console.error("save-to-minio error:", error);
    return new Response(JSON.stringify({ success: false, error: error instanceof Error ? error.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
