import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

function detectContentType(item: any): string {
  // Apify Instagram Scraper uses these type indicators
  const type = item.type || item.productType || "";
  if (type === "Sidecar" || type === "GraphSidecar" || item.childPosts?.length > 0 || item.sidecarImages?.length > 0) return "carousel";
  if (type === "Video" || type === "GraphVideo" || item.videoUrl || item.isVideo) return "reel";
  return "post"; // Image / GraphImage
}

function extractImageUrls(item: any): string[] {
  // For carousels, extract all slide URLs
  if (item.childPosts) return item.childPosts.map((c: any) => c.displayUrl || c.imageUrl || "").filter(Boolean);
  if (item.sidecarImages) return item.sidecarImages.map((c: any) => c.url || c.displayUrl || "").filter(Boolean);
  if (item.images) return item.images.map((c: any) => c.url || c.displayUrl || "").filter(Boolean);
  return [];
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { username, limit = 20, provider = "apify", contentTypes = ["reel", "post", "carousel"], action = "posts", actorId, proxyCountry, firecrawlConfig, hashtags, searchType, resultsType } = await req.json();
    if (!username && action !== "hashtag") throw new Error("username is required");

    const APIFY_API_KEY = Deno.env.get("APIFY_API_KEY");
    const FIRECRAWL_API_KEY = Deno.env.get("FIRECRAWL_API_KEY");

    let posts: any[] = [];
    let profileData: any = null;

    if (provider === "apify" && APIFY_API_KEY) {
      // If action is "stories", fetch stories using Instagram Story Scraper with login
      if (action === "stories") {
        const IG_USERNAME = Deno.env.get("INSTAGRAM_USERNAME");
        const IG_PASSWORD = Deno.env.get("INSTAGRAM_PASSWORD");
        if (!IG_USERNAME || !IG_PASSWORD) {
          throw new Error("INSTAGRAM_USERNAME and INSTAGRAM_PASSWORD are required for story scraping");
        }

        console.log(`Fetching stories for ${username} via Apify (with login)`);
        const storyRes = await fetch(
          `https://api.apify.com/v2/acts/${actorId || "apify~instagram-story-scraper"}/run-sync-get-dataset-items?token=${APIFY_API_KEY}`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              usernames: [username],
              loginUsername: IG_USERNAME,
              loginPassword: IG_PASSWORD,
              resultsLimit: limit,
            }),
          }
        );

        if (!storyRes.ok) {
          const errorText = await storyRes.text();
          console.error("Apify story error:", storyRes.status, errorText);
          throw new Error(`Apify story scraper failed: ${storyRes.status} - ${errorText.slice(0, 200)}`);
        }

        const storyItems = await storyRes.json();
        console.log(`Apify returned ${storyItems.length} stories for @${username}`);

        const stories = storyItems.map((item: any) => ({
          caption: item.caption?.slice(0, 2000) || "",
          owner_username: item.ownerUsername || item.username || username,
          url: item.url || item.storyUrl || "",
          thumbnail_url: item.displayUrl || item.imageUrl || "",
          video_url: item.videoUrl || "",
          views: item.viewCount || item.videoViewCount || 0,
          likes: item.likesCount || 0,
          comments: item.commentsCount || 0,
          post_date: item.timestamp || item.takenAtTimestamp ? new Date(item.takenAtTimestamp * 1000).toISOString() : null,
          content_type: "story",
          image_urls: [],
          eng_rate: 0,
        }));

        return new Response(JSON.stringify({ success: true, reels: stories, count: stories.length }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // If action is "profile", fetch profile details
      if (action === "profile") {
        console.log(`Fetching profile for ${username} via Apify`);
        const profileRes = await fetch(
          `https://api.apify.com/v2/acts/${actorId || "shu8hvrXbJbY3Eb9W"}/run-sync-get-dataset-items?token=${APIFY_API_KEY}`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              directUrls: [`https://www.instagram.com/${username}/`],
              resultsLimit: 1,
              resultsType: "details",
              searchType: "user",
            }),
          }
        );

        if (!profileRes.ok) {
          const errorText = await profileRes.text();
          console.error("Apify profile error:", profileRes.status, errorText);
          throw new Error(`Apify profile failed: ${profileRes.status}`);
        }

        const profileItems = await profileRes.json();
        if (profileItems.length > 0) {
          const p = profileItems[0];
          profileData = {
            bio: p.biography || p.bio || "",
            followers_count: p.followersCount || p.followedByCount || 0,
            following_count: p.followingCount || p.followsCount || 0,
            posts_count: p.postsCount || p.mediaCount || 0,
            profile_pic_url: p.profilePicUrl || p.profilePicUrlHD || "",
            full_name: p.fullName || "",
            is_verified: p.verified || false,
            external_url: p.externalUrl || "",
          };
          console.log(`Profile fetched: ${profileData.followers_count} followers, ${profileData.posts_count} posts`);
        }

        return new Response(JSON.stringify({ success: true, profile: profileData }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // If action is "hashtag", search by hashtags
      if (action === "hashtag") {
        const hashtagList = hashtags || [];
        if (hashtagList.length === 0) throw new Error("hashtags array is required for hashtag action");

        console.log(`Searching hashtags via Apify: ${hashtagList.join(", ")} (limit: ${limit})`);
        
        const allPosts: any[] = [];
        
        for (const tag of hashtagList) {
          const cleanTag = tag.replace(/^#/, "").trim();
          if (!cleanTag) continue;
          
          console.log(`🔍 Searching hashtag #${cleanTag}...`);
          
          try {
            const hashtagRes = await fetch(
              `https://api.apify.com/v2/acts/${actorId || "shu8hvrXbJbY3Eb9W"}/run-sync-get-dataset-items?token=${APIFY_API_KEY}`,
              {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                  search: cleanTag,
                  searchType: searchType || "hashtag",
                  resultsType: resultsType || "posts",
                  resultsLimit: Math.ceil(limit / hashtagList.length),
                  ...(proxyCountry ? { proxy: { useApifyProxy: true, apifyProxyCountry: proxyCountry } } : {}),
                }),
              }
            );

            if (!hashtagRes.ok) {
              const errorText = await hashtagRes.text();
              console.error(`Apify hashtag error for #${cleanTag}:`, hashtagRes.status, errorText.slice(0, 200));
              continue;
            }

            const hashtagItems = await hashtagRes.json();
            console.log(`#${cleanTag}: ${hashtagItems.length} results`);

            const mapped = hashtagItems.map((item: any) => {
              const contentType = detectContentType(item);
              const imageUrls = extractImageUrls(item);
              return {
                caption: item.caption?.slice(0, 2000) || "",
                owner_username: item.ownerUsername || item.username || "",
                url: item.url || (item.shortCode ? `https://www.instagram.com/p/${item.shortCode}/` : ""),
                thumbnail_url: item.displayUrl || "",
                video_url: item.videoUrl || "",
                views: item.videoViewCount || item.videoPlayCount || item.viewCount || item.playCount || item.impressionsCount || 0,
                likes: item.likesCount || 0,
                comments: item.commentsCount || 0,
                post_date: item.timestamp || null,
                content_type: contentType,
                image_urls: imageUrls,
                eng_rate: (() => {
                  const interactions = (item.likesCount || 0) + (item.commentsCount || 0);
                  const reach = item.videoViewCount || item.videoPlayCount || item.viewCount || item.playCount || item.impressionsCount || item.likesCount || 1;
                  return Number(((interactions / reach) * 100).toFixed(2));
                })(),
                hashtag_source: `#${cleanTag}`,
              };
            });

            allPosts.push(...mapped);
          } catch (e) {
            console.error(`Error searching #${cleanTag}:`, e);
          }
          
          // Small delay between hashtag searches
          await new Promise(r => setTimeout(r, 2000));
        }

        // Filter by content types and sort by engagement
        const filtered = allPosts
          .filter((p: any) => contentTypes.includes(p.content_type))
          .sort((a: any, b: any) => {
            const scoreA = (a.views || 0) + (a.likes || 0) * 10 + (a.comments || 0) * 30;
            const scoreB = (b.views || 0) + (b.likes || 0) * 10 + (b.comments || 0) * 30;
            return scoreB - scoreA;
          })
          .slice(0, limit);

        console.log(`Hashtag search total: ${allPosts.length} raw → ${filtered.length} filtered`);

        return new Response(JSON.stringify({ success: true, reels: filtered, count: filtered.length }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      console.log(`Scraping ${username} via Apify - all content types (limit: ${limit})`);

      // Use the general Instagram Scraper actor that returns ALL post types
      const runResponse = await fetch(
        `https://api.apify.com/v2/acts/${actorId || "shu8hvrXbJbY3Eb9W"}/run-sync-get-dataset-items?token=${APIFY_API_KEY}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            directUrls: [`https://www.instagram.com/${username}/`],
            resultsLimit: limit,
            resultsType: "posts",
            searchType: "user",
          }),
        }
      );

      if (!runResponse.ok) {
        const errorText = await runResponse.text();
        console.error("Apify error:", runResponse.status, errorText);
        throw new Error(`Apify failed: ${runResponse.status}`);
      }

      const apifyData = await runResponse.json();
      console.log(`Apify returned ${apifyData.length} results`);

      posts = apifyData.map((item: any, idx: number) => {
        const contentType = detectContentType(item);
        const imageUrls = extractImageUrls(item);
        if (idx < 3) {
          console.log(`Sample item ${idx} (${contentType}): videoViewCount=${item.videoViewCount}, videoPlayCount=${item.videoPlayCount}, viewCount=${item.viewCount}, playCount=${item.playCount}, impressionsCount=${item.impressionsCount}, likesCount=${item.likesCount}`);
        }

        return {
          caption: item.caption?.slice(0, 2000) || "",
          owner_username: item.ownerUsername || username,
          url: item.url || item.shortCode ? `https://www.instagram.com/p/${item.shortCode}/` : "",
          thumbnail_url: item.displayUrl || "",
          video_url: item.videoUrl || "",
          views: item.videoViewCount || item.videoPlayCount || item.viewCount || item.playCount || item.impressionsCount || 0,
          likes: item.likesCount || 0,
          comments: item.commentsCount || 0,
          post_date: item.timestamp || null,
          content_type: contentType,
          image_urls: imageUrls,
          eng_rate: (() => {
            const interactions = (item.likesCount || 0) + (item.commentsCount || 0);
            const reach = item.videoViewCount || item.videoPlayCount || item.viewCount || item.playCount || item.impressionsCount || item.likesCount || 1;
            return Number(((interactions / reach) * 100).toFixed(2));
          })(),
        };
      });

      // Filter by requested content types
      posts = posts.filter((p: any) => contentTypes.includes(p.content_type));
      console.log(`After filtering: ${posts.length} posts (types: ${contentTypes.join(", ")})`);

    } else if (provider === "firecrawl" && FIRECRAWL_API_KEY) {
      // Apply user firecrawl config
      const fcFormats = firecrawlConfig?.formats || ["markdown", "links"];
      const fcWaitFor = firecrawlConfig?.waitFor ?? 3000;
      const fcOnlyMainContent = firecrawlConfig?.onlyMainContent ?? true;

      console.log(`Scraping ${username} via Firecrawl (formats: ${fcFormats.join(",")}, waitFor: ${fcWaitFor}ms)`);

      const profileUrl = username.startsWith("http") ? username : `https://www.instagram.com/${username}/`;

      const response = await fetch("https://api.firecrawl.dev/v1/scrape", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${FIRECRAWL_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          url: profileUrl,
          formats: fcFormats,
          waitFor: fcWaitFor,
          onlyMainContent: fcOnlyMainContent,
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error("Firecrawl error:", response.status, errorText);
        throw new Error(`Firecrawl failed: ${response.status}`);
      }

      const fcData = await response.json();
      const links = fcData.data?.links || [];

      // Detect content type from URL patterns
      const contentLinks = links
        .filter((l: string) => l.includes("/reel/") || l.includes("/p/"))
        .slice(0, limit);

      posts = contentLinks.map((link: string) => ({
        caption: "",
        owner_username: username,
        url: link,
        thumbnail_url: "",
        video_url: "",
        views: 0, likes: 0, comments: 0,
        post_date: null,
        content_type: link.includes("/reel/") ? "reel" : "post",
        image_urls: [],
        eng_rate: 0,
      }));
    } else {
      throw new Error(`No valid API key for provider: ${provider}. Configure APIFY_API_KEY or FIRECRAWL_API_KEY.`);
    }

    return new Response(JSON.stringify({ success: true, reels: posts, count: posts.length }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("scrape-reels error:", error);
    return new Response(JSON.stringify({ success: false, error: error instanceof Error ? error.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
