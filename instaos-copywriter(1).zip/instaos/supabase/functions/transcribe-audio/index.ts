import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { videoUrl, language = "pt" } = await req.json();
    if (!videoUrl) throw new Error("videoUrl is required");

    const GROQ_API_KEY = Deno.env.get("GROQ_API_KEY");
    if (!GROQ_API_KEY) throw new Error("GROQ_API_KEY not configured");

    console.log(`📥 Downloading video from: ${videoUrl.slice(0, 100)}...`);

    // Download the video file
    const videoResponse = await fetch(videoUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      },
    });

    if (!videoResponse.ok) {
      console.error(`Video download failed: ${videoResponse.status}`);
      throw new Error(`Failed to download video: ${videoResponse.status}`);
    }

    const videoBlob = await videoResponse.blob();
    const videoSizeMB = (videoBlob.size / (1024 * 1024)).toFixed(2);
    console.log(`📦 Video downloaded: ${videoSizeMB}MB`);

    // Groq Whisper has a 25MB limit
    if (videoBlob.size > 25 * 1024 * 1024) {
      console.warn(`⚠️ Video too large (${videoSizeMB}MB > 25MB), falling back to caption analysis`);
      return new Response(JSON.stringify({ 
        success: false, 
        error: "Video too large for transcription (>25MB)",
        fallback: true 
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Send to Groq Whisper API
    console.log(`🎙️ Transcribing with Groq Whisper (whisper-large-v3-turbo)...`);
    
    const formData = new FormData();
    formData.append("file", videoBlob, "video.mp4");
    formData.append("model", "whisper-large-v3-turbo");
    formData.append("language", language);
    formData.append("response_format", "verbose_json");
    formData.append("temperature", "0");

    const whisperResponse = await fetch("https://api.groq.com/openai/v1/audio/transcriptions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${GROQ_API_KEY}`,
      },
      body: formData,
    });

    if (!whisperResponse.ok) {
      const errorText = await whisperResponse.text();
      console.error(`Groq Whisper error: ${whisperResponse.status}`, errorText);
      
      // If rate limited, return fallback
      if (whisperResponse.status === 429) {
        return new Response(JSON.stringify({ 
          success: false, 
          error: "Groq rate limit exceeded",
          fallback: true 
        }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      
      throw new Error(`Whisper API error: ${whisperResponse.status}`);
    }

    const transcriptionData = await whisperResponse.json();
    const transcript = transcriptionData.text || "";
    const duration = transcriptionData.duration || 0;
    const segments = transcriptionData.segments || [];

    console.log(`✅ Transcription complete: ${transcript.length} chars, ${duration.toFixed(1)}s, ${segments.length} segments`);

    // Extract the first 3 seconds for hook detection
    const hookSegments = segments.filter((s: any) => s.start < 3);
    const hookText = hookSegments.map((s: any) => s.text).join(" ").trim();

    return new Response(JSON.stringify({ 
      success: true, 
      transcript: transcript.slice(0, 3000),
      hookText: hookText || transcript.slice(0, 200),
      duration,
      segmentCount: segments.length,
      method: "whisper",
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("transcribe-audio error:", error);
    return new Response(JSON.stringify({ 
      success: false, 
      error: error instanceof Error ? error.message : "Unknown error",
      fallback: true,
    }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
