import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// ── helpers ────────────────────────────────────────────────────────────────

async function apifyRun(token: string, actor: string, input: object, timeoutMs = 180_000): Promise<any[]> {
  const runRes = await fetch(
    `https://api.apify.com/v2/acts/${actor}/runs?token=${token}`,
    { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(input) }
  );
  if (!runRes.ok) throw new Error(`Apify run failed: ${runRes.status}`);
  const run = await runRes.json();
  const runId = run.data?.id;
  const datasetId = run.data?.defaultDatasetId;

  // Poll until done
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    await new Promise(r => setTimeout(r, 4000));
    const poll = await fetch(`https://api.apify.com/v2/actor-runs/${runId}?token=${token}`);
    const s = (await poll.json()).data?.status;
    if (s === "SUCCEEDED") break;
    if (s === "FAILED" || s === "ABORTED") throw new Error(`Apify run ${s}: ${runId}`);
  }

  const items = await fetch(`https://api.apify.com/v2/datasets/${datasetId}/items?token=${token}&limit=100`);
  return items.json();
}

async function callAI(supabaseUrl: string, serviceKey: string, agent: string, context: string, provider = "openrouter", model = "google/gemini-2.5-flash-preview-05-20"): Promise<string> {
  const res = await fetch(`${supabaseUrl}/functions/v1/generate-content`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${serviceKey}` },
    body: JSON.stringify({ agent, context, provider, model }),
  });
  const d = await res.json();
  return d.result || "";
}

// ── main ───────────────────────────────────────────────────────────────────

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: cors });

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SERVICE_KEY  = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const APIFY_KEY    = Deno.env.get("APIFY_API_KEY") || "";
    const supabase     = createClient(SUPABASE_URL, SERVICE_KEY);

    const authHeader = req.headers.get("Authorization") || "";
    const { data: { user } } = await supabase.auth.getUser(authHeader.replace("Bearer ", ""));
    if (!user) throw new Error("Auth required");

    const body = await req.json();
    const {
      profileUrls = [],          // ["https://instagram.com/djairrotta", ...]
      action = "investigate",    // investigate | get_results | get_consolidated
      investigationId,           // for get_results
      mode = "profile_5_10",     // single_post | profile_1 | profile_5_10
    } = body;

    // ── GET RESULTS ────────────────────────────────────────────────────────
    if (action === "get_results" && investigationId) {
      const { data } = await supabase
        .from("sherlock_investigations")
        .select("*")
        .eq("id", investigationId)
        .eq("user_id", user.id)
        .single();
      return new Response(JSON.stringify({ success: true, investigation: data }), {
        headers: { ...cors, "Content-Type": "application/json" },
      });
    }

    // ── GET CONSOLIDATED ───────────────────────────────────────────────────
    if (action === "get_consolidated") {
      const { data } = await supabase
        .from("sherlock_investigations")
        .select("*")
        .eq("user_id", user.id)
        .eq("status", "completed")
        .order("created_at", { ascending: false })
        .limit(10);
      return new Response(JSON.stringify({ success: true, investigations: data || [] }), {
        headers: { ...cors, "Content-Type": "application/json" },
      });
    }

    if (!profileUrls.length) throw new Error("profileUrls required");
    if (!APIFY_KEY) throw new Error("APIFY_API_KEY not configured");

    // ── CREATE INVESTIGATION RECORD ────────────────────────────────────────
    const { data: inv, error: invErr } = await supabase
      .from("sherlock_investigations")
      .insert({
        user_id: user.id,
        profile_urls: profileUrls,
        mode,
        status: "running",
        profiles: {},
        consolidated: null,
      })
      .select()
      .single();
    if (invErr) throw invErr;

    // Run async — respond immediately
    runInvestigation(supabase, SUPABASE_URL, SERVICE_KEY, APIFY_KEY, inv.id, user.id, profileUrls, mode)
      .catch(e => {
        console.error("Investigation failed:", e);
        supabase.from("sherlock_investigations")
          .update({ status: "failed", error: e.message })
          .eq("id", inv.id);
      });

    return new Response(JSON.stringify({
      success: true,
      investigationId: inv.id,
      message: `Investigating ${profileUrls.length} profile(s) in background — ~2-5 min`,
    }), { headers: { ...cors, "Content-Type": "application/json" } });

  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({ success: false, error: (e as Error).message }), {
      status: 500, headers: { ...cors, "Content-Type": "application/json" },
    });
  }
});

// ── Investigation runner ───────────────────────────────────────────────────

async function runInvestigation(
  supabase: any, supabaseUrl: string, serviceKey: string, apifyKey: string,
  invId: string, userId: string, profileUrls: string[], mode: string
) {
  const profiles: Record<string, any> = {};

  for (const url of profileUrls) {
    const username = url.replace(/https?:\/\/(www\.)?instagram\.com\//,"").replace(/\//,"").replace("@","");
    console.log(`🔍 Investigating @${username} (mode: ${mode})`);

    try {
      // Scrape posts via Apify
      const limit = mode === "single_post" ? 1 : mode === "profile_1" ? 1 : 10;
      const posts: any[] = await apifyRun(apifyKey, "apify~instagram-post-scraper", {
        usernames: [username],
        resultsLimit: limit,
      });

      if (!posts.length) {
        profiles[username] = { error: "No posts found", posts: [] };
        continue;
      }

      // Extract raw content
      const rawContent = posts.map((p, i) => ({
        index: i + 1,
        url: p.url || p.postUrl || "",
        caption: p.caption || "",
        type: p.type || p.productType || "post",
        likes: p.likesCount || 0,
        views: p.videoViewCount || 0,
        comments: p.commentsCount || 0,
        timestamp: p.timestamp || "",
        imageUrls: p.childPosts?.map((c: any) => c.displayUrl).filter(Boolean) || (p.displayUrl ? [p.displayUrl] : []),
        videoUrl: p.videoUrl || p.videoPlayerUrl || "",
        transcript: p.transcript || "",
      }));

      // Use AI to analyze patterns (hook_analyst agent)
      const analysisPrompt = `Analise este conjunto de posts reais do perfil @${username} do Instagram e extraia:

1. PADRÕES DE GANCHO: Os primeiros elementos de cada post que capturam atenção
2. ESTRUTURA NARRATIVA: Como o conteúdo é organizado (para carrosséis: como os slides progridem)
3. TOM DE VOZ: Vocabulário, estilo, nível de formalidade
4. TIPOS DE CONTEÚDO: Quais formatos performam mais (reel, carrossel, post estático)
5. FÓRMULAS REPLICÁVEIS: Padrões estruturais que se repetem nos posts com mais engajamento
6. GATILHOS PSICOLÓGICOS: Quais emoções são ativadas (curiosidade, medo, FOMO, etc.)

POSTS ANALISADOS (${rawContent.length} posts):
${rawContent.map(p => `
[Post ${p.index}] ${p.type.toUpperCase()} | ❤️${p.likes} 👁️${p.views}
Caption: ${(p.caption || "").slice(0, 300)}
${p.imageUrls.length > 1 ? `Carrossel com ${p.imageUrls.length} slides` : ""}
`).join("\n")}

Retorne análise estruturada em PT-BR com seções: PADRÕES DE GANCHO, ESTRUTURA NARRATIVA, TOM DE VOZ, FÓRMULAS REPLICÁVEIS, GATILHOS PSICOLÓGICOS, SCORE DE REFERÊNCIA (0-100 de quão bom é este perfil como referência).`;

      const patternAnalysis = await callAI(supabaseUrl, serviceKey, "hook_analyst", analysisPrompt);

      profiles[username] = {
        username,
        postsAnalyzed: rawContent.length,
        rawContent,
        patternAnalysis,
        topPosts: rawContent.sort((a, b) => (b.likes + b.views * 0.1) - (a.likes + a.views * 0.1)).slice(0, 3),
      };

      // Update progress
      await supabase.from("sherlock_investigations").update({
        profiles: JSON.stringify(profiles),
        updated_at: new Date().toISOString(),
      }).eq("id", invId);

    } catch (e) {
      console.error(`Error investigating @${username}:`, e);
      profiles[username] = { error: (e as Error).message, posts: [] };
    }
  }

  // Generate consolidated analysis
  const successProfiles = Object.entries(profiles).filter(([, v]: any) => !v.error);

  let consolidated = null;
  if (successProfiles.length > 0) {
    const consolidatePrompt = `Você é Renata ROI — consolidadora de análise de perfis do Instagram.

Analise os seguintes perfis investigados e gere um RELATÓRIO CONSOLIDADO com:

1. PADRÕES UNIVERSAIS: O que funciona em TODOS os perfis analisados
2. FRAMEWORK DE GANCHO RECOMENDADO: A estrutura de gancho mais eficaz baseada nos dados reais
3. TOM DE VOZ SUGERIDO: Como o usuário deveria comunicar baseado nos top performers
4. TOP 5 FÓRMULAS REPLICÁVEIS: As estruturas de conteúdo mais eficazes encontradas
5. VOCABULÁRIO RECOMENDADO: Palavras/frases que mais aparecem nos posts de alto engajamento
6. ANTI-PATTERNS: O que os perfis de baixo engajamento fazem de errado
7. RECOMENDAÇÃO DE FORMATO: Carrossel vs Reel vs Post — qual tem melhor performance neste nicho

PERFIS ANALISADOS:
${successProfiles.map(([username, data]: any) => `
@${username} (${data.postsAnalyzed} posts):
${data.patternAnalysis?.slice(0, 800) || "Análise indisponível"}
`).join("\n---\n")}

Retorne análise profunda e acionável em PT-BR. Este relatório vai informar a criação de agentes de conteúdo.`;

    consolidated = await callAI(supabaseUrl, serviceKey, "viral_analyst", consolidatePrompt);
  }

  // Save to agent configs as best-practice context
  if (consolidated) {
    await supabase.from("squad_memory").upsert({
      user_id: userId,
      squad_name: "instaos-viral-factory",
      key: "sherlock_consolidated",
      value: { consolidated, profiles: Object.keys(profiles), analyzedAt: new Date().toISOString() },
    }, { onConflict: "user_id,squad_name,key" });
  }

  await supabase.from("sherlock_investigations").update({
    status: "completed",
    profiles: JSON.stringify(profiles),
    consolidated,
    completed_at: new Date().toISOString(),
  }).eq("id", invId);

  console.log(`✅ Investigation ${invId} complete: ${successProfiles.length}/${profileUrls.length} profiles`);
}
