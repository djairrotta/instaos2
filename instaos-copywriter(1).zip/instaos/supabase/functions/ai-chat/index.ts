import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const PROVIDER_URLS: Record<string, string> = {
  groq: "https://api.groq.com/openai/v1/chat/completions",
  openrouter: "https://openrouter.ai/api/v1/chat/completions",
  openai: "https://api.openai.com/v1/chat/completions",
  deepseek: "https://api.deepseek.com/v1/chat/completions",
  google: "https://generativelanguage.googleapis.com/v1beta/models",
  anthropic: "https://api.anthropic.com/v1/messages",
  lovable: "https://ai.gateway.lovable.dev/v1/chat/completions",
};

const systemPrompt = `**IDIOMA OBRIGATÓRIO: PORTUGUÊS BRASILEIRO (PT-BR).**

Você é o Assistente IA do IG OS v3, um sistema de análise e automação para Instagram.

### SUAS CAPACIDADES
- Ajudar usuários a entender e usar o sistema IG OS v3
- Analisar perfis de competidores no Instagram (dar dicas de estratégia)
- Sugerir ideias de conteúdo (Reels, Stories, Carrosséis, Posts)
- Explicar métricas de engajamento e como melhorá-las
- Ajudar com estratégias de crescimento no Instagram
- Sugerir hooks virais e formatos de conteúdo
- Analisar tendências e nichos
- Dar dicas de copywriting para legendas
- Sugerir horários de postagem e frequência

### REGRAS
- Sempre responda em PT-BR
- Seja direto, prático e acionável
- Use emojis com moderação para tornar a conversa mais agradável
- Quando analisar perfis, peça o @ do competidor
- Formate respostas com markdown (listas, negrito, cabeçalhos)
- Se não souber algo específico, seja honesto e sugira alternativas`;

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { messages } = await req.json();

    // Get user from auth header
    const authHeader = req.headers.get("Authorization") || "";
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    let provider = "openrouter";
    let model = "google/gemini-2.5-flash";
    let apiKey = Deno.env.get("OPENROUTER_API_KEY") || "";
    let apiUrl = PROVIDER_URLS.openrouter;

    // Try to get user's chatbot config
    const token = authHeader.replace("Bearer ", "");
    const { data: { user } } = await supabase.auth.getUser(token);

    if (user) {
      // Get chatbot agent config
      const { data: agentConfig } = await supabase
        .from("agent_configs")
        .select("provider, model, is_active")
        .eq("user_id", user.id)
        .eq("agent_type", "chatbot")
        .maybeSingle();

      if (agentConfig?.is_active && agentConfig.provider) {
        provider = agentConfig.provider;
        model = agentConfig.model;

        if (provider !== "lovable") {
          // Fetch user's API key for this provider
          const { data: keyData } = await supabase
            .from("user_api_keys")
            .select("api_key")
            .eq("user_id", user.id)
            .eq("provider", provider)
            .eq("is_active", true)
            .maybeSingle();

          if (!keyData?.api_key) {
            return new Response(JSON.stringify({ error: `API key para ${provider} não configurada. Vá em Agentes de IA > API Keys para configurar.` }), {
              status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
            });
          }
          apiKey = keyData.api_key;
          apiUrl = PROVIDER_URLS[provider] || PROVIDER_URLS.lovable;
        } else {
          apiKey = Deno.env.get("LOVABLE_API_KEY") || "";
          apiUrl = PROVIDER_URLS.lovable;
        }
      }
    }

    if (!apiKey) throw new Error("Nenhuma API key disponível para o chatbot");

    // --- Anthropic uses a different API format ---
    if (provider === "anthropic") {
      const resp = await fetch(apiUrl, {
        method: "POST",
        headers: {
          "x-api-key": apiKey,
          "anthropic-version": "2023-06-01",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model,
          max_tokens: 4096,
          system: systemPrompt,
          messages: messages.map((m: any) => ({ role: m.role, content: m.content })),
          stream: true,
        }),
      });

      if (!resp.ok) {
        const t = await resp.text();
        console.error("Anthropic error:", resp.status, t);
        return new Response(JSON.stringify({ error: `Erro Anthropic: ${resp.status}` }), {
          status: resp.status, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      return new Response(resp.body, {
        headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
      });
    }

    // --- Google AI Studio uses a different API format ---
    if (provider === "google") {
      const googleUrl = `${apiUrl}/${model}:streamGenerateContent?alt=sse&key=${apiKey}`;
      const resp = await fetch(googleUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [
            { role: "user", parts: [{ text: systemPrompt }] },
            ...messages.map((m: any) => ({
              role: m.role === "assistant" ? "model" : "user",
              parts: [{ text: m.content }],
            })),
          ],
          generationConfig: { maxOutputTokens: 4096 },
        }),
      });

      if (!resp.ok) {
        const t = await resp.text();
        console.error("Google error:", resp.status, t);
        return new Response(JSON.stringify({ error: `Erro Google: ${resp.status}` }), {
          status: resp.status, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      return new Response(resp.body, {
        headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
      });
    }

    // --- OpenAI-compatible providers (groq, openrouter, openai, deepseek, lovable) ---
    const headers: Record<string, string> = {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    };
    if (provider === "openrouter") {
      headers["HTTP-Referer"] = "https://ig-os-v3.lovable.app";
    }

    const response = await fetch(apiUrl, {
      method: "POST",
      headers,
      body: JSON.stringify({
        model,
        messages: [
          { role: "system", content: systemPrompt },
          ...messages,
        ],
        stream: true,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit excedido. Tente novamente em alguns segundos." }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Créditos insuficientes. Adicione créditos ao provedor." }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI error:", response.status, t);
      return new Response(JSON.stringify({ error: "Erro no gateway de IA" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (e) {
    console.error("ai-chat error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Erro desconhecido" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
