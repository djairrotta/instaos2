import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// ── Types ──────────────────────────────────────────────────────────────────

interface ViralAnalysis {
  viralScore: number;
  hook: string;
  hookType: string;
  structure: string;
  emotion: string;
  callToAction: string;
  whyViral: string;
  weakPoints: string;
  adaptedHook: string;
  contentIdeas: string[];
  bestFormat: "reel" | "carrossel" | "post";
  estimatedReach: string;
}

interface UserProfile {
  name: string;           // e.g. "@djairrotta"
  niche: string;          // e.g. "Advogado especialista em direito bancário"
  toneOfVoice: string;    // e.g. "Direto, educativo, acessível"
  hashtags: string;       // e.g. "#advogado #direitobancario"
  targetAudience: string; // e.g. "Adultos com dívidas e problemas com bancos"
}

interface BuiltPrompt {
  system: string;
  userText: string;
  mediaAttachments: Array<{ type: "image" | "video"; url: string; description: string }>;
  fullPrompt: string;     // serialized for logging/storage
  format: string;
  estimatedTokens: number;
}

// ── helpers ────────────────────────────────────────────────────────────────

function countTokens(text: string): number {
  return Math.ceil(text.length / 4); // rough estimate
}

function buildSystemPrompt(profile: UserProfile, format: string): string {
  return `Você é um criador de conteúdo profissional para o perfil ${profile.name}.

NICHO: ${profile.niche}
TOM DE VOZ: ${profile.toneOfVoice}
PÚBLICO-ALVO: ${profile.targetAudience}
HASHTAGS PADRÃO: ${profile.hashtags}
FORMATO ALVO: ${format.toUpperCase()}

REGRAS OBRIGATÓRIAS:
- Todo o conteúdo em Português Brasileiro (PT-BR)
- Mantenha o tom de voz definido — nem formal demais, nem informal demais
- Sempre inclua um CTA claro no final
- Hashtags no final da legenda, nunca no meio
- Nunca mencione concorrentes pelo nome
- Foco em valor educativo e acionável para o público`;
}

function buildCarouselInstructions(adapted: ViralAnalysis, mediaCount: number): string {
  return `
TAREFA: Criar um CARROSSEL de Instagram baseado na análise viral abaixo.

ANÁLISE DO CONTEÚDO DE REFERÊNCIA:
- Gancho original identificado: "${adapted.hook}"
- Por que funciona: ${adapted.whyViral}
- Emoção ativada: ${adapted.emotion}
- Estrutura: ${adapted.structure}
- Score viral: ${adapted.viralScore}/100

GANCHO ADAPTADO PARA O SEU PERFIL:
"${adapted.adaptedHook}"

${mediaCount > 0 ? `MÍDIAS DO USUÁRIO FORNECIDAS: ${mediaCount} imagem(ns)/vídeo(s) — use-as como base visual dos slides` : "Sem mídia do usuário — descreva as imagens ideais para cada slide"}

ESTRUTURA DO CARROSSEL (6 slides):
Slide 1 — CAPA: Use o gancho adaptado. Máx 8 palavras. Visual impactante.
Slide 2 — PROBLEMA: Apresente a dor/situação que o público vive.
Slide 3 — DESENVOLVIMENTO: Aprofunde com dado, exemplo ou prova.
Slide 4 — INSIGHT: O ponto de virada ou revelação.
Slide 5 — SOLUÇÃO: O que fazer / como resolver.
Slide 6 — CTA: Call to action claro. Ex: "Salva esse post", "Comenta X".

RETORNE JSON VÁLIDO:
{
  "slides": [
    {
      "num": 1,
      "label": "CAPA",
      "text": "texto principal do slide",
      "subtext": "subtítulo opcional",
      "design_notes": "instrução visual: cor de fundo, estilo de fonte, elementos",
      "image_prompt": "prompt para gerar imagem deste slide com IA de imagem"
    }
  ],
  "caption": "legenda completa com emojis e hashtags (máx 300 chars)",
  "hook_cta": "primeira linha da legenda — deve aparecer antes do 'ver mais'",
  "hashtags": ["#tag1", "#tag2"]
}`;
}

function buildReelInstructions(adapted: ViralAnalysis, hasVideo: boolean): string {
  return `
TAREFA: Criar um ROTEIRO DE REEL para Instagram.

ANÁLISE DO CONTEÚDO DE REFERÊNCIA:
- Gancho original: "${adapted.hook}"
- Por que funciona: ${adapted.whyViral}
- Tipo de gancho: ${adapted.hookType}
- Score viral: ${adapted.viralScore}/100

GANCHO ADAPTADO:
"${adapted.adaptedHook}"

${hasVideo ? "VÍDEO DO USUÁRIO FORNECIDO — crie o roteiro para ser gravado usando este vídeo como referência de contexto/ambiente" : "Sem vídeo — descreva direções de câmera e ambiente ideal"}

ESTRUTURA (máx 60s):
[0–3s]  GANCHO: Fala de abertura magnética — baseada no gancho adaptado acima
[3–8s]  PROBLEMA: Apresenta a situação/dor do público
[8–25s] CONTEÚDO: Desenvolvimento com valor real, informação, prova
[25–35s] VIRADA: O insight ou ponto de diferenciação
[35–45s] SOLUÇÃO: Resposta clara e acionável
[45–60s] CTA: Call to action direto — pede ação específica

RETORNE JSON VÁLIDO:
{
  "hook": "fala exata de abertura — primeiros 3 segundos",
  "script": [
    {
      "time": "0–3s",
      "label": "GANCHO",
      "fala": "texto exato da fala",
      "visual": "descrição do visual/câmera/B-roll",
      "texto_tela": "texto que aparece na tela ou vazio"
    }
  ],
  "caption": "legenda completa com emojis e hashtags",
  "hook_cta": "primeira linha da legenda",
  "hashtags": ["#tag1", "#tag2"],
  "duracao_estimada_segundos": 45
}`;
}

function buildPostInstructions(adapted: ViralAnalysis, hasImage: boolean): string {
  return `
TAREFA: Criar um POST ESTÁTICO para Instagram.

GANCHO ADAPTADO: "${adapted.adaptedHook}"
EMOÇÃO: ${adapted.emotion} | SCORE: ${adapted.viralScore}/100

${hasImage ? "IMAGEM DO USUÁRIO FORNECIDA — crie a legenda complementando esta imagem" : "Sem imagem — descreva a imagem ideal"}

RETORNE JSON VÁLIDO:
{
  "caption": "legenda completa (máx 300 chars antes do 'ver mais')",
  "hook_cta": "primeira linha da legenda",
  "image_notes": "o que a imagem deve mostrar / como complementar com texto",
  "hashtags": ["#tag1", "#tag2"]
}`;
}

// ── main ───────────────────────────────────────────────────────────────────

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SUPABASE_SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY);

    const authHeader = req.headers.get("Authorization");
    const body = await req.json();

    // Auth (optional for internal calls from cron/pipeline)
    let userId: string | null = null;
    if (authHeader) {
      const { data: { user } } = await supabase.auth.getUser(authHeader.replace("Bearer ", ""));
      userId = user?.id || null;
    }

    const {
      action = "build",
      analysis,           // ViralAnalysis object
      format = "carrossel", // carrossel | reel | post
      userMediaUrls = [], // Array<{type: "image"|"video", url: string, description?: string}>
      reelId,             // optional: load analysis from DB
      profileOverride,    // optional: override profile settings
      execute = false,    // if true, also calls generate-content and returns result
      aiProvider = "openrouter",
      aiModel = "google/gemini-2.5-flash",
    } = body;

    // ── BUILD action: just assemble the prompt ─────────────────────────────
    if (action === "build" || action === "build_and_execute") {

      // Load profile from pipeline_config
      let profile: UserProfile = {
        name: "@djairrotta",
        niche: "Advogado especialista em direito bancário — juros abusivos, defesa do consumidor, renegociação",
        toneOfVoice: "Direto, educativo, acessível. Fala com quem está endividado ou com problemas com banco.",
        targetAudience: "Adultos com dívidas, juros abusivos, problemas com bancos e cartões",
        hashtags: "#advogado #direitobancario #juroabusivo #bancario #consumidor",
      };

      if (userId) {
        const { data: cfg } = await supabase.from("pipeline_config")
          .select("instagram_username, niche_description, tone_of_voice, target_audience, default_hashtags")
          .eq("user_id", userId).maybeSingle();

        if (cfg) {
          profile = {
            name: `@${cfg.instagram_username || "djairrotta"}`,
            niche: cfg.niche_description || profile.niche,
            toneOfVoice: cfg.tone_of_voice || profile.toneOfVoice,
            targetAudience: cfg.target_audience || profile.targetAudience,
            hashtags: cfg.default_hashtags || profile.hashtags,
          };
        }
      }

      // Override with request payload
      if (profileOverride) Object.assign(profile, profileOverride);

      // Load analysis from DB if only reelId provided
      let resolvedAnalysis: ViralAnalysis | null = analysis || null;
      if (!resolvedAnalysis && reelId) {
        const { data: reel } = await supabase
          .from("reels_competidores").select("viral_analysis, viral_score, hook_analysis, adapted_hook, hook_type")
          .eq("id", reelId).maybeSingle();

        if (reel?.viral_analysis) {
          resolvedAnalysis = reel.viral_analysis as ViralAnalysis;
        } else if (reel) {
          // Build minimal analysis from DB fields
          resolvedAnalysis = {
            viralScore: reel.viral_score || 0,
            hook: reel.hook_analysis || "",
            hookType: reel.hook_type || "Curiosidade",
            structure: "",
            emotion: "",
            callToAction: "",
            whyViral: "",
            weakPoints: "",
            adaptedHook: reel.adapted_hook || reel.hook_analysis || "",
            contentIdeas: [],
            bestFormat: format as "reel" | "carrossel" | "post",
            estimatedReach: "médio",
          };
        }
      }

      if (!resolvedAnalysis) throw new Error("analysis ou reelId obrigatório");

      // Build system prompt
      const systemPrompt = buildSystemPrompt(profile, format);

      // Build format-specific user instructions
      const hasImage = userMediaUrls.some((m: any) => m.type === "image");
      const hasVideo = userMediaUrls.some((m: any) => m.type === "video");
      const mediaCount = userMediaUrls.length;

      let userInstructions = "";
      if (format === "carrossel") userInstructions = buildCarouselInstructions(resolvedAnalysis, mediaCount);
      else if (format === "reel") userInstructions = buildReelInstructions(resolvedAnalysis, hasVideo);
      else userInstructions = buildPostInstructions(resolvedAnalysis, hasImage);

      // Build media attachment descriptors
      const mediaAttachments = userMediaUrls.map((m: any, i: number) => ({
        type: m.type as "image" | "video",
        url: m.url,
        description: m.description || `${m.type === "image" ? "Imagem" : "Vídeo"} ${i + 1} do usuário`,
      }));

      const builtPrompt: BuiltPrompt = {
        system: systemPrompt,
        userText: userInstructions,
        mediaAttachments,
        fullPrompt: `SYSTEM:\n${systemPrompt}\n\nUSER:\n${userInstructions}`,
        format,
        estimatedTokens: countTokens(systemPrompt + userInstructions),
      };

      // Log to DB for audit/reuse
      if (userId) {
        try {
          await supabase.from("prompt_builder_log").insert({
            user_id: userId,
            format,
            reel_id: reelId || null,
            viral_score: resolvedAnalysis.viralScore,
            adapted_hook: resolvedAnalysis.adaptedHook,
            media_count: mediaCount,
            estimated_tokens: builtPrompt.estimatedTokens,
            prompt_system: systemPrompt.slice(0, 2000),
            prompt_user: userInstructions.slice(0, 4000),
          });
        } catch (_) { /* table may not exist yet — ok */ }
      }

      // ── EXECUTE: also call generate-content and return AI result ──────────
      if (action === "build_and_execute" || execute) {
        // Build multimodal message for AI
        const messages: any[] = [];

        if (mediaAttachments.length > 0) {
          // Multimodal: include images/video frames
          const parts: any[] = [{ type: "text", text: userInstructions }];
          for (const media of mediaAttachments) {
            if (media.type === "image") {
              parts.push({ type: "image_url", image_url: { url: media.url } });
            }
            // Note: video frames would require extracting as images; skip for now
          }
          messages.push({ role: "user", content: parts });
        } else {
          messages.push({ role: "user", content: userInstructions });
        }

        // Call generate-content function
        const genRes = await fetch(`${SUPABASE_URL}/functions/v1/generate-content`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${SUPABASE_SERVICE_KEY}`,
          },
          body: JSON.stringify({
            agent: format === "carrossel" ? "carousel_planner" : format === "reel" ? "script_writer" : "caption_writer",
            context: userInstructions,
            provider: aiProvider,
            model: aiModel,
            custom_prompt: systemPrompt,
            // Pass media separately for multimodal-capable providers
            media_urls: mediaAttachments.map(m => m.url),
          }),
        });

        const genData = await genRes.json();

        if (!genData.success) throw new Error(genData.error || "generate-content failed");

        // Parse JSON from AI response
        let parsedResult: any = null;
        try {
          const raw = (genData.result || "").replace(/```json|```/g, "").trim();
          parsedResult = JSON.parse(raw);
        } catch (_) {
          parsedResult = { raw: genData.result };
        }

        // Auto-queue if successfully parsed
        let queueId: string | null = null;
        if (parsedResult && userId && parsedResult.slides) {
          const { data: qi } = await supabase.from("publish_queue").insert({
            user_id: userId,
            content_type: "carousel",
            status: "pending_approval",
            caption: parsedResult.caption || "",
            carousel_slides: parsedResult.slides,
            viral_score: resolvedAnalysis.viralScore,
            source_reel_id: reelId || null,
            metadata: {
              adaptedHook: resolvedAnalysis.adaptedHook,
              hookType: resolvedAnalysis.hookType,
              profileName: profile.name,
              generatedBy: "build_and_execute",
              aiProvider,
              aiModel,
            },
          }).select("id").single();
          queueId = qi?.id || null;
        }

        return new Response(JSON.stringify({
          success: true,
          prompt: builtPrompt,
          result: parsedResult,
          rawResult: genData.result,
          queueId,
          provider: genData.provider,
          model: genData.model,
        }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      // Return just the prompt (build only)
      return new Response(JSON.stringify({ success: true, prompt: builtPrompt }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ── GET PROFILE: return current profile settings ───────────────────────
    if (action === "get_profile") {
      if (!userId) throw new Error("Authentication required");
      const { data: cfg } = await supabase.from("pipeline_config")
        .select("instagram_username, niche_description, tone_of_voice, target_audience, default_hashtags")
        .eq("user_id", userId).maybeSingle();
      return new Response(JSON.stringify({ success: true, profile: cfg }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ── UPDATE PROFILE ─────────────────────────────────────────────────────
    if (action === "update_profile") {
      if (!userId) throw new Error("Authentication required");
      const { niche_description, tone_of_voice, target_audience, default_hashtags } = body;
      await supabase.from("pipeline_config").upsert({
        user_id: userId,
        niche_description, tone_of_voice, target_audience, default_hashtags,
      }, { onConflict: "user_id" });
      return new Response(JSON.stringify({ success: true }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    throw new Error(`Unknown action: ${action}`);

  } catch (error) {
    console.error("build-content-prompt error:", error);
    return new Response(JSON.stringify({
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
