import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const IG_GRAPH_API = "https://graph.facebook.com/v21.0";

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) throw new Error("Authorization required");

    // Get user from JWT
    const { data: { user }, error: authError } = await supabase.auth.getUser(
      authHeader.replace("Bearer ", "")
    );
    if (authError || !user) throw new Error("Invalid auth token");

    const body = await req.json();
    const { action } = body;

    // Get Instagram credentials for this user
    const { data: creds } = await supabase
      .from("instagram_credentials")
      .select("*")
      .eq("user_id", user.id)
      .single();

    if (action === "verify_token") {
      // Verify token and get account info
      const { accessToken } = body;
      if (!accessToken) throw new Error("accessToken required");

      console.log("🔍 Verifying Instagram token...");

      // Get token info
      const debugRes = await fetch(
        `${IG_GRAPH_API}/debug_token?input_token=${accessToken}&access_token=${accessToken}`
      );
      const debugData = await debugRes.json();

      if (debugData.error) {
        throw new Error(debugData.error.message || "Invalid token");
      }

      // Get pages
      const pagesRes = await fetch(
        `${IG_GRAPH_API}/me/accounts?fields=id,name,instagram_business_account{id,username,profile_picture_url,followers_count}&access_token=${accessToken}`
      );
      const pagesData = await pagesRes.json();

      if (pagesData.error) {
        throw new Error(pagesData.error.message || "Failed to fetch pages");
      }

      // Find page with Instagram Business account
      const pageWithIg = pagesData.data?.find((p: any) => p.instagram_business_account);
      
      if (!pageWithIg) {
        return new Response(JSON.stringify({
          success: false,
          error: "Nenhuma conta Instagram Business encontrada. Certifique-se de que sua página do Facebook está conectada a uma conta Instagram Business/Creator.",
        }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const igAccount = pageWithIg.instagram_business_account;
      const scopes = debugData.data?.scopes || [];
      const expiresAt = debugData.data?.expires_at
        ? new Date(debugData.data.expires_at * 1000).toISOString()
        : null;

      // Save credentials
      const credData = {
        user_id: user.id,
        ig_user_id: igAccount.id,
        ig_username: igAccount.username,
        page_id: pageWithIg.id,
        access_token: accessToken,
        token_expires_at: expiresAt,
        permissions: scopes,
        is_connected: true,
        last_verified_at: new Date().toISOString(),
      };

      if (creds) {
        await supabase.from("instagram_credentials").update(credData).eq("id", creds.id);
      } else {
        await supabase.from("instagram_credentials").insert(credData);
      }

      console.log(`✅ Instagram connected: @${igAccount.username} (${igAccount.id})`);

      return new Response(JSON.stringify({
        success: true,
        account: {
          username: igAccount.username,
          id: igAccount.id,
          profilePicUrl: igAccount.profile_picture_url,
          followersCount: igAccount.followers_count,
          pageName: pageWithIg.name,
        },
        permissions: scopes,
        expiresAt,
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });

    } else if (action === "get_status") {
      if (!creds) {
        return new Response(JSON.stringify({ success: true, connected: false }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // Quick check if token is still valid
      const meRes = await fetch(
        `${IG_GRAPH_API}/${creds.ig_user_id}?fields=username,profile_picture_url,followers_count&access_token=${creds.access_token}`
      );
      const meData = await meRes.json();

      const isValid = !meData.error;
      if (!isValid) {
        await supabase.from("instagram_credentials").update({ is_connected: false }).eq("id", creds.id);
      }

      return new Response(JSON.stringify({
        success: true,
        connected: isValid,
        account: isValid ? {
          username: meData.username || creds.ig_username,
          id: creds.ig_user_id,
          profilePicUrl: meData.profile_picture_url,
          followersCount: meData.followers_count,
        } : null,
        tokenExpires: creds.token_expires_at,
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });

    } else if (action === "publish") {
      if (!creds || !creds.is_connected) {
        throw new Error("Instagram não conectado. Configure nas Configurações de API.");
      }

      const { queueId } = body;
      if (!queueId) throw new Error("queueId required");

      // Get queue item
      const { data: queueItem } = await supabase
        .from("publish_queue")
        .select("*")
        .eq("id", queueId)
        .eq("user_id", user.id)
        .single();

      if (!queueItem) throw new Error("Queue item not found");
      if (queueItem.status !== "approved") throw new Error("Item not approved for publishing");

      // Update status to publishing
      await supabase.from("publish_queue").update({ status: "publishing" }).eq("id", queueId);

      const accessToken = creds.access_token;
      const igUserId = creds.ig_user_id;

      try {
        let containerId: string;

        if (queueItem.content_type === "reel" && queueItem.video_url) {
          // Create reel container
          const createRes = await fetch(`${IG_GRAPH_API}/${igUserId}/media`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              media_type: "REELS",
              video_url: queueItem.video_url,
              caption: queueItem.caption || "",
              access_token: accessToken,
            }),
          });
          const createData = await createRes.json();
          if (createData.error) throw new Error(createData.error.message);
          containerId = createData.id;

        } else if (queueItem.content_type === "carousel" && queueItem.media_urls?.length > 0) {
          // Create carousel children first
          const childIds: string[] = [];
          for (const url of queueItem.media_urls) {
            const isVideo = url.includes(".mp4") || url.includes("video");
            const childRes = await fetch(`${IG_GRAPH_API}/${igUserId}/media`, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                ...(isVideo ? { media_type: "VIDEO", video_url: url } : { image_url: url }),
                is_carousel_item: true,
                access_token: accessToken,
              }),
            });
            const childData = await childRes.json();
            if (childData.error) throw new Error(childData.error.message);
            childIds.push(childData.id);
          }

          // Create carousel container
          const carouselRes = await fetch(`${IG_GRAPH_API}/${igUserId}/media`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              media_type: "CAROUSEL",
              children: childIds,
              caption: queueItem.caption || "",
              access_token: accessToken,
            }),
          });
          const carouselData = await carouselRes.json();
          if (carouselData.error) throw new Error(carouselData.error.message);
          containerId = carouselData.id;

        } else {
          // Single image post
          const imageUrl = queueItem.media_urls?.[0];
          if (!imageUrl) throw new Error("No media URL provided");
          
          const createRes = await fetch(`${IG_GRAPH_API}/${igUserId}/media`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              image_url: imageUrl,
              caption: queueItem.caption || "",
              access_token: accessToken,
            }),
          });
          const createData = await createRes.json();
          if (createData.error) throw new Error(createData.error.message);
          containerId = createData.id;
        }

        // Wait for media to be ready (for videos)
        if (queueItem.content_type === "reel" || queueItem.content_type === "carousel") {
          let ready = false;
          for (let attempt = 0; attempt < 30; attempt++) {
            await new Promise(r => setTimeout(r, 5000));
            const statusRes = await fetch(
              `${IG_GRAPH_API}/${containerId}?fields=status_code&access_token=${accessToken}`
            );
            const statusData = await statusRes.json();
            if (statusData.status_code === "FINISHED") { ready = true; break; }
            if (statusData.status_code === "ERROR") throw new Error("Media processing failed");
          }
          if (!ready) throw new Error("Media processing timeout");
        }

        // Publish the container
        const publishRes = await fetch(`${IG_GRAPH_API}/${igUserId}/media_publish`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            creation_id: containerId,
            access_token: accessToken,
          }),
        });
        const publishData = await publishRes.json();
        if (publishData.error) throw new Error(publishData.error.message);

        // Get permalink
        const mediaRes = await fetch(
          `${IG_GRAPH_API}/${publishData.id}?fields=permalink&access_token=${accessToken}`
        );
        const mediaData = await mediaRes.json();

        // Update queue
        await supabase.from("publish_queue").update({
          status: "published",
          published_at: new Date().toISOString(),
          ig_media_id: publishData.id,
          ig_permalink: mediaData.permalink || null,
        }).eq("id", queueId);

        console.log(`✅ Published to Instagram: ${publishData.id}`);

        return new Response(JSON.stringify({
          success: true,
          mediaId: publishData.id,
          permalink: mediaData.permalink,
        }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });

      } catch (pubError) {
        await supabase.from("publish_queue").update({
          status: "failed",
          error_message: pubError instanceof Error ? pubError.message : "Publishing failed",
        }).eq("id", queueId);
        throw pubError;
      }

    } else if (action === "disconnect") {
      if (creds) {
        await supabase.from("instagram_credentials").delete().eq("id", creds.id);
      }
      return new Response(JSON.stringify({ success: true }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });

    } else {
      throw new Error(`Unknown action: ${action}`);
    }
  } catch (error) {
    console.error("publish-instagram error:", error);
    return new Response(JSON.stringify({
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
