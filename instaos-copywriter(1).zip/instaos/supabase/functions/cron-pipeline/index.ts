import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    // Find all pipeline configs with cron enabled
    const { data: configs, error: configError } = await supabase
      .from("pipeline_config")
      .select("*")
      .eq("cron_enabled", true);

    if (configError) throw configError;
    if (!configs || configs.length === 0) {
      console.log("No cron-enabled pipelines found");
      return new Response(JSON.stringify({ success: true, message: "No pipelines to run" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const results: any[] = [];

    for (const config of configs) {
      const userId = config.user_id;
      console.log(`🕐 Cron pipeline for user ${userId} — processing ALL active competitors`);

      try {
        // Fetch active competitors for this user
        const { data: competitors } = await supabase
          .from("competidores")
          .select("id, name")
          .eq("status", true)
          .order("created_at", { ascending: true });

        if (!competitors || competitors.length === 0) {
          console.log(`⚠️ No active competitors for user ${userId}, skipping`);
          results.push({ user_id: userId, success: true, message: "No competitors" });
          continue;
        }

        console.log(`🎯 Processing ${competitors.length} active competitors sequentially (30s delay between each)`);

        let processedCount = 0;
        let failedCount = 0;

        for (let i = 0; i < competitors.length; i++) {
          const comp = competitors[i];

          // Delay between competitors (skip first one)
          if (i > 0) {
            console.log(`⏳ Waiting 30s before next competitor...`);
            await new Promise(r => setTimeout(r, 30000));
          }

          console.log(`🔄 [${i + 1}/${competitors.length}] Processing @${comp.name}...`);

          try {
            const pipelineRes = await fetch(`${SUPABASE_URL}/functions/v1/run-pipeline`, {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
              },
              body: JSON.stringify({
                user_id: userId,
                source: "cron",
                competitor_id: comp.id,
              }),
            });

            const pipelineData = await pipelineRes.json();

            if (pipelineData.success) {
              processedCount++;
              console.log(`✅ [${i + 1}/${competitors.length}] @${comp.name} completed (${pipelineData.logs?.length || 0} logs)`);
            } else {
              failedCount++;
              console.error(`❌ [${i + 1}/${competitors.length}] @${comp.name} failed: ${pipelineData.error || "unknown"}`);
            }
          } catch (compErr) {
            failedCount++;
            console.error(`❌ [${i + 1}/${competitors.length}] @${comp.name} error:`, compErr);
          }
        }

        // Always generate strategy report after processing all competitors
        if (processedCount > 0) {
          console.log(`📊 All competitors processed — triggering strategy report for user ${userId}...`);
          try {
            const reportRes = await fetch(`${SUPABASE_URL}/functions/v1/weekly-strategy-report`, {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
              },
              body: JSON.stringify({ user_id: userId }),
            });
            const reportData = await reportRes.json();
            console.log(`📊 Strategy report: ${reportData.success ? "✅" : "❌"} ${reportData.title || reportData.error || ""}`);
          } catch (e) {
            console.warn(`⚠️ Strategy report failed for user ${userId}:`, e);
          }
        }

        // Update last run timestamp
        await supabase
          .from("pipeline_config")
          .update({ cron_last_run: new Date().toISOString() })
          .eq("id", config.id);

        results.push({
          user_id: userId,
          success: true,
          competitors_processed: processedCount,
          competitors_failed: failedCount,
          total_competitors: competitors.length,
        });

        console.log(`✅ Cron completed: ${processedCount}/${competitors.length} competitors processed (${failedCount} failed)`);
      } catch (e) {
        console.error(`❌ Cron failed for user ${userId}:`, e);
        results.push({ user_id: userId, success: false, error: String(e) });
      }
    }

    return new Response(JSON.stringify({ success: true, results }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("cron-pipeline error:", error);
    return new Response(JSON.stringify({ success: false, error: error instanceof Error ? error.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
