import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
  const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");

  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

  try {
    const { user_id, batch_size = 20 } = await req.json();

    if (!user_id) {
      return new Response(JSON.stringify({ error: "user_id required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Load agent config for relevance_classifier
    const { data: classifierConfig } = await supabase
      .from("agent_configs")
      .select("provider, model, custom_prompt")
      .eq("user_id", user_id)
      .eq("agent_type", "relevance_classifier")
      .maybeSingle();

    const provider = classifierConfig?.provider || "lovable";
    const model = classifierConfig?.model || "google/gemini-2.5-flash-lite";
    const customPrompt = classifierConfig?.custom_prompt || null;

    // Load niche keywords
    const { data: nicheKwConfig } = await supabase
      .from("system_config")
      .select("config_value")
      .eq("user_id", user_id)
      .eq("config_key", "niche_keywords")
      .maybeSingle();

    const nicheKeywords: string[] = nicheKwConfig?.config_value
      ? nicheKwConfig.config_value.split(",").map((k: string) => k.trim().toLowerCase()).filter(Boolean)
      : [];

    // Load niche description
    const { data: nicheContext } = await supabase
      .from("system_config")
      .select("config_value")
      .eq("user_id", user_id)
      .eq("config_key", "niche_description")
      .maybeSingle();

    const nicheDesc = nicheContext?.config_value || "direito, advocacia, jurídico, leis, tribunal, justiça";

    // Get pending reels
    const { data: pendingReels } = await supabase
      .from("reels_competidores")
      .select("id, caption, owner_username, hook_analysis")
      .eq("user_id", user_id)
      .eq("relevance_status", "pending")
      .order("created_at", { ascending: false })
      .limit(Math.min(batch_size, 50));

    if (!pendingReels?.length) {
      return new Response(JSON.stringify({ 
        success: true, 
        classified: 0, 
        remaining: 0,
        message: "Nenhum reel pendente para classificar" 
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    console.log(`🏷️ Classifying ${pendingReels.length} pending reels...`);

    let classified = 0;
    let errors = 0;

    const systemPrompt = customPrompt || `Você é um classificador de relevância de conteúdo. O usuário trabalha no nicho de: ${nicheDesc}. Palavras-chave do nicho: ${nicheKeywords.join(", ") || "direito, advocacia, jurídico, lei, tribunal, justiça, advogado, OAB, processo, contrato"}.

Analise a caption do conteúdo e retorne APENAS um JSON com:
{"relevant": true/false, "score": 0-100, "reason": "motivo curto em português"}

Se o conteúdo NÃO é relacionado ao nicho do usuário, retorne relevant=false.`;

    // Process in batches of 5
    for (let i = 0; i < pendingReels.length; i += 5) {
      const batch = pendingReels.slice(i, i + 5);

      const results = await Promise.allSettled(
        batch.map(async (reel) => {
          const caption = (reel.caption || "").toLowerCase();
          const hookAnalysis = (reel.hook_analysis || "").toLowerCase();
          const allText = `${caption} ${hookAnalysis} ${reel.owner_username || ""}`;

          // Quick keyword check first
          if (nicheKeywords.length > 0) {
            const keywordMatch = nicheKeywords.some(k => allText.includes(k));
            if (keywordMatch) {
              await supabase.from("reels_competidores").update({
                relevance_status: "approved",
                relevance_score: 80,
                relevance_reason: "Palavra-chave do nicho encontrada",
              }).eq("id", reel.id);
              console.log(`✅ ${reel.id} approved by keyword`);
              return;
            }
          }

          // AI classification
          if (provider === "lovable" && LOVABLE_API_KEY) {
            const aiRes = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
              method: "POST",
              headers: { "Authorization": `Bearer ${LOVABLE_API_KEY}`, "Content-Type": "application/json" },
              body: JSON.stringify({
                model,
                messages: [
                  { role: "system", content: systemPrompt },
                  { role: "user", content: `Caption: ${(reel.caption || "").slice(0, 500)}\nAutor: @${reel.owner_username || "desconhecido"}` },
                ],
              }),
            });

            if (!aiRes.ok) {
              if (aiRes.status === 429) {
                console.log(`⏳ Rate limited, waiting...`);
                await new Promise(r => setTimeout(r, 5000));
              }
              throw new Error(`AI error: ${aiRes.status}`);
            }

            const aiData = await aiRes.json();
            const aiText = aiData?.choices?.[0]?.message?.content || "";
            const jsonMatch = aiText.match(/\{[\s\S]*\}/);

            if (jsonMatch) {
              const parsed = JSON.parse(jsonMatch[0]);
              const status = parsed.relevant ? "approved" : "rejected";
              const score = Math.min(100, Math.max(0, parsed.score || 0));

              await supabase.from("reels_competidores").update({
                relevance_status: status,
                relevance_score: score,
                relevance_reason: parsed.reason || (parsed.relevant ? "Relevante ao nicho" : "Fora do nicho"),
              }).eq("id", reel.id);

              console.log(`🏷️ ${reel.id} → ${status} (${score}) - ${parsed.reason}`);
            }
          } else {
            // Use generate-content for other providers
            const genRes = await fetch(`${SUPABASE_URL}/functions/v1/generate-content`, {
              method: "POST",
              headers: { "Content-Type": "application/json", "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
              body: JSON.stringify({
                agent: "relevance_classifier",
                context: `Caption: ${(reel.caption || "").slice(0, 500)}\nAutor: @${reel.owner_username || "desconhecido"}`,
                provider,
                model,
                custom_prompt: systemPrompt,
              }),
            });

            const genData = await genRes.json();
            if (genData?.success && genData.result) {
              const jsonMatch = genData.result.match(/\{[\s\S]*\}/);
              if (jsonMatch) {
                const parsed = JSON.parse(jsonMatch[0]);
                const status = parsed.relevant ? "approved" : "rejected";
                const score = Math.min(100, Math.max(0, parsed.score || 0));

                await supabase.from("reels_competidores").update({
                  relevance_status: status,
                  relevance_score: score,
                  relevance_reason: parsed.reason || (parsed.relevant ? "Relevante ao nicho" : "Fora do nicho"),
                }).eq("id", reel.id);

                console.log(`🏷️ ${reel.id} → ${status} (${score})`);
              }
            }
          }
        })
      );

      classified += results.filter(r => r.status === "fulfilled").length;
      errors += results.filter(r => r.status === "rejected").length;

      // Small delay between batches to avoid rate limits
      if (i + 5 < pendingReels.length) {
        await new Promise(r => setTimeout(r, 1000));
      }
    }

    // Count remaining
    const { count: remaining } = await supabase
      .from("reels_competidores")
      .select("id", { count: "exact", head: true })
      .eq("user_id", user_id)
      .eq("relevance_status", "pending");

    console.log(`✅ Classified: ${classified}, Errors: ${errors}, Remaining: ${remaining}`);

    return new Response(JSON.stringify({
      success: true,
      classified,
      errors,
      remaining: remaining || 0,
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("Classification error:", err);
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
