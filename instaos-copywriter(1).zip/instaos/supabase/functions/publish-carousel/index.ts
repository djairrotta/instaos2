import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const IG_API = "https://graph.facebook.com/v21.0";

// ── helpers ────────────────────────────────────────────────────────────────

function sleep(ms: number) { return new Promise(r => setTimeout(r, ms)); }

async function waitForContainer(containerId: string, accessToken: string, maxAttempts = 40): Promise<void> {
  for (let i = 0; i < maxAttempts; i++) {
    await sleep(4000);
    const r = await fetch(`${IG_API}/${containerId}?fields=status_code,status&access_token=${accessToken}`);
    const d = await r.json();
    if (d.status_code === "FINISHED") return;
    if (d.status_code === "ERROR") throw new Error(`Container ${containerId} failed: ${d.status}`);
    console.log(`Container ${containerId}: ${d.status_code} (attempt ${i + 1}/${maxAttempts})`);
  }
  throw new Error("Container processing timeout after 160s");
}

// ── main ───────────────────────────────────────────────────────────────────

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SUPABASE_SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY);

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) throw new Error("Authorization required");

    const { data: { user }, error: authErr } = await supabase.auth.getUser(authHeader.replace("Bearer ", ""));
    if (authErr || !user) throw new Error("Invalid auth token");

    const body = await req.json();
    const { action } = body;

    // ── GET STATUS ─────────────────────────────────────────────────────────
    if (action === "get_status") {
      const { data: creds } = await supabase
        .from("instagram_credentials").select("*").eq("user_id", user.id).maybeSingle();
      return new Response(JSON.stringify({ success: true, connected: !!creds?.is_connected, account: creds }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ── VALIDATE SLIDES ────────────────────────────────────────────────────
    if (action === "validate") {
      const { slides } = body;
      if (!Array.isArray(slides) || slides.length < 2) throw new Error("Carrossel precisa de pelo menos 2 slides");
      if (slides.length > 10) throw new Error("Carrossel suporta no máximo 10 slides");

      const errors: string[] = [];
      slides.forEach((s: any, i: number) => {
        if (!s.image_url && !s.rendered_url) errors.push(`Slide ${i + 1}: sem imagem`);
        if (s.text && s.text.length > 2200) errors.push(`Slide ${i + 1}: texto muito longo`);
      });

      return new Response(JSON.stringify({ success: errors.length === 0, errors }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ── PUBLISH CAROUSEL ───────────────────────────────────────────────────
    if (action === "publish") {
      const { queueId, slides, caption, dryRun = false } = body;

      // Get credentials
      const { data: creds } = await supabase
        .from("instagram_credentials").select("*").eq("user_id", user.id).maybeSingle();
      if (!creds?.is_connected) throw new Error("Instagram não conectado. Configure nas Integrações.");

      const { access_token: token, ig_user_id: igId } = creds;

      // Resolve slides from queue item OR direct payload
      let resolvedSlides: Array<{ image_url: string; is_video?: boolean; video_url?: string }> = [];

      if (queueId) {
        const { data: qi } = await supabase
          .from("publish_queue").select("*").eq("id", queueId).eq("user_id", user.id).single();
        if (!qi) throw new Error("Item da fila não encontrado");
        if (qi.status !== "approved") throw new Error("Item precisa estar aprovado antes de publicar");

        // carousel_slides may be structured slide objects or plain media_urls
        if (qi.carousel_slides && Array.isArray(qi.carousel_slides)) {
          resolvedSlides = qi.carousel_slides.map((s: any) => ({
            image_url: s.rendered_url || s.image_url || s.url || s,
            is_video: s.is_video || false,
            video_url: s.video_url,
          }));
        } else if (qi.media_urls && Array.isArray(qi.media_urls)) {
          resolvedSlides = qi.media_urls.map((url: string) => ({ image_url: url }));
        }

        // Update status
        if (!dryRun) {
          await supabase.from("publish_queue").update({ status: "publishing" }).eq("id", queueId);
        }
      } else if (Array.isArray(slides)) {
        resolvedSlides = slides;
      }

      if (resolvedSlides.length < 2) throw new Error("Carrossel precisa de pelo menos 2 imagens");
      if (resolvedSlides.length > 10) throw new Error("Carrossel suporta no máximo 10 slides");

      console.log(`🎠 Publishing carousel: ${resolvedSlides.length} slides | dry_run=${dryRun}`);

      if (dryRun) {
        return new Response(JSON.stringify({
          success: true, dryRun: true,
          message: `Dry run OK — ${resolvedSlides.length} slides válidos`,
          slides: resolvedSlides,
        }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      // Step 1: Create child containers (one per slide)
      const childIds: string[] = [];
      for (let i = 0; i < resolvedSlides.length; i++) {
        const slide = resolvedSlides[i];
        const url = slide.image_url || slide.video_url;
        if (!url) throw new Error(`Slide ${i + 1}: URL de mídia ausente`);

        const isVideo = slide.is_video || (url.includes(".mp4") || url.includes("video"));
        const childBody: Record<string, unknown> = {
          is_carousel_item: true,
          access_token: token,
        };

        if (isVideo) {
          childBody.media_type = "VIDEO";
          childBody.video_url = url;
        } else {
          childBody.image_url = url;
        }

        console.log(`  Creating child ${i + 1}/${resolvedSlides.length}: ${isVideo ? "video" : "image"}`);

        const childRes = await fetch(`${IG_API}/${igId}/media`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(childBody),
        });
        const childData = await childRes.json();
        if (childData.error) throw new Error(`Slide ${i + 1} falhou: ${childData.error.message}`);

        childIds.push(childData.id);
        console.log(`  ✓ Child ${i + 1} created: ${childData.id}`);

        // Small delay to avoid rate limits
        if (i < resolvedSlides.length - 1) await sleep(800);
      }

      // Step 2: Create carousel container
      console.log(`Creating carousel container with ${childIds.length} children...`);
      const carouselRes = await fetch(`${IG_API}/${igId}/media`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          media_type: "CAROUSEL",
          children: childIds,
          caption: (caption || "").slice(0, 2200),
          access_token: token,
        }),
      });
      const carouselData = await carouselRes.json();
      if (carouselData.error) throw new Error(`Container carrossel: ${carouselData.error.message}`);
      const containerId = carouselData.id;
      console.log(`Carousel container created: ${containerId}`);

      // Step 3: Wait for processing
      console.log("Waiting for container processing...");
      await waitForContainer(containerId, token);

      // Step 4: Publish
      console.log("Publishing...");
      const publishRes = await fetch(`${IG_API}/${igId}/media_publish`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ creation_id: containerId, access_token: token }),
      });
      const publishData = await publishRes.json();
      if (publishData.error) throw new Error(`Publicação: ${publishData.error.message}`);

      // Step 5: Get permalink
      const permalinkRes = await fetch(
        `${IG_API}/${publishData.id}?fields=permalink,timestamp&access_token=${token}`
      );
      const permalinkData = await permalinkRes.json();
      const permalink = permalinkData.permalink || null;

      // Step 6: Update queue
      if (queueId) {
        await supabase.from("publish_queue").update({
          status: "published",
          published_at: new Date().toISOString(),
          ig_media_id: publishData.id,
          ig_permalink: permalink,
        }).eq("id", queueId);
      }

      // Step 7: Log to published_posts if table exists
      try {
        await supabase.from("published_posts").insert({
          user_id: user.id,
          ig_media_id: publishData.id,
          ig_permalink: permalink,
          content_type: "carousel",
          caption: (caption || "").slice(0, 2200),
          slides_count: resolvedSlides.length,
          queue_id: queueId || null,
          published_at: new Date().toISOString(),
        });
      } catch (_) { /* table may not exist yet — ok */ }

      console.log(`✅ Carousel published: ${publishData.id} | ${permalink}`);

      return new Response(JSON.stringify({
        success: true,
        mediaId: publishData.id,
        permalink,
        slidesCount: resolvedSlides.length,
      }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // ── QUEUE CAROUSEL ─────────────────────────────────────────────────────
    // Saves generated carousel content to publish_queue with pending_approval status
    if (action === "queue") {
      const {
        title, caption, slides, viralScore = 0,
        sourceReelId, adaptedHook, hookType,
        profileName, generatedBy = "manual",
      } = body;

      if (!Array.isArray(slides) || slides.length === 0) throw new Error("slides required");

      const { data: qi, error: qErr } = await supabase.from("publish_queue").insert({
        user_id: user.id,
        content_type: "carousel",
        status: "pending_approval",
        caption: caption || "",
        carousel_slides: slides,
        viral_score: viralScore,
        source_reel_id: sourceReelId || null,
        metadata: { title, adaptedHook, hookType, profileName, generatedBy },
      }).select().single();

      if (qErr) throw qErr;

      return new Response(JSON.stringify({ success: true, queueId: qi.id, status: "pending_approval" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ── LIST QUEUE ─────────────────────────────────────────────────────────
    if (action === "list_queue") {
      const { status = "pending_approval", limit = 20 } = body;
      const { data } = await supabase
        .from("publish_queue")
        .select("*")
        .eq("user_id", user.id)
        .eq("content_type", "carousel")
        .in("status", Array.isArray(status) ? status : [status])
        .order("created_at", { ascending: false })
        .limit(limit);

      return new Response(JSON.stringify({ success: true, items: data || [] }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ── APPROVE / REJECT ───────────────────────────────────────────────────
    if (action === "approve" || action === "reject") {
      const { queueId, notes } = body;
      if (!queueId) throw new Error("queueId required");

      const newStatus = action === "approve" ? "approved" : "rejected";
      const { error: upErr } = await supabase
        .from("publish_queue")
        .update({ status: newStatus, ...(notes ? { error_message: notes } : {}) })
        .eq("id", queueId)
        .eq("user_id", user.id);

      if (upErr) throw upErr;

      return new Response(JSON.stringify({ success: true, queueId, status: newStatus }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    throw new Error(`Unknown action: ${action}`);

  } catch (error) {
    console.error("publish-carousel error:", error);
    return new Response(JSON.stringify({
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
