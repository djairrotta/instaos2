import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: cors });

  try {
    const SUPA_URL = Deno.env.get("SUPABASE_URL")!;
    const SUPA_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(SUPA_URL, SUPA_KEY);

    const auth = req.headers.get("Authorization") || "";
    const { data: { user } } = await supabase.auth.getUser(auth.replace("Bearer ", ""));
    if (!user) throw new Error("Auth required");

    const body = await req.json();
    const { action = "research" } = body;

    // ── RESEARCH: domain research brief ───────────────────────────────────
    if (action === "research") {
      const {
        topic,
        niche = "direito bancário e advocacia",
        timeRange = "últimos 6 meses",
        depth = "medium", // light | medium | deep
      } = body;

      if (!topic) throw new Error("topic required");

      const researchPrompt = `## FORMAT: Research & Data Collection
### Core Rules
- Source verification FIRST — every factual claim needs 2+ independent sources
- Confidence levels mandatory: HIGH (3+ sources) / MEDIUM (2 sources) / LOW (1 source)
- Primary over secondary — original reports > blog posts
- ALL 5 sections mandatory

Você é Ângela Ângulo — pesquisadora especialista em curadoria de informações para criação de conteúdo.

## Tarefa
Pesquise o tema abaixo e produza um research brief completo e estruturado.

**Tema:** ${topic}
**Nicho:** ${niche}
**Período:** ${timeRange}
**Profundidade:** ${depth}

## Output Structure (TODOS os 5 blocos obrigatórios)

### KEY FINDINGS
Liste 5-8 fatos concretos com dados verificáveis. Para cada:
- Afirmação factual precisa
- Dado específico (número, percentual, data)
- Fonte identificável
- Confidence: HIGH / MEDIUM / LOW

### TRENDING ANGLES
Liste 3-5 ângulos de conteúdo com potencial viral baseados nos fatos:
- Nome do ângulo
- Hook rascunho para Instagram
- Ciclo: emergente / crescimento / maduro / declinando
- Potencial de engajamento: 1-10

### SOURCES TABLE
| # | Fonte | Tipo | Relevância (1-10) | Data |
Para cada fato do Key Findings.

### RECOMMENDATIONS
3-5 recomendações acionáveis para criação de conteúdo baseadas nos dados.
Cada recomendação: formato sugerido + plataforma + prazo de oportunidade.

### GAPS
O que NÃO foi possível encontrar ou verificar. Documentar blind spots é obrigatório.

Retorne a análise completa em PT-BR.`;

      const res = await fetch(`${SUPA_URL}/functions/v1/generate-content`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPA_KEY}` },
        body: JSON.stringify({
          agent: "content_strategist",
          context: researchPrompt,
          provider: "openrouter",
          model: "google/gemini-2.5-flash-preview-05-20",
          format: "researching",
        }),
      });
      const data = await res.json();
      const brief = data.result || "";

      // Parse trending angles for content suggestions
      const angles = extractAngles(brief);

      // Save to DB
      const { data: saved } = await supabase
        .from("research_briefs")
        .insert({
          user_id: user.id,
          topic,
          niche,
          time_range: timeRange,
          depth,
          brief,
          angles,
          status: "completed",
        })
        .select()
        .single();

      return new Response(JSON.stringify({
        success: true,
        briefId: saved?.id,
        brief,
        angles,
        topic,
      }), { headers: { ...cors, "Content-Type": "application/json" } });
    }

    // ── SUGGEST TOPICS: AI suggests research topics based on niche ─────────
    if (action === "suggest_topics") {
      const { niche = "direito bancário", recentPosts = [] } = body;

      const prompt = `Você é um estrategista de conteúdo especialista em ${niche}.

Sugira 8 tópicos de pesquisa com alto potencial viral para criar conteúdo no Instagram.
Cada tópico deve: ser atual, ter dados verificáveis, ser relevante para o público do nicho.

Posts recentes do perfil (para evitar repetição):
${recentPosts.slice(0, 5).map((p: any) => `- ${p.caption?.slice(0, 60)}`).join("\n") || "Nenhum disponível"}

Retorne JSON:
{
  "topics": [
    {
      "topic": "título do tópico de pesquisa",
      "why": "por que tem potencial viral",
      "hook_hint": "gancho provável para o conteúdo",
      "urgency": "alta|média|baixa",
      "format_suggestion": "carrossel|reel|post"
    }
  ]
}`;

      const res = await fetch(`${SUPA_URL}/functions/v1/generate-content`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPA_KEY}` },
        body: JSON.stringify({ agent: "idea_generator", context: prompt, provider: "openrouter", model: "google/gemini-2.5-flash-preview-05-20" }),
      });
      const data = await res.json();
      let topics: any[] = [];
      try { topics = JSON.parse((data.result || "").replace(/```json|```/g, "").trim()).topics || []; } catch (_) {}

      return new Response(JSON.stringify({ success: true, topics }), {
        headers: { ...cors, "Content-Type": "application/json" },
      });
    }

    // ── LIST past briefs ───────────────────────────────────────────────────
    if (action === "list") {
      const { data } = await supabase
        .from("research_briefs")
        .select("id,topic,niche,status,created_at,angles")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(20);
      return new Response(JSON.stringify({ success: true, briefs: data || [] }), {
        headers: { ...cors, "Content-Type": "application/json" },
      });
    }

    // ── GET one brief ──────────────────────────────────────────────────────
    if (action === "get") {
      const { briefId } = body;
      const { data } = await supabase
        .from("research_briefs")
        .select("*")
        .eq("id", briefId)
        .eq("user_id", user.id)
        .single();
      return new Response(JSON.stringify({ success: true, brief: data }), {
        headers: { ...cors, "Content-Type": "application/json" },
      });
    }

    throw new Error(`Unknown action: ${action}`);
  } catch (e) {
    console.error("research-agent:", e);
    return new Response(JSON.stringify({ success: false, error: (e as Error).message }), {
      status: 500, headers: { ...cors, "Content-Type": "application/json" },
    });
  }
});

function extractAngles(brief: string): any[] {
  const angles: any[] = [];
  const lines = brief.split("\n");
  let inAngles = false;
  let current: any = null;

  for (const line of lines) {
    if (line.includes("TRENDING ANGLES") || line.includes("ÂNGULOS")) { inAngles = true; continue; }
    if (line.includes("SOURCES") || line.includes("FONTES") || line.includes("RECOMMENDATIONS")) inAngles = false;

    if (inAngles && line.trim().startsWith("-")) {
      if (current) angles.push(current);
      current = { name: line.replace(/^-+\s*/, "").trim(), hook: "", lifecycle: "growth", score: 7 };
    } else if (inAngles && current && line.includes("Hook")) {
      current.hook = line.replace(/.*Hook.*:/i, "").trim();
    } else if (inAngles && current && line.match(/emergente|crescimento|maduro|declinando/i)) {
      current.lifecycle = line.match(/emergente|crescimento|maduro|declinando/i)?.[0]?.toLowerCase() || "growth";
    }
  }
  if (current) angles.push(current);
  return angles.slice(0, 5);
}
