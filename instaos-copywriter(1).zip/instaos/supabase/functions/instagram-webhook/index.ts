import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const IG_GRAPH_API = "https://graph.facebook.com/v21.0";

serve(async (req) => {
  // CORS preflight
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const VERIFY_TOKEN = Deno.env.get("INSTAGRAM_WEBHOOK_VERIFY_TOKEN");
  const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
  const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

  // ========== GET: Webhook verification (Meta sends this on setup) ==========
  if (req.method === "GET") {
    const url = new URL(req.url);
    const mode = url.searchParams.get("hub.mode");
    const token = url.searchParams.get("hub.verify_token");
    const challenge = url.searchParams.get("hub.challenge");

    console.log(`Webhook verification: mode=${mode}, token=${token}`);

    if (mode === "subscribe" && token === VERIFY_TOKEN) {
      console.log("✅ Webhook verified successfully");
      return new Response(challenge, { status: 200 });
    }

    console.error("❌ Webhook verification failed");
    return new Response("Forbidden", { status: 403 });
  }

  // ========== POST: Incoming webhook events ==========
  if (req.method === "POST") {
    try {
      const body = await req.json();
      console.log("📩 Webhook received:", JSON.stringify(body).slice(0, 500));

      // Meta sends a specific structure for Instagram messaging
      if (body.object !== "instagram") {
        console.log("Ignoring non-Instagram webhook:", body.object);
        return new Response("OK", { status: 200 });
      }

      const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

      for (const entry of body.entry || []) {
        // Handle both formats: entry.messaging (DMs) and entry.changes (webhook events)
        let messagingEvents = entry.messaging || [];
        
        // If no messaging array, check for changes format
        if (messagingEvents.length === 0 && entry.changes) {
          for (const change of entry.changes) {
            if (change.field === "messages" && change.value) {
              const val = change.value;
              messagingEvents.push({
                sender: val.sender,
                recipient: val.recipient,
                message: val.message,
              });
            }
          }
        }

        console.log(`📨 Processing ${messagingEvents.length} messaging events from entry`);

      for (const messaging of messagingEvents) {
          const senderId = messaging.sender?.id;
          const recipientId = messaging.recipient?.id;
          const messageText = messaging.message?.text || "";
          const attachments = messaging.message?.attachments || [];

          if (!senderId) continue;

          // Only process messages from allowed sender (djair.rotta) or self-sent
          const isSelfSent = senderId === recipientId;
          
          console.log(`💬 DM from ${senderId} to ${recipientId} (self=${isSelfSent})`);

          // Find which user owns this IG account (recipientId = ig_user_id)
          const { data: creds } = await supabase
            .from("instagram_credentials")
            .select("user_id, access_token, ig_user_id, ig_username")
            .eq("ig_user_id", recipientId)
            .eq("is_connected", true)
            .maybeSingle();

          if (!creds) {
            console.error(`No credentials found for IG user ${recipientId}`);
            continue;
          }

          // Check allowed senders from DB whitelist
          const { data: allowedList } = await supabase
            .from("allowed_senders")
            .select("ig_username")
            .eq("user_id", creds.user_id)
            .eq("is_active", true);

          const allowedUsernames = (allowedList || []).map((a: any) => a.ig_username.toLowerCase());

          // Look up sender's IG username  
          const { data: senderCreds } = await supabase
            .from("instagram_credentials")
            .select("ig_username")
            .eq("ig_user_id", senderId)
            .maybeSingle();

          const senderUsername = (senderCreds?.ig_username || "").toLowerCase();
          const isAllowedSender = isSelfSent || allowedUsernames.includes(senderUsername);

          if (!isAllowedSender) {
            console.log(`⏭️ Ignoring DM from non-allowed sender: ${senderId} (${senderUsername}). Allowed: ${allowedUsernames.join(", ")}`);
            continue;
          }

          // Collect Instagram links from text AND attachments
          const igLinks: InstagramLink[] = [];

          // Extract from text
          if (messageText) {
            igLinks.push(...extractInstagramLinks(messageText));
          }

          // Extract from attachments (shared reels/posts come as attachments)
          for (const attachment of attachments) {
            const attachUrl = attachment.payload?.url || "";
            console.log(`📎 Attachment type=${attachment.type}, url=${attachUrl.slice(0, 200)}`);
            
            if (attachUrl && attachUrl.includes("instagram.com")) {
              igLinks.push(...extractInstagramLinks(attachUrl));
            }
            
            // Instagram shares reels as type "ig_reel" or generic with IG URL
            if (attachment.type === "ig_reel" || attachment.type === "share") {
              const shareUrl = attachment.payload?.url || attachment.url || "";
              if (shareUrl && !igLinks.some(l => l.url === shareUrl)) {
                igLinks.push(...extractInstagramLinks(shareUrl));
              }
            }
          }

          if (igLinks.length === 0) {
            console.log("No Instagram links found in message or attachments");
            await sendInstagramReply(
              recipientId,
              senderId,
              "❌ Nenhum reel/post do Instagram encontrado. Compartilhe um reel diretamente na DM.",
              supabase
            );
            continue;
          }

          // Process each link
          for (const link of igLinks) {
            console.log(`🔗 Processing link: ${link.url} (type: ${link.type})`);

            try {
              const processRes = await fetch(
                `${SUPABASE_URL}/functions/v1/process-instagram-link`,
                {
                  method: "POST",
                  headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
                  },
                  body: JSON.stringify({
                    url: link.url,
                    type: link.type,
                    user_id: creds.user_id,
                  }),
                }
              );

              const processData = await processRes.json();

              if (processData.success) {
                const emoji = link.type === "profile" ? "👤" : "📹";
                const msg = link.type === "profile"
                  ? `${emoji} Competidor @${processData.username || link.username} adicionado! ✅\n\n📊 ${processData.followers || 0} seguidores`
                  : `${emoji} Reel de @${processData.username || link.username} salvo! ✅\n\n❤️ ${processData.likes || 0} likes | 👁️ ${processData.views || 0} views`;

                await sendInstagramReply(recipientId, senderId, msg, supabase);
              } else {
                await sendInstagramReply(
                  recipientId,
                  senderId,
                  `⚠️ Erro ao processar: ${processData.error || "Erro desconhecido"}`,
                  supabase
                );
              }
            } catch (e) {
              console.error(`Error processing link ${link.url}:`, e);
              await sendInstagramReply(
                recipientId,
                senderId,
                `❌ Erro: ${e instanceof Error ? e.message : "Erro desconhecido"}`,
                supabase
              );
            }
          }
        }
      }

      // Always return 200 to Meta quickly
      return new Response("OK", { status: 200, headers: corsHeaders });
    } catch (error) {
      console.error("Webhook error:", error);
      // Must return 200 to avoid Meta retrying
      return new Response("OK", { status: 200 });
    }
  }

  return new Response("Method not allowed", { status: 405 });
});

// ========== Helper Functions ==========

interface InstagramLink {
  url: string;
  type: "profile" | "reel" | "post";
  username?: string;
}

function extractInstagramLinks(text: string): InstagramLink[] {
  const links: InstagramLink[] = [];

  // Match Instagram URLs
  const urlRegex = /https?:\/\/(?:www\.)?instagram\.com\/([^\s?#]+)/gi;
  let match;

  while ((match = urlRegex.exec(text)) !== null) {
    const path = match[1].replace(/\/$/, ""); // Remove trailing slash
    const fullUrl = match[0].split(/[\s?#]/)[0]; // Clean URL

    if (path.startsWith("reel/") || path.startsWith("reels/")) {
      links.push({ url: fullUrl, type: "reel", username: undefined });
    } else if (path.startsWith("p/")) {
      links.push({ url: fullUrl, type: "post", username: undefined });
    } else if (path.startsWith("stories/")) {
      // Stories - treat as post
      const storyUser = path.split("/")[1];
      links.push({ url: fullUrl, type: "post", username: storyUser });
    } else if (!path.includes("/") || path.endsWith("/")) {
      // Profile URL: instagram.com/username
      const username = path.split("/")[0];
      if (username && !["explore", "accounts", "direct", "about", "legal", "developer"].includes(username)) {
        links.push({ url: fullUrl, type: "profile", username });
      }
    }
  }

  // Also match plain @username mentions
  const mentionRegex = /@([a-zA-Z0-9_.]{1,30})/g;
  while ((match = mentionRegex.exec(text)) !== null) {
    const username = match[1];
    // Only add if no URL for this user was already found
    if (!links.some(l => l.username === username)) {
      links.push({
        url: `https://www.instagram.com/${username}/`,
        type: "profile",
        username,
      });
    }
  }

  return links;
}

async function sendInstagramReply(
  pageIgUserId: string,
  recipientId: string,
  message: string,
  supabase: any
) {
  try {
    // Get the access token for this IG account
    const { data: creds } = await supabase
      .from("instagram_credentials")
      .select("access_token, page_id")
      .eq("ig_user_id", pageIgUserId)
      .eq("is_connected", true)
      .maybeSingle();

    if (!creds?.access_token || !creds?.page_id) {
      console.error("Cannot reply: no credentials found");
      return;
    }

    // Instagram DM reply uses the Page ID, not the IG User ID
    const res = await fetch(`${IG_GRAPH_API}/${creds.page_id}/messages`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        recipient: { id: recipientId },
        message: { text: message },
        access_token: creds.access_token,
      }),
    });

    const data = await res.json();
    if (data.error) {
      console.error("DM reply error:", data.error);
    } else {
      console.log("✅ DM reply sent successfully");
    }
  } catch (e) {
    console.error("sendInstagramReply error:", e);
  }
}
