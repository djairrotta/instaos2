import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// The 6 tones from OpenSquad's tone-of-voice system
const SIX_TONES = [
  {
    id: "revelador",
    name: "Tom 1: Revelador",
    description: "Expõe algo que o leitor não sabia. Dado surpreendente → contexto → implicação → reflexão",
    hook_pattern: "X% das pessoas que fazem [ação] não sabem que [consequência].",
    best_for: "Dados contraintuitivos, estatísticas chocantes, revelações de bastidores",
    example_opening: "Dado real surpreendente → Por que isso acontece → Impacto para o leitor → Pergunta reflexiva",
  },
  {
    id: "comparativo",
    name: "Tom 2: Comparativo",
    description: "Contrasta duas realidades. Cenário A vs Cenário B → diferença em dados → o que fazer",
    hook_pattern: "A diferença entre [quem usa X] e [quem não usa]: [resultado concreto].",
    best_for: "Mudanças de mercado, antes/depois, perfis diferentes na mesma situação",
    example_opening: "Duas pessoas, mesma função — resultados completamente diferentes.",
  },
  {
    id: "passo_a_passo",
    name: "Tom 3: Passo a Passo",
    description: "Tutorial didático puro. Problema → N passos numerados → resultado esperado → CTA",
    hook_pattern: "Você não precisa de [recurso difícil] pra fazer isso. São [N] passos.",
    best_for: "Guias práticos, tutoriais, processos, métodos replicáveis",
    example_opening: "Como fazer [resultado] em [N] passos — sem precisar de [obstáculo].",
  },
  {
    id: "pergunta_incomoda",
    name: "Tom 4: Pergunta Incômoda",
    description: "Provoca e desafia crença comum. Pergunta → dados → nuance → nova perspectiva",
    hook_pattern: "Por que você ainda acredita que [crença desatualizada]?",
    best_for: "Mitos do setor, crenças limitantes, posições contraintuitivas",
    example_opening: "Por que você ainda [faz/acredita em X] quando [evidência contrária]?",
  },
  {
    id: "tendencia_oportunidade",
    name: "Tom 5: Tendência + Oportunidade",
    description: "Movimento de mercado + janela de ação. Evidência → velocidade → quem aproveita → o que fazer",
    hook_pattern: "Isso mudou em [período]. A maioria das pessoas ainda não percebeu.",
    best_for: "Mudanças de mercado, novas tecnologias, momentos de transição",
    example_opening: "Em [período], [X] mudou completamente. Quem percebeu primeiro ganhou [vantagem].",
  },
  {
    id: "checklist_diagnostico",
    name: "Tom 6: Checklist / Diagnóstico",
    description: "Auto-avaliação guiada. Critérios → análise → diagnóstico → próximo passo",
    hook_pattern: "Você está no nível certo de [área]? [N] critérios para descobrir.",
    best_for: "Avaliações, auditorias, checklists de qualidade, diagnósticos",
    example_opening: "[N] sinais de que você já está [acima/abaixo da média] em [área].",
  },
];

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: cors });

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SERVICE_KEY  = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase     = createClient(SUPABASE_URL, SERVICE_KEY);

    const authHeader = req.headers.get("Authorization") || "";
    const { data: { user } } = await supabase.auth.getUser(authHeader.replace("Bearer ", ""));
    if (!user) throw new Error("Auth required");

    const body = await req.json();
    const { action = "get" } = body;

    // ── GET current tone of voice ──────────────────────────────────────────
    if (action === "get") {
      const { data } = await supabase
        .from("tone_of_voice")
        .select("*")
        .eq("user_id", user.id)
        .maybeSingle();

      return new Response(JSON.stringify({
        success: true,
        toneOfVoice: data,
        sixTones: SIX_TONES,
      }), { headers: { ...cors, "Content-Type": "application/json" } });
    }

    // ── SAVE / UPDATE tone of voice ────────────────────────────────────────
    if (action === "save") {
      const {
        profileName, niche, approvedSample, approvedStyle,
        toneRules, vocabularyUse, vocabularyAvoid,
        activeTones = SIX_TONES.map(t => t.id),
      } = body;

      const { data, error } = await supabase.from("tone_of_voice").upsert({
        user_id: user.id,
        profile_name: profileName,
        niche,
        approved_sample: approvedSample,
        approved_style: approvedStyle,
        tone_rules: toneRules,
        vocabulary_use: vocabularyUse,
        vocabulary_avoid: vocabularyAvoid,
        active_tones: activeTones,
        six_tones: SIX_TONES,
        is_active: true,
        updated_at: new Date().toISOString(),
      }, { onConflict: "user_id" }).select().single();

      if (error) throw error;

      return new Response(JSON.stringify({ success: true, toneOfVoice: data }), {
        headers: { ...cors, "Content-Type": "application/json" },
      });
    }

    // ── GENERATE sample in each tone ──────────────────────────────────────
    if (action === "generate_samples") {
      const { topic, niche = "Direito bancário", profileName = "@djairrotta" } = body;
      if (!topic) throw new Error("topic required");

      const samples: any[] = [];

      // Generate a hook sample for each of the 6 tones
      for (const tone of SIX_TONES) {
        const prompt = `Você é um especialista em conteúdo viral para ${profileName} (${niche}).

Gere um exemplo de gancho de carrossel do Instagram usando EXATAMENTE o tom "${tone.name}".

TOM: ${tone.description}
PADRÃO DE HOOK: ${tone.hook_pattern}
TEMA: ${topic}

Gere APENAS o texto do slide 1 (gancho) — máx 3 linhas, em PT-BR. Sem explicações.`;

        const res = await fetch(`${SUPABASE_URL}/functions/v1/generate-content`, {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${SERVICE_KEY}` },
          body: JSON.stringify({
            agent: "caption_writer",
            context: prompt,
            provider: "openrouter",
            model: "google/gemini-2.5-flash-preview-05-20",
          }),
        });
        const d = await res.json();

        samples.push({
          toneId: tone.id,
          toneName: tone.name,
          sample: d.result?.trim() || "",
          hookPattern: tone.hook_pattern,
        });
      }

      return new Response(JSON.stringify({ success: true, samples, topic }), {
        headers: { ...cors, "Content-Type": "application/json" },
      });
    }

    // ── APPROVE a sample (user picks their favorite) ───────────────────────
    if (action === "approve_sample") {
      const { toneId, approvedText, topic } = body;
      if (!toneId || !approvedText) throw new Error("toneId and approvedText required");

      // Save to tone_of_voice approvals
      const tone = SIX_TONES.find(t => t.id === toneId);
      if (!tone) throw new Error("Invalid toneId");

      await supabase.from("tone_of_voice_approvals").insert({
        user_id: user.id,
        tone_id: toneId,
        tone_name: tone.name,
        topic,
        approved_text: approvedText,
        created_at: new Date().toISOString(),
      });

      // Update main tone_of_voice record with this approval as the reference
      await supabase.from("tone_of_voice").upsert({
        user_id: user.id,
        approved_sample: approvedText,
        approved_style: `Tom aprovado: ${tone.name}\nEstilo: ${tone.description}`,
        is_active: true,
      }, { onConflict: "user_id" });

      return new Response(JSON.stringify({
        success: true,
        message: `Tom "${tone.name}" aprovado como referência de qualidade`,
        approvedTone: tone,
      }), { headers: { ...cors, "Content-Type": "application/json" } });
    }

    // ── BUILD injection string for agents ─────────────────────────────────
    if (action === "build_injection") {
      const { data: tov } = await supabase
        .from("tone_of_voice")
        .select("*")
        .eq("user_id", user.id)
        .maybeSingle();

      if (!tov) {
        return new Response(JSON.stringify({
          success: true,
          injection: "",
          message: "No tone of voice configured yet",
        }), { headers: { ...cors, "Content-Type": "application/json" } });
      }

      // Build the injection string that gets added to every agent prompt
      const activeToneDetails = SIX_TONES
        .filter(t => (tov.active_tones || []).includes(t.id))
        .map(t => `  ${t.name}: ${t.hook_pattern}`)
        .join("\n");

      const injection = `
## TOM DE VOZ APROVADO — ${tov.profile_name || "@usuario"}
**Nicho:** ${tov.niche || ""}
**Estilo aprovado:** ${tov.approved_style || ""}
${tov.approved_sample ? `**Amostra de qualidade aprovada:**\n"${tov.approved_sample}"` : ""}
${tov.tone_rules ? `**Regras de tom:**\n${tov.tone_rules}` : ""}
${tov.vocabulary_use ? `**Vocabulário — SEMPRE USE:** ${tov.vocabulary_use}` : ""}
${tov.vocabulary_avoid ? `**Vocabulário — NUNCA USE:** ${tov.vocabulary_avoid}` : ""}

**6 TONS DISPONÍVEIS:**
${activeToneDetails}

IMPORTANTE: Todo conteúdo gerado DEVE seguir este tom de voz. A amostra aprovada é o padrão mínimo de qualidade.
`.trim();

      return new Response(JSON.stringify({ success: true, injection }), {
        headers: { ...cors, "Content-Type": "application/json" },
      });
    }

    throw new Error(`Unknown action: ${action}`);

  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({ success: false, error: (e as Error).message }), {
      status: 500, headers: { ...cors, "Content-Type": "application/json" },
    });
  }
});
