import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const providers: Record<string, string> = {
    groq: "GROQ_API_KEY",
    openrouter: "OPENROUTER_API_KEY",
    openai: "OPENAI_API_KEY",
    anthropic: "ANTHROPIC_API_KEY",
    google: "GOOGLE_AI_API_KEY",
    deepseek: "DEEPSEEK_API_KEY",
    lovable: "LOVABLE_API_KEY",
  };

  const storageProviders: Record<string, string> = {
    minio_configured: "MINIO_ENDPOINT",
    firecrawl_configured: "FIRECRAWL_API_KEY",
    apify_configured: "APIFY_API_KEY",
  };

  const configured: Record<string, boolean | string> = {};
  for (const [provider, envVar] of Object.entries(providers)) {
    configured[provider] = !!Deno.env.get(envVar);
  }
  for (const [key, envVar] of Object.entries(storageProviders)) {
    configured[key] = !!Deno.env.get(envVar);
  }

  // Return MinIO config info (non-secret values only)
  configured["minio_endpoint"] = Deno.env.get("MINIO_ENDPOINT") || "";
  configured["minio_bucket"] = Deno.env.get("MINIO_BUCKET") || "";

  return new Response(JSON.stringify({ configured }), {
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
});
