import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// ── Full format library ─────────────────────────────────────────────────────
const FORMATS: Record<string, {
  name: string; platform: string; content_type: string;
  constraints: Record<string, any>; injection: string
}> = {

  "instagram-feed": {
    name: "Instagram Feed Post", platform: "instagram", content_type: "feed",
    constraints: { caption_max_chars: 2200, caption_visible_chars: 125, max_hashtags: 30, recommended_hashtags: "5-15", carousel_max_slides: 20, recommended_slides: "6-10", image_ratio: "4:5 portrait", image_resolution: "1080x1350px" },
    injection: `## FORMAT: Instagram Feed Post
### Platform Rules
- Engagement weight: Saves > Shares > Comments > Likes
- Carousels get ~1.4x more reach than single images
- Best posting times: 9-11 AM or 7-9 PM local time
- Shares to DMs are the highest-value engagement signal

### Carousel Formats (choose one)
1. Editorial/Tese — argue a thesis with evidence (8-10 slides)
2. Listicle — scannable numbered value (8-10 slides)
3. Tutorial/Passo-a-passo — teach a process (8-12 slides)
4. Mito vs Realidade — bust misconceptions (6-10 slides)
5. Storytelling — build emotional connection (8-10 slides)
6. Problema→Solução — address pain point (6-10 slides)

### Constraints (HARD LIMITS — non-negotiable)
- Caption max: 2200 chars | Visible before "more": 125 chars
- Each slide: 40-80 words, two-layer hierarchy (bold headline + supporting text)
- 5-15 hashtags only — no spam, no banned tags
- Last slide: ALWAYS a specific actionable CTA (not "follow for more")

### Anti-Patterns
- Links in captions (not clickable)
- Less than 40 words per slide (superficial)
- No CTA
- Editing captions after posting (resets algorithm distribution)`
  },

  "instagram-reels": {
    name: "Instagram Reels", platform: "instagram", content_type: "reels",
    constraints: { max_duration_seconds: 90, recommended_duration: "15-30s", aspect_ratio: "9:16 vertical", caption_max_chars: 2200, caption_visible_chars: 125, max_hashtags: 30 },
    injection: `## FORMAT: Instagram Reels
### Platform Rules
- Reels are the primary DISCOVERY format — shown to non-followers via Explore
- Watch time dominant: completion rate + replays directly boost distribution
- Engagement weight: Shares > Saves > Comments > Likes
- Trending audio gives measurable boost to Explore placement

### Script Structure
1. HOOK (0-2s): Spoken or text overlay — creates curiosity IMMEDIATELY. No logos, no intros.
2. SETUP (2-5s): Quick context — why viewer should care
3. DELIVERY (5-60s): Core value — visual variety, cuts every 3-5 seconds
4. CTA (last 3-5s): Direct specific ask — "Comenta X" not "segue o perfil"

### Loop Design
Design ending to connect back to beginning → replays → algorithm boost
Techniques: ending mid-sentence, visual match cuts, circular storytelling

### Constraints (HARD LIMITS)
- Duration: 15-30 seconds for maximum completion rate
- MANDATORY: burned-in subtitles (85% watch without sound)
- Aspect ratio: 9:16 vertical ONLY — never cropped horizontal
- 5-15 relevant hashtags

### Anti-Patterns
- Landscape video cropped to 9:16
- No subtitles (loses 85% of audience)
- Slow intro or "hey guys"
- Generic "follow for more" CTA`
  },

  "instagram-stories": {
    name: "Instagram Stories", platform: "instagram", content_type: "stories",
    constraints: { max_duration_seconds: 60, aspect_ratio: "9:16 vertical", format: "ephemeral 24h", frames: "3-7" },
    injection: `## FORMAT: Instagram Stories
### Platform Rules
- Stories reach primarily EXISTING followers — retention/deepening tool, not discovery
- Interactive elements (polls, questions, quizzes) dramatically increase engagement
- Link stickers are the ONLY clickable link option outside bio
- Posting 3-7 frames keeps profile at front of Stories bar all day

### Story Sequence (3-7 frames)
1. OPENER: Bold statement or striking visual — hooks in 2 seconds
2. CONTEXT (1-3 frames): Build the story — one idea per frame, large bold text
3. INTERACTIVE: Poll, question box, quiz, or emoji slider — mandatory
4. CLOSER: Conclusion + CTA — link sticker with context text, or "Me responde"

### Constraints (HARD LIMITS)
- Text per frame: MAX 2-3 lines, large bold font (readable on mobile)
- Each frame consumable in 3-5 seconds — zero walls of text
- At least 1 interactive element per sequence
- Tone: casual, conversational — NOT corporate

### Anti-Patterns
- Wall of text on single frame (viewers skip)
- No interactive elements (wastes the format)
- Link sticker with no context text (zero click-through)
- Posting only 1 story per day`
  },

  "linkedin-post": {
    name: "LinkedIn Post", platform: "linkedin", content_type: "post",
    constraints: { post_max_chars: 3000, post_visible_chars: 210, hashtags_max: 5, recommended_hashtags: "3-5", max_posts_per_day: 1 },
    injection: `## FORMAT: LinkedIn Post
### Platform Rules
- Posts with EXTERNAL LINKS get ~3x LESS reach — ALWAYS "link in comments"
- Comments weighted far more than reactions — ask genuine questions
- First 60 minutes critical for algorithmic expansion
- Document/carousel posts get 2-3x more reach than text-only
- Best times: 7-9 AM or 12-1 PM weekdays (Tue/Wed/Thu perform best)

### Text Post Structure
1. HOOK (first 2 lines / ~210 chars): Contrarian take, surprising stat, or personal opener
2. STORY/CONTEXT: First person, 1-2 sentence paragraphs with line breaks
3. INSIGHTS: 3-5 numbered actionable takeaways
4. TAKEAWAY: 1-2 sentence summary
5. CTA QUESTION: Specific, genuine question to drive comments
6. HASHTAGS: 3-5 on last line ONLY

### Constraints (HARD LIMITS)
- Hook: max 210 chars (before "see more" fold)
- NEVER put links in post body (3x reach penalty)
- 3-5 hashtags maximum, on last line only
- 1 post per day maximum
- Write in FIRST PERSON

### Anti-Patterns
- Links in post body
- Corporate jargon (synergy, leverage, circle back)
- Wall of text without line breaks
- Generic motivational quotes`
  },

  "whatsapp-broadcast": {
    name: "WhatsApp Broadcast", platform: "whatsapp", content_type: "broadcast",
    constraints: { message_max_chars: 4096, optimal_length: "300-500 chars", frequency: "2-4x per week max" },
    injection: `## FORMAT: WhatsApp Broadcast
### Platform Rules
- 90-98% open rate — every bad message damages trust permanently
- Write like texting a friend, NOT a press release
- Max 2-4 broadcasts/week — more triggers blocks and opt-outs
- One message = one purpose — never combine tip + promo + survey

### Message Structure
1. GREETING: "Olá {{name}}!" — warm, personalized, 1 line
2. VALUE HOOK: What this message delivers, why it matters — 1-2 sentences
3. BODY: 2-4 short paragraphs, *bold* key phrases, one idea each
4. CTA: Single clear low-friction action — "Responda SIM" or link
5. SIGNATURE + OPT-OUT: "Responda PARE para cancelar" — mandatory

### Constraints (HARD LIMITS)
- Under 500 chars when possible (higher reply rates)
- 1-3 emojis max — more looks spammy
- ALWAYS include opt-out option (legal + trust signal)
- {{name}} personalization in greeting

### Anti-Patterns
- Formal/corporate tone (invasive in intimate channel)
- More than 1 message per day
- Multiple CTAs in one message
- No opt-out option`
  },

  "youtube-script": {
    name: "YouTube Video Script", platform: "youtube", content_type: "script",
    constraints: { title_max_chars: 100, title_optimal: "50-70 chars", optimal_duration: "8-15 minutes", thumbnail_size: "1280x720px" },
    injection: `## FORMAT: YouTube Video Script
### Platform Rules
- CTR + Watch Time are the TWO MOST IMPORTANT metrics
- First 30 seconds determine whether viewers stay — make or break
- THUMBNAIL is 50% of a video's performance — design it BEFORE scripting
- 8-15 minutes: enables mid-roll ads + maintains strong retention
- Pattern interrupt every 30-60 seconds (B-roll, graphics, angle change, story shift)

### Video Architecture
1. HOOK (0-30s): State premise + preview payoff + open curiosity loop. NO "hey guys, welcome back."
2. INTRO/CONTEXT (30s-1min): Why this topic matters — keep tight
3. BODY: 3-5 distinct sections, pattern interrupt every 30-60s
4. CLIMAX/KEY INSIGHT: Most valuable moment at 60-70% through
5. SUMMARY (last 1-2min): Recap + reinforce primary takeaway
6. CTA + END SCREEN (last 20s): ONE primary CTA — subscribe, watch next, or comment

### Constraints (HARD LIMITS)
- Title: 50-70 chars optimal, keywords front-loaded
- Description: first 2 lines must contain hook + primary keywords
- Thumbnail concept MUST be defined before scripting
- Write for SPOKEN delivery: short sentences, conversational language

### Anti-Patterns
- Slow opening without immediate hook
- "Hey guys, welcome back to my channel"
- Multiple stacked CTAs at end
- No pattern interrupts (causes retention drop-off)`
  },

  "youtube-shorts": {
    name: "YouTube Shorts", platform: "youtube", content_type: "shorts",
    constraints: { max_duration_seconds: 60, aspect_ratio: "9:16 vertical", optimal_duration: "15-45 seconds", required_hashtag: "#Shorts" },
    injection: `## FORMAT: YouTube Shorts
### Platform Rules
- Shorts feed is swipe-based — viewer decides in 1-2 SECONDS
- Completion rate + replays are primary algorithmic signals
- Loop seamlessly = rewatches = wider distribution
- Always include "#Shorts" in title or description

### Structure
1. HOOK (0-2s): Bold text overlay or provocative statement — IMPOSSIBLE to ignore
2. DELIVERY (2-50s): ONE point, ONE story, ONE tip — zero fluff, no tangents
3. PUNCHLINE/LOOP (last 5-10s): Payoff that connects back to hook for seamless replay

### Loop Design Techniques
- End statement that leads into opening hook
- Visual match cuts (last frame = first frame)
- Circular storytelling (end where you began, with new context)

### Constraints (HARD LIMITS)
- 15-45 seconds optimal (shorter is better for algorithm)
- Mandatory text overlays (many watch without sound)
- 9:16 native vertical — NEVER cropped horizontal
- ONE topic, ONE takeaway — multiple points kill completion

### Anti-Patterns
- Title cards or logos at start
- Multiple points in one Short
- Cropped horizontal content`
  },

  "researching": {
    name: "Research & Data Collection", platform: "general", content_type: "research",
    constraints: { confidence_levels: "high/medium/low", sources_minimum: 3, output_sections: "Key Findings, Trending Angles, Sources, Recommendations, Gaps" },
    injection: `## FORMAT: Research & Data Collection
### Core Rules
1. Source verification FIRST — never include a finding without verifying against at least 2 independent sources
2. Freshness bias — prefer recent sources, always note publication date
3. Primary over secondary — original reports > blog posts > aggregators
4. Confidence levels MANDATORY: HIGH (3+ sources), MEDIUM (2 sources), LOW (1 source)
5. Contradictions: present BOTH sides with evidence — never choose one

### Output Structure (ALL sections mandatory)
1. KEY FINDINGS: Concise cited statements with confidence levels and source URLs
2. TRENDING ANGLES: Lifecycle assessment (emerging/growth/mature/declining) per angle
3. SOURCES TABLE: # | Source | Type | Relevance (1-10) | Date | URL
4. RECOMMENDATIONS: Actionable, numbered, grounded in findings only
5. GAPS: What could not be found — documenting blind spots is as valuable as findings

### Anti-Patterns
- Data without source URL (never acceptable)
- "According to industry reports" (must cite specifically)
- Single source as proof
- Mixing facts with opinions in same section
- Omitting the Gaps section`
  },

  "publishing": {
    name: "Social Networks Publishing", platform: "general", content_type: "publishing",
    constraints: { dry_run: true, confirmation_required: true, sequential: true },
    injection: `## FORMAT: Social Networks Publishing
### Cardinal Rules (non-negotiable)
1. NEVER publish without EXPLICIT user confirmation ("publicar" / "go ahead")
2. Dry-run FIRST on any new platform — validate credentials, images, caption limits
3. Multi-platform: publish SEQUENTIALLY (one at a time) — report result before next
4. Report IMMEDIATELY: platform + permalink + post ID + timestamp or error

### Pre-publish Validation Checklist
Instagram: JPEG only | 2-10 images carousel | max 2200 char caption | 25 posts/24h
LinkedIn: JPG/PNG | max 9 images | 3000 char limit | no links in body
X/Twitter: JPG/PNG/GIF | max 4 images | 280 chars
WhatsApp: 300-500 chars optimal | {{name}} personalization | opt-out required

### Publishing Flow
1. Validate all platform requirements before any API call
2. Dry-run to test credentials and formatting
3. Show full preview (platform + images + caption + hashtags)
4. Wait for explicit "publicar" confirmation
5. Publish — report result immediately
6. If failure: report error + HTTP status + suggested fix

### Anti-Patterns
- Publishing without explicit confirmation
- Parallel multi-platform publishing (always sequential)
- Ignoring rate limits without warning user
- Skipping dry-run on first execution`
  },
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: cors });

  try {
    const SUPA_URL = Deno.env.get("SUPABASE_URL")!;
    const SUPA_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(SUPA_URL, SUPA_KEY);

    const auth = req.headers.get("Authorization") || "";
    const { data: { user } } = await supabase.auth.getUser(auth.replace("Bearer ", ""));
    if (!user) throw new Error("Auth required");

    const body = await req.json();
    const { action = "list" } = body;

    if (action === "list") {
      return new Response(JSON.stringify({
        success: true,
        formats: Object.entries(FORMATS).map(([slug, f]) => ({
          slug, name: f.name, platform: f.platform, content_type: f.content_type, constraints: f.constraints,
        })),
      }), { headers: { ...cors, "Content-Type": "application/json" } });
    }

    if (action === "get") {
      const { slug } = body;
      const fmt = FORMATS[slug];
      if (!fmt) throw new Error(`Format not found: ${slug}. Available: ${Object.keys(FORMATS).join(", ")}`);
      return new Response(JSON.stringify({ success: true, format: { ...fmt, slug } }), {
        headers: { ...cors, "Content-Type": "application/json" },
      });
    }

    if (action === "inject") {
      const { agentPrompt, formatSlug, toneOfVoiceInjection = "", sherlockContext = "" } = body;
      if (!agentPrompt) throw new Error("agentPrompt required");

      const fmt = formatSlug ? FORMATS[formatSlug] : null;
      const parts: string[] = [agentPrompt.trim()];

      if (fmt) parts.push(`\n${fmt.injection}`);
      if (toneOfVoiceInjection?.trim()) parts.push(`\n--- TOM DE VOZ APROVADO ---\n${toneOfVoiceInjection.trim()}`);
      if (sherlockContext?.trim()) parts.push(`\n--- CONTEXTO DE REFERÊNCIA ---\n${sherlockContext.slice(0, 600)}`);

      return new Response(JSON.stringify({ success: true, injectedPrompt: parts.join("\n") }), {
        headers: { ...cors, "Content-Type": "application/json" },
      });
    }

    if (action === "validate") {
      const { formatSlug, caption, slideCount, hashtagCount, durationSeconds } = body;
      const fmt = FORMATS[formatSlug];
      if (!fmt) throw new Error(`Unknown format: ${formatSlug}`);

      const violations: string[] = [];
      const c = fmt.constraints;
      if (caption && c.caption_max_chars && caption.length > c.caption_max_chars)
        violations.push(`Caption muito longa: ${caption.length} chars (máx ${c.caption_max_chars})`);
      if (slideCount && c.carousel_max_slides && slideCount > c.carousel_max_slides)
        violations.push(`Muitos slides: ${slideCount} (máx ${c.carousel_max_slides})`);
      if (hashtagCount && c.max_hashtags && hashtagCount > c.max_hashtags)
        violations.push(`Muitas hashtags: ${hashtagCount} (máx ${c.max_hashtags})`);
      if (durationSeconds && c.max_duration_seconds && durationSeconds > c.max_duration_seconds)
        violations.push(`Duração excedida: ${durationSeconds}s (máx ${c.max_duration_seconds}s)`);

      return new Response(JSON.stringify({ success: true, valid: violations.length === 0, violations, format: { name: fmt.name, constraints: c } }), {
        headers: { ...cors, "Content-Type": "application/json" },
      });
    }

    throw new Error(`Unknown action: ${action}`);
  } catch (e) {
    return new Response(JSON.stringify({ success: false, error: (e as Error).message }), {
      status: 500, headers: { ...cors, "Content-Type": "application/json" },
    });
  }
});
