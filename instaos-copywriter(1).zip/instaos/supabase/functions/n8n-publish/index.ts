import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const IG_GRAPH_API = "https://graph.facebook.com/v21.0";

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const N8N_SECRET = Deno.env.get("N8N_WEBHOOK_SECRET");

    // Validate n8n secret
    const authHeader = req.headers.get("x-n8n-secret") || req.headers.get("authorization")?.replace("Bearer ", "");
    if (N8N_SECRET && authHeader !== N8N_SECRET) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
    const body = await req.json();
    const { action, user_id } = body;

    if (!user_id) throw new Error("user_id is required");

    // ========== LIST: Get scheduled/approved items ready to publish ==========
    if (action === "list_ready") {
      const { data: items, error } = await supabase
        .from("publish_queue")
        .select("id, caption, content_type, status, scheduled_at, media_urls, video_url, created_at")
        .eq("user_id", user_id)
        .in("status", ["approved", "scheduled"])
        .order("scheduled_at", { ascending: true, nullsFirst: false });

      if (error) throw error;

      // Filter scheduled items that are due
      const now = new Date();
      const readyItems = (items || []).filter((item: any) => {
        if (item.status === "approved") return true;
        if (item.status === "scheduled" && item.scheduled_at) {
          return new Date(item.scheduled_at) <= now;
        }
        return false;
      });

      return new Response(JSON.stringify({ success: true, items: readyItems, total: readyItems.length }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ========== PUBLISH: Publish a specific queue item ==========
    if (action === "publish") {
      const { queue_id } = body;
      if (!queue_id) throw new Error("queue_id is required");

      // Get credentials
      const { data: creds } = await supabase
        .from("instagram_credentials")
        .select("*")
        .eq("user_id", user_id)
        .eq("is_connected", true)
        .single();

      if (!creds) throw new Error("Instagram not connected for this user");

      // Get queue item
      const { data: queueItem } = await supabase
        .from("publish_queue")
        .select("*")
        .eq("id", queue_id)
        .eq("user_id", user_id)
        .single();

      if (!queueItem) throw new Error("Queue item not found");
      if (!["approved", "scheduled"].includes(queueItem.status)) {
        throw new Error(`Item status is '${queueItem.status}', expected 'approved' or 'scheduled'`);
      }

      // Update status to publishing
      await supabase.from("publish_queue").update({ status: "publishing" }).eq("id", queue_id);

      const accessToken = creds.access_token;
      const igUserId = creds.ig_user_id;

      try {
        let containerId: string;

        if (queueItem.content_type === "reel" && queueItem.video_url) {
          const createRes = await fetch(`${IG_GRAPH_API}/${igUserId}/media`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              media_type: "REELS",
              video_url: queueItem.video_url,
              caption: queueItem.caption || "",
              access_token: accessToken,
            }),
          });
          const createData = await createRes.json();
          if (createData.error) throw new Error(createData.error.message);
          containerId = createData.id;

        } else if (queueItem.content_type === "carousel" && queueItem.media_urls?.length > 0) {
          const childIds: string[] = [];
          for (const url of queueItem.media_urls) {
            const isVideo = url.includes(".mp4") || url.includes("video");
            const childRes = await fetch(`${IG_GRAPH_API}/${igUserId}/media`, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                ...(isVideo ? { media_type: "VIDEO", video_url: url } : { image_url: url }),
                is_carousel_item: true,
                access_token: accessToken,
              }),
            });
            const childData = await childRes.json();
            if (childData.error) throw new Error(childData.error.message);
            childIds.push(childData.id);
          }

          const carouselRes = await fetch(`${IG_GRAPH_API}/${igUserId}/media`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              media_type: "CAROUSEL",
              children: childIds,
              caption: queueItem.caption || "",
              access_token: accessToken,
            }),
          });
          const carouselData = await carouselRes.json();
          if (carouselData.error) throw new Error(carouselData.error.message);
          containerId = carouselData.id;

        } else {
          const imageUrl = queueItem.media_urls?.[0];
          if (!imageUrl) throw new Error("No media URL provided");

          const createRes = await fetch(`${IG_GRAPH_API}/${igUserId}/media`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              image_url: imageUrl,
              caption: queueItem.caption || "",
              access_token: accessToken,
            }),
          });
          const createData = await createRes.json();
          if (createData.error) throw new Error(createData.error.message);
          containerId = createData.id;
        }

        // Wait for media processing (videos/carousels)
        if (queueItem.content_type === "reel" || queueItem.content_type === "carousel") {
          let ready = false;
          for (let attempt = 0; attempt < 30; attempt++) {
            await new Promise(r => setTimeout(r, 5000));
            const statusRes = await fetch(
              `${IG_GRAPH_API}/${containerId}?fields=status_code&access_token=${accessToken}`
            );
            const statusData = await statusRes.json();
            if (statusData.status_code === "FINISHED") { ready = true; break; }
            if (statusData.status_code === "ERROR") throw new Error("Media processing failed");
          }
          if (!ready) throw new Error("Media processing timeout");
        }

        // Publish
        const publishRes = await fetch(`${IG_GRAPH_API}/${igUserId}/media_publish`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ creation_id: containerId, access_token: accessToken }),
        });
        const publishData = await publishRes.json();
        if (publishData.error) throw new Error(publishData.error.message);

        // Get permalink
        const mediaRes = await fetch(
          `${IG_GRAPH_API}/${publishData.id}?fields=permalink&access_token=${accessToken}`
        );
        const mediaData = await mediaRes.json();

        // Update queue
        await supabase.from("publish_queue").update({
          status: "published",
          published_at: new Date().toISOString(),
          ig_media_id: publishData.id,
          ig_permalink: mediaData.permalink || null,
        }).eq("id", queue_id);

        console.log(`✅ Published to Instagram: ${publishData.id}`);

        return new Response(JSON.stringify({
          success: true,
          mediaId: publishData.id,
          permalink: mediaData.permalink,
          caption: queueItem.caption?.slice(0, 50),
        }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });

      } catch (pubError) {
        await supabase.from("publish_queue").update({
          status: "failed",
          error_message: pubError instanceof Error ? pubError.message : "Publishing failed",
        }).eq("id", queue_id);
        throw pubError;
      }
    }

    throw new Error(`Unknown action: ${action}. Use 'list_ready' or 'publish'`);
  } catch (error) {
    console.error("n8n-publish error:", error);
    return new Response(JSON.stringify({
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
