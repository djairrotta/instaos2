import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// ── Engagement score (normalized 0-100, log scale) ─────────────────────────
function engScore(views: number, likes: number, comments: number): number {
  const raw = views + likes * 10 + comments * 30;
  if (raw <= 0) return 0;
  return Math.min(100, Math.round((Math.log10(raw + 1) / 6) * 100));
}

// ── AI call helper ─────────────────────────────────────────────────────────
async function callAI(supaUrl: string, supaKey: string, context: string, model = "google/gemini-2.5-flash-preview-05-20", agent = "hook_analyst"): Promise<string> {
  const r = await fetch(`${supaUrl}/functions/v1/generate-content`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${supaKey}` },
    body: JSON.stringify({ agent, context, provider: "openrouter", model }),
  });
  const d = await r.json();
  return d.result || "";
}

function parseJSON(raw: string): any {
  try { return JSON.parse(raw.replace(/```json|```/g, "").trim()); }
  catch { return null; }
}

// ── Core: analyze one post ─────────────────────────────────────────────────
async function analyzePost(
  supabase: any, supaUrl: string, supaKey: string,
  post: any, table = "reels_competidores"
): Promise<any> {
  const {
    id, caption = "", content_type = "post",
    views = 0, likes = 0, comments = 0,
    transcript = "", hook_analysis = "",
    image_urls = [],
  } = post;

  const eng = engScore(views, likes, comments);

  const context = [
    caption    && `Caption: ${caption.slice(0, 500)}`,
    transcript && `Transcrição: ${transcript.slice(0, 600)}`,
    hook_analysis && `Hook anterior: ${hook_analysis.slice(0, 200)}`,
    `Métricas: ${views} views | ${likes} likes | ${comments} comentários`,
    `Tipo: ${content_type}`,
    image_urls?.length > 1 ? `Carrossel: ${image_urls.length} slides` : "",
  ].filter(Boolean).join("\n");

  const prompt = `Analise este post do Instagram e retorne análise viral completa.

CONTEÚDO:
${context}

Critério de score: score_ia (qualidade do gancho 0-100) será combinado com score_engajamento (${eng}/100).
Score final = score_ia * 0.6 + ${eng} * 0.4

Retorne JSON exato:
{
  "score_ia": 0-100,
  "hook": "gancho exato — primeiros elementos que capturam atenção",
  "hook_type": "Curiosidade|Dor|Promessa|Choque|Prova Social|Tendência|Urgência",
  "power_words": ["word1","word2","word3"],
  "emotional_trigger": "SURPRESA|FOMO|DISSONÂNCIA|URGÊNCIA|SEGURANÇA|CURIOSIDADE",
  "structure": "estrutura narrativa em 1 frase",
  "why_viral": "por que funciona — 2 frases concretas com exemplos do texto",
  "weak_points": "ponto fraco principal em 1 frase",
  "adapted_hook": "gancho reescrito para advogado/direito bancário mantendo estrutura viral exata",
  "best_format": "reel|carrossel|post",
  "estimated_reach": "baixo|médio|alto|viral",
  "content_ideas": ["ideia adaptada 1","ideia adaptada 2","ideia adaptada 3"],
  "call_to_action": "CTA identificado ou nenhum"
}`;

  const raw  = await callAI(supaUrl, supaKey, prompt);
  const data = parseJSON(raw);

  if (!data) {
    await supabase.from(table).update({ viral_score: eng }).eq("id", id);
    return { viral_score: eng };
  }

  const aiS    = Math.min(100, Math.max(0, data.score_ia || 0));
  const final  = Math.round(aiS * 0.6 + eng * 0.4);
  data.viral_score        = final;
  data.engagement_score   = eng;

  await supabase.from(table).update({
    viral_score:     final,
    hook_type:       data.hook_type     || null,
    adapted_hook:    data.adapted_hook  || null,
    estimated_reach: data.estimated_reach || "baixo",
    best_format:     data.best_format   || content_type,
    viral_analysis:  data,
    hook_analysis:   data.hook          || hook_analysis,
  }).eq("id", id);

  console.log(`✅ ${id} score=${final} type=${data.hook_type} reach=${data.estimated_reach}`);
  return data;
}

// ── Main serve ─────────────────────────────────────────────────────────────
serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: cors });

  try {
    const SUPA_URL = Deno.env.get("SUPABASE_URL")!;
    const SUPA_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(SUPA_URL, SUPA_KEY);

    const auth = req.headers.get("Authorization") || "";
    const { data: { user } } = await supabase.auth.getUser(auth.replace("Bearer ", ""));
    if (!user) throw new Error("Auth required");

    const body = await req.json();
    const { action = "analyze_batch" } = body;

    // ── analyze_batch: all unscored approved posts ─────────────────────────
    if (action === "analyze_batch") {
      const { limit = 30, forceReanalyze = false } = body;

      let q = supabase
        .from("reels_competidores")
        .select("id,owner_username,caption,content_type,views,likes,comments,transcript,hook_analysis,image_urls,thumbnail_url")
        .eq("user_id", user.id)
        .eq("relevance_status", "approved")
        .order("created_at", { ascending: false })
        .limit(limit);

      if (!forceReanalyze) q = q.or("viral_score.is.null,viral_score.eq.0");

      const { data: posts, error } = await q;
      if (error) throw error;

      if (!posts?.length) {
        return new Response(JSON.stringify({ success: true, analyzed: 0, message: "Todos os posts já têm score viral" }), {
          headers: { ...cors, "Content-Type": "application/json" },
        });
      }

      console.log(`🔍 Analyzing ${posts.length} posts for user ${user.id}`);
      let analyzed = 0;

      for (let i = 0; i < posts.length; i += 3) {
        await Promise.all(posts.slice(i, i + 3).map(async (p) => {
          try { await analyzePost(supabase, SUPA_URL, SUPA_KEY, p); analyzed++; }
          catch (e) { console.error(`Post ${p.id} failed:`, e); }
        }));
        if (i + 3 < posts.length) await new Promise(r => setTimeout(r, 2500));
      }

      return new Response(JSON.stringify({ success: true, analyzed, total: posts.length }), {
        headers: { ...cors, "Content-Type": "application/json" },
      });
    }

    // ── analyze_one ────────────────────────────────────────────────────────
    if (action === "analyze_one") {
      const { postId, table = "reels_competidores" } = body;
      if (!postId) throw new Error("postId required");

      const { data: post } = await supabase.from(table).select("*").eq("id", postId).single();
      if (!post) throw new Error("Post not found");

      const result = await analyzePost(supabase, SUPA_URL, SUPA_KEY, post, table);
      return new Response(JSON.stringify({ success: true, result }), {
        headers: { ...cors, "Content-Type": "application/json" },
      });
    }

    // ── get_ranking: sorted by viral_score ────────────────────────────────
    if (action === "get_ranking") {
      const { limit = 30, contentType, minScore = 0 } = body;

      let q = supabase
        .from("reels_competidores")
        .select("id,owner_username,caption,content_type,views,likes,comments,thumbnail_url,viral_score,hook_type,adapted_hook,estimated_reach,best_format,viral_analysis,hook_analysis,created_at,url")
        .eq("user_id", user.id)
        .eq("relevance_status", "approved")
        .gte("viral_score", minScore)
        .order("viral_score", { ascending: false })
        .limit(limit);

      if (contentType && contentType !== "all") q = q.eq("content_type", contentType);

      const { data, error } = await q;
      if (error) throw error;

      // Summarize stats
      const all = data || [];
      const stats = {
        total: all.length,
        avgScore: all.length ? Math.round(all.reduce((s, p) => s + (p.viral_score || 0), 0) / all.length) : 0,
        topScore: all[0]?.viral_score || 0,
        byHookType: all.reduce((acc: any, p) => { if (p.hook_type) acc[p.hook_type] = (acc[p.hook_type] || 0) + 1; return acc; }, {}),
        byFormat: all.reduce((acc: any, p) => { acc[p.content_type] = (acc[p.content_type] || 0) + 1; return acc; }, {}),
        byReach: all.reduce((acc: any, p) => { if (p.estimated_reach) acc[p.estimated_reach] = (acc[p.estimated_reach] || 0) + 1; return acc; }, {}),
      };

      return new Response(JSON.stringify({ success: true, posts: all, stats }), {
        headers: { ...cors, "Content-Type": "application/json" },
      });
    }

    // ── get_insights: AI synthesis of top patterns ────────────────────────
    if (action === "get_insights") {
      const { topN = 10 } = body;

      const { data: top } = await supabase
        .from("reels_competidores")
        .select("viral_analysis,hook_analysis,hook_type,adapted_hook,content_type")
        .eq("user_id", user.id)
        .eq("relevance_status", "approved")
        .gte("viral_score", 40)
        .order("viral_score", { ascending: false })
        .limit(topN);

      if (!top?.length) {
        return new Response(JSON.stringify({ success: true, insights: null, message: "Analise mais posts primeiro (mínimo: rodar analyze_batch)" }), {
          headers: { ...cors, "Content-Type": "application/json" },
        });
      }

      const hookDist: Record<string, number> = {};
      const fmtDist:  Record<string, number> = {};
      const hooks: string[] = [];

      for (const p of top) {
        if (p.hook_type) hookDist[p.hook_type] = (hookDist[p.hook_type] || 0) + 1;
        if (p.content_type) fmtDist[p.content_type] = (fmtDist[p.content_type] || 0) + 1;
        if (p.adapted_hook) hooks.push(p.adapted_hook);
      }

      const synthesisPrompt = `Você é Renata ROI — analise os ${top.length} posts mais virais e sintetize os padrões.

TOP POSTS (análises resumidas):
${top.map((p, i) => `${i+1}. ${p.content_type} | Tipo: ${p.hook_type || "?"} | Hook: ${(p.adapted_hook || p.hook_analysis || "").slice(0, 100)}`).join("\n")}

DISTRIBUIÇÃO:
Tipos de Gancho: ${JSON.stringify(hookDist)}
Formatos: ${JSON.stringify(fmtDist)}

Retorne JSON:
{
  "dominant_hook_type": "tipo mais frequente e por que funciona",
  "dominant_format": "reel|carrossel|post",
  "winning_formula": "fórmula em 1 frase que descreve o padrão vencedor neste nicho",
  "power_words": ["top5 palavras mais usadas nos ganchos que mais performam"],
  "emotional_triggers": ["top3 gatilhos emocionais dominantes"],
  "hook_template": "template do gancho mais eficaz para este nicho — com [variáveis] para customizar",
  "what_to_avoid": ["anti-pattern1", "anti-pattern2", "anti-pattern3"],
  "recommendation": "recomendação estratégica de 2 frases para o criador aplicar imediatamente"
}`;

      const insightsRaw = await callAI(SUPA_URL, SUPA_KEY, synthesisPrompt, "google/gemini-2.5-flash-preview-05-20", "viral_analyst");
      const insights    = parseJSON(insightsRaw);

      return new Response(JSON.stringify({
        success: true,
        insights: {
          ...insights,
          hookTypeDistribution: hookDist,
          formatDistribution: fmtDist,
          topAdaptedHooks: hooks.slice(0, 5),
          postsAnalyzed: top.length,
        },
      }), { headers: { ...cors, "Content-Type": "application/json" } });
    }

    throw new Error(`Unknown action: ${action}`);

  } catch (e) {
    console.error("viral-engine:", e);
    return new Response(JSON.stringify({ success: false, error: (e as Error).message }), {
      status: 500, headers: { ...cors, "Content-Type": "application/json" },
    });
  }
});
