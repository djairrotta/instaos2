import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    // Detect source (cron vs manual)
    let bodyData: any = {};
    try { bodyData = await req.json(); } catch {}
    const source = bodyData?.source || "manual";
    const isCron = source === "cron";

    // Get pipeline config
    const { data: config } = await supabase.from("pipeline_config").select("*").limit(1).single();
    if (!config) throw new Error("Pipeline config not found");

    const { instagram_username, scrape_provider, ai_model, user_id: configUserId } = config;
    
    // Manual mode overrides from body (sent by pipeline-settings-modal)
    const manualSettings = bodyData?.settings || {};
    
    // Cron mode: 24h filter, lower limits, delays between competitors
    // Manual mode: use body overrides or configured values
    const competitor_reels_limit = isCron 
      ? Math.min(config.competitor_reels_limit, 5) 
      : (manualSettings.competitor_reels_limit ?? config.competitor_reels_limit);
    const my_reels_limit = manualSettings.my_reels_limit ?? config.my_reels_limit;
    const competitor_weeks_filter = manualSettings.competitor_weeks_filter ?? config.competitor_weeks_filter;
    const my_reels_months_filter = manualSettings.my_reels_months_filter ?? config.my_reels_months_filter;
    const MANUAL_DELAY_MS = (manualSettings.delay_between_competitors ?? 0) * 1000;
    const CRON_DELAY_MS = 20000; // 20s delay between competitors in cron mode
    const clearBeforeRun = manualSettings.clear_before_run ?? true;
    
    const delayMs = isCron ? CRON_DELAY_MS : MANUAL_DELAY_MS;
    
    console.log(`🚀 Pipeline starting for @${instagram_username} (${isCron ? "CRON — modo leve 24h" : "MANUAL — completo"})`);
    const logs: string[] = [];
    const addLog = (msg: string) => { console.log(msg); logs.push(msg); };
    addLog(`⚙️ Modo: ${isCron ? `Cron automático (últimas 24h, limite ${competitor_reels_limit}/competidor, delay ${CRON_DELAY_MS/1000}s)` : `Manual (últimas ${competitor_weeks_filter} semanas, limite ${competitor_reels_limit}/competidor, delay ${MANUAL_DELAY_MS/1000}s, limpar: ${clearBeforeRun})`}`);

    // Fetch agent configs for custom prompts
    const agentPrompts: Record<string, { custom_prompt?: string; custom_prompt_2?: string; custom_prompt_3?: string; model?: string }> = {};
    if (configUserId) {
      const { data: agentConfigs } = await supabase
        .from("agent_configs")
        .select("agent_type, model, custom_prompt, custom_prompt_2, custom_prompt_3")
        .eq("user_id", configUserId)
        .eq("is_active", true)
        .in("agent_type", ["hook_analyst", "viral_analyst", "content_strategist", "idea_generator", "content_analyzer", "image_analyzer", "video_transcriber"]);
      if (agentConfigs) {
        for (const ac of agentConfigs) {
          agentPrompts[ac.agent_type] = {
            custom_prompt: ac.custom_prompt || undefined,
            custom_prompt_2: ac.custom_prompt_2 || undefined,
            custom_prompt_3: ac.custom_prompt_3 || undefined,
            model: ac.model || undefined,
          };
        }
      }
      for (const [agentType, cfg] of Object.entries(agentPrompts)) {
        const promptPreview = cfg.custom_prompt ? cfg.custom_prompt.slice(0, 80) + (cfg.custom_prompt.length > 80 ? "..." : "") : "padrão";
        addLog(`🤖 Agente [${agentType}] → modelo: ${cfg.model || ai_model} | prompt: "${promptPreview}"`);
      }
      if (Object.keys(agentPrompts).length === 0) {
        addLog(`🧠 Nenhum agente customizado encontrado — usando prompts e modelos padrão`);
      }
    }

    // Load Apify config from system_config
    let apifyConfig: any = {
      postsScraper: "shu8hvrXbJbY3Eb9W",
      storyScraper: "apify~instagram-story-scraper",
      profileScraper: "shu8hvrXbJbY3Eb9W",
      storyLoginEnabled: true,
      storyMaxItems: 20,
      postsMaxItems: 20,
      delayBetweenRequests: 2,
      proxyCountry: "BR",
    };
    if (configUserId) {
      const { data: apifyRow } = await supabase
        .from("system_config")
        .select("config_value")
        .eq("user_id", configUserId)
        .eq("config_key", "apify_config")
        .maybeSingle();
      if (apifyRow) {
        try {
          apifyConfig = { ...apifyConfig, ...JSON.parse(apifyRow.config_value) };
          addLog(`🐛 Apify config carregado: actor posts=${apifyConfig.postsScraper}, stories=${apifyConfig.storyScraper}, limites=${apifyConfig.postsMaxItems}/${apifyConfig.storyMaxItems}`);
        } catch {}
      }
    }

    // Load Firecrawl config from system_config
    let firecrawlConfig: any = {
      formats: ["markdown", "links"],
      waitFor: 3000,
      onlyMainContent: true,
      crawlMaxPages: 100,
      crawlMaxDepth: 3,
      mapSearchLimit: 5000,
      includeSubdomains: false,
    };
    if (configUserId) {
      const { data: fcRow } = await supabase
        .from("system_config")
        .select("config_value")
        .eq("user_id", configUserId)
        .eq("config_key", "firecrawl_config")
        .maybeSingle();
      if (fcRow) {
        try {
          firecrawlConfig = { ...firecrawlConfig, ...JSON.parse(fcRow.config_value) };
          addLog(`🔥 Firecrawl config carregado: formats=${JSON.stringify(firecrawlConfig.formats)}, waitFor=${firecrawlConfig.waitFor}ms`);
        } catch {}
      }
    }

    // ===== PHASE 1: My Content (Reels + Posts + Carousels) =====
    addLog("📌 Phase 1: Scraping my content (Reels, Posts, Carousels)...");
    
    // Clear old data (only if clearBeforeRun is true for manual, always skip for cron)
    if (!isCron && clearBeforeRun) {
      await supabase.from("meus_reels").delete().neq("id", "00000000-0000-0000-0000-000000000000");
      addLog("🗑️ Dados antigos de meus reels removidos");
    } else if (!isCron) {
      addLog("📌 Modo incremental — dados antigos mantidos");
    }
    
    const scrapeMyContent = await fetch(`${SUPABASE_URL}/functions/v1/scrape-reels`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
      body: JSON.stringify({
        username: instagram_username,
        limit: my_reels_limit * 2,
        provider: scrape_provider,
        contentTypes: ["reel", "post", "carousel"],
        actorId: apifyConfig.postsScraper,
        proxyCountry: apifyConfig.proxyCountry,
        firecrawlConfig: scrape_provider === "firecrawl" ? firecrawlConfig : undefined,
      }),
    });
    const myContentResult = await scrapeMyContent.json();
    
    if (!myContentResult.success) {
      addLog(`❌ Failed to scrape my content: ${myContentResult.error}`);
      throw new Error(myContentResult.error);
    }

    // Filter by date (last N months)
    const monthsAgo = new Date();
    monthsAgo.setMonth(monthsAgo.getMonth() - my_reels_months_filter);
    
    // Viral composite score: average of views, likes, comments (normalized)
    const viralScore = (item: any) => {
      const views = item.views || 0;
      const likes = item.likes || 0;
      const comments = item.comments || 0;
      // Weighted average: views (reach) + likes*10 (approval) + comments*30 (conversation)
      return views + likes * 10 + comments * 30;
    };

    let myContent = myContentResult.reels
      .filter((r: any) => !r.post_date || new Date(r.post_date) >= monthsAgo)
      .sort((a: any, b: any) => viralScore(b) - viralScore(a))
      .slice(0, my_reels_limit);

    const contentCounts = myContent.reduce((acc: any, r: any) => {
      acc[r.content_type] = (acc[r.content_type] || 0) + 1;
      return acc;
    }, {});
    addLog(`✅ Got ${myContent.length} of my content: ${JSON.stringify(contentCounts)}`);

    // Analyze each piece of content with AI
    for (let i = 0; i < myContent.length; i++) {
      const item = myContent[i];
      addLog(`🔍 Analyzing my ${item.content_type} ${i + 1}/${myContent.length}...`);
      
      try {
        let transcriptText = "";

        // Route by content type for best analysis
        if (item.content_type === "reel" && item.video_url) {
          // Gemini multimodal VIDEO analysis for reels
          addLog(`📹 Gemini video analysis for reel ${i + 1}...`);
          try {
            const videoRes = await fetch(`${SUPABASE_URL}/functions/v1/analyze-content`, {
              method: "POST",
              headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
              body: JSON.stringify({ action: "video_analysis", content: item.caption || "", videoUrl: item.video_url, model: agentPrompts["video_transcriber"]?.model || ai_model, contentType: "reel", custom_prompt: agentPrompts["video_transcriber"]?.custom_prompt, custom_prompt_2: agentPrompts["video_transcriber"]?.custom_prompt_2, custom_prompt_3: agentPrompts["video_transcriber"]?.custom_prompt_3 }),
            });
            const videoData = await videoRes.json();
            if (videoData.success && videoData.result) {
              transcriptText = videoData.result;
              addLog(`✅ Gemini video: ${transcriptText.length} chars`);
            } else {
              addLog(`⚠️ Gemini video fallback: ${videoData.error || "no result"}`);
            }
          } catch (e) {
            addLog(`⚠️ Gemini video error: ${e}`);
          }
          await new Promise(r => setTimeout(r, 1500));
        } else if ((item.content_type === "post" || item.content_type === "carousel") && (item.thumbnail_url || (item.image_urls && item.image_urls.length > 0))) {
          // Gemini multimodal IMAGE analysis for posts/carousels
          const imageUrls = item.content_type === "carousel" && item.image_urls?.length > 0
            ? item.image_urls
            : [item.thumbnail_url].filter(Boolean);
          addLog(`🖼️ Gemini image analysis for ${item.content_type} ${i + 1} (${imageUrls.length} images)...`);
          try {
            const imgRes = await fetch(`${SUPABASE_URL}/functions/v1/analyze-content`, {
              method: "POST",
              headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
              body: JSON.stringify({ action: "image_analysis", content: item.caption || "", imageUrls, model: agentPrompts["image_analyzer"]?.model || ai_model, contentType: item.content_type, custom_prompt: agentPrompts["image_analyzer"]?.custom_prompt, custom_prompt_2: agentPrompts["image_analyzer"]?.custom_prompt_2, custom_prompt_3: agentPrompts["image_analyzer"]?.custom_prompt_3 }),
            });
            const imgData = await imgRes.json();
            if (imgData.success && imgData.result) {
              transcriptText = imgData.result;
              addLog(`✅ Gemini image: ${transcriptText.length} chars`);
            } else {
              addLog(`⚠️ Gemini image fallback: ${imgData.error || "no result"}`);
            }
          } catch (e) {
            addLog(`⚠️ Gemini image error: ${e}`);
          }
          await new Promise(r => setTimeout(r, 1500));
        }

        // Fallback: AI-based caption analysis (for posts, carousels, or failed video analysis)
        if (!transcriptText) {
          let analysisContent = item.caption || "No caption";
          if (item.content_type === "carousel" && item.image_urls?.length > 0) {
            analysisContent += `\n[Carousel with ${item.image_urls.length} slides]`;
          }
          const transcribeRes = await fetch(`${SUPABASE_URL}/functions/v1/analyze-content`, {
            method: "POST",
            headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
             body: JSON.stringify({ action: "transcribe", content: analysisContent, model: agentPrompts["content_analyzer"]?.model || ai_model, contentType: item.content_type, custom_prompt: agentPrompts["content_analyzer"]?.custom_prompt, custom_prompt_2: agentPrompts["content_analyzer"]?.custom_prompt_2, custom_prompt_3: agentPrompts["content_analyzer"]?.custom_prompt_3 }),
          });
          const transcribeData = await transcribeRes.json();
          transcriptText = transcribeData.success ? transcribeData.result?.slice(0, 2000) : "transcription failed";
        }

        item.transcript = transcriptText;

        // Hook/viral analysis using the full video analysis or transcript
        const hookAgent = agentPrompts["hook_analyst"] || {};
        const hookRes = await fetch(`${SUPABASE_URL}/functions/v1/analyze-content`, {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
          body: JSON.stringify({ action: "hook_analysis", content: item.transcript, model: hookAgent.model || ai_model, contentType: item.content_type, ...hookAgent.custom_prompt && { custom_prompt: hookAgent.custom_prompt }, ...hookAgent.custom_prompt_2 && { custom_prompt_2: hookAgent.custom_prompt_2 }, ...hookAgent.custom_prompt_3 && { custom_prompt_3: hookAgent.custom_prompt_3 } }),
        });
        const hookData = await hookRes.json();
        item.hook_analysis = hookData.success ? hookData.result : "analysis failed";

        await new Promise(r => setTimeout(r, 1000));

        // Viral points & psychological triggers analysis
        addLog(`🧠 Viral analysis for my ${item.content_type} ${i + 1}...`);
        try {
          const viralAgent = agentPrompts["viral_analyst"] || {};
          const viralRes = await fetch(`${SUPABASE_URL}/functions/v1/analyze-content`, {
            method: "POST",
            headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
            body: JSON.stringify({
              action: "viral_analysis",
              content: item.caption || "",
              transcript: item.transcript,
              hookAnalysis: item.hook_analysis,
              model: viralAgent.model || ai_model,
              contentType: item.content_type,
              ...viralAgent.custom_prompt && { custom_prompt: viralAgent.custom_prompt },
              ...viralAgent.custom_prompt_2 && { custom_prompt_2: viralAgent.custom_prompt_2 },
              ...viralAgent.custom_prompt_3 && { custom_prompt_3: viralAgent.custom_prompt_3 },
            }),
          });
          const viralData = await viralRes.json();
          if (viralData.success && viralData.result) {
            try {
              const parsed = JSON.parse(viralData.result);
              item.viral_points = parsed.viral_points || "";
              item.psychological_triggers = parsed.psychological_triggers || "";
              addLog(`✅ Viral analysis done for ${item.content_type} ${i + 1}`);
            } catch {
              item.viral_points = viralData.result;
              item.psychological_triggers = "";
            }
          }
        } catch (e) {
          addLog(`⚠️ Viral analysis failed: ${e}`);
        }

        await new Promise(r => setTimeout(r, 1000));
      } catch (e) {
        addLog(`⚠️ Analysis failed for ${item.content_type} ${i + 1}: ${e}`);
        item.transcript = "transcription failed";
        item.hook_analysis = "analysis failed";
      }
    }

    // Save to database
    if (myContent.length > 0) {
      const { error: insertError } = await supabase.from("meus_reels").insert(myContent);
      if (insertError) addLog(`⚠️ Error saving my content: ${insertError.message}`);
      else addLog(`💾 Saved ${myContent.length} of my content`);

      // Save analysis results to MinIO
      try {
        const dateStr = new Date().toISOString().split("T")[0];
        for (const item of myContent) {
          const minioPath = `analysis/${dateStr}/my-content/${item.content_type}/${item.owner_username || "unknown"}_${item.url ? item.url.split("/").pop() : Date.now()}.json`;
          await fetch(`${SUPABASE_URL}/functions/v1/save-to-minio`, {
            method: "POST",
            headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
            body: JSON.stringify({
              action: "save",
              path: minioPath,
              data: {
                content_type: item.content_type,
                owner_username: item.owner_username,
                url: item.url,
                caption: item.caption,
                views: item.views,
                likes: item.likes,
                comments: item.comments,
                eng_rate: item.eng_rate,
                transcript: item.transcript,
                hook_analysis: item.hook_analysis,
                viral_points: item.viral_points,
                psychological_triggers: item.psychological_triggers,
                post_date: item.post_date,
                analyzed_at: new Date().toISOString(),
              },
            }),
          });
        }
        addLog(`📦 Saved ${myContent.length} analysis results to MinIO`);
      } catch (e) {
        addLog(`⚠️ MinIO save failed for my content: ${e}`);
      }
    }

    // ===== PHASE 2: Competitor Profiles + Content (Reels + Posts + Carousels) =====
    addLog(isCron 
      ? `📌 Phase 2: Cron mode — scraping últimas 24h ${bodyData?.competitor_id ? "(1 competidor round-robin)" : "dos competidores"}...`
      : "📌 Phase 2: Scraping competitor profiles & content (all types)...");
    
    // In cron mode, don't delete old data — just add new content
    // In manual mode, respect clearBeforeRun setting
    if (!isCron && clearBeforeRun) {
      await supabase.from("reels_competidores").delete().neq("id", "00000000-0000-0000-0000-000000000000");
      addLog("🗑️ Dados antigos de reels competidores removidos");
    }
    
    // In cron mode with competitor_id, only process that single competitor
    let competitorQuery = supabase.from("competidores").select("*").eq("status", true);
    if (isCron && bodyData?.competitor_id) {
      competitorQuery = supabase.from("competidores").select("*").eq("id", bodyData.competitor_id);
    }
    const { data: competitors } = await competitorQuery;
    
    if (!competitors || competitors.length === 0) {
      addLog("⚠️ No active competitors found, skipping phase 2");
    } else {
      // Cron: last 24 hours | Manual: configured weeks
      const dateThreshold = new Date();
      if (isCron) {
        dateThreshold.setHours(dateThreshold.getHours() - 24);
        addLog(`📅 Filtro: últimas 24h (desde ${dateThreshold.toISOString()})`);
      } else {
        dateThreshold.setDate(dateThreshold.getDate() - competitor_weeks_filter * 7);
        addLog(`📅 Filtro: últimas ${competitor_weeks_filter} semanas`);
      }

      for (let compIdx = 0; compIdx < competitors.length; compIdx++) {
        // Apply delay between competitors (both cron and manual)
        if (compIdx > 0 && delayMs > 0) {
          addLog(`⏳ Aguardando ${delayMs / 1000}s antes do próximo competidor...`);
          await new Promise(r => setTimeout(r, delayMs));
        }
        
        const comp = competitors[compIdx];
        addLog(`🎯 Processando competidor ${compIdx + 1}/${competitors.length}: @${comp.name}`);
        
        const compUsername = comp.page_url.replace("https://www.instagram.com/", "").replace("/", "");
        
        // --- Fetch profile data ---
        addLog(`👤 Fetching profile for @${comp.name}...`);
        try {
          const profileRes = await fetch(`${SUPABASE_URL}/functions/v1/scrape-reels`, {
            method: "POST",
            headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
            body: JSON.stringify({ username: compUsername, provider: scrape_provider, action: "profile", actorId: apifyConfig.profileScraper, proxyCountry: apifyConfig.proxyCountry, firecrawlConfig: scrape_provider === "firecrawl" ? firecrawlConfig : undefined }),
          });
          const profileResult = await profileRes.json();

          if (profileResult.success && profileResult.profile) {
            const profile = profileResult.profile;
            
            // Calculate predominant content type from their posts
            // We'll determine this after scraping content below
            
            await supabase.from("competidores").update({
              bio: profile.bio,
              followers_count: profile.followers_count,
              following_count: profile.following_count,
              posts_count: profile.posts_count,
              profile_pic_url: profile.profile_pic_url,
              last_profile_update: new Date().toISOString(),
            }).eq("id", comp.id);
            
            addLog(`✅ @${comp.name}: ${profile.followers_count} followers, ${profile.posts_count} posts`);
          } else {
            addLog(`⚠️ Could not fetch profile for @${comp.name}`);
          }
        } catch (e) {
          addLog(`⚠️ Profile fetch failed for @${comp.name}: ${e}`);
        }

        // --- Fetch content ---
        addLog(`🔍 Scraping @${comp.name} content (all types)...`);
        
        try {
          const scrapeRes = await fetch(`${SUPABASE_URL}/functions/v1/scrape-reels`, {
            method: "POST",
            headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
            body: JSON.stringify({
              username: compUsername,
              limit: competitor_reels_limit * 2,
              provider: scrape_provider,
              contentTypes: ["reel", "post", "carousel"],
              actorId: apifyConfig.postsScraper,
              proxyCountry: apifyConfig.proxyCountry,
              firecrawlConfig: scrape_provider === "firecrawl" ? firecrawlConfig : undefined,
            }),
          });
          const compResult = await scrapeRes.json();

          if (!compResult.success) {
            addLog(`⚠️ Failed to scrape @${comp.name}: ${compResult.error}`);
            continue;
          }

          let compContent = compResult.reels
            .filter((r: any) => !r.post_date || new Date(r.post_date) >= dateThreshold)
            .sort((a: any, b: any) => viralScore(b) - viralScore(a))
            .slice(0, competitor_reels_limit);

          const compCounts = compContent.reduce((acc: any, r: any) => {
            acc[r.content_type] = (acc[r.content_type] || 0) + 1;
            return acc;
          }, {});
          addLog(`📊 @${comp.name}: ${compContent.length} items - ${JSON.stringify(compCounts)}`);

          // Determine predominant content type and posting frequency
          const allContent = compResult.reels;
          const typeCounts = allContent.reduce((acc: any, r: any) => {
            acc[r.content_type] = (acc[r.content_type] || 0) + 1;
            return acc;
          }, {} as Record<string, number>);
          const predominantType = Object.entries(typeCounts).sort((a: any, b: any) => b[1] - a[1])[0]?.[0] || "reel";

          // Calculate avg posts per week from dates
          const postDates = allContent.filter((r: any) => r.post_date).map((r: any) => new Date(r.post_date).getTime()).sort();
          let avgPostsPerWeek = 0;
          if (postDates.length >= 2) {
            const spanMs = postDates[postDates.length - 1] - postDates[0];
            const spanWeeks = spanMs / (7 * 24 * 60 * 60 * 1000);
            avgPostsPerWeek = spanWeeks > 0 ? Number((postDates.length / spanWeeks).toFixed(1)) : 0;
          }

          await supabase.from("competidores").update({
            predominant_content_type: predominantType,
            avg_posts_per_week: avgPostsPerWeek,
          }).eq("id", comp.id);

          // Analyze each competitor content
          for (let i = 0; i < compContent.length; i++) {
            const item = compContent[i];
            try {
              let transcriptText = "";

              // Route by content type
              if (item.content_type === "reel" && item.video_url) {
                try {
                  const videoRes = await fetch(`${SUPABASE_URL}/functions/v1/analyze-content`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
                    body: JSON.stringify({ action: "video_analysis", content: item.caption || "", videoUrl: item.video_url, model: agentPrompts["video_transcriber"]?.model || ai_model, contentType: "reel", custom_prompt: agentPrompts["video_transcriber"]?.custom_prompt, custom_prompt_2: agentPrompts["video_transcriber"]?.custom_prompt_2, custom_prompt_3: agentPrompts["video_transcriber"]?.custom_prompt_3 }),
                  });
                  const videoData = await videoRes.json();
                  if (videoData.success && videoData.result) transcriptText = videoData.result;
                } catch (e) { /* fallback below */ }
                await new Promise(r => setTimeout(r, 1500));
              } else if ((item.content_type === "post" || item.content_type === "carousel") && (item.thumbnail_url || (item.image_urls && item.image_urls.length > 0))) {
                const imageUrls = item.content_type === "carousel" && item.image_urls?.length > 0
                  ? item.image_urls
                  : [item.thumbnail_url].filter(Boolean);
                try {
                  const imgRes = await fetch(`${SUPABASE_URL}/functions/v1/analyze-content`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
                    body: JSON.stringify({ action: "image_analysis", content: item.caption || "", imageUrls, model: agentPrompts["image_analyzer"]?.model || ai_model, contentType: item.content_type, custom_prompt: agentPrompts["image_analyzer"]?.custom_prompt, custom_prompt_2: agentPrompts["image_analyzer"]?.custom_prompt_2, custom_prompt_3: agentPrompts["image_analyzer"]?.custom_prompt_3 }),
                  });
                  const imgData = await imgRes.json();
                  if (imgData.success && imgData.result) transcriptText = imgData.result;
                } catch (e) { /* fallback below */ }
                await new Promise(r => setTimeout(r, 1500));
              }

              // Fallback: AI caption analysis
              if (!transcriptText) {
                let analysisContent = item.caption || "No caption";
                if (item.content_type === "carousel" && item.image_urls?.length > 0) {
                  analysisContent += `\n[Carousel with ${item.image_urls.length} slides]`;
                }
                const transcribeRes = await fetch(`${SUPABASE_URL}/functions/v1/analyze-content`, {
                  method: "POST",
                  headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
                  body: JSON.stringify({ action: "transcribe", content: analysisContent, model: agentPrompts["content_analyzer"]?.model || ai_model, contentType: item.content_type, custom_prompt: agentPrompts["content_analyzer"]?.custom_prompt, custom_prompt_2: agentPrompts["content_analyzer"]?.custom_prompt_2, custom_prompt_3: agentPrompts["content_analyzer"]?.custom_prompt_3 }),
                });
                const transcribeData = await transcribeRes.json();
                transcriptText = transcribeData.success ? transcribeData.result?.slice(0, 2000) : "transcription failed";
              }

              item.transcript = transcriptText;

              const hookAgent = agentPrompts["hook_analyst"] || {};
              const hookRes = await fetch(`${SUPABASE_URL}/functions/v1/analyze-content`, {
                method: "POST",
                headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
                body: JSON.stringify({ action: "hook_analysis", content: item.transcript, model: hookAgent.model || ai_model, contentType: item.content_type, ...hookAgent.custom_prompt && { custom_prompt: hookAgent.custom_prompt }, ...hookAgent.custom_prompt_2 && { custom_prompt_2: hookAgent.custom_prompt_2 }, ...hookAgent.custom_prompt_3 && { custom_prompt_3: hookAgent.custom_prompt_3 } }),
              });
              const hookData = await hookRes.json();
              item.hook_analysis = hookData.success ? hookData.result : "analysis failed";

              await new Promise(r => setTimeout(r, 1000));

              // Viral points & psychological triggers for competitor content
              try {
                const viralAgent = agentPrompts["viral_analyst"] || {};
                const viralRes = await fetch(`${SUPABASE_URL}/functions/v1/analyze-content`, {
                  method: "POST",
                  headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
                  body: JSON.stringify({
                    action: "viral_analysis",
                    content: item.caption || "",
                    transcript: item.transcript,
                    hookAnalysis: item.hook_analysis,
                    model: viralAgent.model || ai_model,
                    contentType: item.content_type,
                    ...viralAgent.custom_prompt && { custom_prompt: viralAgent.custom_prompt },
                    ...viralAgent.custom_prompt_2 && { custom_prompt_2: viralAgent.custom_prompt_2 },
                    ...viralAgent.custom_prompt_3 && { custom_prompt_3: viralAgent.custom_prompt_3 },
                  }),
                });
                const viralData = await viralRes.json();
                if (viralData.success && viralData.result) {
                  try {
                    const parsed = JSON.parse(viralData.result);
                    item.viral_points = parsed.viral_points || "";
                    item.psychological_triggers = parsed.psychological_triggers || "";
                  } catch {
                    item.viral_points = viralData.result;
                    item.psychological_triggers = "";
                  }
                }
              } catch { /* non-blocking */ }

              await new Promise(r => setTimeout(r, 1000));
            } catch (e) {
              item.transcript = "transcription failed";
              item.hook_analysis = "analysis failed";
            }
            item.competidor_id = comp.id;
          }

          if (compContent.length > 0) {
            const { error: insertError } = await supabase.from("reels_competidores").insert(compContent);
            if (insertError) addLog(`⚠️ Error saving comp content: ${insertError.message}`);
            else addLog(`💾 Saved ${compContent.length} content from @${comp.name}`);

            // Save competitor analysis to MinIO
            try {
              const dateStr = new Date().toISOString().split("T")[0];
              for (const item of compContent) {
                const minioPath = `analysis/${dateStr}/competitors/${comp.name}/${item.content_type}_${item.url ? item.url.split("/").pop() : Date.now()}.json`;
                await fetch(`${SUPABASE_URL}/functions/v1/save-to-minio`, {
                  method: "POST",
                  headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
                  body: JSON.stringify({
                    action: "save",
                    path: minioPath,
                    data: {
                      competitor: comp.name,
                      content_type: item.content_type,
                      owner_username: item.owner_username,
                      url: item.url,
                      caption: item.caption,
                      views: item.views,
                      likes: item.likes,
                      comments: item.comments,
                      eng_rate: item.eng_rate,
                      transcript: item.transcript,
                      hook_analysis: item.hook_analysis,
                      viral_points: item.viral_points,
                      psychological_triggers: item.psychological_triggers,
                      post_date: item.post_date,
                      analyzed_at: new Date().toISOString(),
                    },
                  }),
                });
              }
              addLog(`📦 Saved ${compContent.length} competitor analysis to MinIO`);
            } catch (e) {
              addLog(`⚠️ MinIO save failed for @${comp.name}: ${e}`);
            }
          }
        } catch (e) {
          addLog(`❌ Error processing @${comp.name}: ${e}`);
        }
      }
    }

    // ===== PHASE 2.1: Hashtag Discovery (Viral Content by Niche) =====
    if (apifyConfig.searchEnabled || true) {
      addLog("📌 Phase 2.1: Descoberta de conteúdo viral por hashtags do nicho...");
      
      // Load niche keywords
      let nicheKeywords: string[] = [];
      if (configUserId) {
        const { data: nicheRow } = await supabase
          .from("system_config")
          .select("config_value")
          .eq("user_id", configUserId)
          .eq("config_key", "niche_keywords")
          .maybeSingle();
        if (nicheRow?.config_value) {
          nicheKeywords = nicheRow.config_value.split(",").map((k: string) => k.trim()).filter(Boolean);
        }
      }
      
      // Also check competitor niches for additional keywords
      if (competitors && competitors.length > 0) {
        const compNiches = competitors
          .map((c: any) => c.niche)
          .filter(Boolean)
          .flatMap((n: string) => n.split(",").map((k: string) => k.trim()));
        nicheKeywords = [...new Set([...nicheKeywords, ...compNiches])];
      }
      
      if (nicheKeywords.length === 0) {
        addLog("⏭️ Nenhuma keyword de nicho configurada — pulando descoberta por hashtag");
      } else {
        // Pick top hashtags (limit to avoid excessive API usage)
        const hashtagsToSearch = nicheKeywords.slice(0, isCron ? 3 : 5);
        const hashtagLimit = isCron ? 10 : (apifyConfig.searchLimit || 15);
        
        addLog(`🔍 Buscando hashtags: ${hashtagsToSearch.map((h: string) => `#${h}`).join(", ")} (limite: ${hashtagLimit})`);
        
        try {
          const hashtagRes = await fetch(`${SUPABASE_URL}/functions/v1/scrape-reels`, {
            method: "POST",
            headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
            body: JSON.stringify({
              action: "hashtag",
              hashtags: hashtagsToSearch,
              limit: hashtagLimit,
              provider: scrape_provider,
              contentTypes: ["reel", "post", "carousel"],
              actorId: apifyConfig.hashtagScraper !== "apify~instagram-hashtag-scraper" ? apifyConfig.hashtagScraper : apifyConfig.postsScraper,
              proxyCountry: apifyConfig.proxyCountry,
              searchType: apifyConfig.searchType || "hashtag",
              resultsType: apifyConfig.resultsType || "posts",
            }),
          });
          const hashtagResult = await hashtagRes.json();
          
          if (hashtagResult.success && hashtagResult.reels?.length > 0) {
            const hashtagContent = hashtagResult.reels;
            addLog(`✅ Hashtag discovery: ${hashtagContent.length} conteúdos virais encontrados`);
            
            // Check for duplicates against existing competitor reels (by URL)
            const { data: existingUrls } = await supabase
              .from("reels_competidores")
              .select("url")
              .not("url", "is", null);
            const existingUrlSet = new Set((existingUrls || []).map((r: any) => r.url));
            
            const newContent = hashtagContent.filter((item: any) => item.url && !existingUrlSet.has(item.url));
            addLog(`📊 ${newContent.length} novos (${hashtagContent.length - newContent.length} duplicados removidos)`);
            
            if (newContent.length > 0) {
              // Analyze top hashtag content with AI (limit to top 5 to save credits)
              const topHashtag = newContent.slice(0, isCron ? 3 : 5);
              
              for (let i = 0; i < topHashtag.length; i++) {
                const item = topHashtag[i];
                addLog(`🔍 Analyzing hashtag ${item.content_type} ${i + 1}/${topHashtag.length} from @${item.owner_username} (${item.hashtag_source})...`);
                
                try {
                  let transcriptText = "";
                  
                  if (item.content_type === "reel" && item.video_url) {
                    try {
                      const videoRes = await fetch(`${SUPABASE_URL}/functions/v1/analyze-content`, {
                        method: "POST",
                        headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
                        body: JSON.stringify({ action: "video_analysis", content: item.caption || "", videoUrl: item.video_url, model: agentPrompts["video_transcriber"]?.model || ai_model, contentType: "reel" }),
                      });
                      const videoData = await videoRes.json();
                      if (videoData.success && videoData.result) transcriptText = videoData.result;
                    } catch {}
                    await new Promise(r => setTimeout(r, 1500));
                  }
                  
                  if (!transcriptText) {
                    const analyzeRes = await fetch(`${SUPABASE_URL}/functions/v1/analyze-content`, {
                      method: "POST",
                      headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
                      body: JSON.stringify({ action: "transcribe", content: item.caption || "No caption", model: agentPrompts["content_analyzer"]?.model || ai_model, contentType: item.content_type }),
                    });
                    const analyzeData = await analyzeRes.json();
                    transcriptText = analyzeData.success ? analyzeData.result?.slice(0, 2000) : "";
                  }
                  
                  item.transcript = transcriptText;
                  
                  // Hook analysis
                  const hookRes = await fetch(`${SUPABASE_URL}/functions/v1/analyze-content`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
                    body: JSON.stringify({ action: "hook_analysis", content: item.transcript || item.caption, model: agentPrompts["hook_analyst"]?.model || ai_model, contentType: item.content_type }),
                  });
                  const hookData = await hookRes.json();
                  item.hook_analysis = hookData.success ? hookData.result : "";
                  
                  await new Promise(r => setTimeout(r, 1000));
                } catch (e) {
                  addLog(`⚠️ Analysis failed for hashtag item ${i + 1}: ${e}`);
                }
              }
              
              // Save hashtag-discovered content to reels_competidores
              const toInsert = newContent.map((item: any) => ({
                caption: item.caption || "",
                owner_username: item.owner_username,
                url: item.url,
                thumbnail_url: item.thumbnail_url,
                video_url: item.video_url,
                views: item.views || 0,
                likes: item.likes || 0,
                comments: item.comments || 0,
                post_date: item.post_date,
                content_type: item.content_type,
                image_urls: item.image_urls || [],
                eng_rate: item.eng_rate || 0,
                transcript: item.transcript || "",
                hook_analysis: item.hook_analysis || "",
                viral_points: item.hashtag_source || "",
                relevance_status: "pending",
                relevance_reason: `Descoberto via hashtag: ${item.hashtag_source}`,
                user_id: configUserId,
              }));
              
              const { error: insertErr } = await supabase.from("reels_competidores").insert(toInsert);
              if (insertErr) addLog(`⚠️ Erro salvando conteúdo de hashtags: ${insertErr.message}`);
              else addLog(`💾 ${toInsert.length} conteúdos de hashtags salvos em reels_competidores`);
              
              // Save to MinIO
              try {
                const dateStr = new Date().toISOString().split("T")[0];
                await fetch(`${SUPABASE_URL}/functions/v1/save-to-minio`, {
                  method: "POST",
                  headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
                  body: JSON.stringify({
                    action: "save",
                    path: `analysis/${dateStr}/hashtag-discovery/results.json`,
                    data: { hashtags: hashtagsToSearch, total_found: hashtagContent.length, new_saved: newContent.length, items: newContent.slice(0, 20) },
                  }),
                });
                addLog(`📦 Resultados de hashtags salvos no MinIO`);
              } catch {}
            }
          } else {
            addLog(`⚠️ Hashtag discovery: ${hashtagResult.error || "nenhum resultado"}`);
          }
        } catch (e) {
          addLog(`❌ Erro na descoberta por hashtags: ${e}`);
        }
      }
    }

    // ===== PHASE 2.5: Competitor Stories =====
    const IG_USERNAME = Deno.env.get("INSTAGRAM_USERNAME");
    const IG_PASSWORD = Deno.env.get("INSTAGRAM_PASSWORD");
    
    if (apifyConfig.storyLoginEnabled && IG_USERNAME && IG_PASSWORD && competitors && competitors.length > 0) {
      addLog("📌 Phase 2.5: Scraping competitor Stories (com login)...");
      
      for (let compIdx = 0; compIdx < competitors.length; compIdx++) {
        if (compIdx > 0 && delayMs > 0) {
          addLog(`⏳ Aguardando ${delayMs / 1000}s antes do próximo competidor (stories)...`);
          await new Promise(r => setTimeout(r, delayMs));
        }
        
        const comp = competitors[compIdx];
        const compUsername = comp.page_url.replace("https://www.instagram.com/", "").replace("/", "");
        addLog(`📱 Buscando stories de @${comp.name}...`);
        
        try {
          const storyRes = await fetch(`${SUPABASE_URL}/functions/v1/scrape-reels`, {
            method: "POST",
            headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
            body: JSON.stringify({
              username: compUsername,
              limit: isCron ? Math.min(apifyConfig.storyMaxItems, 10) : apifyConfig.storyMaxItems,
              provider: scrape_provider,
              action: "stories",
              actorId: apifyConfig.storyScraper,
              proxyCountry: apifyConfig.proxyCountry,
              firecrawlConfig: scrape_provider === "firecrawl" ? firecrawlConfig : undefined,
            }),
          });
          const storyResult = await storyRes.json();

          if (!storyResult.success) {
            addLog(`⚠️ Falha ao buscar stories de @${comp.name}: ${storyResult.error}`);
            continue;
          }

          const storyContent = storyResult.reels || [];
          addLog(`📱 @${comp.name}: ${storyContent.length} stories encontrados`);

          if (storyContent.length > 0) {
            // Analyze stories with AI (caption/image analysis)
            for (const story of storyContent) {
              try {
                let transcriptText = "";
                
                if (story.video_url) {
                  try {
                    const videoRes = await fetch(`${SUPABASE_URL}/functions/v1/analyze-content`, {
                      method: "POST",
                      headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
                      body: JSON.stringify({ action: "video_analysis", content: story.caption || "", videoUrl: story.video_url, model: agentPrompts["video_transcriber"]?.model || ai_model, contentType: "story" }),
                    });
                    const videoData = await videoRes.json();
                    if (videoData.success && videoData.result) transcriptText = videoData.result;
                  } catch (e) { /* fallback */ }
                  await new Promise(r => setTimeout(r, 1500));
                } else if (story.thumbnail_url) {
                  try {
                    const imgRes = await fetch(`${SUPABASE_URL}/functions/v1/analyze-content`, {
                      method: "POST",
                      headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
                      body: JSON.stringify({ action: "image_analysis", content: story.caption || "", imageUrls: [story.thumbnail_url], model: agentPrompts["image_analyzer"]?.model || ai_model, contentType: "story" }),
                    });
                    const imgData = await imgRes.json();
                    if (imgData.success && imgData.result) transcriptText = imgData.result;
                  } catch (e) { /* fallback */ }
                  await new Promise(r => setTimeout(r, 1500));
                }

                if (!transcriptText && story.caption) {
                  transcriptText = story.caption;
                }

                story.transcript = transcriptText;
                story.competidor_id = comp.id;
                story.user_id = configUserId;
              } catch (e) {
                story.transcript = "";
                story.competidor_id = comp.id;
                story.user_id = configUserId;
              }
            }

            // Save stories to reels_competidores with content_type = "story"
            const { error: insertError } = await supabase.from("reels_competidores").insert(
              storyContent.map((s: any) => ({
                caption: s.caption || "",
                owner_username: s.owner_username,
                url: s.url,
                thumbnail_url: s.thumbnail_url,
                video_url: s.video_url,
                views: s.views || 0,
                likes: s.likes || 0,
                comments: s.comments || 0,
                post_date: s.post_date,
                content_type: "story",
                eng_rate: s.eng_rate || 0,
                transcript: s.transcript || "",
                competidor_id: comp.id,
                user_id: configUserId,
                relevance_status: "approved",
              }))
            );
            if (insertError) addLog(`⚠️ Erro salvando stories: ${insertError.message}`);
            else addLog(`💾 ${storyContent.length} stories de @${comp.name} salvos`);

            // Save to MinIO
            try {
              const dateStr = new Date().toISOString().split("T")[0];
              await fetch(`${SUPABASE_URL}/functions/v1/save-to-minio`, {
                method: "POST",
                headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
                body: JSON.stringify({
                  action: "save",
                  path: `analysis/${dateStr}/stories/${comp.name}/stories.json`,
                  data: storyContent,
                }),
              });
            } catch (e) { addLog(`⚠️ MinIO save failed for stories @${comp.name}`); }
          }
        } catch (e) {
          addLog(`❌ Erro ao buscar stories de @${comp.name}: ${e}`);
        }
      }
    } else if (!IG_USERNAME || !IG_PASSWORD) {
      addLog("⏭️ Phase 2.5: Stories ignorado (INSTAGRAM_USERNAME/PASSWORD não configurados)");
    }

    // ===== PHASE 3: Strategy Report (All Content Types) =====
    addLog("📌 Phase 3: Generating strategy report (Reels + Posts + Carousels + Stories)...");
    
    const { data: savedMyContent } = await supabase.from("meus_reels").select("*").order("views", { ascending: false });
    const { data: savedCompContent } = await supabase.from("reels_competidores").select("*").order("views", { ascending: false });

    const strategyContent = `# MY CONTENT (Reels + Posts + Carousels):\n${JSON.stringify(savedMyContent?.map(r => ({
      type: r.content_type,
      caption: r.caption?.slice(0, 500),
      user: r.owner_username,
      views: r.views,
      likes: r.likes,
      comments: r.comments,
      transcript: r.transcript?.slice(0, 500),
      hook_analysis: r.hook_analysis,
      slides: r.image_urls?.length || 0,
    })))}\n\n# COMPETITOR CONTENT (Reels + Posts + Carousels):\n${JSON.stringify(savedCompContent?.map(r => ({
      type: r.content_type,
      caption: r.caption?.slice(0, 500),
      user: r.owner_username,
      url: r.url,
      views: r.views,
      likes: r.likes,
      comments: r.comments,
      transcript: r.transcript?.slice(0, 500),
      hook_analysis: r.hook_analysis,
      post_date: r.post_date,
      slides: r.image_urls?.length || 0,
    })))}`;

    const stratAgent = agentPrompts["content_strategist"] || {};
    const strategyRes = await fetch(`${SUPABASE_URL}/functions/v1/analyze-content`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
      body: JSON.stringify({
        action: "strategy_report",
        content: strategyContent,
        model: stratAgent.model || "google/gemini-2.5-pro",
        ...stratAgent.custom_prompt && { custom_prompt: stratAgent.custom_prompt },
        ...stratAgent.custom_prompt_2 && { custom_prompt_2: stratAgent.custom_prompt_2 },
        ...stratAgent.custom_prompt_3 && { custom_prompt_3: stratAgent.custom_prompt_3 },
      }),
    });
    const strategyData = await strategyRes.json();

    if (strategyData.success) {
      try {
        const report = JSON.parse(strategyData.result);
        await supabase.from("estrategias").insert({
          title: `${new Date().toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric" })} - Análise Completa`,
          key_takeaway: report.key_takeaway,
          top_videos: report.top_content || report.top_competitor_videos,
          winning_patterns: report.winning_patterns,
          hook_ideas: report.hook_ideas,
          raw_report: strategyData.result,
          user_id: configUserId,
        });
        addLog("✅ Strategy report saved (Reels + Posts + Carousels + Stories)!");

        // Save strategy report to MinIO
        try {
          const dateStr = new Date().toISOString().split("T")[0];
          await fetch(`${SUPABASE_URL}/functions/v1/save-to-minio`, {
            method: "POST",
            headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
            body: JSON.stringify({
              action: "save",
              path: `reports/${dateStr}/strategy-report.json`,
              data: { ...report, generated_at: new Date().toISOString(), my_content_count: savedMyContent?.length || 0, competitor_content_count: savedCompContent?.length || 0 },
            }),
          });
          addLog("📦 Strategy report saved to MinIO");
        } catch (e) {
          addLog(`⚠️ MinIO save failed for strategy report: ${e}`);
        }
      } catch (e) {
        await supabase.from("estrategias").insert({
          title: new Date().toLocaleDateString("pt-BR"),
          raw_report: strategyData.result,
          user_id: configUserId,
        });
        addLog("⚠️ Report saved as raw text (JSON parse failed)");
      }
    } else {
      addLog(`❌ Strategy generation failed: ${strategyData.error}`);
    }

    // ===== PHASE 4: Auto-Generate Ideas & Push to Kanban =====
    addLog("📌 Phase 4: Gerando ideias automaticamente...");

    try {
      // Build context from all analyzed content
      const allMyContent = savedMyContent || [];
      const allCompContent = savedCompContent || [];

      let ideaContext = "Gere 5 ideias criativas de conteúdo para Instagram baseado nos seguintes dados RECÉM-ANALISADOS:\n\n";

      if (allCompContent.length > 0) {
        ideaContext += "CONTEÚDOS DOS COMPETIDORES (recém-raspados):\n" + allCompContent.slice(0, 15).map(r =>
          `- [${r.content_type}] @${r.owner_username}: ${(r.caption || "").slice(0, 100)} | Views: ${r.views || 0} | Eng: ${Number(r.eng_rate || 0).toFixed(1)}% | Hook: ${(r.hook_analysis || "").slice(0, 80)}`
        ).join("\n") + "\n\n";
      }

      if (allMyContent.length > 0) {
        ideaContext += "MEUS TOP CONTEÚDOS:\n" + allMyContent.slice(0, 10).map(r =>
          `- [${r.content_type}] ${(r.caption || "").slice(0, 100)} | Views: ${r.views || 0} | Eng: ${Number(r.eng_rate || 0).toFixed(1)}% | Hook: ${(r.hook_analysis || "").slice(0, 80)}`
        ).join("\n") + "\n\n";
      }

      // Add competitor profile context
      if (competitors && competitors.length > 0) {
        ideaContext += "PERFIS DOS COMPETIDORES:\n" + competitors.map(c =>
          `- @${c.name} (${c.niche || "sem nicho"}) | ${c.followers_count || 0} seguidores | ${c.posts_count || 0} posts | Tipo principal: ${c.predominant_content_type || "?"} | ${Number(c.avg_posts_per_week || 0).toFixed(1)} posts/semana`
        ).join("\n") + "\n\n";
      }

      ideaContext += `\nPara CADA ideia retorne em JSON array: { "title": "título curto", "description": "descrição de 2-3 frases", "format": "reel|post|carrossel|story", "hook": "gancho sugerido" }\nRetorne APENAS o JSON array, sem markdown.`;

      // Use idea_generator agent config if available
      const ideaAgent = agentPrompts["idea_generator"] || {};
      if (!ideaAgent.custom_prompt) {
        // Check DB for idea_generator config
        if (configUserId) {
          const { data: ideaCfg } = await supabase.from("agent_configs")
            .select("provider, model, custom_prompt, custom_prompt_2, custom_prompt_3")
            .eq("user_id", configUserId).eq("agent_type", "idea_generator").maybeSingle();
          if (ideaCfg) {
            Object.assign(ideaAgent, {
              model: ideaCfg.model || undefined,
              custom_prompt: ideaCfg.custom_prompt || undefined,
              custom_prompt_2: ideaCfg.custom_prompt_2 || undefined,
              custom_prompt_3: ideaCfg.custom_prompt_3 || undefined,
            });
          }
        }
      }

      addLog(`🤖 Agente [idea_generator] → modelo: ${ideaAgent.model || ai_model}`);

      const ideaRes = await fetch(`${SUPABASE_URL}/functions/v1/generate-content`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
        body: JSON.stringify({
          agent: "idea_generator",
          context: ideaContext,
          provider: "groq",
          model: ideaAgent.model || "llama-3.3-70b-versatile",
          custom_prompt: ideaAgent.custom_prompt || undefined,
          custom_prompt_2: ideaAgent.custom_prompt_2 || undefined,
          custom_prompt_3: ideaAgent.custom_prompt_3 || undefined,
        }),
      });

      const ideaData = await ideaRes.json();

      if (ideaData?.success && ideaData.result) {
        let newIdeas: any[] = [];
        try {
          const cleaned = ideaData.result.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
          const parsed = JSON.parse(cleaned);
          newIdeas = (Array.isArray(parsed) ? parsed : []).map((item: any, i: number) => ({
            id: `pipeline-${Date.now()}-${i}`,
            title: item.title || `Ideia ${i + 1}`,
            description: item.description || "",
            format: item.format || "reel",
            hook: item.hook || "",
            createdAt: new Date().toISOString(),
            source: "auto-pipeline",
          }));
        } catch {
          newIdeas = [{
            id: `pipeline-${Date.now()}`,
            title: "Ideia do Pipeline",
            description: ideaData.result.slice(0, 300),
            format: "reel",
            hook: "",
            createdAt: new Date().toISOString(),
            source: "auto-pipeline",
          }];
        }

        addLog(`💡 ${newIdeas.length} ideias geradas!`);

        // Save ideas to MinIO ideas bank
        const userId = configUserId || "default";
        const ideasPath = `ideas/${userId}/ideas.json`;
        let existingIdeas: any[] = [];
        try {
          const getRes = await fetch(`${SUPABASE_URL}/functions/v1/save-to-minio`, {
            method: "POST",
            headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
            body: JSON.stringify({ action: "get", path: ideasPath }),
          });
          const getData = await getRes.json();
          if (getData?.success && getData.content) existingIdeas = JSON.parse(getData.content);
        } catch { /* no existing ideas */ }

        const mergedIdeas = [...newIdeas, ...existingIdeas];
        await fetch(`${SUPABASE_URL}/functions/v1/save-to-minio`, {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
          body: JSON.stringify({ action: "save", path: ideasPath, data: mergedIdeas }),
        });
        addLog(`📦 ${mergedIdeas.length} ideias salvas no MinIO`);

        // Push ideas to Kanban board as "ideia" status items
        const kanbanPath = `kanban/${userId}/board.json`;
        let kanbanItems: any[] = [];
        try {
          const kbRes = await fetch(`${SUPABASE_URL}/functions/v1/save-to-minio`, {
            method: "POST",
            headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
            body: JSON.stringify({ action: "get", path: kanbanPath }),
          });
          const kbData = await kbRes.json();
          if (kbData?.success && kbData.content) kanbanItems = JSON.parse(kbData.content);
        } catch { /* no existing kanban */ }

        const formatEmojis: Record<string, string> = { reel: "🎬", post: "📷", carrossel: "🎠", story: "📱" };
        const newKanbanItems = newIdeas.map((idea: any) => ({
          id: `kb-${idea.id}`,
          title: `${formatEmojis[idea.format] || "💡"} ${idea.title}`,
          description: `${idea.description}\n\n🪝 Hook: "${idea.hook}"`,
          tags: [idea.format, "auto-pipeline"],
          date: new Date().toLocaleDateString("pt-BR", { day: "2-digit", month: "short" }),
          status: "ideia" as const,
        }));

        const updatedKanban = [...newKanbanItems, ...kanbanItems];
        await fetch(`${SUPABASE_URL}/functions/v1/save-to-minio`, {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
          body: JSON.stringify({ action: "save", path: kanbanPath, data: updatedKanban }),
        });
        addLog(`✅ ${newKanbanItems.length} ideias adicionadas à Central de Conteúdo (coluna Ideia)`);
      } else {
        addLog(`⚠️ Geração de ideias falhou: ${ideaData?.error || "sem resultado"}`);
      }
    } catch (ideaErr) {
      addLog(`❌ Erro na geração de ideias: ${ideaErr}`);
    }

    addLog("🎉 Pipeline complete! (Reels + Posts + Carousels + Stories analyzed + Ideas generated)");

    return new Response(JSON.stringify({ success: true, logs }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("run-pipeline error:", error);
    return new Response(JSON.stringify({ success: false, error: error instanceof Error ? error.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
