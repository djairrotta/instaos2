import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import Anthropic from "https://esm.sh/@anthropic-ai/sdk@0.24.3";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: cors });

  try {
    const SUPA_URL = Deno.env.get("SUPABASE_URL")!;
    const SUPA_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(SUPA_URL, SUPA_KEY);

    const auth = req.headers.get("Authorization") || "";
    const { data: { user } } = await supabase.auth.getUser(auth.replace("Bearer ", ""));
    if (!user) throw new Error("Auth required");

    const body = await req.json();
    const { action = "generate" } = body;

    // ── GENERATE: create full content strategy ─────────────────────────────
    if (action === "generate") {
      const {
        prompt,                          // user's free-text brief
        weeks = 4,                        // how many weeks to plan
        postsPerWeek = 5,                 // total posts per week
        distribution = { reel: 3, carrossel: 2, post: 0 }, // format split
        anthropicApiKey,                 // user's Anthropic key
        pillar1 = "", pillar2 = "", pillar3 = "", // content pillars
        niche = "direito bancário",
        tone = "educativo e direto",
      } = body;

      if (!prompt) throw new Error("prompt required");

      // Gather context: viral posts, recent sherlock, tone of voice
      const [{ data: topPosts }, { data: toneData }, { data: nicheConfig }] = await Promise.all([
        supabase.from("reels_competidores")
          .select("owner_username,caption,hook_type,adapted_hook,viral_score,content_type")
          .eq("user_id", user.id).eq("relevance_status", "approved")
          .gte("viral_score", 40).order("viral_score", { ascending: false }).limit(8),
        supabase.from("tone_of_voice")
          .select("tone_name,injection_string").eq("user_id", user.id).eq("is_active", true).limit(3),
        supabase.from("pipeline_config")
          .select("niche_description,target_audience").eq("user_id", user.id).maybeSingle(),
      ]);

      const topPostsContext = (topPosts || []).map((p, i) =>
        `${i+1}. @${p.owner_username} [${p.content_type}] Score:${p.viral_score} Hook:"${(p.adapted_hook || p.caption || "").slice(0, 80)}"`
      ).join("\n");

      const toneContext = (toneData || []).map(t => t.tone_name).join(", ") || tone;
      const nicheDesc = nicheConfig?.niche_description || niche;
      const audience = nicheConfig?.target_audience || "pessoas com dívidas bancárias, microempresários";

      const totalPosts = weeks * postsPerWeek;
      const reelCount = Math.round(totalPosts * (distribution.reel / postsPerWeek));
      const carrosselCount = Math.round(totalPosts * (distribution.carrossel / postsPerWeek));
      const postCount = totalPosts - reelCount - carrosselCount;

      const systemPrompt = `Você é um estrategista de conteúdo digital sênior especializado em Instagram para criadores de conteúdo profissional. Sua missão é criar estratégias de conteúdo que geram resultado real: seguidores, leads e conversões.

Você escreve em português brasileiro. Retorna SOMENTE JSON válido sem markdown.`;

      const userPrompt = `Crie uma estratégia de conteúdo completa para Instagram com base nas informações abaixo.

## BRIEFING DO USUÁRIO
${prompt}

## CONTEXTO DO PERFIL
- Nicho: ${nicheDesc}
- Público: ${audience}
- Tom de voz: ${toneContext}
- Pilares de conteúdo: ${[pillar1, pillar2, pillar3].filter(Boolean).join(" | ") || "educação, casos reais, dicas práticas"}

## POSTS VIRAIS DE REFERÊNCIA (top ${topPosts?.length || 0} do nicho)
${topPostsContext || "Nenhum disponível ainda"}

## PARÂMETROS DO PLANO
- Duração: ${weeks} semanas
- Posts por semana: ${postsPerWeek}
- Distribuição: ${reelCount} Reels + ${carrosselCount} Carrosséis + ${postCount} Posts estáticos
- Total: ${totalPosts} publicações

## INSTRUÇÕES
1. Crie ${totalPosts} ideias de conteúdo únicas e específicas para este nicho
2. Cada ideia deve ter: tema concreto, gancho de abertura (adaptado dos virais de referência), e formato
3. Distribua estrategicamente ao longo de ${weeks} semanas, ${postsPerWeek} por semana
4. Use os pilares informados para variar os temas
5. Baseie os ganchos nos padrões virais identificados nos posts de referência

Retorne JSON neste formato exato:
{
  "strategy_name": "nome da estratégia",
  "summary": "resumo de 2-3 frases da estratégia",
  "pillars": [
    {"name": "pilar 1", "description": "...", "posts_count": N, "color": "#hexcolor"}
  ],
  "weekly_themes": [
    {"week": 1, "theme": "tema da semana", "focus": "foco estratégico desta semana"}
  ],
  "posts": [
    {
      "id": "p1",
      "week": 1,
      "day_of_week": "segunda|terça|quarta|quinta|sexta|sábado|domingo",
      "format": "reel|carrossel|post",
      "pillar": "nome do pilar",
      "title": "título interno",
      "hook": "gancho exato de abertura (1 frase)",
      "hook_type": "Curiosidade|Dor|Promessa|Choque|Prova Social|Tendência|Urgência",
      "angle": "ângulo de abordagem",
      "cta": "call-to-action sugerido",
      "notes": "notas de produção (opcional)"
    }
  ],
  "insights": [
    "insight estratégico 1",
    "insight estratégico 2",
    "insight estratégico 3"
  ]
}`;

      // Use user's Anthropic key if provided, else system key
      const apiKey = anthropicApiKey || Deno.env.get("ANTHROPIC_API_KEY");
      if (!apiKey) throw new Error("Anthropic API key required. Configure em Agentes → Chaves de API.");

      const anthropic = new Anthropic({ apiKey });
      const message = await anthropic.messages.create({
        model: "claude-opus-4-20250514",
        max_tokens: 8000,
        messages: [
          { role: "user", content: userPrompt }
        ],
        system: systemPrompt,
      });

      const rawText = message.content[0].type === "text" ? message.content[0].text : "";
      let strategy: any;
      try {
        strategy = JSON.parse(rawText.replace(/```json|```/g, "").trim());
      } catch {
        throw new Error("Erro ao parsear resposta da IA. Tente novamente.");
      }

      // Save strategy to DB
      const { data: saved, error } = await supabase
        .from("content_strategies")
        .insert({
          user_id: user.id,
          name: strategy.strategy_name || `Estratégia ${new Date().toLocaleDateString("pt-BR")}`,
          summary: strategy.summary,
          weeks,
          posts_per_week: postsPerWeek,
          distribution,
          pillars: strategy.pillars || [],
          weekly_themes: strategy.weekly_themes || [],
          posts: strategy.posts || [],
          insights: strategy.insights || [],
          prompt_used: prompt,
          status: "draft",
        })
        .select()
        .single();

      if (error) throw error;

      return new Response(JSON.stringify({ success: true, strategy: saved }), {
        headers: { ...cors, "Content-Type": "application/json" },
      });
    }

    // ── LIST: get all strategies ───────────────────────────────────────────
    if (action === "list") {
      const { data } = await supabase
        .from("content_strategies")
        .select("id,name,summary,weeks,posts_per_week,status,created_at,pillars")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(20);
      return new Response(JSON.stringify({ success: true, strategies: data || [] }), {
        headers: { ...cors, "Content-Type": "application/json" },
      });
    }

    // ── GET: single strategy with all posts ───────────────────────────────
    if (action === "get") {
      const { strategyId } = body;
      const { data } = await supabase
        .from("content_strategies")
        .select("*")
        .eq("id", strategyId)
        .eq("user_id", user.id)
        .single();
      return new Response(JSON.stringify({ success: true, strategy: data }), {
        headers: { ...cors, "Content-Type": "application/json" },
      });
    }

    // ── UPDATE_POST: update a single post (agent, scheduled_date, status) ─
    if (action === "update_post") {
      const { strategyId, postId, updates } = body;
      const { data: strategy } = await supabase
        .from("content_strategies")
        .select("posts")
        .eq("id", strategyId)
        .eq("user_id", user.id)
        .single();
      if (!strategy) throw new Error("Strategy not found");

      const posts = (strategy.posts as any[]).map(p =>
        p.id === postId ? { ...p, ...updates } : p
      );
      await supabase.from("content_strategies").update({ posts }).eq("id", strategyId);
      return new Response(JSON.stringify({ success: true }), {
        headers: { ...cors, "Content-Type": "application/json" },
      });
    }

    // ── ACTIVATE: set strategy as active and push posts to calendar ───────
    if (action === "activate") {
      const { strategyId, startDate } = body;
      const { data: strategy } = await supabase
        .from("content_strategies")
        .select("*")
        .eq("id", strategyId)
        .eq("user_id", user.id)
        .single();
      if (!strategy) throw new Error("Strategy not found");

      // Map day_of_week to actual dates starting from startDate
      const start = new Date(startDate);
      const DAY_MAP: Record<string, number> = {
        "domingo": 0, "segunda": 1, "terça": 2, "quarta": 3,
        "quinta": 4, "sexta": 5, "sábado": 6,
      };

      const posts = (strategy.posts as any[]).map(post => {
        const weekOffset = (post.week - 1) * 7;
        const targetDay = DAY_MAP[post.day_of_week?.toLowerCase()] ?? 1;
        const date = new Date(start);
        date.setDate(date.getDate() + weekOffset);
        // Move to target day of week
        const currentDay = date.getDay();
        const diff = (targetDay - currentDay + 7) % 7;
        date.setDate(date.getDate() + diff);
        return { ...post, scheduled_date: date.toISOString().split("T")[0] };
      });

      await supabase.from("content_strategies").update({
        posts,
        status: "active",
        start_date: startDate,
      }).eq("id", strategyId);

      // Also deactivate other strategies
      await supabase.from("content_strategies")
        .update({ status: "archived" })
        .eq("user_id", user.id)
        .neq("id", strategyId)
        .eq("status", "active");

      return new Response(JSON.stringify({ success: true, posts }), {
        headers: { ...cors, "Content-Type": "application/json" },
      });
    }

    // ── DELETE ────────────────────────────────────────────────────────────
    if (action === "delete") {
      const { strategyId } = body;
      await supabase.from("content_strategies").delete()
        .eq("id", body.strategyId).eq("user_id", user.id);
      return new Response(JSON.stringify({ success: true }), {
        headers: { ...cors, "Content-Type": "application/json" },
      });
    }

    throw new Error(`Unknown action: ${action}`);
  } catch (e) {
    console.error("strategy-planner:", e);
    return new Response(JSON.stringify({ success: false, error: (e as Error).message }), {
      status: 500, headers: { ...cors, "Content-Type": "application/json" },
    });
  }
});
