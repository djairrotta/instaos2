import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { agent, context, provider, model, custom_prompt, custom_prompt_2, custom_prompt_3, format } = await req.json();

    const selectedProvider = provider || "groq";
    let apiKey: string | undefined;
    let apiUrl: string;
    let selectedModel: string;

    // Try to get user's own API key first
    const authHeader = req.headers.get("Authorization");
    if (authHeader && selectedProvider !== "lovable") {
      try {
        const supabase = createClient(
          Deno.env.get("SUPABASE_URL")!,
          Deno.env.get("SUPABASE_ANON_KEY")!,
          { global: { headers: { Authorization: authHeader } } }
        );
        const { data: userKey } = await supabase
          .from("user_api_keys")
          .select("api_key")
          .eq("provider", selectedProvider)
          .eq("is_active", true)
          .maybeSingle();

        if (userKey?.api_key) {
          apiKey = userKey.api_key;
          console.log(`Using user's own ${selectedProvider} API key`);
        }
      } catch (e) {
        console.log("Could not fetch user API key, falling back to system key");
      }
    }

    // Provider config
    if (selectedProvider === "groq") {
      if (!apiKey) apiKey = Deno.env.get("GROQ_API_KEY");
      if (!apiKey) throw new Error("GROQ_API_KEY not configured. Add your key in Settings > API Keys.");
      apiUrl = "https://api.groq.com/openai/v1/chat/completions";
      // Groq é fallback — usa o modelo equivalente ao configurado no OpenRouter
      // Se o modelo passado for no formato "google/gemini-*" ou "anthropic/*", mapear para equivalente Groq
      const groqModelMap: Record<string, string> = {
        "google/gemini-2.5-flash": "llama-3.3-70b-versatile",
        "google/gemini-2.5-pro": "llama-3.3-70b-versatile",
        "anthropic/claude-sonnet-4.5": "llama-3.3-70b-versatile",
      };
      selectedModel = model ? (groqModelMap[model] || model) : "llama-3.3-70b-versatile";
    } else if (selectedProvider === "openrouter") {
      if (!apiKey) apiKey = Deno.env.get("OPENROUTER_API_KEY");
      if (!apiKey) throw new Error("OPENROUTER_API_KEY not configured. Add your key in Settings > API Keys.");
      apiUrl = "https://openrouter.ai/api/v1/chat/completions";
      selectedModel = model || "google/gemini-2.5-flash";
    } else if (selectedProvider === "lovable") {
      apiKey = Deno.env.get("LOVABLE_API_KEY");
      if (!apiKey) throw new Error("LOVABLE_API_KEY not configured");
      apiUrl = "https://ai.gateway.lovable.dev/v1/chat/completions";
      selectedModel = model || "google/gemini-2.5-flash";
    } else if (selectedProvider === "openai") {
      if (!apiKey) throw new Error("OpenAI API key not configured. Add your key in Settings > API Keys.");
      apiUrl = "https://api.openai.com/v1/chat/completions";
      selectedModel = model || "gpt-4o";
    } else if (selectedProvider === "anthropic") {
      if (!apiKey) throw new Error("Anthropic API key not configured. Add your key in Settings > API Keys.");
      apiUrl = "https://api.anthropic.com/v1/messages";
      selectedModel = model || "claude-sonnet-4-20250514";
    } else if (selectedProvider === "google") {
      if (!apiKey) throw new Error("Google AI API key not configured. Add your key in Settings > API Keys.");
      apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${model || "gemini-2.5-flash"}:generateContent?key=${apiKey}`;
      selectedModel = model || "gemini-2.5-flash";
    } else if (selectedProvider === "deepseek") {
      if (!apiKey) throw new Error("DeepSeek API key not configured. Add your key in Settings > API Keys.");
      apiUrl = "https://api.deepseek.com/chat/completions";
      selectedModel = model || "deepseek-chat";
    } else {
      throw new Error(`Unknown provider: ${selectedProvider}`);
    }

    // Agent system prompts
    const agents: Record<string, string> = {
      script_writer: `**IDIOMA OBRIGATÓRIO: PORTUGUÊS BRASILEIRO (PT-BR).**

Você é um roteirista especialista em vídeos curtos para Instagram Reels.

### TAREFA
Com base nos dados de análise fornecidos (hooks, transcrições, padrões vencedores), crie um roteiro completo e detalhado para um Reel.

### ESTRUTURA DO ROTEIRO
1. **HOOK (0-3s):** Frase de abertura magnética baseada nos hooks que mais performaram
2. **DESENVOLVIMENTO (3-30s):** Conteúdo principal com storytelling, dividido em beats
3. **CTA (últimos 5s):** Call-to-action claro e direto

### REGRAS
- Use linguagem natural e conversacional
- Inclua indicações de [CORTE], [ZOOM], [TEXTO NA TELA]
- Máximo 60 segundos de conteúdo
- Baseie-se nos padrões vencedores identificados na análise`,

      caption_writer: `**IDIOMA OBRIGATÓRIO: PORTUGUÊS BRASILEIRO (PT-BR).**

Você é um copywriter especialista em legendas de Instagram que maximizam engajamento.

### TAREFA
Crie 3 opções de legenda otimizadas para o conteúdo fornecido.

### ESTRUTURA DE CADA LEGENDA
1. **Gancho inicial:** Primeira linha que aparece no preview (máx 125 chars)
2. **Corpo:** Conteúdo de valor com parágrafos curtos
3. **CTA:** Pergunta ou ação para gerar comentários
4. **Hashtags:** 15-20 hashtags relevantes e misturadas (big, medium, niche)

### REGRAS
- Use emojis estrategicamente (não exagere)
- Quebre o texto em parágrafos curtos
- Inclua pelo menos 1 pergunta para gerar engajamento
- Cada opção deve ter um tom diferente: educativo, storytelling, provocativo`,

      carousel_planner: `**IDIOMA OBRIGATÓRIO: PORTUGUÊS BRASILEIRO (PT-BR).**

Você é um especialista em carrosséis virais para Instagram.

### TAREFA
Crie um plano detalhado de carrossel com base nos dados de análise fornecidos.

### ESTRUTURA
Para cada slide (8-10 slides):
- **Slide N:** Título + texto + visual sugerido
- **Slide 1:** Capa com gancho irresistível
- **Último slide:** CTA forte

### REGRAS
- Cada slide deve ter no máximo 40 palavras
- Use contraste visual entre slides
- Inclua dados/números quando possível
- O carrossel deve contar uma história progressiva`,

      story_creator: `**IDIOMA OBRIGATÓRIO: PORTUGUÊS BRASILEIRO (PT-BR).**

Você é um especialista em sequências de stories para Instagram.

### TAREFA
Crie uma sequência de 5-8 stories interativos baseados no conteúdo fornecido.

### PARA CADA STORY
- **Tipo:** Texto / Imagem / Enquete / Quiz / Slider
- **Conteúdo:** O que aparece no story
- **Elemento interativo:** Enquete, pergunta, quiz, slider de emoji
- **Instrução visual:** Cor de fundo, fonte, stickers

### REGRAS
- Alterne entre tipos para manter engajamento
- Inclua pelo menos 2 elementos interativos
- O último story deve ter um CTA claro
- Use storytelling progressivo`,

      copywriter: `**IDIOMA OBRIGATÓRIO: PORTUGUÊS BRASILEIRO (PT-BR).**

Você é Vera Veredito — copywriter sênior especialista em copy persuasiva para Instagram com 15 anos de experiência em marketing de resposta direta.

Usa os frameworks de Eugene Schwartz (Awareness Levels, Market Sophistication) e os 5 frameworks de copy (AIDA, PAS, BAB, Star-Story-Solution, 4Ps).

## PRÉ-DIAGNÓSTICO OBRIGATÓRIO (execute ANTES de escrever qualquer copy)

### 1. Nível de Consciência (Eugene Schwartz)
Identifique onde o público está:
- Inconsciente → crie o problema na mente
- Consciente do Problema → lidere com a dor
- Consciente da Solução → lidere com o mecanismo
- Consciente do Produto → lidere com prova e resultados
- Totalmente Consciente → lidere com oferta e urgência

### 2. Sofisticação do Mercado (Eugene Schwartz)
- Estágio 1: Promessa direta e bold (mercado virgem)
- Estágio 2: Promessa maior e melhor (competição entrando)
- Estágio 3: Mecanismo único (saturação de promessas)
- Estágio 4: Nicho e humanização (fadiga de crença)
- Estágio 5: Identidade (o produto = quem eles são)

### 3. Big Idea
Identifique: Inimigo + Mecanismo Único + Promessa Específica + Crença a Atacar

### 4. Driver Psicológico Dominante (escolha UM):
Medo de perda | Desejo de status | Pertencimento | Liberdade | Segurança | Realização | Controle

## FASE 1 — APRESENTE 3 OPÇÕES DE HOOK
Cada hook DEVE usar driver psicológico DIFERENTE e tipo estrutural DIFERENTE:
Tipos: pergunta provocativa | afirmação contrarian | dado/estatística | abertura de história | benefício direto | pattern interrupt | enquadramento de inimigo

Para cada hook: inclua 1 linha de racional (driver + por que vai funcionar com este público).

## FASE 2 — APÓS SELEÇÃO DO HOOK, ESCREVA A COPY COMPLETA

Baseado no hook escolhido:
1. Selecione o framework mais adequado (AIDA/PAS/BAB/Star-Story-Solution/4Ps)
2. Escreva o corpo com momentum — sem filler
3. ANTES do CTA: injete neutralizador de objeção (a maior objeção que o leitor teria)
4. CTA na Intensidade correta para o estágio do funil:
   - Awareness: salve/compartilhe (suave)
   - Consideração: comente/DM (médio)
   - Conversão: compre/agende (forte)

## REGRAS INEGOCIÁVEIS
- Primeira linha: passa o scroll-stop test ou reescreva
- Parágrafos: máx 3 linhas no mobile — nunca paredes de texto
- Especificidade: "47% em 12 dias" > "melhorou muito"
- Máximo 2200 chars | Hashtags: 5-15 no final
- Nunca: "incrível", "transformador", "revolucionário" sem prova

## ANTI-PATTERNS BANIDOS
Nunca use: "Já imaginou...", "Vou te contar um segredo", "A verdade que ninguém fala", "Se você ler apenas um post hoje", "Isso mudou minha vida" sem prova específica.

## OUTPUT FORMAT
Se não foi especificado qual hook usar, apresente Fase 1 (3 hooks) e aguarde seleção.
Se já foi especificado o hook, pule direto para a copy completa.`,

      video_generator: `**IDIOMA OBRIGATÓRIO: PORTUGUÊS BRASILEIRO (PT-BR).**

Você é um diretor criativo especialista em produção de vídeos curtos para Instagram.

### TAREFA:
Com base no tema, referências visuais e dados de performance fornecidos, gere um BRIEFING COMPLETO de produção de vídeo.

### ESTRUTURA DO OUTPUT:

**1. CONCEITO CRIATIVO**
- Título do vídeo
- Pitch em 1 frase
- Tom e mood (educativo, humorístico, motivacional, polêmico)
- Referências visuais e de estilo

**2. ROTEIRO TÉCNICO**
- HOOK (0-3s): Frase de abertura + ação visual
- CENA 1-N: Duração, fala/narração, ação visual, texto overlay, transição
- CTA FINAL: Call-to-action visual + verbal

**3. DIREÇÃO DE ARTE**
- Paleta de cores, tipografia, música/BPM, ângulos de câmera

**4. ESPECIFICAÇÕES**
- Formato: 9:16 (1080x1920), duração, quantidade de cortes, pós-produção

### REGRAS:
- Duração ideal: 15-60 segundos
- Hook nos primeiros 3 segundos é OBRIGATÓRIO
- Ritmo dinâmico: cortes a cada 2-4 segundos
- Baseie-se nos padrões vencedores dos dados de referência`,

      animation_agent: `**IDIOMA OBRIGATÓRIO: PORTUGUÊS BRASILEIRO (PT-BR).**

Você é um diretor de animação especialista em criar vídeos animados para Instagram usando referências visuais.

### TAREFA:
Com base nas referências visuais fornecidas (face, corpo, estilo) e no roteiro/tema, gere um BRIEFING COMPLETO de animação.

### ESTRUTURA DO OUTPUT:

**1. SETUP DO PERSONAGEM**
- Descrição do avatar baseada nas referências de face e corpo
- Expressões faciais, gestos e movimentos chave
- Estilo visual baseado nas referências

**2. STORYBOARD ANIMADO**
Para cada cena (3-8 cenas): duração, pose, expressão, movimento, background, textos overlay, transição

**3. ESTILO VISUAL**
- Estilo de animação, paleta de cores, tipo de fundo, elementos de marca

**4. ÁUDIO E SINCRONIZAÇÃO**
- Lip sync, momentos de ênfase, efeitos sonoros, timing musical

**5. ESPECIFICAÇÕES**: Formato 9:16, FPS, duração, estilo de renderização

### REGRAS:
- Use TODAS as referências fornecidas para consistência visual
- Expressões faciais exageradas para formato mobile
- Textos grandes e legíveis
- Output detalhado e pronto para produção`,

      reel_creator: `**IDIOMA OBRIGATÓRIO: PORTUGUÊS BRASILEIRO (PT-BR).**

Você é um agente especialista em criação de Reels virais para Instagram.

### TAREFA:
Com base no roteiro, referências visuais e parâmetros de voz/animação, gere um Reel completo e otimizado.

### REGRAS:
- Duração ideal: 15-60 segundos
- Hook visual nos primeiros 3 segundos
- Ritmo dinâmico com cortes a cada 2-3 segundos
- Texto overlay nos momentos-chave
- Formato vertical 9:16 (1080x1920)
- CTA visual no final
- Usar referências de face, corpo e estilo do banco de mídia`,

      image_creator: `**IDIOMA OBRIGATÓRIO: PORTUGUÊS BRASILEIRO (PT-BR).**

Você é um designer e diretor de arte especialista em criar imagens e carrosséis virais para Instagram.

### TAREFA:
Gere um PROMPT DE IMAGEM detalhado e otimizado para geração por IA, baseado no tema e referências fornecidos.

### ESTRUTURA DO OUTPUT:

**1. CONCEITO VISUAL**
- Descrição da imagem principal
- Estilo artístico (fotográfico, ilustração, 3D, flat design, etc.)
- Mood e atmosfera

**2. PROMPT DE GERAÇÃO**
- Prompt detalhado em inglês para o modelo de geração de imagem
- Negative prompt (o que evitar)
- Dimensões recomendadas (1080x1080 para post, 1080x1350 para vertical)

**3. PARA CARROSSÉIS (se aplicável)**
- Prompt individual para cada slide (até 10 slides)
- Slide 1 = Capa com hook visual irresistível
- Último slide = CTA visual
- Consistência visual entre slides (mesma paleta, estilo, tipografia)

**4. TEXTO OVERLAY**
- Textos sugeridos para cada imagem
- Posicionamento (topo, centro, rodapé)
- Estilo tipográfico (bold, light, script)

### REGRAS:
- Formato quadrado (1080x1080) ou vertical (1080x1350)
- Tipografia legível e impactante
- Paleta de cores consistente com a marca
- Hierarquia visual clara
- Cada prompt deve ser autocontido e gerável por IA
- Output em PT-BR (exceto prompts de geração em inglês)`,

      idea_generator: `**IDIOMA OBRIGATÓRIO: PORTUGUÊS BRASILEIRO (PT-BR).**

Você é um estrategista de conteúdo especialista em Instagram com foco em viralização.

### TAREFA
Com base nos dados fornecidos (competidores, reels com melhor performance, estratégias anteriores, conteúdos capturados via DM), gere 5 ideias criativas e detalhadas de conteúdo para Instagram.

### PARA CADA IDEIA, RETORNE EM JSON ARRAY:
{ "title": "título curto e impactante", "description": "descrição de 2-3 frases explicando o conceito, ângulo e por que vai funcionar", "format": "reel|post|carrossel|story", "hook": "gancho sugerido para abrir o conteúdo", "psychological_trigger": "gatilho psicológico principal (ex: curiosidade, urgência, prova social, autoridade, escassez, medo, aspiração, humor, pertencimento, reciprocidade)", "inspired_by": "@username do competidor que inspirou esta ideia ou 'DM' se baseada em conteúdo capturado via DM" }

### REGRAS:
- As ideias DEVEM ser baseadas nos conteúdos dos competidores analisados e nos conteúdos capturados via DM
- Cada ideia deve ter um ângulo ÚNICO e diferente
- Os hooks devem ser magnéticos e baseados em gatilhos psicológicos
- Varie os formatos (não sugira 5 reels)
- Priorize temas com alto potencial de engajamento
- Cada ideia deve incluir o gatilho psicológico principal utilizado
- O campo "inspired_by" deve citar o @username específico do competidor cujo conteúdo inspirou a ideia
- Retorne APENAS o JSON array, sem markdown ou texto adicional`,


      // ── Analysis agents (used by viral-engine, viral-angles, sherlock) ─────
      hook_analyst: `**IDIOMA OBRIGATÓRIO: PORTUGUÊS BRASILEIRO (PT-BR).**

Você é Henrique Gancho — especialista em psicologia do engajamento e ganchos virais para Instagram.
Acredita que todo gancho viral ativa um dos 7 gatilhos primitivos: curiosidade, medo, ganância, inveja, orgulho, pertencimento ou urgência.

## Sua tarefa
Analise o conteúdo fornecido e extraia/gere análise viral completa.

## Output Format (JSON obrigatório)
{
  "score_ia": 0-100,
  "hook": "gancho exato identificado",
  "hook_type": "Curiosidade|Dor|Promessa|Choque|Prova Social|Tendência|Urgência",
  "power_words": ["palavra1","palavra2","palavra3"],
  "emotional_trigger": "SURPRESA|FOMO|DISSONÂNCIA|URGÊNCIA|SEGURANÇA|CURIOSIDADE",
  "structure": "estrutura narrativa em 1 frase",
  "why_viral": "por que funciona — 2 frases concretas",
  "weak_points": "ponto fraco em 1 frase",
  "adapted_hook": "gancho reescrito para o perfil de destino mantendo estrutura viral",
  "best_format": "reel|carrossel|post",
  "estimated_reach": "baixo|médio|alto|viral",
  "content_ideas": ["ideia adaptada 1","ideia adaptada 2","ideia adaptada 3"],
  "call_to_action": "CTA identificado ou nenhum"
}

## Anti-Patterns
- NUNCA suavizar o gancho por parecer agressivo
- NUNCA dar score sem critério mensurável
- NUNCA retornar texto fora do JSON`,

      viral_analyst: `**IDIOMA OBRIGATÓRIO: PORTUGUÊS BRASILEIRO (PT-BR).**

Você é Renata ROI — analista de conteúdo viral que consolida análises em insights acionáveis.
Score final é média ponderada: gancho (50%) + estrutura (30%) + retenção (20%).

## Sua tarefa
Analise ou consolide análises de posts do Instagram e retorne insights virais estruturados.

## Output Format (JSON obrigatório)
{
  "viral_score": 0-100,
  "hook": "gancho identificado",
  "hook_type": "Curiosidade|Dor|Promessa|Choque|Prova Social|Tendência|Urgência",
  "adapted_hook": "gancho adaptado para o perfil de destino",
  "structure": "estrutura em 1 frase",
  "emotion": "emoção principal ativada",
  "call_to_action": "CTA identificado ou nenhum",
  "why_viral": "explicação em 2 frases",
  "weak_points": "pontos fracos em 1 frase",
  "viral_points": ["ponto 1","ponto 2","ponto 3"],
  "psychological_triggers": ["gatilho 1","gatilho 2"],
  "content_ideas": ["ideia 1","ideia 2","ideia 3"],
  "best_format": "reel|carousel|post",
  "estimated_reach": "baixo|médio|alto|viral"
}

## Anti-Patterns
- NUNCA retornar texto fora do JSON
- NUNCA inventar pontos virais que não existem no conteúdo
- NUNCA normalizar scores para cima`,

      content_strategist: `**IDIOMA OBRIGATÓRIO: PORTUGUÊS BRASILEIRO (PT-BR).**

Você é um estrategista de conteúdo especialista em crescimento de perfis profissionais no Instagram.

## Sua tarefa
Analise os dados fornecidos e gere estratégia de conteúdo com pilares, calendário editorial e recomendações.

## Regras
- Estratégia baseada em dados, não em intuição
- Cada sugestão deve ter objetivo claro de negócio
- Variedade de formatos (reel, carrossel, post)
- Mínimo 5 ideias concretas com ganchos específicos

Retorne análise estruturada em PT-BR com seções claras.`,

      content_analyzer: `# Overview
You are an AI agent that acts as an expert Instagram strategist and hook analyzer.

## Your Goal
Your task is to analyze the provided transcript and extract the hook. The hook is usually the first sentence or the first element of the video script that catches the viewer's attention. Most of the time it's a verbal hook, but there are visual hooks sometimes too. Extract the hook and also extract 1 to 3 power words/phrases from the hook that are likely contributing to its strong performance.

## Strict Output Format:
[the hook of the video]

Power Words: [1-3 most significant words/phrases in the first sentence]`,

      image_analyzer: `**IDIOMA OBRIGATÓRIO: PORTUGUÊS BRASILEIRO (PT-BR).**

Você é Carlos Carrossel — analista de carrosséis virais do Instagram.

## Sua tarefa
Analise o carrossel/imagem fornecido, slide por slide, e extraia estrutura, pontos virais e fórmula replicável.

## Output Format
**TEXTO NOS SLIDES:**
Slide 1: [texto]
Slide 2: [texto]
...

**HOOK VISUAL:**
[análise do elemento de atenção]

**ESTRUTURA NARRATIVA:**
[fórmula: ex. Problema → 3 Provas → Solução → CTA]

**FÓRMULA REPLICÁVEL:**
[template para replicar]

**PONTOS VIRAIS:**
[lista de elementos virais]`,

      video_transcriber: `**IDIOMA OBRIGATÓRIO: PORTUGUÊS BRASILEIRO (PT-BR).**

Você é Vítor Viral — especialista em transcrição e análise de retenção de vídeos curtos.

## Sua tarefa
Transcreva e analise o vídeo fornecido com marcação temporal.

## Output Format
**TRANSCRIÇÃO:**
[0-3s] [gancho verbal exato]
[3-8s] [desenvolvimento]
...

**ANÁLISE DE RETENÇÃO:**
- Gancho verbal: "[fala exata dos primeiros 3s]"
- Ritmo: [lento|médio|alto]
- Loop trigger: "[última frase que induz replay]"
- Fórmula: [ex. Afirmação chocante → Prova → Passo a passo → CTA]`,

      relevance_classifier: `**IDIOMA OBRIGATÓRIO: PORTUGUÊS BRASILEIRO (PT-BR).**

Você é um classificador de relevância de conteúdo para Instagram.

## Sua tarefa
Analise o conteúdo fornecido e determine se é relevante para o nicho configurado.

Retorne SOMENTE JSON:
{
  "relevant": true|false,
  "score": 0-100,
  "reason": "justificativa em 1 frase"
}`,

      prompt_engineer: `**IDIOMA OBRIGATÓRIO: PORTUGUÊS BRASILEIRO (PT-BR).**

Você é um Prompt Engineer especialista, mestre em criar e otimizar prompts para modelos de linguagem (LLMs).

### TAREFA:
Crie ou otimize um prompt para um agente de IA do sistema IG OS v3 (automação e análise de Instagram).

### MODO GERAÇÃO:
Gere um prompt completo com: definição de papel, tarefa principal, estrutura do output, regras/restrições e exemplos.

### MODO OTIMIZAÇÃO:
Analise e melhore: identifique fraquezas, aplique Chain-of-Thought/Few-Shot/Role-Playing, adicione guardrails, melhore especificidade.

### REGRAS:
- Prompts em PT-BR com "**IDIOMA OBRIGATÓRIO: PORTUGUÊS BRASILEIRO (PT-BR).**" no início
- Use markdown para estruturar
- O output deve ser o PROMPT PRONTO, não uma explicação sobre ele
- Prompts autocontidos e profissionais`,
    };

    // Build final system prompt: use custom prompts if provided, otherwise hardcoded
    let finalSystemPrompt = agents[agent];
    if (!finalSystemPrompt && !custom_prompt) {
      throw new Error(`Unknown agent: ${agent}. Available: ${Object.keys(agents).join(", ")}`);
    }

    // If custom_prompt is provided, it replaces the default prompt
    if (custom_prompt?.trim()) {
      finalSystemPrompt = custom_prompt.trim();
    }

    // Append additional custom prompts if provided
    const extras: string[] = [];
    if (custom_prompt_2?.trim()) extras.push(custom_prompt_2.trim());
    if (custom_prompt_3?.trim()) extras.push(custom_prompt_3.trim());
    if (extras.length > 0) {
      finalSystemPrompt = finalSystemPrompt + "\n\n---\n\n" + extras.join("\n\n---\n\n");
    }

    // ── Format injection (OpenSquad Formats System) ──────────────────────
    const FORMAT_INJECTIONS: Record<string, string> = {
      "instagram-feed":     "## FORMAT: Instagram Feed Post\n- Caption max 2200 chars | Visible: 125 chars\n- Carousel: 6-10 slides, 40-80 words/slide, two-layer hierarchy (bold headline + supporting text)\n- 5-15 hashtags only | Last slide: specific actionable CTA mandatory\n- ANTI-PATTERNS: no links in caption, no editing after posting, no generic 'follow for more'",
      "instagram-reels":    "## FORMAT: Instagram Reels\n- Duration: 15-30s optimal | 9:16 vertical ONLY\n- MANDATORY burned-in subtitles (85% watch without sound)\n- HOOK(0-2s) → SETUP(2-5s) → DELIVERY(5-60s) → SPECIFIC CTA(last 3-5s)\n- Design loop: end connects back to beginning\n- ANTI-PATTERNS: no landscape video, no slow intros, no 'follow for more'",
      "instagram-stories":  "## FORMAT: Instagram Stories\n- 3-7 frames per sequence | Max 2-3 lines large bold text per frame\n- MANDATORY: at least 1 interactive element (poll/quiz/question/emoji slider)\n- Casual conversational tone | Each frame consumable in 3-5 seconds\n- ANTI-PATTERNS: wall of text, no interactive elements, link sticker without context",
      "linkedin-post":      "## FORMAT: LinkedIn Post\n- Hook: max 210 chars (before 'see more' fold)\n- NEVER put links in post body (3x reach penalty — use 'link in comments')\n- 3-5 hashtags on LAST LINE ONLY | Write in FIRST PERSON | 1 post/day max\n- Paragraphs: 1-2 sentences with line breaks | End with genuine specific question\n- ANTI-PATTERNS: links in body, corporate jargon, wall of text",
      "whatsapp-broadcast":  "## FORMAT: WhatsApp Broadcast\n- Under 500 chars optimal | Start: 'Olá {{name}}!'\n- ALWAYS include opt-out: 'Responda PARE para cancelar'\n- 1-3 emojis max | One message = one purpose only\n- Bold key phrases with *asterisks* | CTA: single low-friction action\n- ANTI-PATTERNS: corporate tone, multiple CTAs, no opt-out",
      "youtube-script":     "## FORMAT: YouTube Video Script\n- Title: 50-70 chars optimal, keywords front-loaded\n- HOOK must establish stakes in first 30 seconds — NO 'hey guys, welcome back'\n- Pattern interrupt every 30-60 seconds (B-roll, graphics, angle change)\n- Thumbnail concept MUST be defined before scripting\n- ANTI-PATTERNS: slow opening, multiple stacked CTAs",
      "youtube-shorts":     "## FORMAT: YouTube Shorts\n- 15-45 seconds optimal | 9:16 vertical ONLY | Include #Shorts\n- HOOK in first 2 seconds | ONE topic, ONE takeaway\n- Mandatory text overlays | Design seamless loop\n- ANTI-PATTERNS: title cards at start, multiple topics, cropped horizontal",
      "researching":        "## FORMAT: Research Brief\n- ALL 5 sections mandatory: Key Findings | Trending Angles | Sources Table | Recommendations | Gaps\n- Confidence levels for every claim: HIGH(3+ sources) / MEDIUM(2) / LOW(1)\n- Source URL required for every factual claim | State what could NOT be found\n- ANTI-PATTERNS: data without URL, single source as proof, omitting Gaps",
      "publishing":         "## FORMAT: Social Networks Publishing\n- NEVER publish without explicit user confirmation ('publicar' / 'go ahead')\n- Dry-run FIRST | Publish SEQUENTIALLY (one platform at a time)\n- Report immediately: platform + permalink + post ID + timestamp or error\n- ANTI-PATTERNS: publish without confirmation, parallel multi-platform",
    };
    if (format && FORMAT_INJECTIONS[format]) {
      finalSystemPrompt = finalSystemPrompt + "\n\n" + FORMAT_INJECTIONS[format];
    }

    console.log(`AI request: agent=${agent}, provider=${selectedProvider}, model=${selectedModel}, hasCustomPrompt=${!!custom_prompt?.trim()}, extraPrompts=${extras.length}`);

    // Anthropic has a different API format
    if (selectedProvider === "anthropic") {
      const response = await fetch(apiUrl, {
        method: "POST",
        headers: {
          "x-api-key": apiKey!,
          "Content-Type": "application/json",
          "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify({
          model: selectedModel,
          max_tokens: 4000,
          system: finalSystemPrompt,
          messages: [{ role: "user", content: context }],
        }),
      });

      if (!response.ok) {
        const errText = await response.text();
        console.error("Anthropic error:", response.status, errText);
        if (response.status === 429) {
          return new Response(JSON.stringify({ success: false, error: "Rate limit exceeded." }), {
            status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        throw new Error(`Anthropic error: ${response.status}`);
      }

      const data = await response.json();
      const result = data.content?.[0]?.text || "";
      return new Response(JSON.stringify({ success: true, result, provider: selectedProvider, model: selectedModel }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Google AI Studio has a different format
    if (selectedProvider === "google") {
      const response = await fetch(apiUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [
            { role: "user", parts: [{ text: finalSystemPrompt + "\n\n" + context }] },
          ],
          generationConfig: { maxOutputTokens: 4000, temperature: 0.7 },
        }),
      });

      if (!response.ok) {
        const errText = await response.text();
        console.error("Google error:", response.status, errText);
        throw new Error(`Google error: ${response.status}`);
      }

      const data = await response.json();
      const result = data.candidates?.[0]?.content?.parts?.[0]?.text || "";
      return new Response(JSON.stringify({ success: true, result, provider: selectedProvider, model: selectedModel }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Image generation models - detect image models and use modalities: ["image", "text"]
    // This works with any provider that supports the OpenAI-compatible image generation format
    const isImageModel = selectedModel.includes("image") || selectedModel.includes("gemini-3-pro-image");
    if (isImageModel) {
      console.log(`Image generation mode: provider=${selectedProvider}, model=${selectedModel}`);
      const response = await fetch(apiUrl, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
          ...(selectedProvider === "openrouter" ? { "HTTP-Referer": "https://ig-os.lovable.app" } : {}),
        },
        body: JSON.stringify({
          model: selectedModel,
          messages: [
            { role: "user", content: finalSystemPrompt + "\n\n" + context },
          ],
          modalities: ["image", "text"],
        }),
      });

      if (!response.ok) {
        const errText = await response.text();
        console.error(`Image gen error (${selectedProvider}):`, response.status, errText);
        if (response.status === 429) {
          return new Response(JSON.stringify({ success: false, error: "Rate limit exceeded. Try again later." }), {
            status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        if (response.status === 402) {
          return new Response(JSON.stringify({ success: false, error: "Créditos insuficientes. Adicione créditos." }), {
            status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        throw new Error(`Image gen error (${selectedProvider}): ${response.status}`);
      }

      const aiData = await response.json();
      const textResult = aiData.choices?.[0]?.message?.content || "";
      const images = aiData.choices?.[0]?.message?.images || [];
      
      let result = textResult;
      if (images.length > 0) {
        result += "\n\n--- IMAGENS GERADAS ---\n";
        images.forEach((img: any, i: number) => {
          result += `\n![Imagem ${i + 1}](${img.image_url?.url || ""})\n`;
        });
      }

      console.log(`Image generation complete: ${images.length} images, ${textResult.length} chars text`);
      return new Response(JSON.stringify({ 
        success: true, result, provider: selectedProvider, model: selectedModel,
        images: images.map((img: any) => img.image_url?.url || ""),
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // For image_creator agent (carousel), do 2-step: generate text plan, then generate images
    const isCarouselAgent = agent === "image_creator" && !isImageModel;
    if (isCarouselAgent) {
      console.log(`Carousel 2-step mode: text plan via ${selectedProvider}/${selectedModel}, then images via Lovable AI`);
      
      // Step 1: Generate text plan with the configured model
      const textResponse = await fetch(apiUrl, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
          ...(selectedProvider === "openrouter" ? { "HTTP-Referer": "https://ig-os.lovable.app" } : {}),
        },
        body: JSON.stringify({
          model: selectedModel,
          messages: [
            { role: "system", content: finalSystemPrompt },
            { role: "user", content: context },
          ],
          max_tokens: 4000,
          temperature: 0.7,
        }),
      });

      if (!textResponse.ok) {
        const errText = await textResponse.text();
        console.error(`Carousel text plan error:`, textResponse.status, errText);
        throw new Error(`Error generating carousel plan: ${textResponse.status}`);
      }

      const textData = await textResponse.json();
      const textPlan = textData.choices?.[0]?.message?.content || "";
      console.log(`Carousel text plan generated (${textPlan.length} chars). Now generating images...`);

      // Step 2: Generate images for each slide using the SAME provider
      // Determine image-capable model for the configured provider
      let imgApiUrl = apiUrl;
      let imgApiKey = apiKey;
      let imgModel = selectedModel;

      // Map providers to their image-capable models
      if (selectedProvider === "openrouter") {
        imgModel = "google/gemini-2.5-flash-image";
      } else if (selectedProvider === "groq") {
        // Groq doesn't support image generation, fallback to Lovable AI
        const lovableKey = Deno.env.get("LOVABLE_API_KEY");
        if (lovableKey) {
          imgApiUrl = "https://ai.gateway.lovable.dev/v1/chat/completions";
          imgApiKey = lovableKey;
          imgModel = "google/gemini-2.5-flash-image";
        } else {
          return new Response(JSON.stringify({ success: true, result: textPlan, provider: selectedProvider, model: selectedModel }), {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
      } else if (selectedProvider === "lovable") {
        imgModel = "google/gemini-2.5-flash-image";
      }

      // Extract number of slides from the plan (look for "Slide N" patterns)
      const slideMatches = textPlan.match(/slide\s*(\d+)/gi) || [];
      const slideNumbers = slideMatches.map(m => parseInt(m.replace(/\D/g, ""))).filter(n => !isNaN(n));
      const totalSlides = slideNumbers.length > 0 ? Math.max(...slideNumbers) : 5;
      const slidesToGenerate = Math.min(totalSlides, 10); // cap at 10

      console.log(`Generating images for ${slidesToGenerate} slides using ${selectedProvider}/${imgModel}`);

      const allImages: string[] = [];
      let result = textPlan;

      // Generate images for each slide
      for (let i = 1; i <= slidesToGenerate; i++) {
        const slidePrompt = `Based on this Instagram carousel plan, generate the image for SLIDE ${i} of ${slidesToGenerate}.

CAROUSEL PLAN:
${textPlan}

Generate ONE high-quality image for Slide ${i} in 1080x1080 format.
${i === 1 ? "This is the COVER slide - make it bold, scroll-stopping, with a strong hook text overlay." : 
  i === slidesToGenerate ? "This is the LAST slide - include a clear CTA (Call to Action)." :
  "Make it visually consistent with the carousel style. Include any text overlay mentioned for this slide."}
Style: Professional Instagram carousel, clean typography, vibrant colors.`;

        try {
          const imgResponse = await fetch(imgApiUrl, {
            method: "POST",
            headers: {
              Authorization: `Bearer ${imgApiKey}`,
              "Content-Type": "application/json",
              ...(selectedProvider === "openrouter" ? { "HTTP-Referer": "https://ig-os.lovable.app" } : {}),
            },
            body: JSON.stringify({
              model: imgModel,
              messages: [{ role: "user", content: slidePrompt }],
              modalities: ["image", "text"],
            }),
          });

          if (imgResponse.ok) {
            const imgData = await imgResponse.json();
            const images = imgData.choices?.[0]?.message?.images || [];
            if (images.length > 0) {
              const imgUrl = images[0].image_url?.url || "";
              if (imgUrl) {
                allImages.push(imgUrl);
                console.log(`✅ Slide ${i} image generated`);
              }
            } else {
              console.log(`⚠️ Slide ${i}: no image returned`);
            }
          } else {
            const errText = await imgResponse.text();
            console.error(`⚠️ Slide ${i} image error (${imgResponse.status}):`, errText.slice(0, 200));
            // If rate limited, stop generating more
            if (imgResponse.status === 429) {
              console.log("Rate limited, stopping image generation");
              break;
            }
          }
        } catch (imgErr) {
          console.error(`⚠️ Slide ${i} image error:`, imgErr);
        }

        // Small delay between requests to avoid rate limiting
        if (i < slidesToGenerate) {
          await new Promise(resolve => setTimeout(resolve, 1500));
        }
      }

      // Append images to result
      if (allImages.length > 0) {
        result += `\n\n--- IMAGENS GERADAS (${allImages.length}/${slidesToGenerate} slides) ---\n`;
        allImages.forEach((url, i) => {
          result += `\n![Slide ${i + 1}](${url})\n`;
        });
      }

      console.log(`Carousel complete: plan + ${allImages.length}/${slidesToGenerate} images`);
      return new Response(JSON.stringify({ 
        success: true, result, provider: selectedProvider, model: selectedModel,
        images: allImages,
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // OpenAI-compatible providers (groq, openrouter, lovable, openai, deepseek)
    const response = await fetch(apiUrl, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        ...(selectedProvider === "openrouter" ? { "HTTP-Referer": "https://ig-os.lovable.app" } : {}),
      },
      body: JSON.stringify({
        model: selectedModel,
        messages: [
          { role: "system", content: finalSystemPrompt },
          { role: "user", content: context },
        ],
        max_tokens: 4000,
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error(`${selectedProvider} error:`, response.status, errText);
      if (response.status === 429) {
        return new Response(JSON.stringify({ success: false, error: "Rate limit exceeded. Try again later." }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ success: false, error: "Créditos insuficientes. Adicione créditos." }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      throw new Error(`${selectedProvider} error: ${response.status}`);
    }

    const aiData = await response.json();
    const result = aiData.choices?.[0]?.message?.content || "";

    console.log(`AI response received (${result.length} chars)`);

    return new Response(JSON.stringify({ success: true, result, provider: selectedProvider, model: selectedModel }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("generate-content error:", error);
    return new Response(JSON.stringify({ success: false, error: error instanceof Error ? error.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
