import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const body = await req.json().catch(() => ({}));
    const userId = body.user_id || null;

    console.log("📊 Weekly Strategy Report starting...");

    // Get date range for the week
    const now = new Date();
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    const weekAgoISO = weekAgo.toISOString();

    // Fetch my content from the last week
    let myQuery = supabase
      .from("meus_reels")
      .select("*")
      .gte("created_at", weekAgoISO)
      .order("views", { ascending: false })
      .limit(30);
    if (userId) myQuery = myQuery.eq("user_id", userId);
    const { data: myContent } = await myQuery;

    // Fetch competitor content from the last week
    let compQuery = supabase
      .from("reels_competidores")
      .select("*")
      .gte("created_at", weekAgoISO)
      .order("views", { ascending: false })
      .limit(50);
    if (userId) compQuery = compQuery.eq("user_id", userId);
    const { data: compContent } = await compQuery;

    // Fetch content_strategist agent config for custom prompts & model
    let agentConfig: any = null;
    if (userId) {
      const { data: configs } = await supabase
        .from("agent_configs")
        .select("model, provider, custom_prompt, custom_prompt_2, custom_prompt_3")
        .eq("user_id", userId)
        .eq("agent_type", "content_strategist")
        .eq("is_active", true)
        .maybeSingle();
      agentConfig = configs;
    }
    const strategyModel = agentConfig?.model || "google/gemini-2.5-pro";

    // Fetch competitor profiles
    let compProfileQuery = supabase.from("competidores").select("name, followers_count, predominant_content_type, avg_posts_per_week, niche").eq("status", true);
    if (userId) compProfileQuery = compProfileQuery.eq("user_id", userId);
    const { data: competitors } = await compProfileQuery;

    // Fetch previous strategy reports for trend comparison
    let prevQuery = supabase
      .from("estrategias")
      .select("title, key_takeaway, created_at")
      .order("created_at", { ascending: false })
      .limit(3);
    if (userId) prevQuery = prevQuery.eq("user_id", userId);
    const { data: prevReports } = await prevQuery;

    if ((!myContent || myContent.length === 0) && (!compContent || compContent.length === 0)) {
      console.log("⚠️ No content found for the last week. Skipping report.");
      return new Response(JSON.stringify({ success: true, skipped: true, reason: "No content in the last 7 days" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Build comprehensive prompt
    const weekLabel = `${weekAgo.toLocaleDateString("pt-BR")} — ${now.toLocaleDateString("pt-BR")}`;
    
    const strategyContent = `# RELATÓRIO SEMANAL DE ESTRATÉGIA (${weekLabel})

## MEU CONTEÚDO DA SEMANA (${myContent?.length || 0} itens):
${JSON.stringify(myContent?.map(r => ({
      type: r.content_type,
      caption: r.caption?.slice(0, 400),
      user: r.owner_username,
      views: r.views,
      likes: r.likes,
      comments: r.comments,
      eng_rate: r.eng_rate,
      transcript: r.transcript?.slice(0, 300),
      hook_analysis: r.hook_analysis?.slice(0, 300),
      viral_points: r.viral_points?.slice(0, 200),
      post_date: r.post_date,
    })) || [])}

## CONTEÚDO DOS COMPETIDORES DA SEMANA (${compContent?.length || 0} itens):
${JSON.stringify(compContent?.map(r => ({
      type: r.content_type,
      caption: r.caption?.slice(0, 400),
      user: r.owner_username,
      url: r.url,
      views: r.views,
      likes: r.likes,
      comments: r.comments,
      eng_rate: r.eng_rate,
      transcript: r.transcript?.slice(0, 300),
      hook_analysis: r.hook_analysis?.slice(0, 300),
      post_date: r.post_date,
    })) || [])}

## PERFIS DOS COMPETIDORES:
${JSON.stringify(competitors || [])}

## RELATÓRIOS ANTERIORES (para contexto de evolução):
${JSON.stringify(prevReports?.map(r => ({ title: r.title, takeaway: r.key_takeaway?.slice(0, 200), date: r.created_at })) || [])}

INSTRUÇÕES ADICIONAIS: Este é um relatório SEMANAL automatizado. Foque em:
1. Mudanças e tendências da semana comparado com semanas anteriores
2. Oportunidades urgentes para a próxima semana
3. O que os competidores fizeram de diferente esta semana
4. Recomendações práticas com base nos dados da semana`;

    console.log(`📝 Generating report with ${myContent?.length || 0} my items + ${compContent?.length || 0} competitor items`);

    const strategyRes = await fetch(`${SUPABASE_URL}/functions/v1/analyze-content`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
      body: JSON.stringify({
        action: "strategy_report",
        content: strategyContent,
        model: strategyModel,
        ...(agentConfig?.custom_prompt ? { custom_prompt: agentConfig.custom_prompt } : {}),
        ...(agentConfig?.custom_prompt_2 ? { custom_prompt_2: agentConfig.custom_prompt_2 } : {}),
        ...(agentConfig?.custom_prompt_3 ? { custom_prompt_3: agentConfig.custom_prompt_3 } : {}),
      }),
    });
    const strategyData = await strategyRes.json();

    if (!strategyData.success) {
      console.error("❌ Strategy generation failed:", strategyData.error);
      return new Response(JSON.stringify({ success: false, error: strategyData.error }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Parse and save
    const reportTitle = `Semanal ${weekLabel}`;
    let savedOk = false;

    try {
      const report = JSON.parse(strategyData.result.replace(/```json\s*/g, "").replace(/```\s*/g, "").trim());
      
      const insertData: any = {
        title: reportTitle,
        key_takeaway: report.key_takeaway || null,
        top_videos: report.top_content || report.top_competitor_videos || null,
        winning_patterns: report.winning_patterns || null,
        hook_ideas: report.hook_ideas || null,
        raw_report: strategyData.result,
      };
      if (userId) insertData.user_id = userId;

      const { error: insertErr } = await supabase.from("estrategias").insert(insertData);
      if (insertErr) throw insertErr;
      savedOk = true;
      console.log("✅ Weekly strategy report saved!");
    } catch (e) {
      console.warn("⚠️ JSON parse failed, saving raw:", e);
      const insertData: any = { title: reportTitle, raw_report: strategyData.result };
      if (userId) insertData.user_id = userId;
      await supabase.from("estrategias").insert(insertData);
      savedOk = true;
    }

    // Save to MinIO
    try {
      const dateStr = now.toISOString().split("T")[0];
      await fetch(`${SUPABASE_URL}/functions/v1/save-to-minio`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` },
        body: JSON.stringify({
          action: "save",
          path: `reports/${dateStr}/weekly-strategy-report.json`,
          data: {
            title: reportTitle,
            generated_at: now.toISOString(),
            week_range: weekLabel,
            my_content_count: myContent?.length || 0,
            competitor_content_count: compContent?.length || 0,
            raw_report: strategyData.result,
          },
        }),
      });
      console.log("📦 Report saved to MinIO");
    } catch (e) {
      console.warn("⚠️ MinIO save failed:", e);
    }

    return new Response(JSON.stringify({
      success: true,
      saved: savedOk,
      title: reportTitle,
      my_content_count: myContent?.length || 0,
      competitor_content_count: compContent?.length || 0,
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("weekly-strategy-report error:", error);
    return new Response(JSON.stringify({ success: false, error: error instanceof Error ? error.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
