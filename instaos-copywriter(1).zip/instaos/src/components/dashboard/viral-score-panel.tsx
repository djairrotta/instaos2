import { useState } from "react"
import { supabase } from "@/integrations/supabase/client"
import { toast } from "sonner"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Zap, TrendingUp, AlertTriangle, MessageSquare, Target, Copy, ChevronDown, ChevronUp, Loader2 } from "lucide-react"

export interface ViralAnalysis {
  viralScore: number
  hookType: string
  hook: string
  structure: string
  emotion: string
  callToAction: string
  whyViral: string
  weakPoints: string
  adaptedHook: string
  contentIdeas: string[]
  bestFormat: "reel" | "carrossel" | "post"
  estimatedReach: "baixo" | "médio" | "alto" | "viral"
}

interface ViralScorePanelProps {
  reelId: string
  caption: string
  views: number
  likes: number
  comments: number
  contentType: string
  ownerUsername: string
  existingAnalysis?: ViralAnalysis | null
  profileNiche?: string
  profileName?: string
  onAnalysisDone?: (analysis: ViralAnalysis) => void
  onGenerateContent?: (analysis: ViralAnalysis) => void
}

const REACH_COLOR: Record<string, string> = {
  baixo: "text-muted-foreground",
  médio: "text-blue-400",
  alto: "text-yellow-400",
  viral: "text-green-400",
}

const HOOK_COLOR: Record<string, string> = {
  Curiosidade: "bg-purple-500/10 text-purple-400 border-purple-500/20",
  Dor: "bg-red-500/10 text-red-400 border-red-500/20",
  Promessa: "bg-green-500/10 text-green-400 border-green-500/20",
  Choque: "bg-orange-500/10 text-orange-400 border-orange-500/20",
  "Prova Social": "bg-blue-500/10 text-blue-400 border-blue-500/20",
  Tendência: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20",
}

function ScoreRing({ score }: { score: number }) {
  const r = 28
  const circ = 2 * Math.PI * r
  const pct = Math.min(Math.max(score, 0), 100) / 100
  const dash = pct * circ
  const color = score >= 75 ? "#22c55e" : score >= 50 ? "#eab308" : "#ef4444"

  return (
    <div className="relative w-20 h-20 flex items-center justify-center flex-shrink-0">
      <svg width="80" height="80" className="-rotate-90">
        <circle cx="40" cy="40" r={r} fill="none" stroke="hsl(var(--border))" strokeWidth="6" />
        <circle
          cx="40" cy="40" r={r}
          fill="none"
          stroke={color}
          strokeWidth="6"
          strokeDasharray={`${dash} ${circ}`}
          strokeLinecap="round"
          style={{ transition: "stroke-dasharray 0.8s ease" }}
        />
      </svg>
      <div className="absolute flex flex-col items-center leading-none">
        <span className="text-xl font-bold" style={{ color }}>{score}</span>
        <span className="text-[9px] text-muted-foreground uppercase tracking-wider">viral</span>
      </div>
    </div>
  )
}

export function ViralScorePanel({
  reelId, caption, views, likes, comments, contentType,
  ownerUsername, existingAnalysis, profileNiche = "", profileName = "@djairrotta",
  onAnalysisDone, onGenerateContent,
}: ViralScorePanelProps) {
  const [analysis, setAnalysis] = useState<ViralAnalysis | null>(existingAnalysis || null)
  const [loading, setLoading] = useState(false)
  const [expanded, setExpanded] = useState(false)

  async function runAnalysis() {
    setLoading(true)
    try {
      const prompt = `Você é um especialista em marketing viral para Instagram. Analise este post e retorne SOMENTE JSON válido, sem markdown:

{
  "viralScore": 0-100,
  "hook": "primeira frase ou elemento de gancho identificado",
  "hookType": "Curiosidade|Dor|Promessa|Choque|Prova Social|Tendência",
  "structure": "descrição da estrutura em 1 frase",
  "emotion": "emoção principal ativada",
  "callToAction": "CTA identificado ou nenhum",
  "whyViral": "por que funciona em 2 frases",
  "weakPoints": "pontos fracos em 1 frase",
  "adaptedHook": "gancho reescrito e adaptado para ${profileName} (${profileNiche || "advogado e criador de conteúdo"}) mantendo a estrutura viral",
  "contentIdeas": ["ideia 1", "ideia 2", "ideia 3"],
  "bestFormat": "reel|carrossel|post",
  "estimatedReach": "baixo|médio|alto|viral"
}

POST:
Tipo: ${contentType} | Autor: @${ownerUsername}
Curtidas: ${likes} | Views: ${views} | Comentários: ${comments}
Legenda: ${caption.slice(0, 600)}`

      const { data, error } = await supabase.functions.invoke("generate-content", {
        body: {
          agent: "viral_analyst",
          context: prompt,
          provider: "openrouter",
          model: "google/gemini-2.5-flash",
          custom_prompt: "Retorne SOMENTE JSON válido sem markdown, sem texto adicional.",
        },
      })

      if (error) throw error

      const raw: string = typeof data === "string" ? data : data?.content || data?.text || JSON.stringify(data)
      const clean = raw.replace(/```json|```/g, "").trim()
      const result: ViralAnalysis = JSON.parse(clean)

      setAnalysis(result)
      setExpanded(true)
      onAnalysisDone?.(result)
      toast.success(`Score viral: ${result.viralScore}/100`)
    } catch (e: any) {
      toast.error("Erro na análise viral", { description: e.message })
    } finally {
      setLoading(false)
    }
  }

  function copyAdaptedHook() {
    if (!analysis) return
    navigator.clipboard.writeText(analysis.adaptedHook)
    toast.success("Gancho adaptado copiado!")
  }

  if (!analysis && !loading) {
    return (
      <Button
        size="sm"
        variant="outline"
        className="gap-2 text-xs border-yellow-500/30 text-yellow-400 hover:bg-yellow-500/10"
        onClick={runAnalysis}
      >
        <Zap className="w-3 h-3" />
        Score Viral
      </Button>
    )
  }

  if (loading) {
    return (
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <Loader2 className="w-3 h-3 animate-spin" />
        Analisando...
      </div>
    )
  }

  if (!analysis) return null

  return (
    <Card className="border-yellow-500/20 bg-yellow-500/5 mt-2">
      <CardHeader className="pb-2 pt-3 px-4">
        <div className="flex items-start gap-3">
          <ScoreRing score={analysis.viralScore} />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap mb-1.5">
              <Badge
                variant="outline"
                className={HOOK_COLOR[analysis.hookType] || "bg-muted/20 text-muted-foreground"}
              >
                {analysis.hookType}
              </Badge>
              <Badge variant="outline" className="text-[10px]">
                {analysis.bestFormat === "reel" ? "🎬" : analysis.bestFormat === "carrossel" ? "🎠" : "📸"}
                {" "}{analysis.bestFormat}
              </Badge>
              <span className={`text-xs font-medium ${REACH_COLOR[analysis.estimatedReach]}`}>
                Alcance: {analysis.estimatedReach}
              </span>
            </div>
            <p className="text-xs text-muted-foreground italic line-clamp-2">
              "{analysis.hook}"
            </p>
          </div>
          <button
            onClick={() => setExpanded(v => !v)}
            className="text-muted-foreground hover:text-foreground transition-colors flex-shrink-0 mt-1"
          >
            {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </CardHeader>

      {expanded && (
        <CardContent className="px-4 pb-4 space-y-3">
          <div className="grid grid-cols-1 gap-2 text-xs">
            <div className="flex gap-2">
              <TrendingUp className="w-3.5 h-3.5 text-green-400 mt-0.5 flex-shrink-0" />
              <div>
                <span className="text-muted-foreground uppercase tracking-wide text-[10px]">Por que funciona</span>
                <p className="text-foreground/80 mt-0.5">{analysis.whyViral}</p>
              </div>
            </div>
            <div className="flex gap-2">
              <MessageSquare className="w-3.5 h-3.5 text-blue-400 mt-0.5 flex-shrink-0" />
              <div>
                <span className="text-muted-foreground uppercase tracking-wide text-[10px]">CTA</span>
                <p className="text-foreground/80 mt-0.5">{analysis.callToAction}</p>
              </div>
            </div>
            <div className="flex gap-2">
              <AlertTriangle className="w-3.5 h-3.5 text-orange-400 mt-0.5 flex-shrink-0" />
              <div>
                <span className="text-muted-foreground uppercase tracking-wide text-[10px]">Pontos fracos</span>
                <p className="text-foreground/80 mt-0.5">{analysis.weakPoints}</p>
              </div>
            </div>
          </div>

          <div className="border border-yellow-500/30 rounded-lg p-3 bg-yellow-500/5">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[10px] uppercase tracking-wider text-yellow-400 font-semibold flex items-center gap-1">
                <Target className="w-3 h-3" /> Gancho Adaptado para {profileName}
              </span>
              <button onClick={copyAdaptedHook} className="text-muted-foreground hover:text-yellow-400 transition-colors">
                <Copy className="w-3 h-3" />
              </button>
            </div>
            <p className="text-sm text-yellow-200/90 italic leading-relaxed">"{analysis.adaptedHook}"</p>
          </div>

          {analysis.contentIdeas.length > 0 && (
            <div>
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Ideias de conteúdo</span>
              <ul className="mt-1.5 space-y-1">
                {analysis.contentIdeas.map((idea, i) => (
                  <li key={i} className="flex gap-2 text-xs text-foreground/70">
                    <span className="text-yellow-400 font-mono flex-shrink-0">{String(i + 1).padStart(2, "0")}</span>
                    {idea}
                  </li>
                ))}
              </ul>
            </div>
          )}

          <div className="flex gap-2 pt-1">
            <Button
              size="sm"
              className="flex-1 gap-1.5 text-xs h-8 bg-yellow-500 hover:bg-yellow-400 text-black"
              onClick={() => onGenerateContent?.(analysis)}
            >
              <Zap className="w-3 h-3" />
              Gerar {analysis.bestFormat === "carrossel" ? "Carrossel" : "Roteiro Reel"}
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="text-xs h-8"
              onClick={runAnalysis}
            >
              ↺
            </Button>
          </div>
        </CardContent>
      )}
    </Card>
  )
}
