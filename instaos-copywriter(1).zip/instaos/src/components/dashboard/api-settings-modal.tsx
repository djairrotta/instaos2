import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Mail, MessageSquare, Bot, Eye, EyeOff, Check, Loader2, Database, Instagram, ExternalLink, AlertCircle, CheckCircle2, Unplug, Info } from "lucide-react"
import { toast } from "sonner"
import { supabase } from "@/integrations/supabase/client"

export interface ApiSettings {
  minio: { endpoint: string; accessKey: string; secretKey: string; bucket: string; region: string }
  instagram: { appId: string; appSecret: string; accessToken: string }
  resend: { apiKey: string }
  whatsapp: { apiUrl: string; apiKey: string }
  ai: { provider: string; apiUrl: string; apiKey: string }
}

interface ApiSettingsModalProps {
  open: boolean; onOpenChange: (open: boolean) => void; settings: ApiSettings; onSave: (settings: ApiSettings) => void
}

interface IgAccount {
  username: string
  id: string
  profilePicUrl?: string
  followersCount?: number
  pageName?: string
}

const AI_PROVIDERS = [
  { value: "openai", label: "OpenAI (GPT)" },
  { value: "anthropic", label: "Anthropic (Claude)" },
  { value: "groq", label: "Groq" },
  { value: "ollama", label: "Ollama (Local)" },
  { value: "openrouter", label: "OpenRouter" },
  { value: "deepseek", label: "DeepSeek" },
  { value: "custom", label: "Custom API" },
]

export function ApiSettingsModal({ open, onOpenChange, settings, onSave }: ApiSettingsModalProps) {
  const [localSettings, setLocalSettings] = useState<ApiSettings>(settings)
  const [showKeys, setShowKeys] = useState({ minioAccessKey: false, minioSecretKey: false, instagramToken: false, resend: false, whatsapp: false, ai: false })
  const [testing, setTesting] = useState({ minio: false, instagram: false, resend: false, whatsapp: false, ai: false })

  // Instagram state
  const [igAccessToken, setIgAccessToken] = useState("")
  const [igConnected, setIgConnected] = useState(false)
  const [igAccount, setIgAccount] = useState<IgAccount | null>(null)
  const [igLoading, setIgLoading] = useState(false)
  const [igCheckingStatus, setIgCheckingStatus] = useState(false)
  const [igTokenExpires, setIgTokenExpires] = useState<string | null>(null)

  // Check IG connection status when modal opens
  useEffect(() => {
    if (open) {
      checkIgStatus()
    }
  }, [open])

  const checkIgStatus = async () => {
    setIgCheckingStatus(true)
    try {
      const { data, error } = await supabase.functions.invoke("publish-instagram", {
        body: { action: "get_status" },
      })
      if (!error && data?.success) {
        setIgConnected(data.connected)
        setIgAccount(data.account || null)
        setIgTokenExpires(data.tokenExpires || null)
      }
    } catch (e) {
      console.error("Failed to check IG status:", e)
    } finally {
      setIgCheckingStatus(false)
    }
  }

  const handleConnectInstagram = async () => {
    if (!igAccessToken.trim()) {
      toast.error("Cole o Access Token do Facebook/Instagram")
      return
    }
    setIgLoading(true)
    try {
      const { data, error } = await supabase.functions.invoke("publish-instagram", {
        body: { action: "verify_token", accessToken: igAccessToken.trim() },
      })
      if (error) throw error
      if (!data?.success) throw new Error(data?.error || "Falha na verificação")

      setIgConnected(true)
      setIgAccount(data.account)
      setIgTokenExpires(data.expiresAt)
      setIgAccessToken("")
      toast.success(`Instagram conectado! @${data.account.username}`)
    } catch (e: any) {
      toast.error("Erro ao conectar Instagram", { description: e.message })
    } finally {
      setIgLoading(false)
    }
  }

  const handleDisconnectInstagram = async () => {
    setIgLoading(true)
    try {
      await supabase.functions.invoke("publish-instagram", {
        body: { action: "disconnect" },
      })
      setIgConnected(false)
      setIgAccount(null)
      setIgTokenExpires(null)
      toast.success("Instagram desconectado")
    } catch (e: any) {
      toast.error("Erro ao desconectar", { description: e.message })
    } finally {
      setIgLoading(false)
    }
  }

  const handleSave = () => {
    onSave(localSettings)
    toast.success("Configurações salvas com sucesso!")
    onOpenChange(false)
  }

  const testConnection = async (service: "minio" | "resend" | "whatsapp" | "ai") => {
    setTesting((prev) => ({ ...prev, [service]: true }))
    await new Promise((resolve) => setTimeout(resolve, 1500))
    setTesting((prev) => ({ ...prev, [service]: false }))
    toast.success(`Conexão ${service.toUpperCase()} testada com sucesso!`)
  }

  const toggleShowKey = (key: keyof typeof showKeys) => {
    setShowKeys((prev) => ({ ...prev, [key]: !prev[key] }))
  }

  const renderPasswordInput = (id: string, placeholder: string, value: string, onChange: (v: string) => void, showKey: boolean, toggleKey: () => void, testFn?: () => void, testDisabled?: boolean, testLoading?: boolean) => (
    <div className="flex gap-2">
      <div className="relative flex-1">
        <Input id={id} type={showKey ? "text" : "password"} placeholder={placeholder} value={value} onChange={(e) => onChange(e.target.value)} />
        <Button type="button" variant="ghost" size="icon" className="absolute right-2 top-1/2 -translate-y-1/2 h-7 w-7" onClick={toggleKey}>
          {showKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
        </Button>
      </div>
      {testFn && (
        <Button variant="outline" onClick={testFn} disabled={testDisabled}>
          {testLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
          <span className="ml-2 hidden sm:inline">Testar</span>
        </Button>
      )}
    </div>
  )

  const tokenExpiresFormatted = igTokenExpires
    ? new Date(igTokenExpires).toLocaleDateString("pt-BR", { day: "2-digit", month: "short", year: "numeric" })
    : null

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Configurações de API</DialogTitle>
          <DialogDescription>Configure as chaves de API para integrar os serviços externos.</DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="instagram" className="mt-4">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="instagram" className="gap-2"><Instagram className="h-4 w-4" /><span className="hidden sm:inline">Instagram</span></TabsTrigger>
            <TabsTrigger value="minio" className="gap-2"><Database className="h-4 w-4" /><span className="hidden sm:inline">MinIO</span></TabsTrigger>
            <TabsTrigger value="resend" className="gap-2"><Mail className="h-4 w-4" /><span className="hidden sm:inline">Resend</span></TabsTrigger>
            <TabsTrigger value="whatsapp" className="gap-2"><MessageSquare className="h-4 w-4" /><span className="hidden sm:inline">WhatsApp</span></TabsTrigger>
            <TabsTrigger value="ai" className="gap-2"><Bot className="h-4 w-4" /><span className="hidden sm:inline">IA</span></TabsTrigger>
          </TabsList>

          <TabsContent value="instagram">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Instagram className="h-5 w-5" />
                  Instagram Business API
                  {igConnected && <Badge className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20 ml-2"><CheckCircle2 className="h-3 w-3 mr-1" />Conectado</Badge>}
                  {!igConnected && !igCheckingStatus && <Badge variant="secondary" className="ml-2"><AlertCircle className="h-3 w-3 mr-1" />Desconectado</Badge>}
                </CardTitle>
                <CardDescription>
                  Conecte sua conta Instagram Business para postagem automática com aprovação.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-5">
                {igCheckingStatus ? (
                  <div className="flex items-center justify-center py-8 text-muted-foreground">
                    <Loader2 className="h-5 w-5 animate-spin mr-2" />
                    Verificando conexão...
                  </div>
                ) : igConnected && igAccount ? (
                  <>
                    {/* Connected State */}
                    <div className="rounded-lg border border-emerald-500/20 bg-emerald-500/5 p-4">
                      <div className="flex items-center gap-4">
                        {igAccount.profilePicUrl ? (
                          <img src={igAccount.profilePicUrl} alt={igAccount.username} className="h-14 w-14 rounded-full border-2 border-emerald-500/30" />
                        ) : (
                          <div className="h-14 w-14 rounded-full bg-muted flex items-center justify-center">
                            <Instagram className="h-6 w-6" />
                          </div>
                        )}
                        <div className="flex-1">
                          <p className="font-semibold text-lg">@{igAccount.username}</p>
                          {igAccount.pageName && <p className="text-sm text-muted-foreground">Página: {igAccount.pageName}</p>}
                          {igAccount.followersCount && (
                            <p className="text-sm text-muted-foreground">
                              {igAccount.followersCount.toLocaleString("pt-BR")} seguidores
                            </p>
                          )}
                        </div>
                        <Badge variant="outline" className="text-emerald-500 border-emerald-500/30">
                          <CheckCircle2 className="h-3 w-3 mr-1" /> Ativo
                        </Badge>
                      </div>
                      {tokenExpiresFormatted && (
                        <p className="text-xs text-muted-foreground mt-3">
                          Token expira em: {tokenExpiresFormatted}
                        </p>
                      )}
                    </div>

                    <div className="rounded-lg border bg-card p-4 space-y-2">
                      <h4 className="text-sm font-medium flex items-center gap-2"><Info className="h-4 w-4 text-primary" /> Funcionalidades disponíveis</h4>
                      <ul className="text-sm text-muted-foreground space-y-1 ml-6 list-disc">
                        <li>Publicar Posts (imagem única)</li>
                        <li>Publicar Carrosséis (múltiplas imagens/vídeos)</li>
                        <li>Publicar Reels (vídeos curtos)</li>
                        <li>Fila de aprovação antes de publicar</li>
                        <li>Agendamento de publicações</li>
                      </ul>
                    </div>

                    <div className="flex gap-3">
                      <Button variant="outline" onClick={checkIgStatus} className="flex-1">
                        <Check className="h-4 w-4 mr-2" />Verificar Conexão
                      </Button>
                      <Button variant="destructive" onClick={handleDisconnectInstagram} disabled={igLoading}>
                        {igLoading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Unplug className="h-4 w-4 mr-2" />}
                        Desconectar
                      </Button>
                    </div>
                  </>
                ) : (
                  <>
                    {/* Disconnected State - Setup Guide */}
                    <div className="rounded-lg border bg-card p-4 space-y-3">
                      <h4 className="text-sm font-medium flex items-center gap-2">
                        <Info className="h-4 w-4 text-primary" /> Como conectar seu Instagram
                      </h4>
                      <ol className="text-sm text-muted-foreground space-y-2 ml-5 list-decimal">
                        <li>
                          Acesse o{" "}
                          <a href="https://developers.facebook.com" target="_blank" rel="noopener noreferrer" className="text-primary underline inline-flex items-center gap-1">
                            Meta for Developers <ExternalLink className="h-3 w-3" />
                          </a>{" "}
                          e crie um App do tipo "Business"
                        </li>
                        <li>Adicione o produto <strong>"Instagram Graph API"</strong> ao seu App</li>
                        <li>
                          No <strong>Graph API Explorer</strong>, selecione seu App e gere um token com as permissões:
                          <div className="flex flex-wrap gap-1 mt-1">
                            {["pages_show_list", "instagram_basic", "instagram_content_publish", "pages_read_engagement"].map(p => (
                              <Badge key={p} variant="secondary" className="text-[10px] font-mono">{p}</Badge>
                            ))}
                          </div>
                        </li>
                        <li>
                          Gere um <strong>Long-Lived Token</strong> (válido por 60 dias) usando a{" "}
                          <a href="https://developers.facebook.com/tools/accesstoken/" target="_blank" rel="noopener noreferrer" className="text-primary underline inline-flex items-center gap-1">
                            ferramenta de tokens <ExternalLink className="h-3 w-3" />
                          </a>
                        </li>
                        <li>Cole o token abaixo e clique em "Conectar"</li>
                      </ol>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="ig-token">Access Token (Long-Lived)</Label>
                      <div className="flex gap-2">
                        <div className="relative flex-1">
                          <Input
                            id="ig-token"
                            type={showKeys.instagramToken ? "text" : "password"}
                            placeholder="EAAxxxxxxxx..."
                            value={igAccessToken}
                            onChange={(e) => setIgAccessToken(e.target.value)}
                          />
                          <Button type="button" variant="ghost" size="icon" className="absolute right-2 top-1/2 -translate-y-1/2 h-7 w-7" onClick={() => toggleShowKey("instagramToken")}>
                            {showKeys.instagramToken ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                          </Button>
                        </div>
                      </div>
                    </div>

                    <Button
                      className="w-full"
                      onClick={handleConnectInstagram}
                      disabled={igLoading || !igAccessToken.trim()}
                    >
                      {igLoading ? (
                        <><Loader2 className="h-4 w-4 animate-spin mr-2" />Verificando...</>
                      ) : (
                        <><Instagram className="h-4 w-4 mr-2" />Conectar Instagram</>
                      )}
                    </Button>

                    <div className="rounded-lg border border-amber-500/20 bg-amber-500/5 p-3">
                      <p className="text-xs text-amber-600 dark:text-amber-400 flex items-start gap-2">
                        <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
                        <span>
                          <strong>Requisitos:</strong> Conta Instagram Business ou Creator conectada a uma Página do Facebook.
                          Contas pessoais não são suportadas pela API do Instagram.
                        </span>
                      </p>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="minio">
            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2"><Database className="h-5 w-5" />MinIO</CardTitle><CardDescription>Configure a conexão com seu servidor MinIO.</CardDescription></CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2"><Label>Endpoint URL</Label><Input placeholder="https://minio.example.com:9000" value={localSettings.minio.endpoint} onChange={(e) => setLocalSettings((prev) => ({ ...prev, minio: { ...prev.minio, endpoint: e.target.value } }))} /></div>
                <div className="space-y-2"><Label>Access Key</Label>{renderPasswordInput("minio-ak", "minioadmin", localSettings.minio.accessKey, (v) => setLocalSettings((p) => ({ ...p, minio: { ...p.minio, accessKey: v } })), showKeys.minioAccessKey, () => toggleShowKey("minioAccessKey"))}</div>
                <div className="space-y-2"><Label>Secret Key</Label>{renderPasswordInput("minio-sk", "minioadmin", localSettings.minio.secretKey, (v) => setLocalSettings((p) => ({ ...p, minio: { ...p.minio, secretKey: v } })), showKeys.minioSecretKey, () => toggleShowKey("minioSecretKey"))}</div>
                <div className="space-y-2"><Label>Bucket</Label><Input placeholder="ig-os-storage" value={localSettings.minio.bucket} onChange={(e) => setLocalSettings((p) => ({ ...p, minio: { ...p.minio, bucket: e.target.value } }))} /></div>
                <Button variant="outline" onClick={() => testConnection("minio")} disabled={testing.minio} className="w-full">{testing.minio ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Check className="h-4 w-4 mr-2" />}Testar Conexão</Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="resend">
            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2"><Mail className="h-5 w-5" />Resend API</CardTitle><CardDescription>Configure o envio de emails.</CardDescription></CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2"><Label>API Key</Label>{renderPasswordInput("resend-key", "re_xxxxxxxxxxxx", localSettings.resend.apiKey, (v) => setLocalSettings((p) => ({ ...p, resend: { ...p.resend, apiKey: v } })), showKeys.resend, () => toggleShowKey("resend"), () => testConnection("resend"), testing.resend, testing.resend)}</div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="whatsapp">
            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2"><MessageSquare className="h-5 w-5" />WhatsApp Evolution API</CardTitle><CardDescription>Configure a integração com WhatsApp.</CardDescription></CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2"><Label>URL da API</Label><Input placeholder="https://sua-api.evolution.com" value={localSettings.whatsapp.apiUrl} onChange={(e) => setLocalSettings((p) => ({ ...p, whatsapp: { ...p.whatsapp, apiUrl: e.target.value } }))} /></div>
                <div className="space-y-2"><Label>API Key</Label>{renderPasswordInput("wa-key", "Sua chave de API", localSettings.whatsapp.apiKey, (v) => setLocalSettings((p) => ({ ...p, whatsapp: { ...p.whatsapp, apiKey: v } })), showKeys.whatsapp, () => toggleShowKey("whatsapp"), () => testConnection("whatsapp"), testing.whatsapp, testing.whatsapp)}</div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="ai">
            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2"><Bot className="h-5 w-5" />API de Inteligência Artificial</CardTitle><CardDescription>Selecione o provedor de IA.</CardDescription></CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2"><Label>Provedor</Label>
                  <Select value={localSettings.ai.provider} onValueChange={(v) => setLocalSettings((p) => ({ ...p, ai: { ...p.ai, provider: v } }))}>
                    <SelectTrigger><SelectValue placeholder="Selecione o provedor" /></SelectTrigger>
                    <SelectContent>{AI_PROVIDERS.map((p) => (<SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>))}</SelectContent>
                  </Select>
                </div>
                <div className="space-y-2"><Label>URL da API</Label><Input placeholder="https://api.openai.com/v1" value={localSettings.ai.apiUrl} onChange={(e) => setLocalSettings((p) => ({ ...p, ai: { ...p.ai, apiUrl: e.target.value } }))} /></div>
                <div className="space-y-2"><Label>API Key</Label>{renderPasswordInput("ai-key", "sk-xxxxxxxxxxxx", localSettings.ai.apiKey, (v) => setLocalSettings((p) => ({ ...p, ai: { ...p.ai, apiKey: v } })), showKeys.ai, () => toggleShowKey("ai"), () => testConnection("ai"), testing.ai, testing.ai)}</div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="flex justify-end gap-3 mt-6">
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
          <Button onClick={handleSave}>Salvar Configurações</Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

export const defaultApiSettings: ApiSettings = {
  minio: { endpoint: "", accessKey: "", secretKey: "", bucket: "", region: "us-east-1" },
  instagram: { appId: "", appSecret: "", accessToken: "" },
  resend: { apiKey: "" },
  whatsapp: { apiUrl: "", apiKey: "" },
  ai: { provider: "", apiUrl: "", apiKey: "" },
}
