import { useState, useEffect } from "react"
import { supabase } from "@/integrations/supabase/client"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Loader2 } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Trophy, TrendingUp, Lightbulb, Eye, Heart, MessageCircle,
  Film, Image, Layers, ExternalLink, Sparkles, Target, Zap,
  ChevronRight, BarChart2, Calendar, Download, FileText,
  ChevronDown, ChevronUp, X, Minimize2,
} from "lucide-react"
import { toast } from "sonner"
import jsPDF from "jspdf"

interface TopContent {
  rank: number
  type: string
  hook: string
  url: string
  views: number
  likes: number
  posted_date: string
  creator: string
  why_it_worked: string
}

interface WinningPattern {
  pattern_name: string
  description: string
  frequency: string
  effectiveness: string
  examples: string[]
}

interface HookIdea {
  hook: string
  format: string
  psychological_trigger: string
  expected_impact: string
  reference_content: string
  why_it_works?: string
}

interface StrategyReport {
  top_content: TopContent[]
  winning_patterns: WinningPattern[]
  hook_ideas: HookIdea[]
  key_takeaway?: string
}

interface DbReport {
  id: string
  title: string
  created_at: string
  raw_report: string | null
  key_takeaway: string | null
  top_videos: any[] | null
  winning_patterns: any[] | null
  hook_ideas: any[] | null
}

// Maps various JSON key formats to our standard interface
function normalizeTopContent(item: any): TopContent {
  return {
    rank: item.rank || 0,
    type: item.type || item.tipo || "reel",
    hook: item.hook || item.gancho || "",
    url: item.url || "",
    views: item.views || item.visualizacoes || 0,
    likes: item.likes || item.curtidas || 0,
    posted_date: item.posted_date || item.data_publicacao || "",
    creator: item.creator || item.criador || "",
    why_it_worked: item.why_it_worked || item.por_que_funcionou || "",
  }
}

function normalizeWinningPattern(item: any): WinningPattern {
  return {
    pattern_name: item.pattern_name || item.nome_padrao || item.padrao || "",
    description: item.description || item.descricao || item.explanation || item.explicacao || "",
    frequency: item.frequency || item.frequencia || "",
    effectiveness: item.effectiveness || item.eficacia || "",
    examples: item.examples || item.exemplos || [],
  }
}

function normalizeHookIdea(item: any): HookIdea {
  return {
    hook: item.hook || item.gancho || "",
    format: item.format || item.formato || "",
    psychological_trigger: item.psychological_trigger || item.gatilho_psicologico || "",
    expected_impact: item.expected_impact || item.impacto_esperado || item.why_it_works || "",
    reference_content: item.reference_content || item.conteudo_referencia || "",
  }
}

function parseReport(raw: string | null, dbReport?: DbReport): StrategyReport | null {
  // First try JSONB columns from the DB (most reliable)
  const fromDb: StrategyReport = {
    top_content: [],
    winning_patterns: [],
    hook_ideas: [],
    key_takeaway: "",
  }

  if (dbReport?.top_videos && Array.isArray(dbReport.top_videos) && dbReport.top_videos.length > 0) {
    fromDb.top_content = dbReport.top_videos.map(normalizeTopContent)
  }
  if (dbReport?.winning_patterns && Array.isArray(dbReport.winning_patterns) && dbReport.winning_patterns.length > 0) {
    fromDb.winning_patterns = dbReport.winning_patterns.map(normalizeWinningPattern)
  }
  if (dbReport?.hook_ideas && Array.isArray(dbReport.hook_ideas) && dbReport.hook_ideas.length > 0) {
    fromDb.hook_ideas = dbReport.hook_ideas.map(normalizeHookIdea)
  }

  // If we have JSONB data, use it
  if (fromDb.top_content.length > 0 || fromDb.winning_patterns.length > 0 || fromDb.hook_ideas.length > 0) {
    // Also try to get key_takeaway from raw_report if it's not JSON
    if (dbReport?.key_takeaway && !dbReport.key_takeaway.startsWith("{") && !dbReport.key_takeaway.startsWith("```")) {
      fromDb.key_takeaway = dbReport.key_takeaway
    }
    return fromDb
  }

  // Then try parsing raw_report
  if (!raw) return null
  try {
    const cleaned = raw.replace(/```json\s*/g, "").replace(/```\s*/g, "").trim()
    const data = JSON.parse(cleaned)

    return {
      top_content: (data.top_content || data.top_competitor_videos || data.videos_top_concorrentes || []).map(normalizeTopContent),
      winning_patterns: (data.winning_patterns || data.padroes_vencedores || []).map(normalizeWinningPattern),
      hook_ideas: (data.hook_ideas || data.ideias_de_hook || data.ideias_hook || []).map(normalizeHookIdea),
      key_takeaway: data.key_takeaway || data.conclusao_chave || "",
    }
  } catch {
    return null
  }
}

// Render raw_report as readable text (fallback when JSON parsing fails)
function renderRawReport(raw: string | null): string {
  if (!raw) return ""
  // Remove JSON/code block markers
  let text = raw.replace(/```json\s*/g, "").replace(/```\s*/g, "").trim()
  // Try to prettify JSON
  try {
    const obj = JSON.parse(text)
    return jsonToReadableText(obj)
  } catch {
    return text
  }
}

function jsonToReadableText(obj: any, indent = 0): string {
  if (typeof obj === "string") return obj
  if (typeof obj === "number" || typeof obj === "boolean") return String(obj)
  if (Array.isArray(obj)) {
    return obj.map((item, i) => {
      if (typeof item === "object" && item !== null) {
        return `  ${i + 1}. ${jsonToReadableText(item, indent + 1)}`
      }
      return `  • ${item}`
    }).join("\n")
  }
  if (typeof obj === "object" && obj !== null) {
    return Object.entries(obj).map(([key, value]) => {
      const label = key
        .replace(/_/g, " ")
        .replace(/\b\w/g, l => l.toUpperCase())
      if (typeof value === "object" && value !== null) {
        return `${label}:\n${jsonToReadableText(value, indent + 1)}`
      }
      return `${label}: ${value}`
    }).join("\n")
  }
  return ""
}

function formatNumber(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`
  return n.toString()
}

const typeIcon: Record<string, React.ReactNode> = {
  reel: <Film className="h-3.5 w-3.5" />,
  post: <Image className="h-3.5 w-3.5" />,
  carousel: <Layers className="h-3.5 w-3.5" />,
}

const typeColor: Record<string, string> = {
  reel: "bg-violet-500/10 text-violet-600 dark:text-violet-400 border-violet-500/20",
  post: "bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20",
  carousel: "bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20",
}

const effectivenessColor: Record<string, string> = {
  alta: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20",
  média: "bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20",
  baixa: "bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/20",
}

function exportReportPDF(report: StrategyReport, title: string, date: string, keyTakeaway: string | null) {
  const doc = new jsPDF()
  const pageW = doc.internal.pageSize.getWidth()
  let y = 20

  const addText = (text: string, x: number, maxW: number, size = 10, style: "normal" | "bold" = "normal") => {
    doc.setFontSize(size)
    doc.setFont("helvetica", style)
    const lines = doc.splitTextToSize(text, maxW)
    for (const line of lines) {
      if (y > 275) { doc.addPage(); y = 20 }
      doc.text(line, x, y)
      y += size * 0.5 + 2
    }
  }

  // Title
  addText(title, 14, pageW - 28, 16, "bold")
  addText(`Gerado em: ${date}`, 14, pageW - 28, 9)
  y += 4

  // Key Takeaway
  if (keyTakeaway) {
    addText("📌 Conclusão Principal", 14, pageW - 28, 12, "bold")
    y += 2
    addText(keyTakeaway, 14, pageW - 28, 10)
    y += 6
  }

  // Top Content
  if (report.top_content.length > 0) {
    addText("🏆 Top Conteúdos", 14, pageW - 28, 12, "bold")
    y += 2
    report.top_content.forEach((item) => {
      addText(`#${item.rank} — "${item.hook}"`, 18, pageW - 36, 10, "bold")
      addText(`Criador: @${item.creator} | Tipo: ${item.type} | Views: ${formatNumber(item.views)} | Data: ${item.posted_date}`, 18, pageW - 36, 9)
      if (item.why_it_worked) addText(`Por que funcionou: ${item.why_it_worked}`, 18, pageW - 36, 9)
      if (item.url) addText(`Link: ${item.url}`, 18, pageW - 36, 8)
      y += 3
    })
    y += 4
  }

  // Winning Patterns
  if (report.winning_patterns.length > 0) {
    addText("📈 Padrões Vencedores", 14, pageW - 28, 12, "bold")
    y += 2
    report.winning_patterns.forEach((p) => {
      addText(`• ${p.pattern_name}`, 18, pageW - 36, 10, "bold")
      if (p.effectiveness) addText(`Eficácia: ${p.effectiveness} | Frequência: ${p.frequency}`, 18, pageW - 36, 9)
      addText(p.description, 18, pageW - 36, 9)
      if (p.examples?.length > 0) {
        p.examples.forEach(ex => addText(`  → ${ex}`, 22, pageW - 44, 8))
      }
      y += 3
    })
    y += 4
  }

  // Hook Ideas
  if (report.hook_ideas.length > 0) {
    addText("💡 Ideias de Hook", 14, pageW - 28, 12, "bold")
    y += 2
    report.hook_ideas.forEach((h) => {
      addText(`"${h.hook}"`, 18, pageW - 36, 10, "bold")
      addText(`Formato: ${h.format} | Gatilho: ${h.psychological_trigger}`, 18, pageW - 36, 9)
      if (h.expected_impact) addText(`Impacto: ${h.expected_impact}`, 18, pageW - 36, 9)
      y += 3
    })
  }

  doc.save(`${title.replace(/[^a-zA-Z0-9àáãéêíóôúç\s-]/g, "").trim()}.pdf`)
}

export function StrategyReportViewer() {
  const [reports, setReports] = useState<DbReport[]>([])
  const [selectedId, setSelectedId] = useState<string>("")
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(true)
  const [generating, setGenerating] = useState(false)

  const loadReports = () => {
    supabase
      .from("estrategias")
      .select("id, title, created_at, raw_report, key_takeaway, top_videos, winning_patterns, hook_ideas")
      .order("created_at", { ascending: false })
      .then(({ data }) => {
        if (data) {
          setReports(data as DbReport[])
          if (data.length > 0 && !selectedId) setSelectedId(data[0].id)
        }
        setLoading(false)
      })
  }

  useEffect(() => { loadReports() }, [])

  const handleGenerateWeekly = async () => {
    setGenerating(true)
    toast.info("Gerando relatório semanal... isso pode levar alguns minutos ☕")
    try {
      const { data, error } = await supabase.functions.invoke("weekly-strategy-report", { body: {} })
      if (error) throw error
      if (data?.success) {
        if (data.skipped) {
          toast.warning("Sem dados suficientes", { description: "Nenhum conteúdo encontrado nos últimos 7 dias." })
        } else {
          toast.success("Relatório semanal gerado! 🎉", { description: data.title })
          loadReports()
        }
      } else {
        throw new Error(data?.error || "Falha ao gerar relatório")
      }
    } catch (e: any) {
      toast.error("Erro ao gerar relatório", { description: e.message })
    } finally {
      setGenerating(false)
    }
  }

  const current = reports.find((r) => r.id === selectedId)
  const parsed = current ? parseReport(current.raw_report, current) : null
  const keyTakeaway = current?.key_takeaway && !current.key_takeaway.startsWith("{") && !current.key_takeaway.startsWith("```")
    ? current.key_takeaway
    : parsed?.key_takeaway || null

  const handleExportPDF = () => {
    if (!current) return
    if (parsed) {
      exportReportPDF(
        parsed,
        current.title,
        new Date(current.created_at).toLocaleDateString("pt-BR"),
        keyTakeaway,
      )
      toast.success("PDF exportado!")
    } else {
      // Export raw text as PDF
      const doc = new jsPDF()
      const text = renderRawReport(current.raw_report)
      const lines = doc.splitTextToSize(text, 180)
      let y = 20
      doc.setFontSize(14)
      doc.setFont("helvetica", "bold")
      doc.text(current.title, 14, y)
      y += 10
      doc.setFontSize(9)
      doc.setFont("helvetica", "normal")
      for (const line of lines) {
        if (y > 280) { doc.addPage(); y = 20 }
        doc.text(line, 14, y)
        y += 5
      }
      doc.save(`${current.title}.pdf`)
      toast.success("PDF exportado!")
    }
  }

  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-12">
          <span className="text-muted-foreground animate-pulse">Carregando relatórios...</span>
        </CardContent>
      </Card>
    )
  }

  if (reports.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-12 text-center gap-2">
          <BarChart2 className="h-10 w-10 text-muted-foreground/40" />
          <p className="text-muted-foreground">Nenhum relatório estratégico disponível.</p>
          <p className="text-xs text-muted-foreground/60">Rode o pipeline para gerar seu primeiro relatório.</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <>
      {/* Preview card */}
      <Card className="overflow-hidden">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Sparkles className="h-5 w-5 text-primary" />
              Relatório Estratégico
            </CardTitle>
            <div className="flex items-center gap-2 flex-wrap">
              {reports.length > 1 && (
                <Select value={selectedId} onValueChange={setSelectedId}>
                  <SelectTrigger className="h-8 w-[200px] text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {reports.map((r) => (
                      <SelectItem key={r.id} value={r.id}>
                        {r.title} — {new Date(r.created_at).toLocaleDateString("pt-BR")}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
              <Button size="sm" variant="outline" className="h-8 gap-1.5 text-xs" onClick={handleGenerateWeekly} disabled={generating}>
                {generating ? <><Loader2 className="h-3.5 w-3.5 animate-spin" /> Gerando...</> : <>📊 Gerar Semanal</>}
              </Button>
              <Button size="sm" variant="outline" className="h-8 gap-1.5 text-xs" onClick={handleExportPDF}>
                <Download className="h-3.5 w-3.5" /> PDF
              </Button>
              <Button size="sm" className="h-8 gap-1.5 text-xs" onClick={() => setOpen(true)}>
                Ver completo <ChevronRight className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>
          {keyTakeaway && (
            <p className="text-sm text-muted-foreground mt-1 leading-relaxed">{keyTakeaway}</p>
          )}
        </CardHeader>
        <CardContent>
          {parsed && (parsed.top_content.length > 0 || parsed.winning_patterns.length > 0 || parsed.hook_ideas.length > 0) ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <SummaryCard icon={<Trophy className="h-4 w-4 text-amber-500" />} label="Top Conteúdos" count={parsed.top_content.length} items={parsed.top_content.map((c) => c.hook)} allItems={parsed.top_content.map(c => `#${c.rank} "${c.hook}" — @${c.creator} (${formatNumber(c.views)} views)`)} />
              <SummaryCard icon={<TrendingUp className="h-4 w-4 text-emerald-500" />} label="Padrões Vencedores" count={parsed.winning_patterns.length} items={parsed.winning_patterns.map((p) => p.pattern_name)} allItems={parsed.winning_patterns.map(p => `${p.pattern_name}: ${p.description}`)} />
              <SummaryCard icon={<Lightbulb className="h-4 w-4 text-amber-400" />} label="Ideias de Hook" count={parsed.hook_ideas.length} items={parsed.hook_ideas.map((h) => h.hook)} allItems={parsed.hook_ideas.map(h => `"${h.hook}" — ${h.format} | ${h.psychological_trigger}`)} />
            </div>
          ) : (
            <RawReportPreview raw={current?.raw_report || null} takeaway={keyTakeaway} />
          )}
        </CardContent>
      </Card>

      {/* Full report dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-4xl max-h-[85vh] p-0 gap-0 overflow-hidden">
          <DialogHeader className="px-6 pt-6 pb-2">
            <div className="flex items-center justify-between">
              <DialogTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-primary" /> {current?.title || "Relatório"}
              </DialogTitle>
              <Button size="sm" variant="outline" className="gap-1.5 text-xs" onClick={handleExportPDF}>
                <Download className="h-3.5 w-3.5" /> Exportar PDF
              </Button>
            </div>
            {current && (
              <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                <Calendar className="h-3 w-3" /> {new Date(current.created_at).toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric" })}
              </p>
            )}
          </DialogHeader>

          {parsed && (parsed.top_content.length > 0 || parsed.winning_patterns.length > 0 || parsed.hook_ideas.length > 0) ? (
            <Tabs defaultValue="top" className="flex-1 flex flex-col overflow-hidden">
              <TabsList className="mx-6 mb-2 w-fit">
                <TabsTrigger value="top" className="gap-1.5 text-xs"><Trophy className="h-3.5 w-3.5" /> Top Conteúdos</TabsTrigger>
                <TabsTrigger value="patterns" className="gap-1.5 text-xs"><TrendingUp className="h-3.5 w-3.5" /> Padrões</TabsTrigger>
                <TabsTrigger value="hooks" className="gap-1.5 text-xs"><Lightbulb className="h-3.5 w-3.5" /> Hooks</TabsTrigger>
              </TabsList>

              <ScrollArea className="flex-1 px-6 pb-6">
                {keyTakeaway && (
                  <div className="mb-4 p-4 rounded-lg border bg-primary/5">
                    <div className="flex items-center gap-2 mb-2">
                      <Target className="h-4 w-4 text-primary" />
                      <span className="text-sm font-semibold">Conclusão Principal</span>
                    </div>
                    <p className="text-sm text-muted-foreground leading-relaxed">{keyTakeaway}</p>
                  </div>
                )}

                <TabsContent value="top" className="mt-0 space-y-3">
                  {parsed.top_content.map((item, i) => (
                    <Card key={i} className="overflow-hidden">
                      <CardContent className="p-4">
                        <div className="flex items-start gap-3">
                          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary font-bold text-sm">
                            #{item.rank}
                          </div>
                          <div className="flex-1 min-w-0 space-y-2">
                            <div className="flex items-center gap-2 flex-wrap">
                              <Badge variant="outline" className={`gap-1 text-xs ${typeColor[item.type] || ""}`}>
                                {typeIcon[item.type]} {item.type}
                              </Badge>
                              <span className="text-xs text-muted-foreground">@{item.creator}</span>
                              {item.posted_date && <span className="text-xs text-muted-foreground">{item.posted_date}</span>}
                            </div>
                            <p className="font-medium text-sm leading-snug">"{item.hook}"</p>
                            <div className="flex items-center gap-4 text-xs text-muted-foreground">
                              {item.views > 0 && <span className="flex items-center gap-1"><Eye className="h-3 w-3" />{formatNumber(item.views)}</span>}
                              <span className="flex items-center gap-1"><Heart className="h-3 w-3" />{formatNumber(item.likes)}</span>
                            </div>
                            <p className="text-xs text-muted-foreground leading-relaxed border-l-2 border-primary/20 pl-3 mt-2">
                              {item.why_it_worked}
                            </p>
                            {item.url && (
                              <a href={item.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-xs text-primary hover:underline mt-1">
                                <ExternalLink className="h-3 w-3" /> Ver original
                              </a>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </TabsContent>

                <TabsContent value="patterns" className="mt-0 space-y-3">
                  {parsed.winning_patterns.map((p, i) => (
                    <Card key={i}>
                      <CardContent className="p-4 space-y-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          <div className="flex items-center gap-1.5">
                            <Target className="h-4 w-4 text-primary" />
                            <span className="font-semibold text-sm">{p.pattern_name}</span>
                          </div>
                          <Badge variant="outline" className={`text-xs ${effectivenessColor[p.effectiveness?.toLowerCase()] || ""}`}>
                            {p.effectiveness}
                          </Badge>
                          {p.frequency && (
                            <Badge variant="outline" className="text-xs">{p.frequency}</Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground leading-relaxed">{p.description}</p>
                        {p.examples?.length > 0 && (
                          <div className="space-y-1 mt-2">
                            <span className="text-xs font-medium text-muted-foreground">Exemplos:</span>
                            <ul className="list-disc list-inside space-y-0.5">
                              {p.examples.map((ex, j) => (
                                <li key={j} className="text-xs text-muted-foreground">{ex}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </TabsContent>

                <TabsContent value="hooks" className="mt-0 space-y-3">
                  {parsed.hook_ideas.map((h, i) => (
                    <Card key={i}>
                      <CardContent className="p-4 space-y-2">
                        <div className="flex items-start gap-3">
                          <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-amber-500/10 text-amber-600 dark:text-amber-400">
                            <Zap className="h-3.5 w-3.5" />
                          </div>
                          <div className="flex-1 space-y-1.5">
                            <p className="font-medium text-sm">"{h.hook}"</p>
                            <div className="flex items-center gap-2 flex-wrap">
                              <Badge variant="outline" className={`gap-1 text-xs ${typeColor[h.format?.toLowerCase()] || ""}`}>
                                {typeIcon[h.format?.toLowerCase()]} {h.format}
                              </Badge>
                              <Badge variant="outline" className="gap-1 text-xs bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/20">
                                <Sparkles className="h-3 w-3" /> {h.psychological_trigger}
                              </Badge>
                            </div>
                            <p className="text-xs text-muted-foreground">{h.expected_impact}</p>
                            {h.reference_content && (
                              <p className="text-xs text-muted-foreground/60 italic">Ref: {h.reference_content}</p>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </TabsContent>
              </ScrollArea>
            </Tabs>
          ) : (
            <ScrollArea className="flex-1 px-6 pb-6">
              <RawReportPreview raw={current?.raw_report || null} takeaway={keyTakeaway} full />
            </ScrollArea>
          )}
        </DialogContent>
      </Dialog>
    </>
  )
}

// Renders raw report as readable formatted text instead of raw JSON
function RawReportPreview({ raw, takeaway, full = false }: { raw: string | null; takeaway: string | null; full?: boolean }) {
  if (!raw && !takeaway) {
    return <p className="text-sm text-muted-foreground">Nenhum conteúdo disponível.</p>
  }

  const readableText = renderRawReport(raw)
  const displayText = full ? readableText : readableText.slice(0, 500) + (readableText.length > 500 ? "…" : "")

  return (
    <div className="space-y-3">
      {takeaway && (
        <div className="p-3 rounded-lg border bg-primary/5">
          <div className="flex items-center gap-2 mb-1">
            <Target className="h-4 w-4 text-primary" />
            <span className="text-sm font-semibold">Conclusão Principal</span>
          </div>
          <p className="text-sm text-muted-foreground leading-relaxed">{takeaway}</p>
        </div>
      )}
      <div className="text-sm text-muted-foreground leading-relaxed whitespace-pre-wrap">
        {displayText}
      </div>
    </div>
  )
}

function SummaryCard({ icon, label, count, items, allItems }: { icon: React.ReactNode; label: string; count: number; items: string[]; allItems?: string[] }) {
  const [expanded, setExpanded] = useState(false)
  const [visible, setVisible] = useState(true)

  if (!visible) return null

  const displayItems = expanded ? (allItems || items) : items.slice(0, 3)

  return (
    <div className="rounded-lg border bg-card/50 p-4 space-y-2 cursor-pointer transition-all hover:shadow-md" onClick={() => setExpanded(!expanded)}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-sm font-medium">{icon} {label}</div>
        <div className="flex items-center gap-1">
          <Badge variant="secondary" className="text-xs">{count}</Badge>
          <Button
            variant="ghost"
            size="icon"
            className="h-5 w-5 shrink-0"
            onClick={(e) => { e.stopPropagation(); setExpanded(!expanded) }}
          >
            {expanded ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-5 w-5 shrink-0 text-muted-foreground hover:text-destructive"
            onClick={(e) => { e.stopPropagation(); setVisible(false) }}
          >
            <X className="h-3 w-3" />
          </Button>
        </div>
      </div>
      <ul className="space-y-1">
        {displayItems.map((text, i) => (
          <li key={i} className={`text-xs text-muted-foreground flex items-center gap-1.5 ${expanded ? "" : "truncate"}`}>
            <span className="h-1 w-1 rounded-full bg-muted-foreground/40 shrink-0" />
            <span className={expanded ? "" : "truncate"}>{expanded ? text : (text.length > 60 ? text.slice(0, 60) + "…" : text)}</span>
          </li>
        ))}
      </ul>
      {!expanded && items.length > 3 && (
        <p className="text-xs text-primary/70 text-center">+{items.length - 3} mais • clique para expandir</p>
      )}
    </div>
  )
}
