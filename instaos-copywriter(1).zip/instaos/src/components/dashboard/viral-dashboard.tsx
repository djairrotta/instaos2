import { useState, useEffect, useCallback } from "react"
import { supabase } from "@/integrations/supabase/client"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import {
  Zap, RefreshCw, TrendingUp, Copy, ChevronDown, ChevronUp,
  Loader2, BarChart3, Target, Lightbulb, AlertTriangle, Play,
} from "lucide-react"

// ── Types ──────────────────────────────────────────────────────────────────
interface Post {
  id: string
  owner_username: string
  caption: string
  content_type: string
  thumbnail_url?: string
  url?: string
  views: number
  likes: number
  comments: number
  viral_score: number
  hook_type?: string
  adapted_hook?: string
  estimated_reach?: string
  best_format?: string
  hook_analysis?: string
  viral_analysis?: {
    hook?: string
    power_words?: string[]
    why_viral?: string
    weak_points?: string
    content_ideas?: string[]
    call_to_action?: string
    emotional_trigger?: string
    structure?: string
  }
}

interface Stats {
  total: number
  avgScore: number
  topScore: number
  byHookType: Record<string, number>
  byFormat: Record<string, number>
  byReach: Record<string, number>
}

interface Insights {
  dominant_hook_type?: string
  dominant_format?: string
  winning_formula?: string
  power_words?: string[]
  emotional_triggers?: string[]
  hook_template?: string
  what_to_avoid?: string[]
  recommendation?: string
  hookTypeDistribution?: Record<string, number>
  formatDistribution?: Record<string, number>
  topAdaptedHooks?: string[]
  postsAnalyzed?: number
}

// ── Helpers ────────────────────────────────────────────────────────────────
function fmtNum(n: number) {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + "M"
  if (n >= 1_000) return (n / 1_000).toFixed(1) + "K"
  return String(n)
}

function scoreColor(s: number) {
  if (s >= 75) return "text-green-400"
  if (s >= 50) return "text-yellow-400"
  if (s >= 25) return "text-orange-400"
  return "text-muted-foreground"
}

function scoreBg(s: number) {
  if (s >= 75) return "bg-green-500/10 border-green-500/30"
  if (s >= 50) return "bg-yellow-500/10 border-yellow-500/30"
  if (s >= 25) return "bg-orange-500/10 border-orange-500/30"
  return "bg-muted/20 border-border"
}

const HOOK_EMOJI: Record<string, string> = {
  "Curiosidade": "🤔", "Dor": "😣", "Promessa": "✨",
  "Choque": "😮", "Prova Social": "👥", "Tendência": "📈", "Urgência": "⏰",
}

// ── Score Ring ─────────────────────────────────────────────────────────────
function ScoreRing({ score }: { score: number }) {
  const r = 22
  const circ = 2 * Math.PI * r
  const pct = Math.min(Math.max(score, 0), 100) / 100
  const color = score >= 75 ? "#22c55e" : score >= 50 ? "#eab308" : score >= 25 ? "#f97316" : "#6b7280"
  return (
    <div className="relative w-14 h-14 flex items-center justify-center flex-shrink-0">
      <svg width="56" height="56" className="-rotate-90">
        <circle cx="28" cy="28" r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="5" />
        <circle cx="28" cy="28" r={r} fill="none" stroke={color} strokeWidth="5"
          strokeDasharray={`${pct * circ} ${circ}`} strokeLinecap="round"
          style={{ transition: "stroke-dasharray 0.6s ease" }} />
      </svg>
      <div className="absolute flex flex-col items-center leading-none">
        <span className="text-sm font-bold" style={{ color }}>{score}</span>
      </div>
    </div>
  )
}

// ── Post Card ──────────────────────────────────────────────────────────────
function PostCard({ post, rank, onAnalyzeOne, onUseAngle }: {
  post: Post; rank: number
  onAnalyzeOne: (id: string) => void
  onUseAngle: (post: Post) => void
}) {
  const [expanded, setExpanded] = useState(false)
  const va = post.viral_analysis

  return (
    <div className={cn(
      "rounded-xl border transition-all",
      post.viral_score >= 75 ? "border-green-500/20 bg-green-500/3" :
      post.viral_score >= 50 ? "border-yellow-500/20 bg-yellow-500/3" : "border-border bg-card"
    )}>
      {/* Header row */}
      <div className="flex items-start gap-3 p-3.5">
        {/* Rank + thumb */}
        <div className="flex flex-col items-center gap-1.5 flex-shrink-0">
          <span className="text-[11px] font-bold text-muted-foreground/50 font-mono">#{rank}</span>
          <div className="w-12 h-12 rounded-lg overflow-hidden bg-muted/20 border border-border flex-shrink-0">
            {post.thumbnail_url
              ? <img src={post.thumbnail_url} className="w-full h-full object-cover" alt="" onError={e => { (e.target as HTMLImageElement).style.display = "none" }} />
              : <div className="w-full h-full flex items-center justify-center text-lg opacity-40">
                  {post.content_type === "reel" ? "🎬" : post.content_type === "carousel" ? "🎠" : "📸"}
                </div>}
          </div>
        </div>

        {/* Score ring */}
        <ScoreRing score={post.viral_score || 0} />

        {/* Content */}
        <div className="flex-1 min-w-0">
          {/* Top badges */}
          <div className="flex items-center gap-1.5 flex-wrap mb-1.5">
            <span className="text-xs font-semibold text-foreground/80">@{post.owner_username}</span>
            {post.hook_type && (
              <Badge variant="outline" className="text-[9px] px-1.5 py-0 text-yellow-400 border-yellow-500/30">
                {HOOK_EMOJI[post.hook_type] || "🎯"} {post.hook_type}
              </Badge>
            )}
            <Badge variant="outline" className="text-[9px] px-1.5 py-0 text-muted-foreground">
              {post.content_type}
            </Badge>
            {post.estimated_reach && (
              <Badge variant="outline" className={cn("text-[9px] px-1.5 py-0",
                post.estimated_reach === "viral" ? "text-green-400 border-green-500/30" :
                post.estimated_reach === "alto" ? "text-yellow-400 border-yellow-500/30" :
                "text-muted-foreground"
              )}>
                {post.estimated_reach}
              </Badge>
            )}
          </div>

          {/* Adapted hook */}
          {post.adapted_hook && (
            <div className="flex items-start gap-1.5 mb-1.5">
              <Target className="w-3 h-3 text-yellow-400 mt-0.5 flex-shrink-0" />
              <p className="text-[11px] text-yellow-300/90 italic leading-snug line-clamp-2">
                "{post.adapted_hook}"
              </p>
              <button onClick={() => { navigator.clipboard.writeText(post.adapted_hook!); toast.success("Copiado!") }}
                className="text-muted-foreground hover:text-yellow-400 flex-shrink-0 ml-auto">
                <Copy className="w-3 h-3" />
              </button>
            </div>
          )}

          {/* Caption preview */}
          <p className="text-[10px] text-muted-foreground line-clamp-1">{post.caption || "(sem legenda)"}</p>

          {/* Metrics */}
          <div className="flex items-center gap-3 mt-1.5 text-[10px] text-muted-foreground/70">
            <span>👁️ {fmtNum(post.views)}</span>
            <span>❤️ {fmtNum(post.likes)}</span>
            <span>💬 {fmtNum(post.comments)}</span>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-col gap-1.5 flex-shrink-0">
          <button onClick={() => setExpanded(v => !v)} className="text-muted-foreground hover:text-foreground">
            {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
          {!post.viral_score && (
            <button onClick={() => onAnalyzeOne(post.id)} className="text-muted-foreground hover:text-yellow-400">
              <Zap className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Expanded details */}
      {expanded && va && (
        <div className="px-4 pb-4 pt-0 space-y-3 border-t border-border/50 mt-0">
          {va.hook && (
            <div className="flex gap-2 mt-3">
              <span className="text-base flex-shrink-0">🎣</span>
              <div>
                <p className="text-[9px] uppercase tracking-wide text-muted-foreground/50 mb-0.5">Gancho Original</p>
                <p className="text-xs italic text-foreground/80">"{va.hook}"</p>
              </div>
            </div>
          )}
          {va.power_words?.length && (
            <div className="flex gap-2">
              <span className="text-base flex-shrink-0">⚡</span>
              <div>
                <p className="text-[9px] uppercase tracking-wide text-muted-foreground/50 mb-1">Power Words</p>
                <div className="flex flex-wrap gap-1">
                  {va.power_words.map((w, i) => (
                    <span key={i} className="text-[10px] px-1.5 py-0.5 rounded bg-yellow-500/10 text-yellow-400 border border-yellow-500/20">{w}</span>
                  ))}
                </div>
              </div>
            </div>
          )}
          {va.why_viral && (
            <div className="flex gap-2">
              <span className="text-base flex-shrink-0">💡</span>
              <div>
                <p className="text-[9px] uppercase tracking-wide text-muted-foreground/50 mb-0.5">Por que funciona</p>
                <p className="text-[11px] text-muted-foreground leading-relaxed">{va.why_viral}</p>
              </div>
            </div>
          )}
          {va.weak_points && (
            <div className="flex gap-2">
              <AlertTriangle className="w-3.5 h-3.5 text-orange-400 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-[9px] uppercase tracking-wide text-muted-foreground/50 mb-0.5">Ponto Fraco</p>
                <p className="text-[11px] text-muted-foreground">{va.weak_points}</p>
              </div>
            </div>
          )}
          {va.content_ideas?.length && (
            <div>
              <p className="text-[9px] uppercase tracking-wide text-muted-foreground/50 mb-1.5">Ideias Adaptadas</p>
              <div className="space-y-1">
                {va.content_ideas.map((idea, i) => (
                  <div key={i} className="flex gap-2 text-[10px] text-muted-foreground">
                    <span className="text-yellow-400 font-mono flex-shrink-0">{String(i + 1).padStart(2, "0")}</span>
                    {idea}
                  </div>
                ))}
              </div>
            </div>
          )}
          <Button size="sm" onClick={() => onUseAngle(post)}
            className="w-full gap-1.5 h-7 text-[11px] bg-yellow-500/20 text-yellow-400 border border-yellow-500/30 hover:bg-yellow-500/30">
            <Zap className="w-3 h-3" />Gerar Conteúdo com este Gancho
          </Button>
        </div>
      )}
    </div>
  )
}

// ── Insights Panel ─────────────────────────────────────────────────────────
function InsightsPanel({ insights, stats }: { insights: Insights | null; stats: Stats | null }) {
  if (!insights && !stats) return null

  return (
    <div className="rounded-xl border border-border bg-card p-4 space-y-4">
      <div className="flex items-center gap-2">
        <BarChart3 className="w-4 h-4 text-yellow-400" />
        <h3 className="font-semibold text-sm">Padrões dos Top Posts</h3>
        {insights?.postsAnalyzed && (
          <span className="text-[10px] text-muted-foreground ml-auto">{insights.postsAnalyzed} posts analisados</span>
        )}
      </div>

      {/* Stats row */}
      {stats && (
        <div className="grid grid-cols-3 gap-2">
          {[
            { label: "Score Médio", value: stats.avgScore },
            { label: "Score Máx", value: stats.topScore },
            { label: "Posts com score", value: stats.total },
          ].map(s => (
            <div key={s.label} className="rounded-lg bg-muted/20 p-2.5 text-center">
              <div className={cn("text-xl font-bold font-mono", scoreColor(s.value))}>{s.value}</div>
              <div className="text-[9px] text-muted-foreground mt-0.5">{s.label}</div>
            </div>
          ))}
        </div>
      )}

      {insights && (
        <>
          {/* Winning formula */}
          {insights.winning_formula && (
            <div className="rounded-lg bg-yellow-500/5 border border-yellow-500/20 p-3">
              <p className="text-[9px] uppercase tracking-wider text-yellow-400/70 mb-1">Fórmula Vencedora</p>
              <p className="text-xs text-yellow-300">{insights.winning_formula}</p>
            </div>
          )}

          {/* Hook template */}
          {insights.hook_template && (
            <div>
              <p className="text-[9px] uppercase tracking-wider text-muted-foreground/50 mb-1.5">Template de Gancho</p>
              <div className="flex items-start gap-1.5">
                <p className="text-xs italic text-foreground/80 flex-1">"{insights.hook_template}"</p>
                <button onClick={() => { navigator.clipboard.writeText(insights.hook_template!); toast.success("Template copiado!") }}
                  className="text-muted-foreground hover:text-foreground flex-shrink-0">
                  <Copy className="w-3 h-3" />
                </button>
              </div>
            </div>
          )}

          {/* Power words */}
          {insights.power_words?.length && (
            <div>
              <p className="text-[9px] uppercase tracking-wider text-muted-foreground/50 mb-1.5">Power Words do Nicho</p>
              <div className="flex flex-wrap gap-1">
                {insights.power_words.map((w, i) => (
                  <span key={i} className="text-[10px] px-2 py-0.5 rounded-full bg-yellow-500/10 text-yellow-400 border border-yellow-500/20">{w}</span>
                ))}
              </div>
            </div>
          )}

          {/* Emotional triggers */}
          {insights.emotional_triggers?.length && (
            <div>
              <p className="text-[9px] uppercase tracking-wider text-muted-foreground/50 mb-1.5">Gatilhos Dominantes</p>
              <div className="flex flex-wrap gap-1">
                {insights.emotional_triggers.map((t, i) => (
                  <span key={i} className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/10 text-purple-400 border border-purple-500/20">{t}</span>
                ))}
              </div>
            </div>
          )}

          {/* What to avoid */}
          {insights.what_to_avoid?.length && (
            <div>
              <p className="text-[9px] uppercase tracking-wider text-muted-foreground/50 mb-1.5">Evitar</p>
              <ul className="space-y-0.5">
                {insights.what_to_avoid.map((w, i) => (
                  <li key={i} className="text-[10px] text-muted-foreground flex items-start gap-1.5">
                    <span className="text-red-400 flex-shrink-0">✗</span>{w}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Recommendation */}
          {insights.recommendation && (
            <div className="rounded-lg bg-blue-500/5 border border-blue-500/20 p-3">
              <p className="text-[9px] uppercase tracking-wider text-blue-400/70 mb-1">Recomendação Estratégica</p>
              <p className="text-[11px] text-blue-300/90 leading-relaxed">{insights.recommendation}</p>
            </div>
          )}

          {/* Hook distribution */}
          {insights.hookTypeDistribution && Object.keys(insights.hookTypeDistribution).length > 0 && (
            <div>
              <p className="text-[9px] uppercase tracking-wider text-muted-foreground/50 mb-1.5">Distribuição de Ganchos</p>
              <div className="space-y-1.5">
                {Object.entries(insights.hookTypeDistribution)
                  .sort(([, a], [, b]) => b - a)
                  .map(([type, count]) => {
                    const total = Object.values(insights.hookTypeDistribution!).reduce((a, b) => a + b, 0)
                    const pct = Math.round((count / total) * 100)
                    return (
                      <div key={type} className="flex items-center gap-2">
                        <span className="text-[10px] text-muted-foreground w-24 truncate">{HOOK_EMOJI[type] || "🎯"} {type}</span>
                        <div className="flex-1 h-1.5 bg-muted/20 rounded-full overflow-hidden">
                          <div className="h-full bg-yellow-400/60 rounded-full" style={{ width: `${pct}%` }} />
                        </div>
                        <span className="text-[10px] font-mono text-muted-foreground w-8 text-right">{pct}%</span>
                      </div>
                    )
                  })}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  )
}

// ── Main Component ─────────────────────────────────────────────────────────
export function ViralDashboard({ onUsePost }: { onUsePost?: (post: Post) => void }) {
  const [posts, setPosts] = useState<Post[]>([])
  const [stats, setStats] = useState<Stats | null>(null)
  const [insights, setInsights] = useState<Insights | null>(null)
  const [loading, setLoading] = useState(true)
  const [analyzing, setAnalyzing] = useState(false)
  const [loadingInsights, setLoadingInsights] = useState(false)
  const [filter, setFilter] = useState<"all" | "reel" | "carousel" | "post">("all")
  const [minScore, setMinScore] = useState(0)
  const [unscored, setUnscored] = useState(0)

  const load = useCallback(async () => {
    setLoading(true)
    const { data: { session } } = await supabase.auth.getSession()
    try {
      const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/viral-engine`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.access_token}` },
        body: JSON.stringify({ action: "get_ranking", limit: 50, contentType: filter, minScore }),
      })
      const d = await res.json()
      if (d.success) { setPosts(d.posts || []); setStats(d.stats || null) }

      // Count unscored
      const { count } = await supabase
        .from("reels_competidores")
        .select("id", { count: "exact", head: true })
        .eq("relevance_status", "approved")
        .or("viral_score.is.null,viral_score.eq.0")
      setUnscored(count || 0)
    } finally { setLoading(false) }
  }, [filter, minScore])

  useEffect(() => { load() }, [load])

  async function runBatch() {
    setAnalyzing(true)
    const { data: { session } } = await supabase.auth.getSession()
    try {
      const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/viral-engine`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.access_token}` },
        body: JSON.stringify({ action: "analyze_batch", limit: 30 }),
      })
      const d = await res.json()
      if (d.success) {
        toast.success(`${d.analyzed} posts analisados!`)
        load()
      } else throw new Error(d.error)
    } catch (e: any) { toast.error(e.message) }
    finally { setAnalyzing(false) }
  }

  async function analyzeOne(postId: string) {
    const { data: { session } } = await supabase.auth.getSession()
    try {
      const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/viral-engine`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.access_token}` },
        body: JSON.stringify({ action: "analyze_one", postId }),
      })
      const d = await res.json()
      if (d.success) { toast.success("Score calculado!"); load() }
      else throw new Error(d.error)
    } catch (e: any) { toast.error(e.message) }
  }

  async function loadInsights() {
    setLoadingInsights(true)
    const { data: { session } } = await supabase.auth.getSession()
    try {
      const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/viral-engine`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.access_token}` },
        body: JSON.stringify({ action: "get_insights", topN: 15 }),
      })
      const d = await res.json()
      if (d.success && d.insights) setInsights(d.insights)
      else toast("Analise mais posts para gerar insights")
    } finally { setLoadingInsights(false) }
  }

  return (
    <div className="p-6 lg:p-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-start justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <TrendingUp className="w-6 h-6 text-yellow-400" />
            Ranking Viral
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Posts ranqueados por score viral — gancho extraído pela IA, adaptado para o seu nicho
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap justify-end">
          {unscored > 0 && (
            <span className="text-xs text-muted-foreground bg-yellow-500/10 border border-yellow-500/20 px-2.5 py-1 rounded-full">
              {unscored} posts sem score
            </span>
          )}
          <Button onClick={runBatch} disabled={analyzing} size="sm"
            className="gap-1.5 text-xs bg-yellow-500 hover:bg-yellow-400 text-black font-semibold h-8">
            {analyzing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Zap className="w-3.5 h-3.5" />}
            {analyzing ? "Analisando..." : unscored > 0 ? `Analisar ${unscored} posts` : "Re-analisar"}
          </Button>
          <Button onClick={loadInsights} disabled={loadingInsights} variant="outline" size="sm"
            className="gap-1.5 text-xs h-8">
            {loadingInsights ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Lightbulb className="w-3.5 h-3.5" />}
            Insights
          </Button>
          <Button onClick={load} disabled={loading} variant="ghost" size="sm" className="h-8 w-8 p-0">
            <RefreshCw className={cn("w-3.5 h-3.5", loading && "animate-spin")} />
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-[1fr_300px] gap-6">
        {/* Posts list */}
        <div>
          {/* Filters */}
          <div className="flex items-center gap-2 mb-4 flex-wrap">
            <div className="flex rounded-lg border border-border overflow-hidden">
              {(["all","reel","carousel","post"] as const).map(f => (
                <button key={f} onClick={() => setFilter(f)}
                  className={cn("px-3 py-1.5 text-xs font-medium transition-colors",
                    filter === f ? "bg-yellow-500/20 text-yellow-400" : "text-muted-foreground hover:text-foreground"
                  )}>
                  {f === "all" ? "Todos" : f.charAt(0).toUpperCase() + f.slice(1)}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-2 ml-auto">
              <span className="text-xs text-muted-foreground">Score mín:</span>
              {[0, 25, 50, 70].map(s => (
                <button key={s} onClick={() => setMinScore(s)}
                  className={cn("text-xs px-2 py-1 rounded border transition-colors",
                    minScore === s ? "border-yellow-500/50 text-yellow-400 bg-yellow-500/10" : "border-border text-muted-foreground"
                  )}>
                  {s === 0 ? "Todos" : `${s}+`}
                </button>
              ))}
            </div>
          </div>

          {/* Post cards */}
          {loading ? (
            <div className="space-y-2">
              {[1,2,3,4,5].map(i => <div key={i} className="h-24 rounded-xl bg-muted/20 animate-pulse" />)}
            </div>
          ) : posts.length === 0 ? (
            <div className="text-center py-16 text-muted-foreground">
              <TrendingUp className="w-10 h-10 opacity-20 mx-auto mb-3" />
              <p className="text-sm font-medium mb-1">Nenhum post com score viral</p>
              <p className="text-xs">Clique em "Analisar posts" para calcular o score de todos os posts coletados</p>
              <Button onClick={runBatch} disabled={analyzing} size="sm" className="mt-4 gap-1.5 bg-yellow-500 hover:bg-yellow-400 text-black">
                {analyzing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Zap className="w-3.5 h-3.5" />}
                Analisar agora
              </Button>
            </div>
          ) : (
            <div className="space-y-2">
              {posts.map((post, i) => (
                <PostCard
                  key={post.id}
                  post={post}
                  rank={i + 1}
                  onAnalyzeOne={analyzeOne}
                  onUseAngle={p => onUsePost?.(p)}
                />
              ))}
            </div>
          )}
        </div>

        {/* Insights sidebar */}
        <div className="space-y-4">
          <InsightsPanel insights={insights} stats={stats} />
          {!insights && !loading && (
            <div className="rounded-xl border border-dashed border-border p-6 text-center">
              <Lightbulb className="w-8 h-8 text-muted-foreground/30 mx-auto mb-2" />
              <p className="text-xs text-muted-foreground">Clique em "Insights" para a IA sintetizar os padrões dos posts mais virais</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
