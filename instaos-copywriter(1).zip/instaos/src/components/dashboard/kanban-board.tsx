import React, { useState, useMemo, useRef, useCallback, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { cn } from "@/lib/utils"
import { toast } from "sonner"
import { supabase } from "@/integrations/supabase/client"
import {
  MoreHorizontal,
  GripVertical,
  Plus,
  ChevronLeft,
  ChevronRight,
  Filter,
  ArrowUpDown,
  Search,
  LayoutGrid,
  Calendar as CalendarIcon,
  Globe,
  Expand,
  Save,
  X,
  Film,
  Image,
  Images as ImagesIcon,
  Smartphone,
  FileText,
  Sparkles,
  Trash2,
  Copy,
  Eye,
  Heart,
  MessageCircle,
  TrendingUp,
  Zap,
  Brain,
  Shield,
  ExternalLink,
  Play,
  ChevronDown,
  Loader2,
  Mic,
  BookOpen,
  Maximize2,
  Minimize2,
  GripHorizontal,
} from "lucide-react"

export type KanbanStatus = "ideia" | "gravando" | "para_editar" | "editando" | "revisar" | "agendado"

export interface KanbanItem {
  id: string
  title: string
  description: string
  tags: string[]
  date: string
  scheduledDate?: Date
  status: KanbanStatus
  hook?: string
  format?: string
  psychological_trigger?: string
  source?: string
  linkedReelId?: string
}

export interface ReelData {
  id: string
  user: string
  caption: string
  url: string
  hookAnalysis?: string
  transcript?: string
  views: number
  likes: number
  comments: number
  engRate: number
  postDate: string
  contentType?: string
  imageUrls?: string[]
  videoUrl?: string
  viralPoints?: string[]
  psychTriggers?: string[]
  relevanceStatus?: string
  relevanceScore?: number
  relevanceReason?: string
}

interface KanbanBoardProps {
  items: KanbanItem[]
  onItemMove: (itemId: string, newStatus: KanbanStatus) => void
  onAddItem: () => void
  onItemUpdate?: (item: KanbanItem) => void
  onItemDelete?: (itemId: string) => void
  onItemDuplicate?: (item: KanbanItem) => void
  onCleanOrphans?: () => void
  reelsData?: ReelData[]
}

const columns: { id: KanbanStatus; label: string; dotColor: string; bgColor: string }[] = [
  { id: "ideia", label: "Ideia", dotColor: "bg-gray-400", bgColor: "bg-background" },
  { id: "gravando", label: "Gravando", dotColor: "bg-blue-500", bgColor: "bg-blue-50 dark:bg-blue-950/30" },
  { id: "para_editar", label: "Para Editar", dotColor: "bg-rose-400", bgColor: "bg-rose-50 dark:bg-rose-950/30" },
  { id: "editando", label: "Editando", dotColor: "bg-pink-400", bgColor: "bg-pink-50 dark:bg-pink-950/30" },
  { id: "revisar", label: "Revisar", dotColor: "bg-orange-400", bgColor: "bg-orange-50 dark:bg-orange-950/30" },
  { id: "agendado", label: "Agendado", dotColor: "bg-amber-500", bgColor: "bg-amber-50 dark:bg-amber-950/30" },
]

const FORMAT_ICONS: Record<string, React.ReactNode> = {
  reel: <Film className="h-3.5 w-3.5" />,
  post: <Image className="h-3.5 w-3.5" />,
  carousel: <ImagesIcon className="h-3.5 w-3.5" />,
  story: <Smartphone className="h-3.5 w-3.5" />,
}

type ViewMode = "board" | "calendar" | "volume"
const formatNumber = (n: number) => {
  if (n >= 1000000) return (n / 1000000).toFixed(1) + "M"
  if (n >= 1000) return (n / 1000).toFixed(1) + "K"
  return n.toString()
}

export function KanbanBoard({ items, onItemMove, onAddItem, onItemUpdate, onItemDelete, onItemDuplicate, onCleanOrphans, reelsData = [] }: KanbanBoardProps) {
  const [draggedItem, setDraggedItem] = useState<string | null>(null)
  const [dragOverColumn, setDragOverColumn] = useState<string | null>(null)
  const [selectedItem, setSelectedItem] = useState<KanbanItem | null>(null)
  const [editingItem, setEditingItem] = useState<KanbanItem | null>(null)
  const [isEditing, setIsEditing] = useState(false)
  const [viewMode, setViewMode] = useState<ViewMode>("board")
  const [currentDate, setCurrentDate] = useState(new Date())
  const [ideiaReelsOpen, setIdeiaReelsOpen] = useState(false)
  const [expandedReelIds, setExpandedReelIds] = useState<Set<string>>(new Set())
  const [reelTranscripts, setReelTranscripts] = useState<Record<string, string>>({})
  const [transcribingIds, setTranscribingIds] = useState<Set<string>>(new Set())
  const [summarizingIds, setSummarizingIds] = useState<Set<string>>(new Set())
  const [reelSummaries, setReelSummaries] = useState<Record<string, string>>({})

  // Get reels linked to ideia items
  const ideiaReels = useMemo(() => {
    const linkedIds = new Set(items.filter(i => i.status === "ideia" && i.linkedReelId).map(i => i.linkedReelId!))
    return reelsData.filter(r => linkedIds.has(r.id))
  }, [items, reelsData])

  const toggleReelExpanded = (id: string) => {
    setExpandedReelIds(prev => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  const handleTranscribe = async (reel: ReelData) => {
    if (!reel.videoUrl) { toast.error("Sem URL de vídeo disponível"); return }
    setTranscribingIds(prev => new Set(prev).add(reel.id))
    try {
      const { data, error } = await supabase.functions.invoke("transcribe-audio", {
        body: { videoUrl: reel.videoUrl, language: "pt" },
      })
      if (error) throw error
      if (data?.success && data.transcript) {
        setReelTranscripts(prev => ({ ...prev, [reel.id]: data.transcript }))
        toast.success("Transcrição concluída!")
      } else {
        toast.error(data?.error || "Falha na transcrição")
      }
    } catch (e: any) {
      toast.error(e.message || "Erro ao transcrever")
    } finally {
      setTranscribingIds(prev => { const n = new Set(prev); n.delete(reel.id); return n })
    }
  }

  const handleSummarize = async (reel: ReelData) => {
    const transcript = reelTranscripts[reel.id] || reel.transcript
    const content = transcript || reel.caption || ""
    if (!content) { toast.error("Sem conteúdo para resumir. Transcreva o vídeo primeiro."); return }
    setSummarizingIds(prev => new Set(prev).add(reel.id))
    try {
      const { data, error } = await supabase.functions.invoke("analyze-content", {
        body: {
          action: "hook_analysis",
          content: `Faça um RESUMO COMPLETO e DETALHADO do conteúdo abaixo, destacando:\n1. Tema principal\n2. Pontos-chave abordados\n3. Estratégias utilizadas\n4. Como replicar este conteúdo\n\nConteúdo:\n${content}`,
          model: "google/gemini-2.5-flash",
        },
      })
      if (error) throw error
      if (data?.result) {
        setReelSummaries(prev => ({ ...prev, [reel.id]: data.result }))
        toast.success("Resumo gerado!")
      } else {
        toast.error("Falha ao gerar resumo")
      }
    } catch (e: any) {
      toast.error(e.message || "Erro ao resumir")
    } finally {
      setSummarizingIds(prev => { const n = new Set(prev); n.delete(reel.id); return n })
    }
  }

  const handleDragStart = (e: React.DragEvent, itemId: string) => {
    setDraggedItem(itemId)
    e.dataTransfer.effectAllowed = "move"
  }

  const handleDragEnd = () => {
    setDraggedItem(null)
    setDragOverColumn(null)
  }

  const handleDragOver = (e: React.DragEvent, columnId: string) => {
    e.preventDefault()
    setDragOverColumn(columnId)
  }

  const handleDragLeave = () => {
    setDragOverColumn(null)
  }

  const handleDrop = (e: React.DragEvent, columnId: KanbanStatus) => {
    e.preventDefault()
    if (draggedItem) {
      onItemMove(draggedItem, columnId)
    }
    setDraggedItem(null)
    setDragOverColumn(null)
  }

  const handleCardClick = (item: KanbanItem) => {
    setSelectedItem(item)
    setEditingItem({ ...item })
    setIsEditing(false)
  }

  const handleSaveEdit = () => {
    if (editingItem && onItemUpdate) {
      onItemUpdate(editingItem)
      setSelectedItem(editingItem)
    }
    setIsEditing(false)
  }

  const handleCloseDetail = () => {
    setSelectedItem(null)
    setEditingItem(null)
    setIsEditing(false)
  }

  const getColumnItems = (columnId: KanbanStatus) => items.filter((item) => item.status === columnId)

  const getFormatLabel = (format?: string) => {
    if (!format) return null
    const labels: Record<string, string> = { reel: "Reel", post: "Post", carousel: "Carrossel", story: "Story" }
    return labels[format] || format
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="flex items-center gap-2 text-xl font-semibold">
          <LayoutGrid className="h-5 w-5 text-pink-500" />
          Central de Conteudo
        </h2>
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1 rounded-lg bg-muted/50 p-1">
          <Button variant={viewMode === "board" ? "secondary" : "ghost"} size="sm" className={cn("gap-2 text-sm", viewMode === "board" && "bg-background shadow-sm")} onClick={() => setViewMode("board")}>
            <LayoutGrid className="h-4 w-4" /> Board
          </Button>
          <Button variant={viewMode === "calendar" ? "secondary" : "ghost"} size="sm" className={cn("gap-2 text-sm", viewMode === "calendar" && "bg-background shadow-sm")} onClick={() => setViewMode("calendar")}>
            <CalendarIcon className="h-4 w-4" /> Calendar
          </Button>
          <Button variant={viewMode === "volume" ? "secondary" : "ghost"} size="sm" className={cn("gap-2 text-sm", viewMode === "volume" && "bg-background shadow-sm")} onClick={() => setViewMode("volume")}>
            <Globe className="h-4 w-4" /> Post Volume
          </Button>
        </div>
        <div className="flex items-center gap-2">
          {onCleanOrphans && (
            <Button variant="ghost" size="sm" className="gap-1.5 text-xs text-destructive hover:text-destructive" onClick={onCleanOrphans}>
              <Trash2 className="h-3.5 w-3.5" /> Limpar irrelevantes
            </Button>
          )}
          <Button variant="ghost" size="icon" className="h-8 w-8"><Filter className="h-4 w-4" /></Button>
          <Button variant="ghost" size="icon" className="h-8 w-8"><ArrowUpDown className="h-4 w-4" /></Button>
          <Button variant="ghost" size="icon" className="h-8 w-8"><Search className="h-4 w-4" /></Button>
        </div>
      </div>

      {viewMode === "board" && (
        <div className="overflow-x-auto pb-4">
          <div className="flex gap-3" style={{ minWidth: "max-content" }}>
            {columns.map((column) => {
              const columnItems = getColumnItems(column.id)
              return (
                <div
                  key={column.id}
                  className={cn("w-48 shrink-0 rounded-lg border bg-card p-3 transition-all", dragOverColumn === column.id && "ring-2 ring-primary")}
                  onDragOver={(e) => handleDragOver(e, column.id)}
                  onDragLeave={handleDragLeave}
                  onDrop={(e) => handleDrop(e, column.id)}
                >
                  <div className="mb-3 flex items-center gap-2">
                    <span className={cn("h-2.5 w-2.5 rounded-full", column.dotColor)} />
                    <Badge variant="secondary" className={cn("font-medium text-foreground", column.bgColor)}>{column.label}</Badge>
                    <span className="ml-auto text-sm text-muted-foreground">{columnItems.length}</span>
                  </div>
                  <div className="space-y-2">
                    {columnItems.map((item) => (
                      <Card
                        key={item.id}
                        draggable
                        onDragStart={(e) => handleDragStart(e, item.id)}
                        onDragEnd={handleDragEnd}
                        className={cn("cursor-grab border-border/50 bg-card transition-all hover:shadow-md active:cursor-grabbing group", draggedItem === item.id && "opacity-50")}
                      >
                        <CardContent className="p-2">
                          <div className="flex items-center justify-between gap-1">
                            <div className="flex items-center gap-1.5 flex-1 min-w-0">
                              <GripVertical className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                              <span className="text-sm font-medium leading-tight truncate">{item.title}</span>
                            </div>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-5 w-5 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
                              onClick={(e) => { e.stopPropagation(); handleCardClick(item) }}
                            >
                              <Expand className="h-3 w-3" />
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                    {column.id === "ideia" && ideiaReels.length > 0 && (
                      <Card
                        className="cursor-pointer border-primary/30 bg-primary/5 hover:bg-primary/10 transition-all"
                        onClick={() => setIdeiaReelsOpen(true)}
                      >
                        <CardContent className="p-3">
                          <div className="flex items-center gap-2">
                            <Sparkles className="h-4 w-4 text-primary" />
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium">📡 Conteúdo Capturado</p>
                              <p className="text-[10px] text-muted-foreground">{ideiaReels.length} posts de competidores</p>
                            </div>
                            <Badge variant="secondary" className="text-xs">{ideiaReels.length}</Badge>
                          </div>
                        </CardContent>
                      </Card>
                    )}
                    {column.id === "ideia" && (
                      <Button variant="ghost" className="w-full justify-start gap-2 text-muted-foreground" onClick={onAddItem}>
                        <Plus className="h-4 w-4" /> Novo
                      </Button>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}

      {viewMode === "calendar" && (
        <CalendarView
          currentDate={currentDate}
          items={items}
          onPreviousMonth={() => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1))}
          onNextMonth={() => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1))}
          onToday={() => setCurrentDate(new Date())}
        />
      )}

      {viewMode === "volume" && <PostVolumeView items={items} />}

      {/* Card Detail Dialog */}
      <Dialog open={!!selectedItem} onOpenChange={(open) => { if (!open) handleCloseDetail() }}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between gap-2">
              <span className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-primary" />
                Detalhes do Card
              </span>
              <Button
                variant={isEditing ? "default" : "outline"}
                size="sm"
                onClick={() => {
                  if (isEditing) {
                    handleSaveEdit()
                  } else {
                    setIsEditing(true)
                  }
                }}
              >
                {isEditing ? <><Save className="h-3.5 w-3.5 mr-1.5" /> Salvar</> : <><FileText className="h-3.5 w-3.5 mr-1.5" /> Editar</>}
              </Button>
            </DialogTitle>
          </DialogHeader>

          {editingItem && (
            <div className="space-y-4 mt-2">
              {/* Format badge */}
              {editingItem.format && (
                <div className="flex items-center gap-2">
                  <Badge variant="secondary" className="gap-1.5">
                    {FORMAT_ICONS[editingItem.format]}
                    {getFormatLabel(editingItem.format)}
                  </Badge>
                  {editingItem.source && (
                    <Badge variant="outline" className="text-[10px]">
                      {editingItem.source === "auto-pipeline" ? "🤖 Pipeline" : editingItem.source === "auto-dm" ? "📩 DM" : "✍️ Manual"}
                    </Badge>
                  )}
                  <Badge variant="outline" className="text-[10px]">{editingItem.date}</Badge>
                </div>
              )}

              {/* Title */}
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold text-muted-foreground">Título</Label>
                {isEditing ? (
                  <Input
                    value={editingItem.title}
                    onChange={(e) => setEditingItem({ ...editingItem, title: e.target.value })}
                    className="text-sm"
                  />
                ) : (
                  <p className="text-sm font-medium">{editingItem.title}</p>
                )}
              </div>

              {/* Hook */}
              {(editingItem.hook || isEditing) && (
                <div className="space-y-1.5">
                  <Label className="text-xs font-semibold text-muted-foreground">🎣 Hook</Label>
                  {isEditing ? (
                    <Input
                      value={editingItem.hook || ""}
                      onChange={(e) => setEditingItem({ ...editingItem, hook: e.target.value })}
                      placeholder="Hook sugerido..."
                      className="text-sm"
                    />
                  ) : (
                    <p className="text-sm italic text-primary/80">{editingItem.hook}</p>
                  )}
                </div>
              )}

              {/* Description */}
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold text-muted-foreground">Descrição</Label>
                {isEditing ? (
                  <Textarea
                    value={editingItem.description}
                    onChange={(e) => setEditingItem({ ...editingItem, description: e.target.value })}
                    rows={4}
                    className="text-sm resize-none"
                  />
                ) : (
                  <p className="text-sm text-muted-foreground whitespace-pre-wrap">{editingItem.description || "Sem descrição"}</p>
                )}
              </div>

              {/* Psychological Trigger */}
              {editingItem.psychological_trigger && (
                <div className="space-y-1.5">
                  <Label className="text-xs font-semibold text-muted-foreground">🧠 Gatilho Psicológico</Label>
                  <p className="text-sm text-muted-foreground">{editingItem.psychological_trigger}</p>
                </div>
              )}

              {/* Tags */}
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold text-muted-foreground">Tags</Label>
                {isEditing ? (
                  <Input
                    value={editingItem.tags?.join(", ") || ""}
                    onChange={(e) => setEditingItem({ ...editingItem, tags: e.target.value.split(",").map(t => t.trim()).filter(Boolean) })}
                    placeholder="tag1, tag2, tag3"
                    className="text-sm"
                  />
                ) : (
                  <div className="flex flex-wrap gap-1.5">
                    {editingItem.tags?.length > 0 ? editingItem.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="text-xs">{tag}</Badge>
                    )) : <span className="text-sm text-muted-foreground">Sem tags</span>}
                  </div>
                )}
              </div>

              {/* Status */}
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold text-muted-foreground">Status</Label>
                <div className="flex items-center gap-2">
                  {columns.map((col) => (
                    <Badge
                      key={col.id}
                      variant={editingItem.status === col.id ? "default" : "outline"}
                      className={cn(
                        "cursor-pointer text-[10px] transition-all",
                        editingItem.status === col.id && "ring-1 ring-primary"
                      )}
                      onClick={() => {
                        if (onItemUpdate) {
                          const updated = { ...editingItem, status: col.id }
                          setEditingItem(updated)
                          setSelectedItem(updated)
                          onItemMove(editingItem.id, col.id)
                        }
                      }}
                    >
                      <span className={cn("h-1.5 w-1.5 rounded-full mr-1", col.dotColor)} />
                      {col.label}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Actions: Duplicate & Delete */}
              <div className="flex items-center gap-2 pt-2 border-t">
                <Button
                  variant="outline"
                  size="sm"
                  className="gap-1.5 flex-1"
                  onClick={() => {
                    if (onItemDuplicate && editingItem) {
                      onItemDuplicate(editingItem)
                      handleCloseDetail()
                    }
                  }}
                >
                  <Copy className="h-3.5 w-3.5" /> Duplicar
                </Button>
                <Button
                  variant="destructive"
                  size="sm"
                  className="gap-1.5 flex-1"
                  onClick={() => {
                    if (onItemDelete && editingItem) {
                      onItemDelete(editingItem.id)
                      handleCloseDetail()
                    }
                  }}
                >
                  <Trash2 className="h-3.5 w-3.5" /> Excluir
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Ideia Reels Custom Modal - Captured Competitor Content */}
      {ideiaReelsOpen && (
        <IdeiaReelsModal
          reels={ideiaReels}
          onClose={() => setIdeiaReelsOpen(false)}
          expandedReelIds={expandedReelIds}
          toggleReelExpanded={toggleReelExpanded}
          reelTranscripts={reelTranscripts}
          reelSummaries={reelSummaries}
          transcribingIds={transcribingIds}
          summarizingIds={summarizingIds}
          handleTranscribe={handleTranscribe}
          handleSummarize={handleSummarize}
        />
      )}
    </div>
  )
}

function IdeiaReelsModal({ reels, onClose, expandedReelIds, toggleReelExpanded, reelTranscripts, reelSummaries, transcribingIds, summarizingIds, handleTranscribe, handleSummarize }: {
  reels: ReelData[]; onClose: () => void; expandedReelIds: Set<string>; toggleReelExpanded: (id: string) => void;
  reelTranscripts: Record<string, string>; reelSummaries: Record<string, string>;
  transcribingIds: Set<string>; summarizingIds: Set<string>;
  handleTranscribe: (r: ReelData) => void; handleSummarize: (r: ReelData) => void;
}) {
  const [isMaximized, setIsMaximized] = useState(false)
  const [pos, setPos] = useState({ x: 0, y: 0 })
  const dragging = useRef(false)
  const dragStart = useRef({ x: 0, y: 0 })

  const onMouseDown = useCallback((e: React.MouseEvent) => {
    if (isMaximized) return
    dragging.current = true
    dragStart.current = { x: e.clientX - pos.x, y: e.clientY - pos.y }
    const onMouseMove = (ev: MouseEvent) => {
      if (!dragging.current) return
      setPos({ x: ev.clientX - dragStart.current.x, y: ev.clientY - dragStart.current.y })
    }
    const onMouseUp = () => {
      dragging.current = false
      window.removeEventListener("mousemove", onMouseMove)
      window.removeEventListener("mouseup", onMouseUp)
    }
    window.addEventListener("mousemove", onMouseMove)
    window.addEventListener("mouseup", onMouseUp)
  }, [isMaximized, pos])

  return (
    <div className="fixed inset-0 z-50">
      <div className="fixed inset-0 bg-black/80" onClick={onClose} />
      <div
        className={cn(
          "fixed z-50 flex flex-col border bg-background shadow-lg rounded-lg",
          isMaximized
            ? "inset-2"
            : "left-1/2 top-1/2 w-[90vw] max-w-2xl h-[85vh]"
        )}
        style={isMaximized ? undefined : { transform: `translate(calc(-50% + ${pos.x}px), calc(-50% + ${pos.y}px))` }}
      >
        {/* Header - draggable */}
        <div
          className="flex items-center justify-between px-4 py-3 border-b shrink-0 cursor-grab active:cursor-grabbing select-none"
          onMouseDown={onMouseDown}
        >
          <div className="flex items-center gap-2">
            <GripHorizontal className="h-4 w-4 text-muted-foreground" />
            <Sparkles className="h-5 w-5 text-primary" />
            <h2 className="text-base font-semibold">Conteúdo Capturado dos Competidores</h2>
            <Badge variant="secondary" className="text-xs">{reels.length} posts</Badge>
          </div>
          <div className="flex items-center gap-1">
            <button onClick={() => { setIsMaximized(!isMaximized); setPos({ x: 0, y: 0 }) }} className="p-1.5 rounded-md hover:bg-muted" title={isMaximized ? "Restaurar" : "Maximizar"}>
              {isMaximized ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
            </button>
            <button onClick={onClose} className="p-1.5 rounded-md hover:bg-muted" title="Fechar">
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        <p className="text-sm text-muted-foreground px-4 py-2 shrink-0 border-b">
          Clique para expandir os detalhes
        </p>

        {/* Scrollable content */}
        <div className="flex-1 overflow-y-auto px-4 py-3">
          <div className="space-y-3">
            {reels.map((r) => {
              const isExpanded = expandedReelIds.has(r.id)
              return (
                <Collapsible key={r.id} open={isExpanded} onOpenChange={() => toggleReelExpanded(r.id)}>
                  <Card className={cn("transition-all", isExpanded && "ring-1 ring-primary/30")}>
                    <CollapsibleTrigger asChild>
                      <CardContent className="p-3 cursor-pointer hover:bg-muted/30 transition-colors">
                        <div className="flex items-center gap-3">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1 flex-wrap">
                              <Badge variant="outline" className="capitalize text-[10px]">{r.contentType || "reel"}</Badge>
                              <Badge
                                variant={r.relevanceStatus === "approved" ? "default" : "secondary"}
                                className={cn("text-[10px]", r.relevanceStatus === "approved" && "bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 border-emerald-500/30")}
                              >
                                {r.relevanceStatus === "approved" ? "Relevante" : r.relevanceStatus === "rejected" ? "Irrelevante" : "Pendente"}
                                {r.relevanceScore ? ` (${r.relevanceScore}%)` : ""}
                              </Badge>
                            </div>
                            <p className="text-sm font-medium">@{r.user}</p>
                            <p className="text-xs text-muted-foreground">{r.postDate}</p>
                            <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                              <span className="flex items-center gap-1"><Eye className="h-3 w-3" />{formatNumber(r.views)}</span>
                              <span className="flex items-center gap-1"><Heart className="h-3 w-3" />{formatNumber(r.likes)}</span>
                              <span className="flex items-center gap-1"><MessageCircle className="h-3 w-3" />{formatNumber(r.comments)}</span>
                              <span className="flex items-center gap-1"><TrendingUp className="h-3 w-3" />{r.engRate.toFixed(1)}%</span>
                            </div>
                          </div>
                          <ChevronDown className={cn("h-4 w-4 text-muted-foreground transition-transform shrink-0", isExpanded && "rotate-180")} />
                        </div>
                      </CardContent>
                    </CollapsibleTrigger>
                    <CollapsibleContent>
                      <div className="px-3 pb-3 space-y-3 border-t pt-3">
                        {r.caption && (<div><h4 className="text-xs font-semibold uppercase text-muted-foreground mb-1">Caption</h4><p className="text-sm bg-muted/50 rounded-lg p-3 whitespace-pre-wrap">{r.caption}</p></div>)}
                        {r.relevanceReason && (<div><h4 className="text-xs font-semibold uppercase text-muted-foreground mb-1 flex items-center gap-1"><Shield className="h-3 w-3" />Motivo da Classificação</h4><p className="text-sm bg-muted/50 rounded-lg p-3">{r.relevanceReason}</p></div>)}
                        {r.transcript && (<div><h4 className="text-xs font-semibold uppercase text-muted-foreground mb-1 flex items-center gap-1"><FileText className="h-3 w-3" />Transcrição</h4><p className="text-sm bg-muted/50 rounded-lg p-3 whitespace-pre-wrap max-h-48 overflow-y-auto">{r.transcript}</p></div>)}
                        {r.hookAnalysis && (<div><h4 className="text-xs font-semibold uppercase text-muted-foreground mb-1 flex items-center gap-1"><Zap className="h-3 w-3" />Análise do Hook</h4><p className="text-sm bg-muted/50 rounded-lg p-3 whitespace-pre-wrap">{r.hookAnalysis}</p></div>)}
                        {r.viralPoints && r.viralPoints.length > 0 && (<div><h4 className="text-xs font-semibold uppercase text-muted-foreground mb-1 flex items-center gap-1"><Zap className="h-3 w-3 text-amber-500" />Pontos Virais</h4><div className="space-y-1">{r.viralPoints.map((vp, i) => (<div key={i} className="text-xs bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20 rounded px-2 py-1.5">⚡ {vp}</div>))}</div></div>)}
                        {r.psychTriggers && r.psychTriggers.length > 0 && (<div><h4 className="text-xs font-semibold uppercase text-muted-foreground mb-1 flex items-center gap-1"><Brain className="h-3 w-3 text-purple-500" />Gatilhos Psicológicos</h4><div className="flex flex-wrap gap-1.5">{r.psychTriggers.map((pt, i) => (<Badge key={i} variant="secondary" className="text-xs bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/20">🧠 {pt}</Badge>))}</div></div>)}
                        {reelTranscripts[r.id] && (<div><h4 className="text-xs font-semibold uppercase text-muted-foreground mb-1 flex items-center gap-1"><Mic className="h-3 w-3" />Transcrição (sob demanda)</h4><p className="text-sm bg-muted/50 rounded-lg p-3 whitespace-pre-wrap max-h-48 overflow-y-auto">{reelTranscripts[r.id]}</p></div>)}
                        {reelSummaries[r.id] && (<div><h4 className="text-xs font-semibold uppercase text-muted-foreground mb-1 flex items-center gap-1"><BookOpen className="h-3 w-3" />Resumo IA</h4><p className="text-sm bg-primary/5 rounded-lg p-3 whitespace-pre-wrap max-h-48 overflow-y-auto">{reelSummaries[r.id]}</p></div>)}
                        <div className="flex flex-wrap gap-2 pt-2 border-t">
                          {r.url && (<Button variant="outline" size="sm" className="gap-1.5" asChild><a href={r.url} target="_blank" rel="noopener noreferrer"><ExternalLink className="h-3.5 w-3.5" />Ver no Instagram</a></Button>)}
                          {r.videoUrl && (<Button variant="outline" size="sm" className="gap-1.5" asChild><a href={r.videoUrl} target="_blank" rel="noopener noreferrer"><Play className="h-3.5 w-3.5" />Assistir Vídeo</a></Button>)}
                          {r.videoUrl && (<Button variant="outline" size="sm" className="gap-1.5" disabled={transcribingIds.has(r.id)} onClick={() => handleTranscribe(r)}>{transcribingIds.has(r.id) ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Mic className="h-3.5 w-3.5" />}{transcribingIds.has(r.id) ? "Transcrevendo..." : "Transcrever Vídeo"}</Button>)}
                          <Button variant="outline" size="sm" className="gap-1.5" disabled={summarizingIds.has(r.id)} onClick={() => handleSummarize(r)}>{summarizingIds.has(r.id) ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <BookOpen className="h-3.5 w-3.5" />}{summarizingIds.has(r.id) ? "Gerando..." : "Resumo IA"}</Button>
                          <Button variant="outline" size="sm" className="gap-1.5" onClick={() => {
                            const transcript = reelTranscripts[r.id] || r.transcript || ''
                            const summary = reelSummaries[r.id] || ''
                            navigator.clipboard.writeText(`@${r.user}\nHook: ${r.hookAnalysis || ''}\nCaption: ${r.caption}\nTranscrição: ${transcript}\n${summary ? `Resumo: ${summary}` : ''}`)
                            toast.success("Copiado!")
                          }}><Copy className="h-3.5 w-3.5" />Copiar Resumo</Button>
                        </div>
                      </div>
                    </CollapsibleContent>
                  </Card>
                </Collapsible>
              )
            })}
          </div>
        </div>
      </div>
    </div>
  )
}

function CalendarView({ currentDate, items, onPreviousMonth, onNextMonth, onToday }: {
  currentDate: Date; items: KanbanItem[]; onPreviousMonth: () => void; onNextMonth: () => void; onToday: () => void
}) {
  const today = new Date()
  const monthNames = ["janeiro", "fevereiro", "marco", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"]
  const dayNames = ["dom.", "seg.", "ter.", "qua.", "qui.", "sex.", "sab."]

  const year = currentDate.getFullYear()
  const month = currentDate.getMonth()
  const firstDay = new Date(year, month, 1)
  const lastDay = new Date(year, month + 1, 0)
  const daysInMonth = lastDay.getDate()
  const startingDay = firstDay.getDay()

  const days: (number | null)[] = []
  for (let i = 0; i < startingDay; i++) {
    const prevMonthLastDay = new Date(year, month, 0).getDate()
    days.push(prevMonthLastDay - startingDay + i + 1)
  }
  for (let i = 1; i <= daysInMonth; i++) days.push(i)

  const isToday = (day: number | null, index: number) => {
    if (day === null || index < startingDay) return false
    return day === today.getDate() && month === today.getMonth() && year === today.getFullYear()
  }

  const isCurrentMonth = (index: number) => index >= startingDay && index < startingDay + daysInMonth

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-medium">{monthNames[month]} de {year}</h3>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={onPreviousMonth}><ChevronLeft className="h-4 w-4" /></Button>
          <Button variant="ghost" size="sm" onClick={onToday}>Hoje</Button>
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={onNextMonth}><ChevronRight className="h-4 w-4" /></Button>
        </div>
      </div>
      <div className="rounded-lg border">
        <div className="grid grid-cols-7 border-b">
          {dayNames.map((day) => (
            <div key={day} className="border-r p-2 text-center text-sm text-muted-foreground last:border-r-0">{day}</div>
          ))}
        </div>
        <div className="grid grid-cols-7">
          {days.map((day, index) => (
            <div key={index} className={cn("min-h-24 border-b border-r p-2 last:border-r-0 [&:nth-child(7n)]:border-r-0", !isCurrentMonth(index) && "bg-muted/30")}>
              <div className="flex justify-end">
                {isToday(day, index) ? (
                  <span className="flex h-7 w-7 items-center justify-center rounded-full bg-rose-500 text-sm font-medium text-white">{day}</span>
                ) : (
                  <span className={cn("text-sm", isCurrentMonth(index) ? "text-foreground" : "text-muted-foreground")}>{day}</span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

function PostVolumeView({ items }: { items: KanbanItem[] }) {
  const maxVolume = 4
  const volumeData = useMemo(() => {
    const days = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sab"]
    return days.map((day) => ({
      day,
      count: items.length > 0 ? Math.floor(Math.random() * (maxVolume + 1)) : 0,
    }))
  }, [items])

  return (
    <div className="space-y-4">
      <div className="rounded-lg border bg-card p-6">
        <div className="flex">
          <div className="flex flex-col justify-between pr-4 text-right text-sm text-muted-foreground">
            {[4, 3, 2, 1, 0].map((n) => (<span key={n} className="h-12 leading-none">{n}</span>))}
          </div>
          <div className="relative flex-1">
            {[0, 1, 2, 3, 4].map((n) => (
              <div key={n} className="absolute left-0 right-0 border-t border-dashed border-border" style={{ top: `${n * 25}%` }} />
            ))}
            <div className="relative flex h-48 items-end justify-around">
              {volumeData.map((data, index) => (
                <div key={index} className="flex flex-col items-center gap-2">
                  <div className="w-8 rounded-t bg-primary/20 transition-all hover:bg-primary/40" style={{ height: `${(data.count / maxVolume) * 100}%`, minHeight: "4px" }} />
                </div>
              ))}
            </div>
            <div className="mt-4 flex justify-around text-sm text-muted-foreground">
              {volumeData.map((data, index) => (<span key={index}>{data.day}</span>))}
            </div>
          </div>
        </div>
        <div className="mt-6 flex items-center justify-center gap-8 border-t pt-4">
          <div className="text-center"><p className="text-2xl font-bold">{items.length}</p><p className="text-sm text-muted-foreground">Total de Posts</p></div>
          <div className="text-center"><p className="text-2xl font-bold">{items.filter((i) => i.status === "agendado").length}</p><p className="text-sm text-muted-foreground">Agendados</p></div>
          <div className="text-center"><p className="text-2xl font-bold">{items.filter((i) => i.status === "ideia").length}</p><p className="text-sm text-muted-foreground">Ideias</p></div>
        </div>
      </div>
    </div>
  )
}
