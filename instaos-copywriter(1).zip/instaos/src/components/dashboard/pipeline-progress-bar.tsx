import { useEffect, useRef } from "react"
import { CheckCircle2, Circle, Loader2, XCircle, ChevronRight } from "lucide-react"
import { cn } from "@/lib/utils"

// ── Types ──────────────────────────────────────────────────────────────────
export type StepStatus = "idle" | "active" | "done" | "error" | "skipped"

export interface PipelineStep {
  id: string
  label: string
  sublabel?: string
  status: StepStatus
  detail?: string     // e.g. "12 reels coletados"
  duration?: number   // ms
}

interface PipelineProgressBarProps {
  steps: PipelineStep[]
  logs?: string[]
  isRunning?: boolean
  className?: string
  compact?: boolean   // horizontal mode (for topbar)
}

// ── Step Icon ──────────────────────────────────────────────────────────────
function StepIcon({ status, size = 20 }: { status: StepStatus; size?: number }) {
  const s = `w-${size === 20 ? 5 : 4} h-${size === 20 ? 5 : 4}`
  if (status === "done") return <CheckCircle2 className={cn(s, "text-green-400")} />
  if (status === "active") return <Loader2 className={cn(s, "text-yellow-400 animate-spin")} />
  if (status === "error") return <XCircle className={cn(s, "text-red-400")} />
  if (status === "skipped") return <Circle className={cn(s, "text-muted-foreground/40")} />
  return <Circle className={cn(s, "text-muted-foreground/50")} />
}

// ── Horizontal compact bar (for top of dashboard) ─────────────────────────
export function PipelineProgressBar({ steps, isRunning, className, compact }: PipelineProgressBarProps) {
  if (compact) {
    const active = steps.find(s => s.status === "active")
    const doneCount = steps.filter(s => s.status === "done").length
    const pct = steps.length ? Math.round((doneCount / steps.length) * 100) : 0

    return (
      <div className={cn("flex items-center gap-3", className)}>
        <div className="flex items-center gap-1">
          {steps.map((step, i) => (
            <div key={step.id} className="flex items-center gap-1">
              <div className={cn(
                "w-2 h-2 rounded-full transition-all",
                step.status === "done" ? "bg-green-400" :
                step.status === "active" ? "bg-yellow-400 animate-pulse" :
                step.status === "error" ? "bg-red-400" : "bg-muted-foreground/25"
              )} title={step.label} />
              {i < steps.length - 1 && (
                <div className={cn("w-3 h-px", step.status === "done" ? "bg-green-400/40" : "bg-muted-foreground/15")} />
              )}
            </div>
          ))}
        </div>
        <div className="flex-1 h-1 rounded-full bg-muted/30 overflow-hidden min-w-[80px]">
          <div
            className="h-full bg-yellow-400 rounded-full transition-all duration-500"
            style={{ width: `${pct}%` }}
          />
        </div>
        <span className="text-xs text-muted-foreground tabular-nums">{pct}%</span>
        {active && (
          <span className="text-xs text-yellow-400 truncate max-w-[120px]">{active.label}</span>
        )}
      </div>
    )
  }

  // ── Full vertical view ──────────────────────────────────────────────────
  return (
    <div className={cn("w-full", className)}>
      <div className="flex flex-col gap-0">
        {steps.map((step, i) => {
          const isLast = i === steps.length - 1
          const lineColor =
            step.status === "done" ? "bg-green-400/40" :
            step.status === "active" ? "bg-yellow-400/20" :
            "bg-border/40"

          return (
            <div key={step.id} className="flex gap-3">
              {/* Left: icon + connector */}
              <div className="flex flex-col items-center">
                <div className={cn(
                  "flex items-center justify-center w-8 h-8 rounded-full border transition-all",
                  step.status === "done" ? "border-green-500/40 bg-green-500/10" :
                  step.status === "active" ? "border-yellow-500/60 bg-yellow-500/10 shadow-sm shadow-yellow-500/20" :
                  step.status === "error" ? "border-red-500/40 bg-red-500/10" :
                  "border-border bg-muted/20"
                )}>
                  <StepIcon status={step.status} />
                </div>
                {!isLast && (
                  <div className={cn("w-px flex-1 my-1 min-h-[16px]", lineColor)} />
                )}
              </div>

              {/* Right: content */}
              <div className={cn("pb-3 pt-1.5 flex-1 min-w-0", isLast && "pb-0")}>
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <span className={cn(
                      "text-sm font-medium",
                      step.status === "active" ? "text-yellow-400" :
                      step.status === "done" ? "text-foreground" :
                      step.status === "error" ? "text-red-400" :
                      "text-muted-foreground"
                    )}>
                      {step.label}
                    </span>
                    {step.sublabel && (
                      <span className="text-xs text-muted-foreground ml-1.5">{step.sublabel}</span>
                    )}
                    {step.detail && (
                      <p className="text-xs text-muted-foreground mt-0.5">{step.detail}</p>
                    )}
                  </div>
                  {step.duration && step.status === "done" && (
                    <span className="text-[10px] font-mono text-muted-foreground/60 flex-shrink-0">
                      {step.duration < 1000 ? `${step.duration}ms` : `${(step.duration / 1000).toFixed(1)}s`}
                    </span>
                  )}
                </div>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

// ── Log terminal ───────────────────────────────────────────────────────────
interface PipelineLogTerminalProps {
  logs: string[]
  isRunning?: boolean
  maxHeight?: string
}

export function PipelineLogTerminal({ logs, isRunning, maxHeight = "160px" }: PipelineLogTerminalProps) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (ref.current) ref.current.scrollTop = ref.current.scrollHeight
  }, [logs])

  function logColor(line: string): string {
    if (line.includes("✅") || line.includes("concluído") || line.includes("sucesso")) return "text-green-400"
    if (line.includes("⚠️") || line.includes("warn")) return "text-yellow-400"
    if (line.includes("❌") || line.includes("Erro") || line.includes("erro")) return "text-red-400"
    if (line.includes("🚀") || line.includes("Iniciando") || line.includes("===")) return "text-blue-400"
    if (line.includes("📊") || line.includes("📡") || line.includes("🤖")) return "text-purple-400"
    return "text-muted-foreground"
  }

  return (
    <div
      ref={ref}
      className="rounded-lg border border-border bg-black/30 p-3 font-mono text-[11px] leading-relaxed overflow-y-auto"
      style={{ maxHeight }}
    >
      {logs.length === 0 ? (
        <span className="text-muted-foreground/50">Aguardando logs...</span>
      ) : (
        logs.map((line, i) => {
          const ts = line.match(/^\[(\d{2}:\d{2}:\d{2})\]/)
          const msg = ts ? line.slice(ts[0].length).trim() : line
          return (
            <div key={i} className="flex gap-2">
              {ts && <span className="text-muted-foreground/40 flex-shrink-0">{ts[1]}</span>}
              <span className={logColor(line)}>{msg}</span>
            </div>
          )
        })
      )}
      {isRunning && (
        <div className="flex gap-1 mt-1">
          <span className="text-yellow-400 animate-pulse">▌</span>
        </div>
      )}
    </div>
  )
}

// ── Hook: parse logs into pipeline steps ───────────────────────────────────
export function usePipelineStepsFromLogs(logs: string[], isRunning: boolean): PipelineStep[] {
  const STEP_PATTERNS: Array<{ pattern: RegExp; id: string; label: string; sublabel?: string }> = [
    { pattern: /scrape|coletando|Coletando|apify|Apify/i, id: "scrape", label: "Coleta de Posts", sublabel: "Apify" },
    { pattern: /analis|classificando|Analisando|Classificando/i, id: "analyze", label: "Análise Viral IA", sublabel: "Claude" },
    { pattern: /hook|gancho|viral/i, id: "hook", label: "Score de Gancho" },
    { pattern: /gerar|geran|gerando|Gerando|Gerand/i, id: "generate", label: "Geração de Conteúdo" },
    { pattern: /fila|queue|aprovação/i, id: "queue", label: "Fila de Aprovação" },
  ]

  const touched = new Set<string>()
  const finished = new Set<string>()
  const errors = new Set<string>()

  for (const line of logs) {
    for (const { pattern, id } of STEP_PATTERNS) {
      if (pattern.test(line)) {
        touched.add(id)
        if (line.includes("✅") || line.includes("concluído")) finished.add(id)
        if (line.includes("❌") || line.includes("Erro")) errors.add(id)
      }
    }
  }

  const lastTouched = [...touched].filter(id => !finished.has(id) && !errors.has(id)).slice(-1)[0]

  return STEP_PATTERNS.map(({ id, label, sublabel }) => {
    let status: StepStatus = "idle"
    if (finished.has(id)) status = "done"
    else if (errors.has(id)) status = "error"
    else if (isRunning && id === lastTouched) status = "active"
    else if (touched.has(id)) status = "done"
    return { id, label, sublabel, status }
  })
}
