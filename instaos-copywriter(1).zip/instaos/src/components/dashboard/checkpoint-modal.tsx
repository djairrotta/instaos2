import { useState, useEffect, useCallback } from "react"
import { supabase } from "@/integrations/supabase/client"
import { toast } from "sonner"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import { CheckCircle2, XCircle, MessageSquare, Loader2, AlertCircle, Layers } from "lucide-react"

interface Checkpoint {
  id: string
  run_id: string
  step_id: string
  step_label: string
  checkpoint_type: "approve" | "select" | "skip"
  output_preview: any
  options: any[] | null
  status: string
  feedback_cycle: number
  max_feedback_cycles: number
  created_at: string
}

interface CheckpointModalProps {
  open: boolean
  onOpenChange: (v: boolean) => void
  pendingCount: number
  onResolved?: () => void
}

export function CheckpointModal({ open, onOpenChange, pendingCount, onResolved }: CheckpointModalProps) {
  const [checkpoints, setCheckpoints] = useState<Checkpoint[]>([])
  const [loading, setLoading] = useState(true)
  const [current, setCurrent] = useState<Checkpoint | null>(null)
  const [feedback, setFeedback] = useState("")
  const [mode, setMode] = useState<"view" | "feedback">("view")
  const [selectedItems, setSelectedItems] = useState<number[]>([])
  const [submitting, setSubmitting] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    const { data } = await supabase
      .from("checkpoint_queue")
      .select("*")
      .eq("status", "pending")
      .order("created_at", { ascending: true })
      .limit(10)

    const items = (data || []) as Checkpoint[]
    setCheckpoints(items)
    if (items.length > 0 && !current) {
      setCurrent(items[0])
      setSelectedItems([])
      setFeedback("")
      setMode("view")
    }
    setLoading(false)
  }, [current])

  useEffect(() => { if (open) load() }, [open, load])

  async function resolve(action: "approve" | "reject" | "feedback", cp: Checkpoint) {
    setSubmitting(true)
    try {
      const update: any = { status: action === "feedback" ? "feedback_given" : action === "approve" ? "approved" : "rejected" }
      if (action === "feedback") update.user_feedback = feedback.trim()
      if (action === "approve" && cp.checkpoint_type === "select") {
        update.options = { selected: selectedItems }
      }

      const { error } = await supabase
        .from("checkpoint_queue")
        .update({ ...update, approved_at: action === "approve" ? new Date().toISOString() : null })
        .eq("id", cp.id)

      if (error) throw error

      if (action === "approve") toast.success("Aprovado! Pipeline continua.")
      else if (action === "reject") toast("Rejeitado. Pipeline pausado.")
      else toast.success("Feedback enviado — agente vai refazer.")

      setFeedback("")
      setMode("view")
      setSelectedItems([])
      setCurrent(null)
      onResolved?.()
      load()
    } catch (e: any) { toast.error(e.message) }
    finally { setSubmitting(false) }
  }

  const preview = current?.output_preview
  const options = current?.options || []

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[85vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-base">
            <AlertCircle className="w-4 h-4 text-yellow-400" />
            Checkpoints do Pipeline
            {pendingCount > 0 && (
              <Badge variant="outline" className="text-yellow-400 border-yellow-500/30 text-xs ml-auto">
                {pendingCount} pendente{pendingCount > 1 ? "s" : ""}
              </Badge>
            )}
          </DialogTitle>
        </DialogHeader>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-5 h-5 animate-spin text-yellow-400" />
          </div>
        ) : checkpoints.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
            <CheckCircle2 className="w-10 h-10 opacity-20 mb-3" />
            <p className="text-sm">Nenhum checkpoint pendente</p>
            <p className="text-xs mt-1">O pipeline está rodando autonomamente</p>
          </div>
        ) : current ? (
          <div className="flex-1 overflow-y-auto space-y-4">
            {/* Step info */}
            <div className="flex items-center gap-2 flex-wrap">
              <Badge variant="outline" className="text-xs text-yellow-400 border-yellow-500/30">
                {current.checkpoint_type === "approve" ? "✅ Aprovar ou dar feedback" :
                 current.checkpoint_type === "select" ? "☑️ Selecionar itens" : "⏭️ Auto-avançar"}
              </Badge>
              <span className="text-xs text-muted-foreground">{current.step_label || current.step_id}</span>
              {current.feedback_cycle > 0 && (
                <span className="text-[10px] text-orange-400">
                  Ciclo de feedback {current.feedback_cycle}/{current.max_feedback_cycles}
                </span>
              )}
            </div>

            {/* Output preview */}
            {preview && (
              <div className="rounded-xl border border-border bg-muted/10 p-4">
                <p className="text-[9px] uppercase tracking-wider text-muted-foreground/40 mb-2">Output do Agente</p>
                {typeof preview === "string" ? (
                  <p className="text-xs text-foreground/80 whitespace-pre-wrap leading-relaxed">{preview.slice(0, 1000)}</p>
                ) : preview.slides ? (
                  <div className="grid grid-cols-3 gap-1.5">
                    {preview.slides.slice(0, 6).map((s: any, i: number) => (
                      <div key={i} className="rounded-lg bg-yellow-500/5 border border-yellow-500/15 p-2 text-[9px]">
                        <span className="text-yellow-400/60 font-mono">{i + 1}</span>
                        <p className="text-foreground/80 mt-0.5 line-clamp-3">{s.text || s.headline || ""}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <pre className="text-xs text-foreground/80 whitespace-pre-wrap overflow-auto max-h-48">
                    {JSON.stringify(preview, null, 2).slice(0, 800)}
                  </pre>
                )}
              </div>
            )}

            {/* SELECT mode: items to pick */}
            {current.checkpoint_type === "select" && options.length > 0 && (
              <div>
                <p className="text-xs text-muted-foreground mb-2">
                  Selecione os itens que quer usar (pode escolher múltiplos):
                </p>
                <div className="space-y-1.5">
                  {options.map((item: any, i: number) => (
                    <button key={i}
                      onClick={() => setSelectedItems(prev =>
                        prev.includes(i) ? prev.filter(x => x !== i) : [...prev, i]
                      )}
                      className={cn(
                        "w-full text-left rounded-lg border p-3 text-xs transition-all",
                        selectedItems.includes(i)
                          ? "border-yellow-500/50 bg-yellow-500/10 text-foreground"
                          : "border-border bg-card text-muted-foreground hover:border-yellow-500/20"
                      )}>
                      <div className="flex items-start gap-2">
                        <div className={cn(
                          "w-4 h-4 rounded border flex items-center justify-center flex-shrink-0 mt-0.5",
                          selectedItems.includes(i) ? "border-yellow-400 bg-yellow-400" : "border-muted-foreground/40"
                        )}>
                          {selectedItems.includes(i) && <span className="text-black text-[8px] font-bold">✓</span>}
                        </div>
                        {typeof item === "string" ? item : (item.title || item.name || JSON.stringify(item).slice(0, 80))}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Feedback input */}
            {mode === "feedback" && (
              <div>
                <p className="text-xs text-muted-foreground mb-1.5">
                  Descreva o que deve ser melhorado (ciclo {current.feedback_cycle + 1}/{current.max_feedback_cycles}):
                </p>
                <Textarea
                  value={feedback}
                  onChange={e => setFeedback(e.target.value)}
                  placeholder="Ex: o gancho está muito genérico, precisa mencionar juros abusivos especificamente..."
                  rows={3}
                  className="text-xs"
                  autoFocus
                />
              </div>
            )}

            {/* Actions */}
            <div className="flex gap-2 pt-1">
              {mode === "view" ? (
                <>
                  <Button onClick={() => resolve("approve", current)} disabled={submitting || (current.checkpoint_type === "select" && selectedItems.length === 0)}
                    className="flex-1 gap-1.5 text-xs bg-green-600 hover:bg-green-500 text-white font-semibold h-9">
                    {submitting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
                    {current.checkpoint_type === "select"
                      ? `Usar ${selectedItems.length} selecionado${selectedItems.length !== 1 ? "s" : ""}`
                      : "Aprovar — continuar"}
                  </Button>
                  {current.feedback_cycle < current.max_feedback_cycles && (
                    <Button onClick={() => setMode("feedback")} variant="outline" size="sm"
                      className="gap-1 text-xs h-9 border-yellow-500/30 text-yellow-400 hover:bg-yellow-500/10">
                      <MessageSquare className="w-3.5 h-3.5" />
                      Feedback
                    </Button>
                  )}
                  <Button onClick={() => resolve("reject", current)} disabled={submitting} variant="outline" size="sm"
                    className="h-9 px-3 border-red-500/30 text-red-400 hover:bg-red-500/10">
                    <XCircle className="w-3.5 h-3.5" />
                  </Button>
                </>
              ) : (
                <>
                  <Button onClick={() => resolve("feedback", current)} disabled={submitting || !feedback.trim()}
                    className="flex-1 gap-1.5 text-xs bg-yellow-500 hover:bg-yellow-400 text-black font-semibold h-9">
                    {submitting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <MessageSquare className="w-3.5 h-3.5" />}
                    Enviar Feedback
                  </Button>
                  <Button onClick={() => setMode("view")} variant="outline" size="sm" className="text-xs h-9">
                    Cancelar
                  </Button>
                </>
              )}
            </div>

            {/* Other pending */}
            {checkpoints.length > 1 && (
              <div>
                <p className="text-[10px] text-muted-foreground mb-1.5">Outros checkpoints pendentes:</p>
                <div className="flex gap-1.5 flex-wrap">
                  {checkpoints.filter(c => c.id !== current.id).map(c => (
                    <button key={c.id} onClick={() => { setCurrent(c); setMode("view"); setSelectedItems([]); setFeedback("") }}
                      className="text-[10px] px-2 py-1 rounded border border-border hover:border-yellow-500/30 text-muted-foreground hover:text-foreground transition-colors">
                      {c.step_label || c.step_id}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        ) : null}
      </DialogContent>
    </Dialog>
  )
}

// ── Small badge showing count, used in sidebar/topbar ──────────────────────
export function CheckpointBadge({ onClick }: { onClick: () => void }) {
  const [count, setCount] = useState(0)

  useEffect(() => {
    async function load() {
      const { count: c } = await supabase
        .from("checkpoint_queue")
        .select("id", { count: "exact", head: true })
        .eq("status", "pending")
      setCount(c || 0)
    }
    load()
    const ch = supabase.channel("checkpoints")
      .on("postgres_changes", { event: "*", schema: "public", table: "checkpoint_queue" }, load)
      .subscribe()
    return () => { supabase.removeChannel(ch) }
  }, [])

  if (count === 0) return null
  return (
    <button onClick={onClick}
      className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-yellow-500/15 border border-yellow-500/30 text-yellow-400 text-xs font-semibold hover:bg-yellow-500/25 transition-colors">
      <AlertCircle className="w-3 h-3" />
      {count} checkpoint{count > 1 ? "s" : ""}
    </button>
  )
}
