import { useState } from "react"
import { X, Minus, Maximize2, Minimize2 } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"

interface WorkflowFlowModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

const STEPS = [
  {
    id: 1,
    emoji: "🔗",
    title: "Inserção de URLs",
    subtitle: "Cadastro de Competidores",
    description:
      "O usuário insere as URLs dos perfis de competidores no Instagram. O sistema armazena na tabela `competidores` e marca como ativos para monitoramento contínuo.",
    color: "from-blue-500/20 to-blue-600/20",
    border: "border-blue-500/40",
    badge: "Input",
  },
  {
    id: 2,
    emoji: "📩",
    title: "Captação via DM",
    subtitle: "Recebimento de Links por Instagram DM",
    description:
      "Usuários autorizados enviam links de Reels/Posts via DM do Instagram. O sistema faz polling periódico (poll-instagram-dms), valida o remetente na lista de permitidos e processa o conteúdo automaticamente.",
    color: "from-purple-500/20 to-purple-600/20",
    border: "border-purple-500/40",
    badge: "Input",
  },
  {
    id: 3,
    emoji: "🕷️",
    title: "Raspagem com Apify",
    subtitle: "Scraping de Reels, Posts e Carrosséis",
    description:
      "O Apify coleta os dados públicos dos perfis: Reels, Posts e Carrosséis com métricas (views, likes, comments, eng_rate), captions, thumbnails e URLs de vídeo/imagem. Os dados são salvos em `meus_reels` e `reels_competidores`.",
    color: "from-orange-500/20 to-orange-600/20",
    border: "border-orange-500/40",
    badge: "Scraping",
  },
  {
    id: 4,
    emoji: "🤖",
    title: "Análise Multimodal com IA",
    subtitle: "Gemini (Vídeo + Imagem) + Análise de Hook",
    description:
      "Cada conteúdo é analisado pela IA em múltiplas camadas: análise de vídeo (transcrição + visual), análise de imagem (texto + design), análise de hook (gancho dos primeiros 3 segundos), e análise viral (pontos fortes + gatilhos psicológicos).",
    color: "from-emerald-500/20 to-emerald-600/20",
    border: "border-emerald-500/40",
    badge: "IA",
  },
  {
    id: 5,
    emoji: "📊",
    title: "Relatório Estratégico",
    subtitle: "Estrategista de Conteúdo (Agente IA)",
    description:
      "O agente Estrategista consolida todos os dados analisados e gera um relatório semanal com: Top 5 vídeos dos competidores, padrões vencedores replicáveis, 10 ideias de hooks e um takeaway estratégico com próximos passos.",
    color: "from-cyan-500/20 to-cyan-600/20",
    border: "border-cyan-500/40",
    badge: "Estratégia",
  },
  {
    id: 6,
    emoji: "✍️",
    title: "Criação de Roteiro",
    subtitle: "Roteirista + Copywriter (Agentes IA)",
    description:
      "Com base na estratégia e nos padrões vencedores, os agentes Roteirista e Copywriter geram roteiros completos com hooks testados, estrutura de conteúdo e CTAs otimizados para o formato escolhido (Reel, Post, Carrossel, Story).",
    color: "from-yellow-500/20 to-yellow-600/20",
    border: "border-yellow-500/40",
    badge: "Criação",
  },
  {
    id: 7,
    emoji: "💡",
    title: "Sugestão de Ideias",
    subtitle: "Gerador de Ideias (Agente IA)",
    description:
      "O agente Gerador de Ideias cruza dados dos competidores, tendências de mercado e os hooks mais eficazes para sugerir ideias de conteúdo com alto potencial de viralização, adaptadas ao nicho e voz do usuário.",
    color: "from-pink-500/20 to-pink-600/20",
    border: "border-pink-500/40",
    badge: "Ideação",
  },
  {
    id: 8,
    emoji: "🎬",
    title: "Criação de Conteúdo",
    subtitle: "Criador de Reel + Imagem + Voz + Animação",
    description:
      "Os agentes especializados geram o conteúdo final: Criador de Reel (vídeo vertical otimizado), Criador de Imagem (posts e thumbnails), Agente de Voz (narração) e Agente de Animação (face swap, body tracking, estilos visuais).",
    color: "from-indigo-500/20 to-indigo-600/20",
    border: "border-indigo-500/40",
    badge: "Produção",
  },
  {
    id: 9,
    emoji: "📤",
    title: "Publicação",
    subtitle: "Fila de Publicação + Agendamento",
    description:
      "O conteúdo gerado vai para a Fila de Publicação, onde pode ser aprovado, editado ou agendado. A publicação no Instagram é feita via API Graph, com suporte a Reels, Posts e Carrosséis, incluindo notificações via WhatsApp.",
    color: "from-green-500/20 to-green-600/20",
    border: "border-green-500/40",
    badge: "Output",
  },
]

export function WorkflowFlowModal({ open, onOpenChange }: WorkflowFlowModalProps) {
  const [minimized, setMinimized] = useState(false)
  const [maximized, setMaximized] = useState(false)

  if (!open) return null

  if (minimized) {
    return (
      <div className="fixed bottom-4 right-4 z-50">
        <Button
          onClick={() => setMinimized(false)}
          className="gap-2 shadow-lg bg-primary text-primary-foreground hover:bg-primary/90"
        >
          <span>🔄</span> Fluxo do Sistema
          <Maximize2 className="h-3.5 w-3.5" />
        </Button>
      </div>
    )
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => onOpenChange(false)} />

      {/* Modal */}
      <div
        className={cn(
          "relative z-10 flex flex-col rounded-xl border border-border bg-background shadow-2xl transition-all duration-300",
          maximized ? "h-[95vh] w-[95vw]" : "h-[85vh] w-[90vw] max-w-4xl"
        )}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-border px-6 py-4">
          <div className="flex items-center gap-3">
            <span className="text-2xl">🔄</span>
            <div>
              <h2 className="text-lg font-bold">Fluxo do Sistema IG OS v3</h2>
              <p className="text-xs text-muted-foreground">Pipeline completo: da captação à publicação</p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setMinimized(true)} title="Minimizar">
              <Minus className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setMaximized(!maximized)} title={maximized ? "Restaurar" : "Maximizar"}>
              {maximized ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onOpenChange(false)} title="Fechar">
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Content */}
        <ScrollArea className="flex-1">
          <div className="p-6 space-y-0">
            {STEPS.map((step, idx) => (
              <div key={step.id} className="relative">
                {/* Connector line */}
                {idx < STEPS.length - 1 && (
                  <div className="absolute left-7 top-[calc(100%-0.5rem)] h-8 w-0.5 bg-gradient-to-b from-muted-foreground/30 to-muted-foreground/10 z-0" />
                )}

                {/* Step card */}
                <div
                  className={cn(
                    "relative z-10 flex gap-4 rounded-lg border p-4 transition-colors hover:bg-accent/30",
                    step.border,
                    "bg-gradient-to-r",
                    step.color
                  )}
                >
                  {/* Step number */}
                  <div className="flex flex-col items-center gap-1 shrink-0">
                    <div className="flex h-14 w-14 items-center justify-center rounded-full bg-background border-2 border-border text-2xl shadow-sm">
                      {step.emoji}
                    </div>
                    <span className="text-[10px] font-bold text-muted-foreground">ETAPA {step.id}</span>
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold text-base">{step.title}</h3>
                      <Badge variant="outline" className="text-[10px] px-1.5 py-0">
                        {step.badge}
                      </Badge>
                    </div>
                    <p className="text-sm font-medium text-muted-foreground mb-2">{step.subtitle}</p>
                    <p className="text-sm text-foreground/80 leading-relaxed">{step.description}</p>
                  </div>
                </div>

                {/* Arrow between steps */}
                {idx < STEPS.length - 1 && (
                  <div className="flex justify-center py-2">
                    <span className="text-muted-foreground/50 text-lg">▼</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </ScrollArea>

        {/* Footer */}
        <div className="border-t border-border px-6 py-3 flex items-center justify-between">
          <p className="text-xs text-muted-foreground">
            {STEPS.length} etapas • Pipeline automatizado via Edge Functions + Agentes IA
          </p>
          <Button variant="outline" size="sm" onClick={() => onOpenChange(false)}>
            Fechar
          </Button>
        </div>
      </div>
    </div>
  )
}
