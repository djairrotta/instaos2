import { useState, useEffect, useCallback, useRef } from "react"
import { supabase } from "@/integrations/supabase/client"
import ReactMarkdown from "react-markdown"
import { MarkdownWithImages, extractImageSources } from "./markdown-with-images"
import JSZip from "jszip"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import {
  Database, Search, Plus, Link, List, Type,
  Filter, ArrowUpDown, Sparkles, Maximize2, Minimize2, Download, X,
  Trash2, Edit2, Check, XCircle, RefreshCw, Users, Eye, Heart, MessageCircle,
  BarChart3, Calendar, FileText, ImageIcon, HelpCircle, LayoutGrid, Share, Copy,
  GripHorizontal,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { toast } from "sonner"
import jsPDF from "jspdf"
import autoTable from "jspdf-autotable"

type DatabaseType = "competidores" | "meus-reels" | "reels-competidores" | "estrategia" | "conteudo"

interface DatabaseModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  databaseType: DatabaseType | null
  onCopyReelWithAI?: (data: { hookAnalysis: string; transcript: string; caption?: string; viralPoints?: string; psychTriggers?: string; relevanceReason?: string; ownerUsername?: string; contentType?: string; url?: string }, generationType?: string) => void
}

const dbTitles: Record<DatabaseType, string> = {
  competidores: "Lista de Competidores",
  "meus-reels": "Meus Reels",
  "reels-competidores": "Reels dos Competidores",
  estrategia: "Estratégia de Conteúdo",
  conteudo: "Database de Conteúdo",
}

// ============ PDF Export Utility ============
function exportTableToPdf(title: string, headers: string[], rows: string[][]) {
  const doc = new jsPDF({ orientation: rows[0]?.length > 5 ? "landscape" : "portrait" })
  doc.setFontSize(16)
  doc.text(title, 14, 18)
  doc.setFontSize(9)
  doc.text(`Exportado em ${new Date().toLocaleString("pt-BR")}`, 14, 25)
  autoTable(doc, {
    startY: 30,
    head: [headers],
    body: rows,
    styles: { fontSize: 8, cellPadding: 2 },
    headStyles: { fillColor: [45, 45, 45] },
  })
  doc.save(`${title.replace(/\s+/g, "_").toLowerCase()}_${new Date().toISOString().slice(0, 10)}.pdf`)
  toast.success("PDF exportado!")
}

// ============ Draggable Hook ============
function useDraggable() {
  const [pos, setPos] = useState({ x: 0, y: 0 })
  const [dragging, setDragging] = useState(false)
  const startRef = useRef({ x: 0, y: 0, px: 0, py: 0 })

  const onMouseDown = useCallback((e: React.MouseEvent) => {
    setDragging(true)
    startRef.current = { x: e.clientX, y: e.clientY, px: pos.x, py: pos.y }
    e.preventDefault()
  }, [pos])

  useEffect(() => {
    if (!dragging) return
    const onMove = (e: MouseEvent) => {
      setPos({
        x: startRef.current.px + (e.clientX - startRef.current.x),
        y: startRef.current.py + (e.clientY - startRef.current.y),
      })
    }
    const onUp = () => setDragging(false)
    window.addEventListener("mousemove", onMove)
    window.addEventListener("mouseup", onUp)
    return () => { window.removeEventListener("mousemove", onMove); window.removeEventListener("mouseup", onUp) }
  }, [dragging])

  const reset = useCallback(() => setPos({ x: 0, y: 0 }), [])

  return { pos, onMouseDown, dragging, reset }
}

// ============ Competidores CRUD Component ============
function CompetidoresTable({ searchQuery, onExportPdf }: { searchQuery: string; onExportPdf: (fn: () => void) => void }) {
  const [rows, setRows] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editValues, setEditValues] = useState<any>({})
  const [addingNew, setAddingNew] = useState(false)
  const [newRow, setNewRow] = useState({ name: "", page_url: "", niche: "" })

  const loadData = useCallback(async () => {
    setLoading(true)
    const { data } = await supabase.from("competidores").select("*").order("created_at", { ascending: false })
    setRows(data || [])
    setLoading(false)
  }, [])

  useEffect(() => { loadData() }, [loadData])

  const filtered = rows.filter(r =>
    !searchQuery || r.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    r.niche?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    r.page_url?.toLowerCase().includes(searchQuery.toLowerCase())
  )

  useEffect(() => {
    onExportPdf(() => {
      exportTableToPdf("Lista de Competidores",
        ["Nome", "URL", "Nicho", "Seguidores", "Posts"],
        filtered.map(r => [r.name, r.page_url, r.niche || "—", r.followers_count?.toLocaleString() || "—", r.posts_count?.toLocaleString() || "—"])
      )
    })
  }, [filtered, onExportPdf])

  const toggleSelect = (id: string) => {
    setSelected(prev => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n })
  }
  const toggleAll = () => {
    if (selected.size === filtered.length) setSelected(new Set())
    else setSelected(new Set(filtered.map(r => r.id)))
  }

  const handleDelete = async (ids: string[]) => {
    try {
      for (const id of ids) { const { error } = await supabase.from("competidores").delete().eq("id", id); if (error) throw error }
      toast.success(`${ids.length} competidor${ids.length > 1 ? "es" : ""} excluído${ids.length > 1 ? "s" : ""}`)
      setSelected(new Set()); loadData()
    } catch (e: any) { toast.error("Erro ao excluir", { description: e.message }) }
  }

  const handleSaveEdit = async () => {
    if (!editingId) return
    try {
      const { error } = await supabase.from("competidores").update({ name: editValues.name, page_url: editValues.page_url, niche: editValues.niche }).eq("id", editingId)
      if (error) throw error
      toast.success("Competidor atualizado"); setEditingId(null); loadData()
    } catch (e: any) { toast.error("Erro ao atualizar", { description: e.message }) }
  }

  const handleAdd = async () => {
    if (!newRow.name.trim()) { toast.warning("Nome é obrigatório"); return }
    const url = newRow.page_url.trim() || `https://www.instagram.com/${newRow.name.trim()}/`
    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) { toast.error("Faça login primeiro"); return }
      const { error } = await supabase.from("competidores").insert({ name: newRow.name.trim(), page_url: url, niche: newRow.niche.trim() || null, user_id: user.id, status: true })
      if (error) throw error
      toast.success(`@${newRow.name.trim()} adicionado`); setNewRow({ name: "", page_url: "", niche: "" }); setAddingNew(false); loadData()
    } catch (e: any) { toast.error("Erro ao adicionar", { description: e.message }) }
  }

  return (
    <div>
      {selected.size > 0 && (
        <div className="flex items-center gap-2 mb-3">
          <Badge variant="secondary">{selected.size} selecionado{selected.size > 1 ? "s" : ""}</Badge>
          <Button variant="destructive" size="sm" className="gap-1.5" onClick={() => handleDelete(Array.from(selected))}><Trash2 className="h-3.5 w-3.5" /> Excluir</Button>
        </div>
      )}
      <div className="border rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/30 hover:bg-muted/30">
                <TableHead className="w-10"><Checkbox checked={filtered.length > 0 && selected.size === filtered.length} onCheckedChange={toggleAll} /></TableHead>
                <TableHead className="min-w-[180px]"><div className="flex items-center gap-2"><Type className="h-4 w-4 text-muted-foreground/60" /> Nome</div></TableHead>
                <TableHead className="min-w-[220px]"><div className="flex items-center gap-2"><Link className="h-4 w-4 text-muted-foreground/60" /> URL</div></TableHead>
                <TableHead className="min-w-[130px]"><div className="flex items-center gap-2"><List className="h-4 w-4 text-muted-foreground/60" /> Nicho</div></TableHead>
                <TableHead className="min-w-[100px]"><div className="flex items-center gap-2"><Users className="h-4 w-4 text-muted-foreground/60" /> Seguidores</div></TableHead>
                <TableHead className="min-w-[80px]"><div className="flex items-center gap-2"><BarChart3 className="h-4 w-4 text-muted-foreground/60" /> Posts</div></TableHead>
                <TableHead className="w-[100px]">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow><TableCell colSpan={7} className="h-32 text-center"><RefreshCw className="h-5 w-5 animate-spin mx-auto text-muted-foreground" /></TableCell></TableRow>
              ) : filtered.length === 0 ? (
                <TableRow><TableCell colSpan={7} className="h-32 text-center text-muted-foreground"><div className="flex flex-col items-center gap-2"><HelpCircle className="h-5 w-5" /><span>Nenhum competidor encontrado</span></div></TableCell></TableRow>
              ) : filtered.map(row => (
                <TableRow key={row.id} className="group">
                  <TableCell><Checkbox checked={selected.has(row.id)} onCheckedChange={() => toggleSelect(row.id)} /></TableCell>
                  {editingId === row.id ? (
                    <>
                      <TableCell><Input value={editValues.name} onChange={e => setEditValues({ ...editValues, name: e.target.value })} className="h-7 text-sm" /></TableCell>
                      <TableCell><Input value={editValues.page_url} onChange={e => setEditValues({ ...editValues, page_url: e.target.value })} className="h-7 text-sm" /></TableCell>
                      <TableCell><Input value={editValues.niche || ""} onChange={e => setEditValues({ ...editValues, niche: e.target.value })} className="h-7 text-sm" /></TableCell>
                      <TableCell className="text-sm text-muted-foreground">{row.followers_count?.toLocaleString() || "—"}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">{row.posts_count?.toLocaleString() || "—"}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-primary" onClick={handleSaveEdit}><Check className="h-3.5 w-3.5" /></Button>
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => setEditingId(null)}><XCircle className="h-3.5 w-3.5" /></Button>
                        </div>
                      </TableCell>
                    </>
                  ) : (
                    <>
                      <TableCell className="font-medium text-sm">@{row.name}</TableCell>
                      <TableCell className="text-sm"><a href={row.page_url} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline truncate block max-w-[200px]">{row.page_url}</a></TableCell>
                      <TableCell className="text-sm">{row.niche || <span className="text-muted-foreground/50">—</span>}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">{row.followers_count?.toLocaleString() || "—"}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">{row.posts_count?.toLocaleString() || "—"}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => { setEditingId(row.id); setEditValues({ name: row.name, page_url: row.page_url, niche: row.niche }) }}><Edit2 className="h-3.5 w-3.5" /></Button>
                          <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => handleDelete([row.id])}><Trash2 className="h-3.5 w-3.5" /></Button>
                        </div>
                      </TableCell>
                    </>
                  )}
                </TableRow>
              ))}
              {addingNew && (
                <TableRow>
                  <TableCell />
                  <TableCell><Input placeholder="@username" value={newRow.name} onChange={e => setNewRow({ ...newRow, name: e.target.value })} className="h-7 text-sm" autoFocus /></TableCell>
                  <TableCell><Input placeholder="https://instagram.com/..." value={newRow.page_url} onChange={e => setNewRow({ ...newRow, page_url: e.target.value })} className="h-7 text-sm" /></TableCell>
                  <TableCell><Input placeholder="Nicho" value={newRow.niche} onChange={e => setNewRow({ ...newRow, niche: e.target.value })} className="h-7 text-sm" /></TableCell>
                  <TableCell /><TableCell />
                  <TableCell>
                    <div className="flex items-center gap-1">
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-primary" onClick={handleAdd}><Check className="h-3.5 w-3.5" /></Button>
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => setAddingNew(false)}><XCircle className="h-3.5 w-3.5" /></Button>
                    </div>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>
      {!addingNew && (
        <Button variant="ghost" className="mt-3 gap-2 text-muted-foreground hover:text-foreground" onClick={() => setAddingNew(true)}>
          <Plus className="h-4 w-4" /> Novo competidor
        </Button>
      )}
      <div className="mt-2 text-xs text-muted-foreground">{filtered.length} competidor{filtered.length !== 1 ? "es" : ""}</div>
    </div>
  )
}

// ============ Reels Table (meus-reels & reels-competidores) ============
function ReelsTable({ tableName, searchQuery, onCopyReelWithAI, onExportPdf }: { tableName: "meus_reels" | "reels_competidores"; searchQuery: string; onCopyReelWithAI?: (data: { hookAnalysis: string; transcript: string; caption?: string; ownerUsername?: string }, generationType?: string) => void; onExportPdf: (fn: () => void) => void }) {
  const [rows, setRows] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [expandedId, setExpandedId] = useState<string | null>(null)

  const loadData = useCallback(async () => {
    setLoading(true)
    const { data } = await supabase.from(tableName).select("*").order("created_at", { ascending: false }).limit(200)
    setRows(data || [])
    setLoading(false)
  }, [tableName])

  useEffect(() => { loadData() }, [loadData])

  const filtered = rows.filter(r =>
    !searchQuery ||
    r.caption?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    r.owner_username?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    r.hook_analysis?.toLowerCase().includes(searchQuery.toLowerCase())
  )

  useEffect(() => {
    onExportPdf(() => {
      const fmt = (n: number | null) => n == null ? "—" : n >= 1_000_000 ? (n / 1_000_000).toFixed(1) + "M" : n >= 1_000 ? (n / 1_000).toFixed(1) + "K" : String(n)
      exportTableToPdf(tableName === "meus_reels" ? "Meus Reels" : "Reels dos Competidores",
        ["User", "Caption", "Views", "Likes", "Comentários", "Eng%", "Tipo"],
        filtered.map(r => [r.owner_username || "—", (r.caption || "").slice(0, 80), fmt(r.views), fmt(r.likes), fmt(r.comments), r.eng_rate != null ? `${Number(r.eng_rate).toFixed(1)}%` : "—", r.content_type || "reel"])
      )
    })
  }, [filtered, onExportPdf, tableName])

  const toggleSelect = (id: string) => { setSelected(prev => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n }) }
  const toggleAll = () => { selected.size === filtered.length ? setSelected(new Set()) : setSelected(new Set(filtered.map(r => r.id))) }

  const handleDelete = async (ids: string[]) => {
    try {
      for (const id of ids) { const { error } = await supabase.from(tableName).delete().eq("id", id); if (error) throw error }
      toast.success(`${ids.length} reel${ids.length > 1 ? "s" : ""} excluído${ids.length > 1 ? "s" : ""}`); setSelected(new Set()); loadData()
    } catch (e: any) { toast.error("Erro ao excluir", { description: e.message }) }
  }

  const fmt = (n: number | null) => { if (n == null) return "—"; if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + "M"; if (n >= 1_000) return (n / 1_000).toFixed(1) + "K"; return n.toLocaleString() }

  return (
    <div>
      {selected.size > 0 && (
        <div className="flex items-center gap-2 mb-3">
          <Badge variant="secondary">{selected.size} selecionado{selected.size > 1 ? "s" : ""}</Badge>
          <Button variant="destructive" size="sm" className="gap-1.5" onClick={() => handleDelete(Array.from(selected))}><Trash2 className="h-3.5 w-3.5" /> Excluir</Button>
        </div>
      )}
      <div className="border rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/30 hover:bg-muted/30">
                <TableHead className="w-10"><Checkbox checked={filtered.length > 0 && selected.size === filtered.length} onCheckedChange={toggleAll} /></TableHead>
                <TableHead className="min-w-[60px]"><div className="flex items-center gap-2"><ImageIcon className="h-4 w-4 text-muted-foreground/60" /> Thumb</div></TableHead>
                <TableHead className="min-w-[180px]"><div className="flex items-center gap-2"><Type className="h-4 w-4 text-muted-foreground/60" /> Caption</div></TableHead>
                <TableHead className="min-w-[100px]"><div className="flex items-center gap-2"><Users className="h-4 w-4 text-muted-foreground/60" /> User</div></TableHead>
                <TableHead className="min-w-[80px]"><div className="flex items-center gap-2"><Eye className="h-4 w-4 text-muted-foreground/60" /> Views</div></TableHead>
                <TableHead className="min-w-[80px]"><div className="flex items-center gap-2"><Heart className="h-4 w-4 text-muted-foreground/60" /> Likes</div></TableHead>
                <TableHead className="min-w-[80px]"><div className="flex items-center gap-2"><MessageCircle className="h-4 w-4 text-muted-foreground/60" /> Coment.</div></TableHead>
                <TableHead className="min-w-[80px]"><div className="flex items-center gap-2"><BarChart3 className="h-4 w-4 text-muted-foreground/60" /> Eng%</div></TableHead>
                <TableHead className="min-w-[80px]"><div className="flex items-center gap-2"><List className="h-4 w-4 text-muted-foreground/60" /> Tipo</div></TableHead>
                <TableHead className="w-[100px]">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow><TableCell colSpan={10} className="h-32 text-center"><RefreshCw className="h-5 w-5 animate-spin mx-auto text-muted-foreground" /></TableCell></TableRow>
              ) : filtered.length === 0 ? (
                <TableRow><TableCell colSpan={10} className="h-32 text-center text-muted-foreground"><div className="flex flex-col items-center gap-2"><HelpCircle className="h-5 w-5" /><span>Nenhum reel encontrado</span></div></TableCell></TableRow>
              ) : filtered.map(row => (
                <TableRow key={row.id} className="group cursor-pointer" onClick={() => setExpandedId(expandedId === row.id ? null : row.id)}>
                  <TableCell onClick={e => e.stopPropagation()}><Checkbox checked={selected.has(row.id)} onCheckedChange={() => toggleSelect(row.id)} /></TableCell>
                  <TableCell>
                    {row.thumbnail_url ? <img src={row.thumbnail_url} alt="" className="h-10 w-10 rounded object-cover" /> : <div className="h-10 w-10 rounded bg-muted flex items-center justify-center"><ImageIcon className="h-4 w-4 text-muted-foreground" /></div>}
                  </TableCell>
                  <TableCell className="text-sm max-w-[200px] truncate">{row.caption?.slice(0, 60) || "—"}</TableCell>
                  <TableCell className="text-sm font-medium">@{row.owner_username || "—"}</TableCell>
                  <TableCell className="text-sm">{fmt(row.views)}</TableCell>
                  <TableCell className="text-sm">{fmt(row.likes)}</TableCell>
                  <TableCell className="text-sm">{fmt(row.comments)}</TableCell>
                  <TableCell className="text-sm">{row.eng_rate != null ? `${Number(row.eng_rate).toFixed(1)}%` : "—"}</TableCell>
                  <TableCell><Badge variant="outline" className="text-xs">{row.content_type || "reel"}</Badge></TableCell>
                  <TableCell onClick={e => e.stopPropagation()}>
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      {onCopyReelWithAI && row.hook_analysis && (
                        <Button variant="ghost" size="icon" className="h-7 w-7 text-primary" title="Copiar Reel com IA" onClick={() => onCopyReelWithAI({ hookAnalysis: row.hook_analysis || "", transcript: row.transcript || "", caption: row.caption || "", ownerUsername: row.owner_username || "" })}><Copy className="h-3.5 w-3.5" /></Button>
                      )}
                      {row.url && <a href={row.url} target="_blank" rel="noopener noreferrer"><Button variant="ghost" size="icon" className="h-7 w-7"><Share className="h-3.5 w-3.5" /></Button></a>}
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => handleDelete([row.id])}><Trash2 className="h-3.5 w-3.5" /></Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>
      {/* Expanded detail rows */}
      {filtered.filter(r => r.id === expandedId).map(row => (
        <div key={`${row.id}-detail`} className="border rounded-lg mt-2 bg-muted/20 p-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            {row.caption && <div><span className="font-medium text-muted-foreground">Caption:</span><p className="mt-1 whitespace-pre-wrap">{row.caption}</p></div>}
            {row.hook_analysis && <div><span className="font-medium text-muted-foreground">Hook Analysis:</span><p className="mt-1 whitespace-pre-wrap">{row.hook_analysis}</p></div>}
            {row.transcript && <div><span className="font-medium text-muted-foreground">Transcrição:</span><p className="mt-1 whitespace-pre-wrap max-h-32 overflow-y-auto">{row.transcript}</p></div>}
            {row.viral_points && <div><span className="font-medium text-muted-foreground">Pontos Virais:</span><p className="mt-1 whitespace-pre-wrap">{row.viral_points}</p></div>}
            {row.psychological_triggers && <div><span className="font-medium text-muted-foreground">Gatilhos:</span><p className="mt-1">{row.psychological_triggers}</p></div>}
            {row.url && <div><span className="font-medium text-muted-foreground">URL:</span> <a href={row.url} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">{row.url}</a></div>}
          </div>
        </div>
      ))}
      <div className="mt-2 text-xs text-muted-foreground">{filtered.length} reel{filtered.length !== 1 ? "s" : ""}</div>
    </div>
  )
}

// ============ Estratégia de Conteúdo Table ============
function EstrategiaTable({ searchQuery, onExportPdf }: { searchQuery: string; onExportPdf: (fn: () => void) => void }) {
  const [rows, setRows] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [expandedId, setExpandedId] = useState<string | null>(null)

  const loadData = useCallback(async () => {
    setLoading(true)
    const { data } = await supabase.from("estrategias").select("*").order("created_at", { ascending: false })
    setRows(data || [])
    setLoading(false)
  }, [])

  useEffect(() => { loadData() }, [loadData])

  const filtered = rows.filter(r =>
    !searchQuery || r.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    r.key_takeaway?.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const parseJson = (val: any): any[] => { if (!val) return []; if (Array.isArray(val)) return val; try { return JSON.parse(val) } catch { return [] } }
  const fmtDate = (d: string | null) => { if (!d) return "—"; try { return new Date(d).toLocaleDateString("pt-BR") } catch { return d } }

  useEffect(() => {
    onExportPdf(() => {
      exportTableToPdf("Estratégia de Conteúdo",
        ["Título", "Key Takeaway", "Top Vídeos", "Padrões", "Hooks", "Data"],
        filtered.map(r => [r.title || "—", (r.key_takeaway || "").slice(0, 100), String(parseJson(r.top_videos).length), String(parseJson(r.winning_patterns).length), String(parseJson(r.hook_ideas).length), fmtDate(r.created_at)])
      )
    })
  }, [filtered, onExportPdf])

  const toggleSelect = (id: string) => { setSelected(prev => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n }) }
  const toggleAll = () => { selected.size === filtered.length ? setSelected(new Set()) : setSelected(new Set(filtered.map(r => r.id))) }

  const handleDelete = async (ids: string[]) => {
    try {
      for (const id of ids) { const { error } = await supabase.from("estrategias").delete().eq("id", id); if (error) throw error }
      toast.success(`${ids.length} estratégia${ids.length > 1 ? "s" : ""} excluída${ids.length > 1 ? "s" : ""}`); setSelected(new Set()); loadData()
    } catch (e: any) { toast.error("Erro ao excluir", { description: e.message }) }
  }

  return (
    <div>
      {selected.size > 0 && (
        <div className="flex items-center gap-2 mb-3">
          <Badge variant="secondary">{selected.size} selecionada{selected.size > 1 ? "s" : ""}</Badge>
          <Button variant="destructive" size="sm" className="gap-1.5" onClick={() => handleDelete(Array.from(selected))}><Trash2 className="h-3.5 w-3.5" /> Excluir</Button>
        </div>
      )}
      <div className="border rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/30 hover:bg-muted/30">
                <TableHead className="w-10"><Checkbox checked={filtered.length > 0 && selected.size === filtered.length} onCheckedChange={toggleAll} /></TableHead>
                <TableHead className="min-w-[220px]"><div className="flex items-center gap-2"><Type className="h-4 w-4 text-muted-foreground/60" /> Título</div></TableHead>
                <TableHead className="min-w-[200px]"><div className="flex items-center gap-2"><FileText className="h-4 w-4 text-muted-foreground/60" /> Takeaway</div></TableHead>
                <TableHead className="min-w-[80px]"><div className="flex items-center gap-2"><BarChart3 className="h-4 w-4 text-muted-foreground/60" /> Top Vídeos</div></TableHead>
                <TableHead className="min-w-[80px]"><div className="flex items-center gap-2"><List className="h-4 w-4 text-muted-foreground/60" /> Padrões</div></TableHead>
                <TableHead className="min-w-[80px]"><div className="flex items-center gap-2"><Sparkles className="h-4 w-4 text-muted-foreground/60" /> Hooks</div></TableHead>
                <TableHead className="min-w-[110px]"><div className="flex items-center gap-2"><Calendar className="h-4 w-4 text-muted-foreground/60" /> Data</div></TableHead>
                <TableHead className="w-[80px]">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow><TableCell colSpan={8} className="h-32 text-center"><RefreshCw className="h-5 w-5 animate-spin mx-auto text-muted-foreground" /></TableCell></TableRow>
              ) : filtered.length === 0 ? (
                <TableRow><TableCell colSpan={8} className="h-32 text-center text-muted-foreground"><div className="flex flex-col items-center gap-2"><HelpCircle className="h-5 w-5" /><span>Nenhuma estratégia encontrada</span></div></TableCell></TableRow>
              ) : filtered.map(row => {
                const topVideos = parseJson(row.top_videos); const patterns = parseJson(row.winning_patterns); const hooks = parseJson(row.hook_ideas)
                return (
                  <TableRow key={row.id} className="group cursor-pointer" onClick={() => setExpandedId(expandedId === row.id ? null : row.id)}>
                    <TableCell onClick={e => e.stopPropagation()}><Checkbox checked={selected.has(row.id)} onCheckedChange={() => toggleSelect(row.id)} /></TableCell>
                    <TableCell className="font-medium text-sm">{row.title || "—"}</TableCell>
                    <TableCell className="text-sm max-w-[220px] truncate">{row.key_takeaway || "—"}</TableCell>
                    <TableCell className="text-sm text-center"><Badge variant="outline">{topVideos.length}</Badge></TableCell>
                    <TableCell className="text-sm text-center"><Badge variant="outline">{patterns.length}</Badge></TableCell>
                    <TableCell className="text-sm text-center"><Badge variant="outline">{hooks.length}</Badge></TableCell>
                    <TableCell className="text-sm text-muted-foreground">{fmtDate(row.created_at)}</TableCell>
                    <TableCell onClick={e => e.stopPropagation()}>
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => handleDelete([row.id])}><Trash2 className="h-3.5 w-3.5" /></Button>
                      </div>
                    </TableCell>
                  </TableRow>
                )
              })}
            </TableBody>
          </Table>
        </div>
      </div>
      {/* Expanded detail */}
      {filtered.filter(r => r.id === expandedId).map(row => {
        const topVideos = parseJson(row.top_videos); const patterns = parseJson(row.winning_patterns); const hooks = parseJson(row.hook_ideas)
        return (
          <div key={`${row.id}-detail`} className="border rounded-lg mt-2 bg-muted/20 p-4 space-y-4 text-sm">
            {row.key_takeaway && <div><span className="font-medium text-muted-foreground">Key Takeaway:</span><p className="mt-1">{row.key_takeaway}</p></div>}
            {topVideos.length > 0 && <div><span className="font-medium text-muted-foreground">Top Vídeos:</span><div className="mt-1 space-y-1">{topVideos.map((v: any, i: number) => (<div key={i} className="flex items-center gap-2 text-xs bg-muted/30 rounded px-2 py-1"><span className="font-medium">#{v.rank || i + 1}</span><span className="truncate">{v.hook || v.caption || "—"}</span>{v.creator && <span className="text-muted-foreground">@{v.creator}</span>}{v.views && <Badge variant="outline" className="text-xs ml-auto">{v.views} views</Badge>}</div>))}</div></div>}
            {patterns.length > 0 && <div><span className="font-medium text-muted-foreground">Padrões Vencedores:</span><div className="mt-1 flex flex-wrap gap-1">{patterns.map((p: any, i: number) => <Badge key={i} variant="secondary" className="text-xs">{typeof p === "string" ? p : p.pattern || p.name || JSON.stringify(p)}</Badge>)}</div></div>}
            {hooks.length > 0 && <div><span className="font-medium text-muted-foreground">Ideias de Hook:</span><div className="mt-1 flex flex-wrap gap-1">{hooks.map((h: any, i: number) => <Badge key={i} variant="outline" className="text-xs">{typeof h === "string" ? h : h.hook || h.idea || JSON.stringify(h)}</Badge>)}</div></div>}
            {row.raw_report && <div><span className="font-medium text-muted-foreground">Relatório Completo:</span><p className="mt-1 whitespace-pre-wrap max-h-48 overflow-y-auto text-xs bg-muted/30 rounded p-2">{row.raw_report}</p></div>}
          </div>
        )
      })}
      <div className="mt-2 text-xs text-muted-foreground">{filtered.length} estratégia{filtered.length !== 1 ? "s" : ""}</div>
    </div>
  )
}

// ============ Conteúdo (generated_content) Table ============
function ConteudoTable({ searchQuery, onExportPdf }: { searchQuery: string; onExportPdf: (fn: () => void) => void }) {
  const [rows, setRows] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [expandedId, setExpandedId] = useState<string | null>(null)
  const [downloadingZip, setDownloadingZip] = useState(false)

  const handleDownloadImagesZip = async (result: string) => {
    const srcs = extractImageSources(result)
    if (srcs.length === 0) {
      toast.error("Nenhuma imagem encontrada neste conteúdo")
      return
    }
    setDownloadingZip(true)
    try {
      const zip = new JSZip()
      for (let i = 0; i < srcs.length; i++) {
        const src = srcs[i]
        if (src.startsWith("data:")) {
          const [header, b64] = src.split(",")
          const mime = header.match(/data:(.*?);/)?.[1] || "image/png"
          const ext = mime.includes("png") ? "png" : mime.includes("webp") ? "webp" : "jpg"
          const binary = atob(b64)
          const bytes = new Uint8Array(binary.length)
          for (let j = 0; j < binary.length; j++) bytes[j] = binary.charCodeAt(j)
          zip.file(`slide-${i + 1}.${ext}`, bytes)
        } else {
          const res = await fetch(src)
          const blob = await res.blob()
          const ext = blob.type.includes("png") ? "png" : blob.type.includes("webp") ? "webp" : "jpg"
          zip.file(`slide-${i + 1}.${ext}`, blob)
        }
      }
      const content = await zip.generateAsync({ type: "blob" })
      const link = document.createElement("a")
      link.href = URL.createObjectURL(content)
      link.download = `carrossel-${Date.now()}.zip`
      link.click()
      URL.revokeObjectURL(link.href)
      toast.success(`${srcs.length} imagens baixadas!`)
    } catch (e: any) {
      toast.error("Erro ao baixar imagens", { description: e.message })
    } finally {
      setDownloadingZip(false)
    }
  }

  const loadData = useCallback(async () => {
    setLoading(true)
    const { data } = await supabase.from("generated_content").select("*").order("created_at", { ascending: false }).limit(200)
    setRows(data || [])
    setLoading(false)
  }, [])

  useEffect(() => { loadData() }, [loadData])

  const filtered = rows.filter(r =>
    !searchQuery ||
    r.prompt?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    r.result?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    r.generation_type?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    r.agent_type?.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const fmtDate = (d: string | null) => { if (!d) return "—"; try { return new Date(d).toLocaleDateString("pt-BR") } catch { return d } }

  useEffect(() => {
    onExportPdf(() => {
      exportTableToPdf("Database de Conteúdo",
        ["Tipo", "Agente", "Modelo", "Prompt", "Resultado", "Data"],
        filtered.map(r => [r.generation_type || "—", r.agent_type || "—", r.model || "—", (r.prompt || "").slice(0, 80), (r.result || "").slice(0, 120), fmtDate(r.created_at)])
      )
    })
  }, [filtered, onExportPdf])

  const toggleSelect = (id: string) => { setSelected(prev => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n }) }
  const toggleAll = () => { selected.size === filtered.length ? setSelected(new Set()) : setSelected(new Set(filtered.map(r => r.id))) }

  const handleDelete = async (ids: string[]) => {
    try {
      for (const id of ids) { const { error } = await supabase.from("generated_content").delete().eq("id", id); if (error) throw error }
      toast.success(`${ids.length} conteúdo${ids.length > 1 ? "s" : ""} excluído${ids.length > 1 ? "s" : ""}`); setSelected(new Set()); loadData()
    } catch (e: any) { toast.error("Erro ao excluir", { description: e.message }) }
  }

  const genTypeLabels: Record<string, string> = { video: "Vídeo", carrossel: "Carrossel", post: "Post", story: "Story", reel: "Reel", script: "Script", copy: "Copy" }

  return (
    <div>
      {selected.size > 0 && (
        <div className="flex items-center gap-2 mb-3">
          <Badge variant="secondary">{selected.size} selecionado{selected.size > 1 ? "s" : ""}</Badge>
          <Button variant="destructive" size="sm" className="gap-1.5" onClick={() => handleDelete(Array.from(selected))}><Trash2 className="h-3.5 w-3.5" /> Excluir</Button>
        </div>
      )}
      <div className="border rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/30 hover:bg-muted/30">
                <TableHead className="w-10"><Checkbox checked={filtered.length > 0 && selected.size === filtered.length} onCheckedChange={toggleAll} /></TableHead>
                <TableHead className="min-w-[100px]"><div className="flex items-center gap-2"><LayoutGrid className="h-4 w-4 text-muted-foreground/60" /> Tipo</div></TableHead>
                <TableHead className="min-w-[120px]"><div className="flex items-center gap-2"><Sparkles className="h-4 w-4 text-muted-foreground/60" /> Agente</div></TableHead>
                <TableHead className="min-w-[120px]"><div className="flex items-center gap-2"><Database className="h-4 w-4 text-muted-foreground/60" /> Modelo</div></TableHead>
                <TableHead className="min-w-[200px]"><div className="flex items-center gap-2"><Type className="h-4 w-4 text-muted-foreground/60" /> Prompt</div></TableHead>
                <TableHead className="min-w-[200px]"><div className="flex items-center gap-2"><FileText className="h-4 w-4 text-muted-foreground/60" /> Resultado</div></TableHead>
                <TableHead className="min-w-[100px]"><div className="flex items-center gap-2"><Calendar className="h-4 w-4 text-muted-foreground/60" /> Data</div></TableHead>
                <TableHead className="w-[80px]">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow><TableCell colSpan={8} className="h-32 text-center"><RefreshCw className="h-5 w-5 animate-spin mx-auto text-muted-foreground" /></TableCell></TableRow>
              ) : filtered.length === 0 ? (
                <TableRow><TableCell colSpan={8} className="h-32 text-center text-muted-foreground"><div className="flex flex-col items-center gap-2"><HelpCircle className="h-5 w-5" /><span>Nenhum conteúdo gerado</span></div></TableCell></TableRow>
              ) : filtered.map(row => (
                <TableRow key={row.id} className="group cursor-pointer" onClick={() => setExpandedId(expandedId === row.id ? null : row.id)}>
                  <TableCell onClick={e => e.stopPropagation()}><Checkbox checked={selected.has(row.id)} onCheckedChange={() => toggleSelect(row.id)} /></TableCell>
                  <TableCell><Badge variant="outline" className="text-xs">{genTypeLabels[row.generation_type] || row.generation_type}</Badge></TableCell>
                  <TableCell className="text-sm">{row.agent_type || "—"}</TableCell>
                  <TableCell className="text-sm text-muted-foreground">{row.model || "—"}</TableCell>
                  <TableCell className="text-sm max-w-[200px] truncate">{row.prompt?.slice(0, 60) || "—"}</TableCell>
                  <TableCell className="text-sm max-w-[200px] truncate">{row.result?.slice(0, 60) || "—"}</TableCell>
                  <TableCell className="text-sm text-muted-foreground">{fmtDate(row.created_at)}</TableCell>
                  <TableCell onClick={e => e.stopPropagation()}>
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Button variant="ghost" size="icon" className="h-7 w-7" title="Copiar resultado" onClick={() => { navigator.clipboard.writeText(row.result || ""); toast.success("Copiado!") }}><Copy className="h-3.5 w-3.5" /></Button>
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => handleDelete([row.id])}><Trash2 className="h-3.5 w-3.5" /></Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>
      {/* Expanded detail */}
      {filtered.filter(r => r.id === expandedId).map(row => (
        <div key={`${row.id}-detail`} className="border rounded-lg mt-2 bg-muted/20 p-4 space-y-3 text-sm">
          <div><span className="font-medium text-muted-foreground">Prompt Completo:</span><p className="mt-1 whitespace-pre-wrap bg-muted/30 rounded p-2 max-h-32 overflow-y-auto text-xs">{row.prompt}</p></div>
          <div>
            <span className="font-medium text-muted-foreground">Resultado:</span>
            <MarkdownWithImages
              content={row.result}
              className="mt-1 bg-muted/30 rounded p-3 max-h-[500px] overflow-y-auto prose prose-sm dark:prose-invert max-w-none [&_img]:rounded-lg [&_img]:border [&_img]:max-w-full [&_h1]:text-lg [&_h2]:text-base [&_h3]:text-sm [&_p]:text-sm [&_li]:text-sm [&_hr]:my-3"
            />
          </div>
          <div className="flex items-center justify-between">
            <div className="flex gap-4 text-xs text-muted-foreground">
              <span>Provider: {row.provider}</span>
              <span>Modelo: {row.model}</span>
              <span>Agente: {row.agent_type}</span>
            </div>
            <div className="flex gap-2">
              <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => { navigator.clipboard.writeText(row.result); toast.success("Copiado!") }}>
                <Copy className="h-3 w-3 mr-1" /> Copiar
              </Button>
              <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => handleDownloadImagesZip(row.result)} disabled={downloadingZip}>
                {downloadingZip ? <RefreshCw className="h-3 w-3 mr-1 animate-spin" /> : <Download className="h-3 w-3 mr-1" />} Baixar ZIP
              </Button>
            </div>
          </div>
        </div>
      ))}
      <div className="mt-2 text-xs text-muted-foreground">{filtered.length} conteúdo{filtered.length !== 1 ? "s" : ""} gerado{filtered.length !== 1 ? "s" : ""}</div>
    </div>
  )
}

// ============ Main Modal ============
export function DatabaseModal({ open, onOpenChange, databaseType, onCopyReelWithAI }: DatabaseModalProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [isMaximized, setIsMaximized] = useState(false)
  const exportPdfRef = useRef<(() => void) | null>(null)
  const { pos, onMouseDown, dragging, reset } = useDraggable()

  const setExportFn = useCallback((fn: () => void) => { exportPdfRef.current = fn }, [])

  // Reset position when maximizing or changing type
  useEffect(() => { reset() }, [isMaximized, databaseType, reset])

  if (!databaseType) return null
  const title = dbTitles[databaseType]

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        showCloseButton={false}
        className="flex flex-col p-0 gap-0 transition-all duration-200"
        style={{
          ...(isMaximized
            ? { maxWidth: "96vw", width: "96vw", height: "96vh", maxHeight: "96vh" }
            : { maxWidth: "72rem", height: "85vh" }),
          transform: `translate(calc(-50% + ${pos.x}px), calc(-50% + ${pos.y}px))`,
          cursor: dragging ? "grabbing" : undefined,
        }}
        onInteractOutside={(e) => e.preventDefault()}
      >
        {/* Draggable header */}
        <div
          className="flex items-center justify-between px-4 py-2 border-b bg-muted/30 cursor-grab active:cursor-grabbing select-none"
          onMouseDown={onMouseDown}
        >
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <GripHorizontal className="h-4 w-4" />
            <Database className="h-4 w-4" />
            <span>{title}</span>
          </div>
          <div className="flex items-center gap-1" onMouseDown={e => e.stopPropagation()}>
            <Button variant="ghost" size="icon" className="h-8 w-8" title="Exportar PDF" onClick={() => exportPdfRef.current?.()}>
              <Download className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setIsMaximized(!isMaximized)}>
              {isMaximized ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onOpenChange(false)}><X className="h-4 w-4" /></Button>
          </div>
        </div>

        <div className="flex-1 overflow-auto p-6">
          <div className="flex items-center gap-3 mb-6">
            <Database className="h-6 w-6 text-primary" />
            <h1 className="text-2xl font-bold">{title}</h1>
          </div>

          {databaseType === "competidores" ? (
            <CompetidoresTable searchQuery={searchQuery} onExportPdf={setExportFn} />
          ) : databaseType === "reels-competidores" || databaseType === "meus-reels" ? (
            <ReelsTable tableName={databaseType === "meus-reels" ? "meus_reels" : "reels_competidores"} searchQuery={searchQuery} onCopyReelWithAI={onCopyReelWithAI} onExportPdf={setExportFn} />
          ) : databaseType === "estrategia" ? (
            <EstrategiaTable searchQuery={searchQuery} onExportPdf={setExportFn} />
          ) : (
            <ConteudoTable searchQuery={searchQuery} onExportPdf={setExportFn} />
          )}
        </div>

        <div className="flex items-center justify-between px-4 py-3 border-t bg-muted/30">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" className="gap-2"><Filter className="h-4 w-4" /> Filtrar</Button>
            <Button variant="ghost" size="sm" className="gap-2"><ArrowUpDown className="h-4 w-4" /> Ordenar</Button>
          </div>
          <Input placeholder="Pesquisar..." className="h-8 w-48" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
        </div>
      </DialogContent>
    </Dialog>
  )
}

export type { DatabaseType }
