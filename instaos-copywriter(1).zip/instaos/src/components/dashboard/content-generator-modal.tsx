import { useState } from "react"
import { supabase } from "@/integrations/supabase/client"
import { toast } from "sonner"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import {
  Loader2, Copy, Download, Send, LayoutGrid, Film,
  CheckCircle2, ChevronRight, Clock, Eye, Mic,
} from "lucide-react"
import type { ViralAnalysis } from "./viral-score-panel"

// ── Types ──────────────────────────────────────────────────────────────────
export interface CarouselSlide {
  num: number
  label: string
  text: string
  subtext?: string
  design?: string
}

export interface ReelSegment {
  time: string
  label: string
  text: string
  visual: string
}

export interface GeneratedContentOutput {
  carousel: {
    title: string
    slides: CarouselSlide[]
    caption: string
  }
  reel: {
    title: string
    hook: string
    script: ReelSegment[]
    caption: string
  }
}

interface ContentGeneratorModalProps {
  open: boolean
  onOpenChange: (v: boolean) => void
  analysis: ViralAnalysis | null
  sourceCaption?: string
  ownerUsername?: string
  profileName?: string
  profileNiche?: string
  profileHashtags?: string
  onAddToQueue?: (type: "carrossel" | "reel" | "ambos", content: GeneratedContentOutput) => void
}

// ── Slide Card ─────────────────────────────────────────────────────────────
function SlideCard({ slide, onClick }: { slide: CarouselSlide; onClick?: () => void }) {
  const isFirst = slide.num === 1
  const isLast = slide.label.toUpperCase().includes("CTA")
  return (
    <div
      onClick={onClick}
      className={`
        relative flex flex-col items-center justify-center text-center rounded-xl border p-3
        aspect-square cursor-pointer transition-all hover:-translate-y-0.5 hover:shadow-lg
        ${isFirst ? "border-yellow-500/50 bg-yellow-500/5" : isLast ? "border-green-500/40 bg-green-500/5" : "border-border bg-card"}
      `}
    >
      <span className="absolute top-2 right-2 text-[10px] font-mono text-muted-foreground opacity-60">{slide.num}</span>
      <span className={`text-[9px] uppercase tracking-widest mb-1.5 font-semibold ${isFirst ? "text-yellow-400" : isLast ? "text-green-400" : "text-muted-foreground"}`}>
        {slide.label}
      </span>
      <p className="text-xs font-semibold leading-snug text-foreground line-clamp-4">{slide.text}</p>
      {slide.subtext && (
        <p className="text-[10px] text-muted-foreground mt-1 line-clamp-2">{slide.subtext}</p>
      )}
    </div>
  )
}

// ── Script Block ───────────────────────────────────────────────────────────
function ScriptSegment({ seg, isHook }: { seg: ReelSegment; isHook?: boolean }) {
  return (
    <div className={`rounded-lg border overflow-hidden ${isHook ? "border-yellow-500/40" : "border-border"}`}>
      <div className={`px-3 py-1.5 flex items-center gap-2 text-xs font-mono font-semibold ${isHook ? "bg-yellow-500/10 text-yellow-400" : "bg-muted/30 text-muted-foreground"}`}>
        <Clock className="w-3 h-3" />
        {seg.time}
        <ChevronRight className="w-3 h-3 opacity-50" />
        <span>{seg.label}</span>
      </div>
      <div className="px-3 py-2.5">
        <p className="text-sm text-foreground leading-relaxed">{seg.text}</p>
        <div className="flex items-start gap-1.5 mt-2">
          <Eye className="w-3 h-3 text-muted-foreground mt-0.5 flex-shrink-0" />
          <p className="text-[11px] text-muted-foreground">{seg.visual}</p>
        </div>
      </div>
    </div>
  )
}

// ── Main Component ─────────────────────────────────────────────────────────
export function ContentGeneratorModal({
  open, onOpenChange, analysis,
  sourceCaption = "", ownerUsername = "",
  profileName = "@djairrotta",
  profileNiche = "Advogado especialista em direito bancário. Tom educativo, direto e acessível.",
  profileHashtags = "#advogado #direitobancario #juroabusivo",
  onAddToQueue,
}: ContentGeneratorModalProps) {
  const [loading, setLoading] = useState(false)
  const [output, setOutput] = useState<GeneratedContentOutput | null>(null)
  const [activeTab, setActiveTab] = useState("carrossel")
  const [selectedSlide, setSelectedSlide] = useState<CarouselSlide | null>(null)
  const [addedTypes, setAddedTypes] = useState<Set<string>>(new Set())

  async function generate(mode: "carrossel" | "reel" | "ambos" = "ambos") {
    if (!analysis) return
    setLoading(true)
    setOutput(null)

    const prompt = `Você é especialista em conteúdo viral para Instagram. Crie conteúdo para ${profileName}.

PERFIL: ${profileNiche}
GANCHO ADAPTADO: "${analysis.adaptedHook}"
FORMATO RECOMENDADO: ${analysis.bestFormat}
HASHTAGS: ${profileHashtags}
REFERÊNCIA: Post de @${ownerUsername} — "${sourceCaption.slice(0, 300)}"

Retorne SOMENTE JSON válido sem markdown:
{
  "carousel": {
    "title": "título interno do carrossel",
    "slides": [
      {"num":1,"label":"CAPA","text":"gancho impactante da capa (max 8 palavras)","subtext":"subtítulo opcional","design":"dica de cor/visual"},
      {"num":2,"label":"SLIDE 2","text":"conteúdo do slide","subtext":"detalhe adicional","design":""},
      {"num":3,"label":"SLIDE 3","text":"desenvolvimento","subtext":"","design":""},
      {"num":4,"label":"SLIDE 4","text":"ponto chave 2","subtext":"","design":""},
      {"num":5,"label":"SLIDE 5","text":"ponto chave 3","subtext":"","design":""},
      {"num":6,"label":"CTA","text":"call to action forte e direto","subtext":"Siga para mais dicas","design":""}
    ],
    "caption": "legenda completa do post com emojis e hashtags (max 280 chars)"
  },
  "reel": {
    "title": "título interno do roteiro",
    "hook": "fala dos primeiros 3 segundos — CRUCIAL para retenção",
    "script": [
      {"time":"0–3s","label":"GANCHO","text":"fala de abertura exata","visual":"câmera no rosto, fundo limpo, texto na tela"},
      {"time":"3–8s","label":"PROBLEMA","text":"apresenta o problema","visual":"corte rápido, B-roll sugerido"},
      {"time":"8–22s","label":"CONTEÚDO","text":"desenvolvimento principal","visual":"talking head com cortes a cada 3s"},
      {"time":"22–28s","label":"SOLUÇÃO","text":"a resposta/solução","visual":"revelar algo, zoom in"},
      {"time":"28–30s","label":"CTA","text":"call to action","visual":"texto grande na tela + expressão direta"}
    ],
    "caption": "legenda completa do reel com emojis e hashtags"
  }
}`

    try {
      const { data, error } = await supabase.functions.invoke("generate-content", {
        body: {
          agent: "carousel_planner",
          context: prompt,
          provider: "openrouter",
          model: "google/gemini-2.5-flash",
          custom_prompt: "Retorne SOMENTE JSON válido sem markdown, sem texto adicional.",
        },
      })
      if (error) throw error

      const raw: string = typeof data === "string" ? data : data?.content || data?.text || JSON.stringify(data)
      const clean = raw.replace(/```json|```/g, "").trim()
      const result: GeneratedContentOutput = JSON.parse(clean)
      setOutput(result)
      setAddedTypes(new Set())
      toast.success("Conteúdo gerado com sucesso!")
    } catch (e: any) {
      toast.error("Erro na geração", { description: e.message })
    } finally {
      setLoading(false)
    }
  }

  function copyText(text: string, label: string) {
    navigator.clipboard.writeText(text)
    toast.success(`${label} copiado!`)
  }

  function addToQueue(type: "carrossel" | "reel" | "ambos") {
    if (!output) return
    onAddToQueue?.(type, output)
    setAddedTypes(prev => {
      const next = new Set(prev)
      if (type === "ambos") { next.add("carrossel"); next.add("reel") }
      else next.add(type)
      return next
    })
    toast.success(type === "ambos" ? "Ambos adicionados à fila!" : `${type} adicionado à fila!`)
  }

  const canAdd = (type: "carrossel" | "reel") => output && !addedTypes.has(type)

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <span className="text-yellow-400">✨</span>
            Gerador de Conteúdo
            {analysis && (
              <Badge variant="outline" className="text-yellow-400 border-yellow-500/30 text-xs ml-2">
                Score {analysis.viralScore} · {analysis.hookType}
              </Badge>
            )}
          </DialogTitle>
        </DialogHeader>

        {/* Adapted Hook Banner */}
        {analysis && (
          <div className="rounded-lg border border-yellow-500/30 bg-yellow-500/5 px-4 py-3 flex items-start gap-3">
            <span className="text-yellow-400 text-sm mt-0.5">🎯</span>
            <div className="flex-1 min-w-0">
              <p className="text-[10px] uppercase tracking-wider text-yellow-400 mb-1">Gancho adaptado</p>
              <p className="text-sm italic text-foreground/90">"{analysis.adaptedHook}"</p>
            </div>
            <button onClick={() => copyText(analysis.adaptedHook, "Gancho")} className="text-muted-foreground hover:text-yellow-400 transition-colors flex-shrink-0">
              <Copy className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Generate buttons */}
        {!output && (
          <div className="flex flex-col gap-3 py-2">
            <div className="grid grid-cols-3 gap-2">
              <Button
                variant="outline"
                className="gap-2 border-yellow-500/30 hover:bg-yellow-500/10 hover:text-yellow-400"
                onClick={() => generate("carrossel")}
                disabled={loading || !analysis}
              >
                <LayoutGrid className="w-4 h-4" />
                Carrossel
              </Button>
              <Button
                variant="outline"
                className="gap-2 border-blue-500/30 hover:bg-blue-500/10 hover:text-blue-400"
                onClick={() => generate("reel")}
                disabled={loading || !analysis}
              >
                <Film className="w-4 h-4" />
                Roteiro Reel
              </Button>
              <Button
                className="gap-2 bg-yellow-500 hover:bg-yellow-400 text-black font-semibold"
                onClick={() => generate("ambos")}
                disabled={loading || !analysis}
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <span>⚡</span>}
                Gerar Ambos
              </Button>
            </div>
            {loading && (
              <div className="text-center text-sm text-muted-foreground animate-pulse py-4">
                Gerando conteúdo com IA...
              </div>
            )}
            {!analysis && (
              <p className="text-xs text-center text-muted-foreground">
                Faça a análise viral de um post primeiro para gerar conteúdo
              </p>
            )}
          </div>
        )}

        {/* Output */}
        {output && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs text-muted-foreground">Conteúdo gerado — revise e adicione à fila</span>
              <Button
                size="sm"
                variant="ghost"
                className="text-xs h-7 gap-1"
                onClick={() => { setOutput(null); generate("ambos") }}
                disabled={loading}
              >
                {loading ? <Loader2 className="w-3 h-3 animate-spin" /> : "↺"} Regenerar
              </Button>
            </div>

            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="w-full">
                <TabsTrigger value="carrossel" className="flex-1 gap-2">
                  <LayoutGrid className="w-3.5 h-3.5" />
                  🎠 Carrossel
                  {addedTypes.has("carrossel") && <CheckCircle2 className="w-3 h-3 text-green-400" />}
                </TabsTrigger>
                <TabsTrigger value="reel" className="flex-1 gap-2">
                  <Film className="w-3.5 h-3.5" />
                  🎬 Roteiro Reel
                  {addedTypes.has("reel") && <CheckCircle2 className="w-3 h-3 text-green-400" />}
                </TabsTrigger>
              </TabsList>

              {/* ── CAROUSEL TAB ── */}
              <TabsContent value="carrossel" className="space-y-4 mt-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-semibold">{output.carousel.title}</h3>
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={!canAdd("carrossel")}
                    onClick={() => addToQueue("carrossel")}
                    className="gap-1.5 text-xs h-7 border-yellow-500/30 hover:bg-yellow-500/10 hover:text-yellow-400"
                  >
                    {addedTypes.has("carrossel") ? <CheckCircle2 className="w-3 h-3 text-green-400" /> : <Send className="w-3 h-3" />}
                    {addedTypes.has("carrossel") ? "Na fila" : "Fila"}
                  </Button>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  {output.carousel.slides.map(slide => (
                    <SlideCard
                      key={slide.num}
                      slide={slide}
                      onClick={() => setSelectedSlide(selectedSlide?.num === slide.num ? null : slide)}
                    />
                  ))}
                </div>

                {/* Slide detail */}
                {selectedSlide && (
                  <div className="rounded-lg border border-yellow-500/30 bg-yellow-500/5 p-3 space-y-2">
                    <p className="text-[10px] uppercase tracking-wider text-yellow-400">Slide {selectedSlide.num} — {selectedSlide.label}</p>
                    <p className="text-sm font-semibold">{selectedSlide.text}</p>
                    {selectedSlide.subtext && <p className="text-xs text-muted-foreground">{selectedSlide.subtext}</p>}
                    {selectedSlide.design && (
                      <p className="text-[11px] text-blue-400 flex items-center gap-1"><Eye className="w-3 h-3" />{selectedSlide.design}</p>
                    )}
                  </div>
                )}

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <Label className="text-xs">Legenda do post</Label>
                    <button onClick={() => copyText(output.carousel.caption, "Legenda")} className="text-muted-foreground hover:text-foreground">
                      <Copy className="w-3 h-3" />
                    </button>
                  </div>
                  <Textarea
                    value={output.carousel.caption}
                    onChange={e => setOutput(prev => prev ? { ...prev, carousel: { ...prev.carousel, caption: e.target.value } } : prev)}
                    className="text-xs resize-none min-h-[80px]"
                  />
                </div>
              </TabsContent>

              {/* ── REEL TAB ── */}
              <TabsContent value="reel" className="space-y-4 mt-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-semibold">{output.reel.title}</h3>
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={!canAdd("reel")}
                    onClick={() => addToQueue("reel")}
                    className="gap-1.5 text-xs h-7 border-blue-500/30 hover:bg-blue-500/10 hover:text-blue-400"
                  >
                    {addedTypes.has("reel") ? <CheckCircle2 className="w-3 h-3 text-green-400" /> : <Send className="w-3 h-3" />}
                    {addedTypes.has("reel") ? "Na fila" : "Fila"}
                  </Button>
                </div>

                <div className="rounded-lg border border-yellow-500/40 bg-yellow-500/5 p-3">
                  <div className="flex items-center gap-2 mb-2">
                    <Mic className="w-3.5 h-3.5 text-yellow-400" />
                    <span className="text-[10px] uppercase tracking-wider text-yellow-400 font-semibold">⚡ Gancho — primeiros 3 segundos</span>
                  </div>
                  <p className="text-sm font-medium italic text-yellow-200/90">"{output.reel.hook}"</p>
                </div>

                <div className="space-y-2">
                  {output.reel.script.map((seg, i) => (
                    <ScriptSegment key={i} seg={seg} isHook={i === 0} />
                  ))}
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <Label className="text-xs">Legenda do reel</Label>
                    <button onClick={() => copyText(output.reel.caption, "Legenda")} className="text-muted-foreground hover:text-foreground">
                      <Copy className="w-3 h-3" />
                    </button>
                  </div>
                  <Textarea
                    value={output.reel.caption}
                    onChange={e => setOutput(prev => prev ? { ...prev, reel: { ...prev.reel, caption: e.target.value } } : prev)}
                    className="text-xs resize-none min-h-[80px]"
                  />
                </div>
              </TabsContent>
            </Tabs>

            {/* Add both to queue */}
            <Button
              className="w-full gap-2 bg-yellow-500 hover:bg-yellow-400 text-black font-semibold"
              onClick={() => addToQueue("ambos")}
              disabled={addedTypes.has("carrossel") && addedTypes.has("reel")}
            >
              <Send className="w-4 h-4" />
              {addedTypes.has("carrossel") && addedTypes.has("reel")
                ? "✅ Ambos na fila de aprovação"
                : "📋 Adicionar ambos à fila de aprovação"}
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
