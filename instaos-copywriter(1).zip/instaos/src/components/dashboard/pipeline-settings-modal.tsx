import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Settings, Zap, Clock, Trash2, Timer } from "lucide-react";

interface PipelineSettings {
  competitor_weeks_filter: number;
  my_reels_months_filter: number;
  competitor_reels_limit: number;
  my_reels_limit: number;
  delay_between_competitors: number;
  clear_before_run: boolean;
}

const DEFAULT_SETTINGS: PipelineSettings = {
  competitor_weeks_filter: 2,
  my_reels_months_filter: 3,
  competitor_reels_limit: 20,
  my_reels_limit: 15,
  delay_between_competitors: 0,
  clear_before_run: true,
};

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onRunPipeline: (settings: PipelineSettings) => void;
  isRunning: boolean;
}

export function PipelineSettingsModal({ open, onOpenChange, onRunPipeline, isRunning }: Props) {
  const [settings, setSettings] = useState<PipelineSettings>(DEFAULT_SETTINGS);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!open) return;
    loadSettings();
  }, [open]);

  const loadSettings = async () => {
    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: config } = await supabase
        .from("pipeline_config")
        .select("competitor_weeks_filter, my_reels_months_filter, competitor_reels_limit, my_reels_limit")
        .eq("user_id", user.id)
        .maybeSingle();

      const { data: sysConfig } = await supabase
        .from("system_config")
        .select("config_value")
        .eq("user_id", user.id)
        .eq("config_key", "pipeline_manual_settings")
        .maybeSingle();

      let manualOverrides: Partial<PipelineSettings> = {};
      if (sysConfig?.config_value) {
        try { manualOverrides = JSON.parse(sysConfig.config_value); } catch {}
      }

      setSettings({
        competitor_weeks_filter: manualOverrides.competitor_weeks_filter ?? config?.competitor_weeks_filter ?? DEFAULT_SETTINGS.competitor_weeks_filter,
        my_reels_months_filter: manualOverrides.my_reels_months_filter ?? config?.my_reels_months_filter ?? DEFAULT_SETTINGS.my_reels_months_filter,
        competitor_reels_limit: manualOverrides.competitor_reels_limit ?? config?.competitor_reels_limit ?? DEFAULT_SETTINGS.competitor_reels_limit,
        my_reels_limit: manualOverrides.my_reels_limit ?? config?.my_reels_limit ?? DEFAULT_SETTINGS.my_reels_limit,
        delay_between_competitors: manualOverrides.delay_between_competitors ?? DEFAULT_SETTINGS.delay_between_competitors,
        clear_before_run: manualOverrides.clear_before_run ?? DEFAULT_SETTINGS.clear_before_run,
      });
    } catch (e) {
      console.error("Error loading pipeline settings:", e);
    } finally {
      setLoading(false);
    }
  };

  const saveAndRun = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      await supabase.from("system_config").upsert({
        user_id: user.id,
        config_key: "pipeline_manual_settings",
        config_value: JSON.stringify(settings),
      }, { onConflict: "user_id,config_key" });

      onRunPipeline(settings);
      onOpenChange(false);
    } catch (e: any) {
      toast.error("Erro ao salvar configurações", { description: e.message });
    }
  };

  const update = <K extends keyof PipelineSettings>(key: K, value: PipelineSettings[K]) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" /> Configurar Pipeline Manual
          </DialogTitle>
          <DialogDescription>
            Ajuste os parâmetros antes de rodar o pipeline manualmente.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-5 py-2">
          {/* Time filters */}
          <div className="space-y-3">
            <h4 className="text-sm font-semibold flex items-center gap-2">
              <Clock className="h-4 w-4 text-muted-foreground" /> Filtros de Tempo
            </h4>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Competidores (semanas)</Label>
                <Input
                  type="number"
                  min={1}
                  max={12}
                  value={settings.competitor_weeks_filter}
                  onChange={e => update("competitor_weeks_filter", parseInt(e.target.value) || 1)}
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Meus Reels (meses)</Label>
                <Input
                  type="number"
                  min={1}
                  max={12}
                  value={settings.my_reels_months_filter}
                  onChange={e => update("my_reels_months_filter", parseInt(e.target.value) || 1)}
                />
              </div>
            </div>
          </div>

          {/* Limits */}
          <div className="space-y-3">
            <h4 className="text-sm font-semibold flex items-center gap-2">
              <Zap className="h-4 w-4 text-muted-foreground" /> Limites de Scraping
            </h4>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Posts por competidor</Label>
                <Input
                  type="number"
                  min={1}
                  max={100}
                  value={settings.competitor_reels_limit}
                  onChange={e => update("competitor_reels_limit", parseInt(e.target.value) || 1)}
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Meus posts (limite)</Label>
                <Input
                  type="number"
                  min={1}
                  max={100}
                  value={settings.my_reels_limit}
                  onChange={e => update("my_reels_limit", parseInt(e.target.value) || 1)}
                />
              </div>
            </div>
          </div>

          {/* Delay */}
          <div className="space-y-3">
            <h4 className="text-sm font-semibold flex items-center gap-2">
              <Timer className="h-4 w-4 text-muted-foreground" /> Delay entre competidores
            </h4>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-xs">Segundos de espera</Label>
                <span className="text-sm font-mono text-muted-foreground">{settings.delay_between_competitors}s</span>
              </div>
              <Slider
                min={0}
                max={30}
                step={1}
                value={[settings.delay_between_competitors]}
                onValueChange={([v]) => update("delay_between_competitors", v)}
              />
              <p className="text-xs text-muted-foreground">0 = sem delay (mais rápido, maior risco de bloqueio)</p>
            </div>
          </div>

          {/* Clear data */}
          <div className="flex items-center justify-between rounded-md border p-3">
            <div className="flex items-center gap-2">
              <Trash2 className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-sm font-medium">Limpar e recriar dados</p>
                <p className="text-xs text-muted-foreground">Remove dados antigos antes de rodar</p>
              </div>
            </div>
            <Switch
              checked={settings.clear_before_run}
              onCheckedChange={v => update("clear_before_run", v)}
            />
          </div>
        </div>

        <div className="flex gap-2 pt-2">
          <Button variant="outline" className="flex-1" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button className="flex-1" onClick={saveAndRun} disabled={isRunning || loading}>
            {isRunning ? "⏳ Executando..." : "🚀 Rodar com estas configs"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export type { PipelineSettings };
