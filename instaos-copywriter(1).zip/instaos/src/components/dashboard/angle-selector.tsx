import { useState } from "react"
import { supabase } from "@/integrations/supabase/client"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { cn } from "@/lib/utils"
import { Loader2, ChevronRight, Zap, RotateCcw, CheckCircle2, Star } from "lucide-react"

interface Angle {
  id: number
  title: string
  type: string
  emotional_trigger: string
  hook_draft: string
  slide_structure: Array<{ slide: number; theme: string }>
  strength: string
  weakness: string
  best_format: string
}

interface AngleSelectorProps {
  reelId?: string
  caption?: string
  hookAnalysis?: string
  transcript?: string
  viralPoints?: string[]
  contentType?: string
  ownerUsername?: string
  views?: number
  likes?: number
  onAngleSelected: (angle: Angle, anglesId: string) => void
}

const TONE_COLORS: Record<string, string> = {
  "Revelador":             "text-yellow-400 border-yellow-500/30 bg-yellow-500/5",
  "Comparativo":           "text-blue-400 border-blue-500/30 bg-blue-500/5",
  "Passo a Passo":         "text-green-400 border-green-500/30 bg-green-500/5",
  "Pergunta Incômoda":     "text-purple-400 border-purple-500/30 bg-purple-500/5",
  "Tendência+Oportunidade":"text-orange-400 border-orange-500/30 bg-orange-500/5",
}

export function AngleSelector({
  reelId, caption = "", hookAnalysis = "", transcript = "",
  viralPoints = [], contentType = "reel", ownerUsername = "",
  views = 0, likes = 0, onAngleSelected,
}: AngleSelectorProps) {
  const [loading, setLoading] = useState(false)
  const [angles, setAngles] = useState<Angle[]>([])
  const [anglesId, setAnglesId] = useState<string | null>(null)
  const [recommendedAngle, setRecommendedAngle] = useState<number>(1)
  const [contentSummary, setContentSummary] = useState("")
  const [selected, setSelected] = useState<number | null>(null)
  const [adjustments, setAdjustments] = useState("")
  const [confirming, setConfirming] = useState(false)

  async function generate() {
    setLoading(true)
    setAngles([])
    setSelected(null)
    const { data: { session } } = await supabase.auth.getSession()
    try {
      const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/viral-angles`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.access_token}` },
        body: JSON.stringify({
          action: "generate",
          reelId, caption, hookAnalysis, transcript,
          viralPoints, contentType, ownerUsername, views, likes,
        }),
      })
      const d = await res.json()
      if (!d.success) throw new Error(d.error)
      setAngles(d.angles)
      setAnglesId(d.anglesId)
      setRecommendedAngle(d.recommendedAngle)
      setContentSummary(d.contentSummary)
      toast.success("5 ângulos gerados!")
    } catch (e: any) { toast.error(e.message) }
    finally { setLoading(false) }
  }

  async function confirmSelection() {
    if (selected === null || !anglesId) return
    setConfirming(true)
    const { data: { session } } = await supabase.auth.getSession()
    try {
      const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/viral-angles`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.access_token}` },
        body: JSON.stringify({ action: "select", anglesId, selectedAngleId: selected, userAdjustments: adjustments }),
      })
      const d = await res.json()
      if (!d.success) throw new Error(d.error)
      const angle = angles.find(a => a.id === selected)!
      onAngleSelected(angle, anglesId)
      toast.success(`Ângulo "${angle.title}" selecionado!`)
    } catch (e: any) { toast.error(e.message) }
    finally { setConfirming(false) }
  }

  return (
    <div className="space-y-4">
      {/* Generate button */}
      {angles.length === 0 && (
        <div className="flex flex-col items-center gap-3 py-6">
          <p className="text-sm text-muted-foreground text-center">
            Antes de gerar conteúdo, escolha o <strong>ângulo viral</strong> — a lente emocional para contar este conteúdo
          </p>
          <Button onClick={generate} disabled={loading} className="gap-2 bg-yellow-500 hover:bg-yellow-400 text-black font-semibold">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
            {loading ? "Gerando 5 ângulos..." : "Gerar 5 Ângulos Virais"}
          </Button>
        </div>
      )}

      {/* Angles list */}
      {angles.length > 0 && (
        <>
          {contentSummary && (
            <p className="text-xs text-muted-foreground bg-muted/20 rounded-lg px-3 py-2">
              📋 {contentSummary}
            </p>
          )}

          <div className="space-y-2">
            {angles.map(angle => {
              const isSelected = selected === angle.id
              const isRecommended = recommendedAngle === angle.id
              return (
                <button key={angle.id} onClick={() => setSelected(isSelected ? null : angle.id)}
                  className={cn("w-full text-left rounded-xl border p-3.5 transition-all",
                    isSelected ? "border-yellow-500/60 bg-yellow-500/8 shadow-sm shadow-yellow-500/10" : "border-border bg-card hover:border-yellow-500/20"
                  )}>
                  <div className="flex items-start gap-3">
                    <div className={cn("w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 mt-0.5 text-xs font-bold transition-all",
                      isSelected ? "border-yellow-400 bg-yellow-400 text-black" : "border-muted-foreground/30 text-muted-foreground"
                    )}>
                      {isSelected ? "✓" : angle.id}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1.5">
                        <span className="font-semibold text-sm">{angle.title}</span>
                        <Badge variant="outline" className={cn("text-[9px] px-1.5", TONE_COLORS[angle.type] || "text-muted-foreground border-border")}>
                          {angle.type}
                        </Badge>
                        <Badge variant="outline" className="text-[9px] px-1.5 text-muted-foreground border-border">
                          {angle.best_format}
                        </Badge>
                        {isRecommended && (
                          <Badge variant="outline" className="text-[9px] px-1.5 text-yellow-400 border-yellow-500/30 flex items-center gap-0.5">
                            <Star className="w-2.5 h-2.5" />recomendado
                          </Badge>
                        )}
                      </div>
                      <p className="text-xs italic text-foreground/80 leading-snug mb-2">"{angle.hook_draft}"</p>
                      <div className="flex gap-3 text-[10px] text-muted-foreground">
                        <span className="flex items-start gap-1"><span className="text-green-400">✓</span>{angle.strength}</span>
                        <span className="flex items-start gap-1"><span className="text-orange-400">⚠</span>{angle.weakness}</span>
                      </div>
                    </div>
                  </div>

                  {/* Slide structure (expanded when selected) */}
                  {isSelected && angle.slide_structure && (
                    <div className="mt-3 ml-9 space-y-1">
                      <p className="text-[9px] uppercase tracking-wider text-muted-foreground/50 mb-1.5">Estrutura de Slides</p>
                      {angle.slide_structure.map(s => (
                        <div key={s.slide} className="flex items-center gap-2 text-[10px] text-muted-foreground">
                          <span className="w-5 h-5 rounded bg-yellow-500/10 text-yellow-400 flex items-center justify-center text-[9px] font-mono flex-shrink-0">{s.slide}</span>
                          {s.theme}
                        </div>
                      ))}
                    </div>
                  )}
                </button>
              )
            })}
          </div>

          {/* Adjustments + confirm */}
          {selected !== null && (
            <div className="space-y-2 pt-2">
              <div>
                <p className="text-xs text-muted-foreground mb-1.5">Ajustes opcionais no ângulo selecionado:</p>
                <Textarea value={adjustments} onChange={e => setAdjustments(e.target.value)}
                  placeholder="Ex: focar mais no aspecto jurídico, mencionar o STJ, usar exemplo de cartão de crédito específico..."
                  rows={2} className="text-xs" />
              </div>
              <div className="flex gap-2">
                <Button onClick={confirmSelection} disabled={confirming} className="flex-1 gap-1.5 bg-yellow-500 hover:bg-yellow-400 text-black font-semibold text-sm">
                  {confirming ? <Loader2 className="w-4 h-4 animate-spin" /> : <ChevronRight className="w-4 h-4" />}
                  Gerar Conteúdo com este Ângulo
                </Button>
                <Button variant="outline" size="sm" onClick={generate} disabled={loading} className="gap-1 text-xs">
                  <RotateCcw className="w-3 h-3" />Novos ângulos
                </Button>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  )
}
