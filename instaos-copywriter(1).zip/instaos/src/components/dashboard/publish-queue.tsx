import { useState, useEffect, useCallback } from "react"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar } from "@/components/ui/calendar"
import { Input } from "@/components/ui/input"
import { cn } from "@/lib/utils"
import { supabase } from "@/integrations/supabase/client"
import { toast } from "sonner"
import {
  CheckCircle, XCircle, Send, Loader2, Clock, ImageIcon, Film, Images,
  ExternalLink, Trash2, RefreshCw, AlertCircle, Eye, CalendarIcon, Pencil
} from "lucide-react"

interface QueueItem {
  id: string
  contentType: string
  caption: string | null
  mediaUrls: string[]
  videoUrl: string | null
  status: string
  scheduledAt: string | null
  publishedAt: string | null
  errorMessage: string | null
  igPermalink: string | null
  createdAt: string
}

interface PublishQueueProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

const STATUS_CONFIG: Record<string, { label: string; color: string; icon: React.ReactNode }> = {
  pending_approval: { label: "Pendente", color: "bg-amber-500/10 text-amber-500 border-amber-500/30", icon: <Clock className="h-3.5 w-3.5" /> },
  scheduled: { label: "Agendado", color: "bg-blue-500/10 text-blue-500 border-blue-500/30", icon: <Clock className="h-3.5 w-3.5" /> },
  approved: { label: "Aprovado", color: "bg-emerald-500/10 text-emerald-500 border-emerald-500/30", icon: <CheckCircle className="h-3.5 w-3.5" /> },
  publishing: { label: "Publicando...", color: "bg-blue-500/10 text-blue-500 border-blue-500/30", icon: <Loader2 className="h-3.5 w-3.5 animate-spin" /> },
  published: { label: "Publicado", color: "bg-emerald-600/10 text-emerald-600 border-emerald-600/30", icon: <CheckCircle className="h-3.5 w-3.5" /> },
  failed: { label: "Erro", color: "bg-red-500/10 text-red-500 border-red-500/30", icon: <AlertCircle className="h-3.5 w-3.5" /> },
  rejected: { label: "Rejeitado", color: "bg-muted text-muted-foreground border-border", icon: <XCircle className="h-3.5 w-3.5" /> },
}

const TYPE_ICONS: Record<string, React.ReactNode> = {
  post: <ImageIcon className="h-4 w-4" />,
  reel: <Film className="h-4 w-4" />,
  carousel: <Images className="h-4 w-4" />,
}

export function PublishQueue({ open, onOpenChange }: PublishQueueProps) {
  const [items, setItems] = useState<QueueItem[]>([])
  const [loading, setLoading] = useState(false)
  const [publishingIds, setPublishingIds] = useState<Set<string>>(new Set())
  const [editingCaption, setEditingCaption] = useState<{ id: string; caption: string } | null>(null)
  const [previewItem, setPreviewItem] = useState<QueueItem | null>(null)

  const loadQueue = useCallback(async () => {
    setLoading(true)
    try {
      const { data, error } = await supabase
        .from("publish_queue")
        .select("*")
        .order("created_at", { ascending: false })

      if (error) throw error
      setItems((data || []).map(d => ({
        id: d.id,
        contentType: d.content_type,
        caption: d.caption,
        mediaUrls: Array.isArray(d.media_urls) ? (d.media_urls as string[]) : [],
        videoUrl: d.video_url,
        status: d.status,
        scheduledAt: d.scheduled_at,
        publishedAt: d.published_at,
        errorMessage: d.error_message,
        igPermalink: d.ig_permalink,
        createdAt: d.created_at,
      })))
    } catch (err: any) {
      toast.error("Erro ao carregar fila", { description: err.message })
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    if (open) loadQueue()
  }, [open, loadQueue])

  const updateStatus = useCallback(async (id: string, status: string) => {
    const { error } = await supabase.from("publish_queue").update({ status }).eq("id", id)
    if (error) {
      toast.error("Erro ao atualizar status")
      return
    }
    setItems(prev => prev.map(i => i.id === id ? { ...i, status } : i))
    toast.success(status === "approved" ? "Conteúdo aprovado!" : "Conteúdo rejeitado")
  }, [])

  const handlePublish = useCallback(async (id: string) => {
    setPublishingIds(prev => new Set(prev).add(id))
    try {
      const { data, error } = await supabase.functions.invoke("publish-instagram", {
        body: { action: "publish", queueId: id },
      })
      if (error) throw error
      if (!data?.success) throw new Error(data?.error || "Publishing failed")

      setItems(prev => prev.map(i => i.id === id ? {
        ...i,
        status: "published",
        publishedAt: new Date().toISOString(),
        igPermalink: data.permalink || null,
      } : i))
      toast.success("Publicado no Instagram! 🎉", {
        description: data.permalink ? "Clique para ver" : undefined,
        action: data.permalink ? { label: "Ver", onClick: () => window.open(data.permalink, "_blank") } : undefined,
      })
    } catch (err: any) {
      toast.error("Erro ao publicar", { description: err.message })
      setItems(prev => prev.map(i => i.id === id ? { ...i, status: "failed", errorMessage: err.message } : i))
    } finally {
      setPublishingIds(prev => { const n = new Set(prev); n.delete(id); return n })
    }
  }, [])

  const handleDelete = useCallback(async (id: string) => {
    const { error } = await supabase.from("publish_queue").delete().eq("id", id)
    if (error) { toast.error("Erro ao excluir"); return }
    setItems(prev => prev.filter(i => i.id !== id))
    toast.success("Item removido da fila")
  }, [])

  const handleSaveCaption = useCallback(async () => {
    if (!editingCaption) return
    const { error } = await supabase.from("publish_queue").update({ caption: editingCaption.caption }).eq("id", editingCaption.id)
    if (error) { toast.error("Erro ao salvar legenda"); return }
    setItems(prev => prev.map(i => i.id === editingCaption.id ? { ...i, caption: editingCaption.caption } : i))
    setEditingCaption(null)
    toast.success("Legenda atualizada")
  }, [editingCaption])

  const handleUpdateSchedule = useCallback(async (id: string, date: Date | null) => {
    const scheduled_at = date ? date.toISOString() : null
    const status = date ? "scheduled" : "pending_approval"
    const { error } = await supabase.from("publish_queue").update({ scheduled_at, status }).eq("id", id)
    if (error) { toast.error("Erro ao atualizar agendamento"); return }
    setItems(prev => prev.map(i => i.id === id ? { ...i, scheduledAt: scheduled_at, status } : i))
    if (previewItem?.id === id) setPreviewItem(prev => prev ? { ...prev, scheduledAt: scheduled_at, status } : null)
    toast.success(date ? `Agendado para ${format(date, "dd/MM/yyyy HH:mm")}` : "Agendamento removido")
  }, [previewItem])

  const filterByTab = (tab: string) => {
    if (tab === "pending") return items.filter(i => i.status === "pending_approval")
    if (tab === "scheduled") return items.filter(i => i.status === "scheduled")
    if (tab === "approved") return items.filter(i => ["approved", "publishing"].includes(i.status))
    if (tab === "published") return items.filter(i => i.status === "published")
    if (tab === "failed") return items.filter(i => ["failed", "rejected"].includes(i.status))
    return items
  }

  const ScheduleEditor = ({ item }: { item: QueueItem }) => {
    const [time, setTime] = useState(() => {
      if (item.scheduledAt) {
        const d = new Date(item.scheduledAt)
        return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`
      }
      return "09:00"
    })

    const handleDateSelect = (date: Date | undefined) => {
      if (!date) return
      const [h, m] = time.split(":").map(Number)
      date.setHours(h, m, 0, 0)
      handleUpdateSchedule(item.id, date)
    }

    const handleTimeChange = (newTime: string) => {
      setTime(newTime)
      if (item.scheduledAt) {
        const date = new Date(item.scheduledAt)
        const [h, m] = newTime.split(":").map(Number)
        date.setHours(h, m, 0, 0)
        handleUpdateSchedule(item.id, date)
      }
    }

    const currentDate = item.scheduledAt ? new Date(item.scheduledAt) : undefined

    return (
      <Popover>
        <PopoverTrigger asChild>
          <Button variant="outline" size="sm" className="h-7 text-xs gap-1">
            <CalendarIcon className="h-3 w-3" />
            {item.scheduledAt
              ? format(new Date(item.scheduledAt), "dd/MM HH:mm")
              : "Agendar"
            }
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="end">
          <Calendar
            mode="single"
            selected={currentDate}
            onSelect={handleDateSelect}
            disabled={(date) => date < new Date(new Date().setHours(0, 0, 0, 0))}
            initialFocus
            className={cn("p-3 pointer-events-auto")}
            locale={ptBR}
          />
          <div className="border-t border-border p-3 flex items-center gap-2">
            <Clock className="h-4 w-4 text-muted-foreground" />
            <Input
              type="time"
              value={time}
              onChange={e => handleTimeChange(e.target.value)}
              className="h-8 w-28 text-xs"
            />
            {item.scheduledAt && (
              <Button variant="ghost" size="sm" className="h-8 text-xs text-destructive"
                onClick={() => handleUpdateSchedule(item.id, null)}>
                Remover
              </Button>
            )}
          </div>
        </PopoverContent>
      </Popover>
    )
  }

  const QueueCard = ({ item }: { item: QueueItem }) => {
    const cfg = STATUS_CONFIG[item.status] || STATUS_CONFIG.pending_approval
    const isPublishing = publishingIds.has(item.id)
    const thumbUrl = item.mediaUrls?.[0] || null

    return (
      <Card className="overflow-hidden border-border/50 hover:border-border transition-colors">
        <CardContent className="p-0">
          <div className="flex gap-4 p-4">
            {/* Thumbnail */}
            <div className="shrink-0 w-20 h-20 rounded-md overflow-hidden bg-muted flex items-center justify-center">
              {thumbUrl ? (
                <img src={thumbUrl} alt="" className="w-full h-full object-cover" />
              ) : item.videoUrl ? (
                <Film className="h-8 w-8 text-muted-foreground" />
              ) : (
                <ImageIcon className="h-8 w-8 text-muted-foreground" />
              )}
            </div>

            {/* Info */}
            <div className="flex-1 min-w-0 space-y-2">
              <div className="flex items-center gap-2 flex-wrap">
                <Badge variant="outline" className="gap-1 text-xs">
                  {TYPE_ICONS[item.contentType] || TYPE_ICONS.post}
                  {item.contentType === "reel" ? "Reel" : item.contentType === "carousel" ? "Carrossel" : "Post"}
                </Badge>
                <Badge variant="outline" className={`gap-1 text-xs ${cfg.color}`}>
                  {cfg.icon} {cfg.label}
                </Badge>
                {item.mediaUrls.length > 1 && (
                  <Badge variant="secondary" className="text-xs">{item.mediaUrls.length} mídias</Badge>
                )}
              </div>

              <p className="text-sm text-foreground line-clamp-2">
                {item.caption || <span className="text-muted-foreground italic">Sem legenda</span>}
              </p>

              <div className="flex items-center gap-3 text-xs text-muted-foreground">
                <span>{new Date(item.createdAt).toLocaleDateString("pt-BR", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}</span>
                {item.scheduledAt && <span className="text-blue-500">• Agendado: {new Date(item.scheduledAt).toLocaleDateString("pt-BR", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}</span>}
                {item.publishedAt && <span>• Publicado {new Date(item.publishedAt).toLocaleDateString("pt-BR")}</span>}
                {item.errorMessage && <span className="text-destructive">• {item.errorMessage}</span>}
              </div>
            </div>

            {/* Actions */}
            <div className="shrink-0 flex flex-col gap-1.5">
              {!["publishing", "published"].includes(item.status) && (
                <ScheduleEditor item={item} />
              )}
              {item.status === "pending_approval" && (
                <>
                  <Button size="sm" variant="outline" className="h-7 text-xs gap-1 text-emerald-500 hover:text-emerald-600"
                    onClick={() => updateStatus(item.id, "approved")}>
                    <CheckCircle className="h-3 w-3" /> Aprovar
                  </Button>
                  <Button size="sm" variant="outline" className="h-7 text-xs gap-1 text-red-500 hover:text-red-600"
                    onClick={() => updateStatus(item.id, "rejected")}>
                    <XCircle className="h-3 w-3" /> Rejeitar
                  </Button>
                </>
              )}
              {item.status === "approved" && (
                <Button size="sm" className="h-7 text-xs gap-1" disabled={isPublishing}
                  onClick={() => handlePublish(item.id)}>
                  {isPublishing ? <Loader2 className="h-3 w-3 animate-spin" /> : <Send className="h-3 w-3" />}
                  {isPublishing ? "Publicando..." : "Publicar"}
                </Button>
              )}
              {item.status === "failed" && (
                <Button size="sm" variant="outline" className="h-7 text-xs gap-1"
                  onClick={() => updateStatus(item.id, "approved")}>
                  <RefreshCw className="h-3 w-3" /> Tentar novamente
                </Button>
              )}
              {item.igPermalink && (
                <Button size="sm" variant="ghost" className="h-7 text-xs gap-1"
                  onClick={() => window.open(item.igPermalink!, "_blank")}>
                  <ExternalLink className="h-3 w-3" /> Ver
                </Button>
              )}
              <Button size="sm" variant="ghost" className="h-7 text-xs gap-1"
                onClick={() => setPreviewItem(item)}>
                <Eye className="h-3 w-3" />
              </Button>
              {!["publishing", "published"].includes(item.status) && (
                <Button size="sm" variant="ghost" className="h-7 text-xs gap-1 text-red-500 hover:text-red-600"
                  onClick={() => handleDelete(item.id)}>
                  <Trash2 className="h-3 w-3" />
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  const TabContent = ({ tab }: { tab: string }) => {
    const filtered = filterByTab(tab)
    if (loading) return <div className="flex justify-center py-12"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
    if (filtered.length === 0) return (
      <div className="flex flex-col items-center justify-center py-12 text-muted-foreground gap-2">
        <Clock className="h-8 w-8" />
        <p className="text-sm">Nenhum conteúdo nesta categoria</p>
      </div>
    )
    return <div className="space-y-3">{filtered.map(item => <QueueCard key={item.id} item={item} />)}</div>
  }

  const pendingCount = items.filter(i => i.status === "pending_approval").length
  const approvedCount = items.filter(i => ["approved", "publishing"].includes(i.status)).length
  const scheduledCount = items.filter(i => i.status === "scheduled").length

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-3xl max-h-[85vh] flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Send className="h-5 w-5 text-primary" />
              Fila de Publicação
              {pendingCount > 0 && <Badge variant="secondary" className="text-xs">{pendingCount} pendentes</Badge>}
            </DialogTitle>
            <DialogDescription>Gerencie e publique conteúdos no Instagram</DialogDescription>
          </DialogHeader>

          <Tabs defaultValue="pending" className="flex-1 min-h-0 flex flex-col">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="pending" className="gap-1.5 text-xs">
                <Clock className="h-3.5 w-3.5" /> Pendentes
                {pendingCount > 0 && <Badge variant="secondary" className="text-xs h-5 px-1.5">{pendingCount}</Badge>}
              </TabsTrigger>
              <TabsTrigger value="scheduled" className="gap-1.5 text-xs">
                <Clock className="h-3.5 w-3.5" /> Agendados
                {scheduledCount > 0 && <Badge variant="secondary" className="text-xs h-5 px-1.5">{scheduledCount}</Badge>}
              </TabsTrigger>
              <TabsTrigger value="approved" className="gap-1.5 text-xs">
                <CheckCircle className="h-3.5 w-3.5" /> Aprovados
                {approvedCount > 0 && <Badge variant="secondary" className="text-xs h-5 px-1.5">{approvedCount}</Badge>}
              </TabsTrigger>
              <TabsTrigger value="published" className="gap-1.5 text-xs">
                <Send className="h-3.5 w-3.5" /> Publicados
              </TabsTrigger>
              <TabsTrigger value="failed" className="gap-1.5 text-xs">
                <AlertCircle className="h-3.5 w-3.5" /> Erros
              </TabsTrigger>
            </TabsList>

            <ScrollArea className="flex-1 mt-4">
              <TabsContent value="pending" className="mt-0"><TabContent tab="pending" /></TabsContent>
              <TabsContent value="scheduled" className="mt-0"><TabContent tab="scheduled" /></TabsContent>
              <TabsContent value="approved" className="mt-0"><TabContent tab="approved" /></TabsContent>
              <TabsContent value="published" className="mt-0"><TabContent tab="published" /></TabsContent>
              <TabsContent value="failed" className="mt-0"><TabContent tab="failed" /></TabsContent>
            </ScrollArea>
          </Tabs>

          <div className="flex justify-between items-center pt-2 border-t border-border">
            <span className="text-xs text-muted-foreground">{items.length} itens na fila</span>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={loadQueue} disabled={loading}>
              <RefreshCw className={`h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`} /> Atualizar
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Preview Modal */}
      <Dialog open={!!previewItem} onOpenChange={() => setPreviewItem(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Pré-visualização</DialogTitle>
            <DialogDescription>
              {previewItem?.contentType === "reel" ? "Reel" : previewItem?.contentType === "carousel" ? "Carrossel" : "Post"}
            </DialogDescription>
          </DialogHeader>
          {previewItem && (
            <div className="space-y-4">
              {previewItem.mediaUrls.length > 0 && (
                <div className="grid grid-cols-2 gap-2">
                  {previewItem.mediaUrls.map((url, i) => (
                    <img key={i} src={url} alt={`Mídia ${i + 1}`} className="w-full rounded-md object-cover aspect-square" />
                  ))}
                </div>
              )}
              <div className="space-y-2">
                <label className="text-sm font-medium">Legenda</label>
                {editingCaption?.id === previewItem.id ? (
                  <div className="space-y-2">
                    <Textarea value={editingCaption.caption} onChange={e => setEditingCaption({ ...editingCaption, caption: e.target.value })} rows={4} />
                    <div className="flex gap-2">
                      <Button size="sm" onClick={handleSaveCaption}>Salvar</Button>
                      <Button size="sm" variant="outline" onClick={() => setEditingCaption(null)}>Cancelar</Button>
                    </div>
                  </div>
                ) : (
                  <div className="text-sm text-foreground whitespace-pre-wrap bg-muted/50 rounded-md p-3 cursor-pointer hover:bg-muted"
                    onClick={() => setEditingCaption({ id: previewItem.id, caption: previewItem.caption || "" })}>
                    {previewItem.caption || <span className="text-muted-foreground italic">Clique para adicionar legenda</span>}
                  </div>
                )}
              </div>
              {/* Schedule editor in preview */}
              {!["publishing", "published"].includes(previewItem.status) && (
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center gap-1.5">
                    <CalendarIcon className="h-4 w-4" /> Agendamento
                  </label>
                  <ScheduleEditor item={previewItem} />
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  )
}
