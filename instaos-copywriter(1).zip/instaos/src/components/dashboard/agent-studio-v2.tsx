import { useState, useEffect, useCallback } from "react"
import { supabase } from "@/integrations/supabase/client"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, Save, Trash2, Brain, Shield, Mic, Settings, Play, Loader2, RotateCcw, Key, Eye, FlaskConical, Zap, Gauge, Cpu, Package, GitBranch, X } from "lucide-react"
import { cn } from "@/lib/utils"

// ─── Types ─────────────────────────────────────────────────────────────────
type AgentTier = "fast" | "powerful" | "economic"

interface AgentConfig {
  id?: string
  agent_type: string
  display_name?: string
  description?: string
  icon?: string
  is_active: boolean
  tier?: AgentTier
  provider: string
  model: string
  execution_mode?: string
  parallel_group?: string | null
  persona?: string | null
  principles?: string | null
  custom_prompt: string | null
  custom_prompt_2: string | null
  custom_prompt_3: string | null
  anti_patterns?: string | null
  output_examples?: string | null
  voice_guidance?: string | null
  quality_criteria?: string | null
  veto_conditions?: string | null
  memory_notes?: string | null
  skills?: string[]
  tasks?: any[]
}

interface Skill {
  slug: string
  name: string
  description: string
  type: string
  is_active: boolean
  is_builtin: boolean
}

// ─── Constants ──────────────────────────────────────────────────────────────
const TIER_CONFIG: Record<AgentTier, { label: string; icon: React.ReactNode; color: string; description: string }> = {
  economic: { label: "Econômico", icon: <Gauge className="w-4 h-4" />, color: "text-green-400 border-green-500/30 bg-green-500/10", description: "Modelo mais leve — menor custo. Ideal para triagem e classificação." },
  fast:     { label: "Rápido",    icon: <Zap className="w-4 h-4" />,   color: "text-blue-400 border-blue-500/30 bg-blue-500/10",   description: "Equilíbrio velocidade/qualidade — maioria das tarefas." },
  powerful: { label: "Poderoso",  icon: <Cpu className="w-4 h-4" />,   color: "text-yellow-400 border-yellow-500/30 bg-yellow-500/10", description: "Melhor modelo disponível — qualidade máxima. Para geração final." },
}

const TIER_MODELS: Record<string, Record<AgentTier, string>> = {
  openrouter: { economic: "meta-llama/llama-4-scout", fast: "google/gemini-2.5-flash-preview-05-20", powerful: "anthropic/claude-opus-4" },
  anthropic:  { economic: "claude-3-5-haiku-20241022", fast: "claude-sonnet-4-20250514", powerful: "claude-opus-4-20250514" },
  openai:     { economic: "gpt-4o-mini", fast: "gpt-4o", powerful: "o3-mini" },
  google:     { economic: "gemini-2.5-flash", fast: "gemini-2.5-flash", powerful: "gemini-2.5-pro" },
  groq:       { economic: "llama-3.1-8b-instant", fast: "llama-3.3-70b-versatile", powerful: "llama-3.3-70b-versatile" },
  lovable:    { economic: "google/gemini-2.5-flash-lite", fast: "google/gemini-2.5-flash", powerful: "openai/gpt-5" },
  deepseek:   { economic: "deepseek-chat", fast: "deepseek-chat", powerful: "deepseek-reasoner" },
}

const PROVIDERS = [
  { value: "lovable",    label: "Lovable AI (inclusa)",  free: true  },
  { value: "openrouter", label: "OpenRouter",            free: false },
  { value: "anthropic",  label: "Anthropic (Claude)",    free: false },
  { value: "openai",     label: "OpenAI (GPT)",          free: false },
  { value: "google",     label: "Google AI Studio",      free: false },
  { value: "groq",       label: "Groq",                  free: false },
  { value: "deepseek",   label: "DeepSeek",              free: false },
]

const BUILTIN_AGENTS = [
  // Analysis (parallel)
  { type: "hook_analyst",       display: "Hook Analyst",       icon: "🎣", group: "Análise (paralelo)",  tier: "fast"    as AgentTier, desc: "Extrai e pontua ganchos virais com power words e score 0-100" },
  { type: "image_analyzer",     display: "Carousel Analyst",   icon: "🎠", group: "Análise (paralelo)",  tier: "fast"    as AgentTier, desc: "Analisa carrosséis slide-a-slide, extrai estrutura e fórmulas" },
  { type: "video_transcriber",  display: "Video Analyst",      icon: "🎬", group: "Análise (paralelo)",  tier: "fast"    as AgentTier, desc: "Transcreve e analisa retenção de vídeos com marcação temporal" },
  { type: "viral_analyst",      display: "Viral Consolidator", icon: "📊", group: "Análise",             tier: "fast"    as AgentTier, desc: "Consolida análises em JSON com score, hook e ideias adaptadas" },
  { type: "content_analyzer",   display: "Content Analyzer",   icon: "📝", group: "Análise",             tier: "fast"    as AgentTier, desc: "Analisa conteúdo geral, extrai hooks e pontos virais" },
  // Generation
  { type: "carousel_planner",   display: "Carousel Planner",   icon: "✨", group: "Geração",             tier: "powerful" as AgentTier, desc: "Planeja carrosséis de 6 slides com texto, design e prompts de imagem" },
  { type: "script_writer",      display: "Script Writer",      icon: "🎙️", group: "Geração",             tier: "powerful" as AgentTier, desc: "Cria roteiros completos de Reel com marcação temporal" },
  { type: "caption_writer",     display: "Caption Writer",     icon: "✍️", group: "Geração",             tier: "powerful" as AgentTier, desc: "Escreve legendas virais com hook, corpo, CTA e hashtags" },
  { type: "copywriter",         display: "Copywriter",         icon: "🖊️", group: "Geração",             tier: "powerful" as AgentTier, desc: "Copy otimizada para engajamento e conversão" },
  // Classifier + Strategy
  { type: "relevance_classifier",display: "Relevance Classifier",icon: "🏷️",group: "Automação",         tier: "economic" as AgentTier, desc: "Classifica posts como relevantes/irrelevantes para o nicho" },
  { type: "content_strategist", display: "Content Strategist", icon: "📈", group: "Estratégia",          tier: "fast"    as AgentTier, desc: "Planeja estratégia editorial e gera ideias com formatos" },
  { type: "idea_generator",     display: "Idea Generator",     icon: "💡", group: "Estratégia",          tier: "fast"    as AgentTier, desc: "Gera 5 ideias de conteúdo com ganchos e formatos específicos" },
]

const BUILTIN_SKILLS: Skill[] = [
  { slug: "instagram-graph",  name: "Instagram Graph API",    description: "Publica posts, reels e carrosséis via Meta Graph API.",         type: "api",    is_active: true,  is_builtin: true },
  { slug: "apify",            name: "Apify Scraper",          description: "Scraping de perfis e posts do Instagram via Apify Actors.",       type: "api",    is_active: true,  is_builtin: true },
  { slug: "image-generator",  name: "Image Generator",        description: "Gera imagens via OpenRouter — modo test e production.",           type: "api",    is_active: false, is_builtin: true },
  { slug: "canva",            name: "Canva Connect",          description: "Cria e exporta designs no Canva via MCP.",                        type: "mcp",    is_active: false, is_builtin: true },
  { slug: "blotato",          name: "Blotato Publisher",      description: "Publica em Instagram, LinkedIn, TikTok, YouTube.",               type: "mcp",    is_active: false, is_builtin: true },
  { slug: "seo-guidelines",   name: "SEO Guidelines",         description: "Melhores práticas de SEO para legendas e hashtags.",             type: "prompt", is_active: false, is_builtin: true },
]

// ─── API Keys Panel ─────────────────────────────────────────────────────────
function ApiKeysPanel() {
  const [keys, setKeys] = useState<Record<string, string>>({})
  const [saving, setSaving] = useState<string | null>(null)
  const [testing, setTesting] = useState<string | null>(null)
  const [visible, setVisible] = useState<Record<string, boolean>>({})

  useEffect(() => {
    supabase.from("user_api_keys").select("provider,api_key").then(({ data }) => {
      const map: Record<string, string> = {}
      for (const row of data || []) map[(row as any).provider] = (row as any).api_key
      setKeys(map)
    })
  }, [])

  async function save(provider: string) {
    if (!keys[provider]?.trim()) return
    setSaving(provider)
    try {
      await supabase.from("user_api_keys").upsert({ provider, api_key: keys[provider].trim(), is_active: true }, { onConflict: "user_id,provider" })
      toast.success(`Chave ${provider} salva!`)
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(null) }
  }

  async function test(provider: string) {
    if (!keys[provider]?.trim()) { toast.error("Digite a chave antes de testar"); return }
    setTesting(provider)
    try {
      const { data } = await supabase.functions.invoke("generate-content", {
        body: { agent: "content_analyzer", context: "teste: responda OK", provider, model: "" }
      })
      if (data?.success) toast.success(`✅ ${provider} funcionando!`)
      else throw new Error(data?.error || "Resposta inválida")
    } catch (e: any) { toast.error(`❌ ${provider}: ${e.message}`) }
    finally { setTesting(null) }
  }

  return (
    <div className="space-y-3 max-w-2xl">
      {PROVIDERS.filter(p => !p.free).map(p => (
        <div key={p.value} className="rounded-xl border border-border bg-card p-4">
          <div className="flex items-center gap-3 mb-2.5">
            <span className="font-semibold text-sm">{p.label}</span>
            {keys[p.value] && <Badge variant="outline" className="text-xs text-green-400 border-green-500/30">✓ Configurado</Badge>}
          </div>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Input type={visible[p.value] ? "text" : "password"} value={keys[p.value] || ""}
                onChange={e => setKeys(prev => ({ ...prev, [p.value]: e.target.value }))}
                placeholder={`API Key do ${p.label}`} className="text-xs font-mono pr-8" />
              <button onClick={() => setVisible(v => ({ ...v, [p.value]: !v[p.value] }))}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                <Eye className="w-3.5 h-3.5" />
              </button>
            </div>
            <Button size="sm" variant="outline" onClick={() => test(p.value)} disabled={testing === p.value} className="h-9 px-3 text-xs">
              {testing === p.value ? <Loader2 className="w-3 h-3 animate-spin" /> : <FlaskConical className="w-3 h-3" />}
            </Button>
            <Button size="sm" onClick={() => save(p.value)} disabled={saving === p.value} className="h-9 px-3 text-xs bg-yellow-500 hover:bg-yellow-400 text-black">
              {saving === p.value ? <Loader2 className="w-3 h-3 animate-spin" /> : <Save className="w-3 h-3" />}
            </Button>
          </div>
        </div>
      ))}
    </div>
  )
}

// ─── Agent Editor ────────────────────────────────────────────────────────────
function AgentEditor({ agentType, skills, onSaved }: { agentType: string; skills: Skill[]; onSaved: () => void }) {
  const [cfg, setCfg] = useState<Partial<AgentConfig>>({})
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [testing, setTesting] = useState(false)
  const [testResult, setTestResult] = useState<string | null>(null)
  const [tab, setTab] = useState("tier")

  const meta = BUILTIN_AGENTS.find(a => a.type === agentType)

  useEffect(() => {
    setLoading(true)
    setTestResult(null)
    supabase.from("agent_configs").select("*").eq("agent_type", agentType).maybeSingle().then(({ data }) => {
      if (data) {
        setCfg(data as AgentConfig)
      } else {
        setCfg({
          agent_type: agentType,
          is_active: true,
          tier: meta?.tier || "fast",
          provider: "openrouter",
          model: TIER_MODELS.openrouter[meta?.tier || "fast"],
          custom_prompt: null, custom_prompt_2: null, custom_prompt_3: null,
          persona: null, principles: null, anti_patterns: null,
          output_examples: null, voice_guidance: null, quality_criteria: null,
          veto_conditions: null, memory_notes: null,
          skills: [], tasks: [], execution_mode: "sequential", parallel_group: null,
        })
      }
      setLoading(false)
    })
  }, [agentType])

  function setTier(tier: AgentTier) {
    const provider = cfg.provider || "openrouter"
    setCfg(p => ({ ...p, tier, model: TIER_MODELS[provider]?.[tier] || "" }))
  }

  async function save() {
    setSaving(true)
    try {
      const { error } = await supabase.from("agent_configs").upsert({
        agent_type: agentType,
        is_active: cfg.is_active ?? true,
        tier: cfg.tier || "fast",
        provider: cfg.provider || "openrouter",
        model: cfg.model || "",
        execution_mode: cfg.execution_mode || "sequential",
        parallel_group: cfg.parallel_group || null,
        custom_prompt: cfg.custom_prompt || null,
        custom_prompt_2: cfg.custom_prompt_2 || null,
        custom_prompt_3: cfg.custom_prompt_3 || null,
        persona: cfg.persona || null,
        principles: cfg.principles || null,
        anti_patterns: cfg.anti_patterns || null,
        output_examples: cfg.output_examples || null,
        voice_guidance: cfg.voice_guidance || null,
        quality_criteria: cfg.quality_criteria || null,
        veto_conditions: cfg.veto_conditions || null,
        memory_notes: cfg.memory_notes || null,
        skills: cfg.skills || [],
        tasks: cfg.tasks || [],
      }, { onConflict: "user_id,agent_type" })
      if (error) throw error
      toast.success(`Agente ${meta?.display || agentType} salvo!`)
      onSaved()
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  async function reset() {
    await supabase.from("agent_configs").delete().eq("agent_type", agentType)
    setCfg({ agent_type: agentType, is_active: true, tier: meta?.tier, provider: "openrouter", model: TIER_MODELS.openrouter[meta?.tier || "fast"], custom_prompt: null, custom_prompt_2: null, custom_prompt_3: null })
    toast("Agente redefinido para o padrão do sistema")
  }

  async function testAgent() {
    setTesting(true)
    setTestResult(null)
    try {
      const { data } = await supabase.functions.invoke("generate-content", {
        body: { agent: agentType, context: "Post de teste: Reel sobre juros abusivos com 150k views", provider: cfg.provider, model: cfg.model, custom_prompt: cfg.custom_prompt || undefined }
      })
      setTestResult(data?.success ? (data.result?.slice(0, 600) + "\n[...]") : `❌ ${data?.error}`)
      if (data?.success) toast.success("Teste concluído!")
      else toast.error(data?.error)
    } catch (e: any) { setTestResult(`❌ ${e.message}`); toast.error(e.message) }
    finally { setTesting(false) }
  }

  const set = (k: keyof AgentConfig) => (e: any) => setCfg(p => ({ ...p, [k]: e.target?.value ?? e }))

  if (loading) return <div className="flex items-center justify-center py-16"><Loader2 className="w-5 h-5 animate-spin text-yellow-400" /></div>

  const tier = (cfg.tier || "fast") as AgentTier

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center gap-3">
        <span className="text-2xl">{meta?.icon || "🤖"}</span>
        <div className="flex-1">
          <p className="font-semibold text-sm">{meta?.display || agentType}</p>
          <p className="text-xs text-muted-foreground">{meta?.desc}</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">Ativo</span>
          <Switch checked={cfg.is_active ?? true} onCheckedChange={v => setCfg(p => ({ ...p, is_active: v }))} />
        </div>
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="w-full grid grid-cols-4 h-8">
          <TabsTrigger value="tier"      className="text-[11px]"><Cpu className="w-3 h-3 mr-1" />Tier</TabsTrigger>
          <TabsTrigger value="identity"  className="text-[11px]"><Brain className="w-3 h-3 mr-1" />Identidade</TabsTrigger>
          <TabsTrigger value="behavior"  className="text-[11px]"><Shield className="w-3 h-3 mr-1" />Comportamento</TabsTrigger>
          <TabsTrigger value="prompts"   className="text-[11px]"><Mic className="w-3 h-3 mr-1" />Prompts</TabsTrigger>
        </TabsList>

        <TabsContent value="tier" className="space-y-4 mt-3">
          {/* Tier selector */}
          <div>
            <Label className="text-xs mb-2 block">Tier de Execução (OpenSquad)</Label>
            <div className="grid grid-cols-3 gap-2">
              {(["economic","fast","powerful"] as AgentTier[]).map(t => {
                const c = TIER_CONFIG[t]
                return (
                  <button key={t} onClick={() => setTier(t)}
                    className={cn("flex flex-col items-start gap-1 p-3 rounded-xl border-2 text-left transition-all",
                      tier === t ? c.color + " border-current" : "border-border bg-card hover:border-yellow-500/20"
                    )}>
                    <div className={cn("flex items-center gap-1.5 text-sm font-semibold", tier === t ? "" : "text-muted-foreground")}>
                      {c.icon} {c.label}
                    </div>
                    <p className="text-[10px] text-muted-foreground">{c.description}</p>
                  </button>
                )
              })}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs mb-1.5 block">Provedor</Label>
              <Select value={cfg.provider || "openrouter"} onValueChange={v => setCfg(p => ({ ...p, provider: v, model: TIER_MODELS[v]?.[tier] || "" }))}>
                <SelectTrigger className="text-xs h-9"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {PROVIDERS.map(p => <SelectItem key={p.value} value={p.value} className="text-xs">{p.label}{p.free && " ✓"}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs mb-1.5 block">Modelo (auto por tier)</Label>
              <Input value={cfg.model || ""} onChange={set("model")} className="text-xs h-9 font-mono" placeholder="auto" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs mb-1.5 block">Modo de Execução</Label>
              <Select value={cfg.execution_mode || "sequential"} onValueChange={v => setCfg(p => ({ ...p, execution_mode: v }))}>
                <SelectTrigger className="text-xs h-9"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="sequential" className="text-xs">▶ Sequential</SelectItem>
                  <SelectItem value="parallel"   className="text-xs">⚡ Parallel</SelectItem>
                  <SelectItem value="subagent"   className="text-xs">🔄 Subagent</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs mb-1.5 block">Grupo Paralelo</Label>
              <Input value={cfg.parallel_group || ""} onChange={e => setCfg(p => ({ ...p, parallel_group: e.target.value || null }))} placeholder="ex: analysis" className="text-xs h-9 font-mono" />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="identity" className="space-y-3 mt-3">
          <div>
            <Label className="text-xs mb-1 block">🧠 Persona</Label>
            <p className="text-[10px] text-muted-foreground mb-1.5">Quem é este agente? Role, identidade, como pensa</p>
            <Textarea value={cfg.persona || ""} onChange={set("persona")} rows={4} className="text-xs" placeholder="Você é [Nome] — especialista em [área]. Sua identidade: [background]..." />
          </div>
          <div>
            <Label className="text-xs mb-1 block">📋 Princípios (mín. 6 regras)</Label>
            <Textarea value={cfg.principles || ""} onChange={set("principles")} rows={6} className="text-xs" placeholder="1. [Princípio específico]&#10;2. [Regra inegociável]&#10;..." />
          </div>
          <div>
            <Label className="text-xs mb-1 block">🗣️ Guia de Voz</Label>
            <Textarea value={cfg.voice_guidance || ""} onChange={set("voice_guidance")} rows={3} className="text-xs" placeholder="USE: [termos do domínio]&#10;EVITE: [clichês]&#10;TOM: [estilo específico]" />
          </div>
        </TabsContent>

        <TabsContent value="behavior" className="space-y-3 mt-3">
          <div>
            <Label className="text-xs mb-1 block">🚫 Anti-Patterns — NUNCA FAÇA</Label>
            <Textarea value={cfg.anti_patterns || ""} onChange={set("anti_patterns")} rows={4} className="text-xs" placeholder="- NUNCA [erro com explicação]&#10;- NUNCA [outro erro]" />
          </div>
          <div>
            <Label className="text-xs mb-1 block">✅ Critérios de Qualidade</Label>
            <Textarea value={cfg.quality_criteria || ""} onChange={set("quality_criteria")} rows={3} className="text-xs" placeholder="- [ ] [Critério mensurável]&#10;- [ ] [Outro critério]" />
          </div>
          <div>
            <Label className="text-xs mb-1 block">🛑 Condições de Veto (refazer se verdadeiro)</Label>
            <Textarea value={cfg.veto_conditions || ""} onChange={set("veto_conditions")} rows={2} className="text-xs" placeholder="1. [Condição que invalida o output]" />
          </div>
          <div>
            <Label className="text-xs mb-1 block">💡 Exemplos de Output</Label>
            <Textarea value={cfg.output_examples || ""} onChange={set("output_examples")} rows={4} className="text-xs" placeholder="Exemplo completo e realista de um output perfeito deste agente..." />
          </div>
        </TabsContent>

        <TabsContent value="prompts" className="space-y-3 mt-3">
          <div className="rounded-lg border border-yellow-500/20 bg-yellow-500/5 px-3 py-2 text-[11px] text-yellow-300">
            O sistema monta: <strong>Persona → Princípios → Prompt Principal → Anti-Patterns → Exemplos → Voz → Qualidade</strong>. Se o Prompt Principal tiver &gt;200 chars, substitui o padrão.
          </div>
          <div>
            <Label className="text-xs mb-1 block">Prompt Principal</Label>
            <Textarea value={cfg.custom_prompt || ""} onChange={set("custom_prompt")} rows={8} className="text-xs font-mono" placeholder="Deixe vazio para usar o prompt padrão + camadas de identidade." />
          </div>
          <div>
            <Label className="text-xs mb-1 block">Prompt Adicional 2</Label>
            <Textarea value={cfg.custom_prompt_2 || ""} onChange={set("custom_prompt_2")} rows={3} className="text-xs font-mono" placeholder="Instruções extras..." />
          </div>
          <div>
            <Label className="text-xs mb-1 block">Prompt Adicional 3</Label>
            <Textarea value={cfg.custom_prompt_3 || ""} onChange={set("custom_prompt_3")} rows={2} className="text-xs font-mono" />
          </div>
        </TabsContent>
      </Tabs>

      {/* Test result */}
      {testResult && (
        <div className="rounded-xl border border-border bg-black/20 p-3">
          <p className="text-[9px] uppercase tracking-wider text-muted-foreground/40 mb-1.5">Resultado do Teste</p>
          <pre className="text-[11px] text-muted-foreground whitespace-pre-wrap font-mono leading-relaxed">{testResult}</pre>
        </div>
      )}

      {/* Actions */}
      <div className="flex gap-2 pt-2 border-t border-border">
        <Button onClick={testAgent} disabled={testing} variant="outline" size="sm" className="text-xs h-8 gap-1">
          {testing ? <Loader2 className="w-3 h-3 animate-spin" /> : <Play className="w-3 h-3" />} Testar
        </Button>
        <Button onClick={reset} variant="ghost" size="sm" className="text-xs h-8 gap-1 text-muted-foreground">
          <RotateCcw className="w-3 h-3" /> Resetar
        </Button>
        <Button onClick={save} disabled={saving} size="sm" className="text-xs h-8 gap-1 ml-auto bg-yellow-500 hover:bg-yellow-400 text-black">
          {saving ? <Loader2 className="w-3 h-3 animate-spin" /> : <Save className="w-3 h-3" />} Salvar
        </Button>
      </div>
    </div>
  )
}

// ─── Main ────────────────────────────────────────────────────────────────────
export function AgentStudioV2() {
  const [selected, setSelected] = useState(BUILTIN_AGENTS[0].type)
  const [view, setView] = useState<"agents" | "keys">("agents")
  const [configured, setConfigured] = useState<Set<string>>(new Set())
  const [skills, setSkills] = useState<Skill[]>(BUILTIN_SKILLS)

  useEffect(() => {
    supabase.from("agent_configs").select("agent_type").then(({ data }) => {
      setConfigured(new Set((data || []).map((r: any) => r.agent_type)))
    })
    // Load custom skills if table exists
    supabase.from("agent_skills").select("*").then(({ data }) => {
      if (data?.length) {
        const builtinSlugs = new Set(BUILTIN_SKILLS.map(s => s.slug))
        const custom = (data as Skill[]).filter(s => !builtinSlugs.has(s.slug))
        setSkills([...BUILTIN_SKILLS, ...custom])
      }
    }).catch(() => {}) // Table may not exist yet
  }, [])

  const groups = [...new Set(BUILTIN_AGENTS.map(a => a.group))]

  return (
    <div className="p-6 lg:p-8 max-w-6xl mx-auto">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Brain className="w-6 h-6 text-yellow-400" />
            Agent Studio
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Configure tier, persona, princípios e prompts de cada agente
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant={view === "agents" ? "default" : "outline"} size="sm" className="text-xs gap-1.5" onClick={() => setView("agents")}>
            <Brain className="w-3.5 h-3.5" /> Agentes ({BUILTIN_AGENTS.length})
          </Button>
          <Button variant={view === "keys" ? "default" : "outline"} size="sm" className="text-xs gap-1.5" onClick={() => setView("keys")}>
            <Key className="w-3.5 h-3.5" /> Chaves de API
          </Button>
        </div>
      </div>

      {view === "keys" ? <ApiKeysPanel /> : (
        <div className="grid grid-cols-[220px_1fr] gap-6">
          {/* Sidebar */}
          <div className="space-y-4">
            {groups.map(group => (
              <div key={group}>
                <p className="text-[9px] uppercase tracking-widest text-muted-foreground/40 mb-1.5 px-1">{group}</p>
                {BUILTIN_AGENTS.filter(a => a.group === group).map(a => {
                  const tierDot = { economic: "bg-green-400", fast: "bg-blue-400", powerful: "bg-yellow-400" }[a.tier]
                  return (
                    <button key={a.type} onClick={() => setSelected(a.type)}
                      className={cn("w-full flex items-center gap-2 px-2.5 py-2 rounded-lg text-xs transition-all text-left border",
                        selected === a.type
                          ? "bg-yellow-500/15 text-yellow-300 border-yellow-500/30"
                          : "text-muted-foreground hover:text-foreground hover:bg-accent/30 border-transparent"
                      )}>
                      <span className="text-sm leading-none flex-shrink-0">{a.icon}</span>
                      <span className="flex-1 font-medium truncate">{a.display}</span>
                      <div className={cn("w-1.5 h-1.5 rounded-full flex-shrink-0", tierDot, configured.has(a.type) ? "opacity-100" : "opacity-30")} />
                    </button>
                  )
                })}
              </div>
            ))}
          </div>

          {/* Editor */}
          <div className="rounded-xl border border-border bg-card p-6">
            <AgentEditor
              key={selected}
              agentType={selected}
              skills={skills}
              onSaved={() => setConfigured(prev => new Set([...prev, selected]))}
            />
          </div>
        </div>
      )}
    </div>
  )
}
