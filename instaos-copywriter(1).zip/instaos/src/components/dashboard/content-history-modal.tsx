import { useState, useEffect, useMemo, useCallback, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar } from "@/components/ui/calendar"
import { Copy, Trash2, X, Maximize2, Minimize2, Film, ImageIcon, Sparkles, PlaySquare, CalendarIcon, Filter, RotateCcw } from "lucide-react"
import { toast } from "sonner"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import { cn } from "@/lib/utils"
import { supabase } from "@/integrations/supabase/client"
import { createPortal } from "react-dom"

interface ContentHistoryItem {
  id: string
  generation_type: string
  agent_type: string
  provider: string
  model: string
  prompt: string
  result: string
  created_at: string
}

interface ContentHistoryModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

const typeLabels: Record<string, string> = {
  video: "Vídeo", reel: "Reel", carrossel: "Carrossel", post: "Post", story: "Story",
}

const typeIcons: Record<string, React.ReactNode> = {
  video: <Film className="h-4 w-4" />, reel: <PlaySquare className="h-4 w-4" />,
  carrossel: <ImageIcon className="h-4 w-4" />, post: <ImageIcon className="h-4 w-4" />,
  story: <Sparkles className="h-4 w-4" />,
}

export function ContentHistoryModal({ open, onOpenChange }: ContentHistoryModalProps) {
  const [items, setItems] = useState<ContentHistoryItem[]>([])
  const [loading, setLoading] = useState(false)
  const [expandedId, setExpandedId] = useState<string | null>(null)
  const [isMaximized, setIsMaximized] = useState(false)

  const [filterType, setFilterType] = useState<string>("all")
  const [filterProvider, setFilterProvider] = useState<string>("all")
  const [filterDateFrom, setFilterDateFrom] = useState<Date | undefined>()
  const [filterDateTo, setFilterDateTo] = useState<Date | undefined>()

  // Drag state
  const [pos, setPos] = useState({ x: 0, y: 0 })
  const dragging = useRef(false)
  const dragStart = useRef({ x: 0, y: 0 })

  const onMouseDown = useCallback((e: React.MouseEvent) => {
    if (isMaximized) return
    dragging.current = true
    dragStart.current = { x: e.clientX - pos.x, y: e.clientY - pos.y }
    const onMove = (ev: MouseEvent) => {
      if (!dragging.current) return
      setPos({ x: ev.clientX - dragStart.current.x, y: ev.clientY - dragStart.current.y })
    }
    const onUp = () => { dragging.current = false; window.removeEventListener("mousemove", onMove); window.removeEventListener("mouseup", onUp) }
    window.addEventListener("mousemove", onMove)
    window.addEventListener("mouseup", onUp)
  }, [isMaximized, pos])

  useEffect(() => {
    if (!open) return
    loadHistory()
  }, [open])

  const loadHistory = async () => {
    setLoading(true)
    const { data, error } = await supabase
      .from("generated_content")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(50)
    if (data) setItems(data as ContentHistoryItem[])
    if (error) toast.error("Erro ao carregar histórico")
    setLoading(false)
  }

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from("generated_content").delete().eq("id", id)
    if (error) {
      toast.error("Erro ao deletar")
    } else {
      setItems(prev => prev.filter(i => i.id !== id))
      toast.success("Conteúdo removido")
    }
  }

  const providers = useMemo(() => {
    const set = new Set(items.map(i => i.provider))
    return Array.from(set).sort()
  }, [items])

  const filteredItems = useMemo(() => {
    return items.filter(item => {
      if (filterType !== "all" && item.generation_type !== filterType) return false
      if (filterProvider !== "all" && item.provider !== filterProvider) return false
      const date = new Date(item.created_at)
      if (filterDateFrom && date < filterDateFrom) return false
      if (filterDateTo) {
        const end = new Date(filterDateTo)
        end.setHours(23, 59, 59, 999)
        if (date > end) return false
      }
      return true
    })
  }, [items, filterType, filterProvider, filterDateFrom, filterDateTo])

  const hasActiveFilters = filterType !== "all" || filterProvider !== "all" || filterDateFrom || filterDateTo

  const clearFilters = () => {
    setFilterType("all")
    setFilterProvider("all")
    setFilterDateFrom(undefined)
    setFilterDateTo(undefined)
  }

  if (!open) return null

  return createPortal(
    <>
      {/* Backdrop */}
      <div className="fixed inset-0 z-50 bg-black/50" onClick={() => onOpenChange(false)} />

      {/* Modal */}
      <div
        className={cn(
          "fixed z-50 flex flex-col border bg-background shadow-lg rounded-lg",
          isMaximized ? "inset-2" : "left-1/2 top-1/2 w-[90vw] max-w-2xl h-[85vh]"
        )}
        style={isMaximized ? undefined : { transform: `translate(calc(-50% + ${pos.x}px), calc(-50% + ${pos.y}px))` }}
      >
        {/* Header - draggable */}
        <div
          className="flex items-center justify-between px-4 py-3 border-b shrink-0 cursor-move select-none"
          onMouseDown={onMouseDown}
        >
          <h2 className="text-xl font-semibold">📋 Histórico de Conteúdos Gerados</h2>
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="icon" onClick={() => { setIsMaximized(!isMaximized); setPos({ x: 0, y: 0 }) }}>
              {isMaximized ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
            </Button>
            <Button variant="ghost" size="icon" onClick={() => onOpenChange(false)}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2 px-4 py-2 border-b shrink-0">
          <Filter className="h-4 w-4 text-muted-foreground shrink-0" />

          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="h-8 w-[130px] text-xs"><SelectValue placeholder="Tipo" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os tipos</SelectItem>
              {Object.entries(typeLabels).map(([val, label]) => (
                <SelectItem key={val} value={val}>{label}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={filterProvider} onValueChange={setFilterProvider}>
            <SelectTrigger className="h-8 w-[140px] text-xs"><SelectValue placeholder="Provedor" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos provedores</SelectItem>
              {providers.map(p => (
                <SelectItem key={p} value={p}>{p}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" size="sm" className={cn("h-8 text-xs gap-1.5", !filterDateFrom && "text-muted-foreground")}>
                <CalendarIcon className="h-3.5 w-3.5" />
                {filterDateFrom ? format(filterDateFrom, "dd/MM/yy") : "De"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar mode="single" selected={filterDateFrom} onSelect={setFilterDateFrom} className="p-3 pointer-events-auto" locale={ptBR} />
            </PopoverContent>
          </Popover>

          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" size="sm" className={cn("h-8 text-xs gap-1.5", !filterDateTo && "text-muted-foreground")}>
                <CalendarIcon className="h-3.5 w-3.5" />
                {filterDateTo ? format(filterDateTo, "dd/MM/yy") : "Até"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar mode="single" selected={filterDateTo} onSelect={setFilterDateTo} className="p-3 pointer-events-auto" locale={ptBR} />
            </PopoverContent>
          </Popover>

          {hasActiveFilters && (
            <Button variant="ghost" size="sm" className="h-8 text-xs gap-1" onClick={clearFilters}>
              <RotateCcw className="h-3.5 w-3.5" /> Limpar
            </Button>
          )}

          <span className="text-xs text-muted-foreground ml-auto">{filteredItems.length} resultado(s)</span>
        </div>

        {/* Scrollable content */}
        <div className="flex-1 overflow-y-auto min-h-0 px-4 py-3">
          {loading ? (
            <p className="text-center text-muted-foreground py-8">Carregando...</p>
          ) : filteredItems.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">
              {hasActiveFilters ? "Nenhum conteúdo encontrado com os filtros selecionados." : "Nenhum conteúdo gerado ainda."}
            </p>
          ) : (
            <div className="space-y-3 pb-4">
              {filteredItems.map(item => (
                <Card key={item.id} className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-2 flex-wrap">
                      {typeIcons[item.generation_type]}
                      <Badge variant="default">{typeLabels[item.generation_type] || item.generation_type}</Badge>
                      <Badge variant="outline" className="text-xs">
                        {item.provider} / {item.model.split("/").pop()?.slice(0, 25)}
                      </Badge>
                      <span className="text-xs text-muted-foreground">
                        {new Date(item.created_at).toLocaleString("pt-BR")}
                      </span>
                    </div>
                    <div className="flex gap-1 shrink-0">
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => { navigator.clipboard.writeText(item.result); toast.success("Copiado!") }}>
                        <Copy className="h-3.5 w-3.5" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => handleDelete(item.id)}>
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2 mb-1">
                    <strong>Prompt:</strong> {item.prompt.slice(0, 120)}{item.prompt.length > 120 ? "..." : ""}
                  </p>
                  <div
                    className="text-sm whitespace-pre-wrap bg-muted/50 rounded p-3 mt-2 cursor-pointer"
                    onClick={() => setExpandedId(expandedId === item.id ? null : item.id)}
                  >
                    {expandedId === item.id
                      ? item.result
                      : item.result.slice(0, 200) + (item.result.length > 200 ? "..." : "")
                    }
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </>,
    document.body
  )
}
