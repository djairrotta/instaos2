import { useMemo, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Brain, TrendingUp, Eye, Heart, MessageCircle, BarChart2, ChevronDown, ChevronUp,
  Zap, Users, Sparkles,
} from "lucide-react"
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip,
  ResponsiveContainer, PieChart, Pie, Cell, RadarChart, PolarGrid,
  PolarAngleAxis, PolarRadiusAxis, Radar, Legend,
} from "recharts"

interface ReelData {
  id: string
  caption: string
  user: string
  views: number
  likes: number
  comments: number
  engRate: number
  contentType?: string
  psychTriggers?: string[]
  viralPoints?: string[]
}

interface TriggerInsightsProps {
  meusReels: ReelData[]
  competitorReels: ReelData[]
}

const TRIGGER_META: Record<string, { label: string; icon: string; color: string }> = {
  "curiosidade": { label: "Curiosidade", icon: "🔍", color: "hsl(var(--chart-1))" },
  "urgência": { label: "Urgência", icon: "⏰", color: "hsl(var(--chart-2))" },
  "escassez": { label: "Escassez", icon: "⚡", color: "hsl(var(--chart-3))" },
  "prova social": { label: "Prova Social", icon: "👥", color: "hsl(var(--chart-4))" },
  "identificação": { label: "Identificação", icon: "🤝", color: "hsl(var(--chart-5))" },
  "contraste": { label: "Contraste", icon: "🔄", color: "hsl(var(--chart-1))" },
  "surpresa": { label: "Surpresa", icon: "😮", color: "hsl(var(--chart-2))" },
  "reciprocidade": { label: "Reciprocidade", icon: "🎁", color: "hsl(var(--chart-3))" },
  "storytelling": { label: "Storytelling", icon: "📖", color: "hsl(var(--chart-4))" },
  "polêmica": { label: "Polêmica", icon: "🔥", color: "hsl(var(--chart-5))" },
  "aspiração": { label: "Aspiração", icon: "🌟", color: "hsl(var(--chart-1))" },
  "simplicidade": { label: "Simplicidade", icon: "✨", color: "hsl(var(--chart-2))" },
  "autoridade": { label: "Autoridade", icon: "🏆", color: "hsl(var(--chart-3))" },
  "fomo": { label: "FOMO", icon: "😰", color: "hsl(var(--chart-4))" },
}

const CHART_COLORS = [
  "hsl(var(--chart-1))",
  "hsl(var(--chart-2))",
  "hsl(var(--chart-3))",
  "hsl(var(--chart-4))",
  "hsl(var(--chart-5))",
]

function normalizeTrigger(raw: string): string {
  const lower = raw.toLowerCase()
  for (const key of Object.keys(TRIGGER_META)) {
    if (lower.includes(key)) return key
  }
  return lower.split(":")[0].trim()
}

interface TriggerStats {
  trigger: string
  label: string
  icon: string
  count: number
  avgViews: number
  avgLikes: number
  avgComments: number
  avgEngRate: number
  totalViews: number
  topContent: ReelData | null
}

function computeStats(reels: ReelData[]): TriggerStats[] {
  const map: Record<string, { reels: ReelData[] }> = {}

  for (const reel of reels) {
    for (const t of reel.psychTriggers || []) {
      const key = normalizeTrigger(t)
      if (!map[key]) map[key] = { reels: [] }
      map[key].reels.push(reel)
    }
  }

  return Object.entries(map)
    .map(([trigger, { reels: items }]) => {
      const meta = TRIGGER_META[trigger] || { label: trigger, icon: "🧠", color: "hsl(var(--chart-1))" }
      const avgViews = items.reduce((s, r) => s + r.views, 0) / items.length
      const avgLikes = items.reduce((s, r) => s + r.likes, 0) / items.length
      const avgComments = items.reduce((s, r) => s + r.comments, 0) / items.length
      const avgEngRate = items.reduce((s, r) => s + r.engRate, 0) / items.length
      const totalViews = items.reduce((s, r) => s + r.views, 0)
      const topContent = [...items].sort((a, b) => b.engRate - a.engRate)[0] || null

      return {
        trigger,
        label: meta.label.charAt(0).toUpperCase() + meta.label.slice(1),
        icon: meta.icon,
        count: items.length,
        avgViews,
        avgLikes,
        avgComments,
        avgEngRate,
        totalViews,
        topContent,
      }
    })
    .sort((a, b) => b.avgEngRate - a.avgEngRate)
}

function formatNumber(num: number): string {
  if (num >= 1_000_000) return (num / 1_000_000).toFixed(1) + "M"
  if (num >= 1_000) return (num / 1_000).toFixed(1) + "K"
  return Math.round(num).toString()
}

export function TriggerInsights({ meusReels, competitorReels }: TriggerInsightsProps) {
  const [expandedTrigger, setExpandedTrigger] = useState<string | null>(null)

  const allReels = useMemo(() => [...meusReels, ...competitorReels], [meusReels, competitorReels])
  const myStats = useMemo(() => computeStats(meusReels), [meusReels])
  const compStats = useMemo(() => computeStats(competitorReels), [competitorReels])
  const allStats = useMemo(() => computeStats(allReels), [allReels])

  const hasData = allStats.length > 0

  // Chart data
  const engBarData = useMemo(() =>
    allStats.slice(0, 8).map(s => ({
      name: s.icon + " " + s.label,
      "Eng. Rate": Number(s.avgEngRate.toFixed(2)),
      "Views Médias": Math.round(s.avgViews),
    })),
    [allStats]
  )

  const pieData = useMemo(() =>
    allStats.slice(0, 8).map(s => ({
      name: s.label,
      value: s.count,
    })),
    [allStats]
  )

  const radarData = useMemo(() => {
    const triggers = [...new Set([...myStats, ...compStats].map(s => s.trigger))].slice(0, 8)
    return triggers.map(t => {
      const my = myStats.find(s => s.trigger === t)
      const comp = compStats.find(s => s.trigger === t)
      const meta = TRIGGER_META[t] || { label: t, icon: "🧠" }
      return {
        trigger: meta.label,
        "Meu Conteúdo": Number((my?.avgEngRate || 0).toFixed(2)),
        "Competidores": Number((comp?.avgEngRate || 0).toFixed(2)),
      }
    })
  }, [myStats, compStats])

  // Top 3 insights
  const topInsights = useMemo(() => {
    if (allStats.length === 0) return []
    const insights: string[] = []

    const best = allStats[0]
    if (best) insights.push(`${best.icon} **${best.label}** é o gatilho com maior engajamento médio (${best.avgEngRate.toFixed(1)}%)`)

    const mostUsed = [...allStats].sort((a, b) => b.count - a.count)[0]
    if (mostUsed && mostUsed.trigger !== best?.trigger) {
      insights.push(`${mostUsed.icon} **${mostUsed.label}** é o mais usado (${mostUsed.count} conteúdos), mas ${mostUsed.avgEngRate < best.avgEngRate ? "tem engajamento menor" : "também lidera em engajamento"}`)
    }

    const myBest = myStats[0]
    const compBest = compStats[0]
    if (myBest && compBest && myBest.trigger !== compBest.trigger) {
      insights.push(`Seu melhor gatilho é ${myBest.icon} **${myBest.label}** (${myBest.avgEngRate.toFixed(1)}%), competidores usam mais ${compBest.icon} **${compBest.label}** (${compBest.avgEngRate.toFixed(1)}%)`)
    }

    return insights
  }, [allStats, myStats, compStats])

  if (!hasData) {
    return (
      <Card className="border-border/50 p-8">
        <div className="flex flex-col items-center gap-3 text-muted-foreground">
          <Brain className="h-8 w-8" />
          <p className="text-sm">Sem dados de gatilhos psicológicos. Execute o pipeline para analisar conteúdos.</p>
        </div>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="border-border/50 p-4">
          <div className="flex items-center gap-2 mb-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
              <Brain className="h-4 w-4 text-primary" />
            </div>
            <span className="text-xs text-muted-foreground">Gatilhos Identificados</span>
          </div>
          <p className="text-2xl font-bold">{allStats.length}</p>
          <p className="text-xs text-muted-foreground mt-1">em {allReels.filter(r => (r.psychTriggers || []).length > 0).length} conteúdos</p>
        </Card>

        <Card className="border-border/50 p-4">
          <div className="flex items-center gap-2 mb-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-chart-1/10">
              <TrendingUp className="h-4 w-4 text-chart-1" />
            </div>
            <span className="text-xs text-muted-foreground">Melhor Gatilho</span>
          </div>
          <p className="text-2xl font-bold">{allStats[0]?.icon} {allStats[0]?.label}</p>
          <p className="text-xs text-muted-foreground mt-1">{allStats[0]?.avgEngRate.toFixed(1)}% eng. médio</p>
        </Card>

        <Card className="border-border/50 p-4">
          <div className="flex items-center gap-2 mb-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-chart-2/10">
              <Eye className="h-4 w-4 text-chart-2" />
            </div>
            <span className="text-xs text-muted-foreground">Maior Alcance</span>
          </div>
          {(() => {
            const best = [...allStats].sort((a, b) => b.avgViews - a.avgViews)[0]
            return (
              <>
                <p className="text-2xl font-bold">{best?.icon} {best?.label}</p>
                <p className="text-xs text-muted-foreground mt-1">{formatNumber(best?.avgViews || 0)} views médias</p>
              </>
            )
          })()}
        </Card>

        <Card className="border-border/50 p-4">
          <div className="flex items-center gap-2 mb-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-chart-3/10">
              <Users className="h-4 w-4 text-chart-3" />
            </div>
            <span className="text-xs text-muted-foreground">Mais Usado</span>
          </div>
          {(() => {
            const best = [...allStats].sort((a, b) => b.count - a.count)[0]
            return (
              <>
                <p className="text-2xl font-bold">{best?.icon} {best?.label}</p>
                <p className="text-xs text-muted-foreground mt-1">{best?.count} conteúdos</p>
              </>
            )
          })()}
        </Card>
      </div>

      {/* Insights */}
      {topInsights.length > 0 && (
        <Card className="border-border/50 p-4 bg-primary/5">
          <div className="flex items-center gap-2 mb-3">
            <Sparkles className="h-4 w-4 text-primary" />
            <h3 className="font-semibold text-sm">Insights Automáticos</h3>
          </div>
          <ul className="space-y-2">
            {topInsights.map((insight, i) => (
              <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                <span className="text-primary mt-0.5">•</span>
                <span dangerouslySetInnerHTML={{ __html: insight.replace(/\*\*(.*?)\*\*/g, '<strong class="text-foreground">$1</strong>') }} />
              </li>
            ))}
          </ul>
        </Card>
      )}

      {/* Charts */}
      <Tabs defaultValue="engagement" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="engagement" className="gap-1.5 text-xs">
            <BarChart2 className="h-3.5 w-3.5" /> Engajamento por Gatilho
          </TabsTrigger>
          <TabsTrigger value="distribution" className="gap-1.5 text-xs">
            <Zap className="h-3.5 w-3.5" /> Distribuição
          </TabsTrigger>
          <TabsTrigger value="comparison" className="gap-1.5 text-xs">
            <Users className="h-3.5 w-3.5" /> Meu vs Competidores
          </TabsTrigger>
        </TabsList>

        <TabsContent value="engagement">
          <Card className="border-border/50 p-4">
            <h3 className="text-sm font-semibold mb-4">Taxa de Engajamento Média por Gatilho Psicológico</h3>
            <ResponsiveContainer width="100%" height={350}>
              <BarChart data={engBarData} layout="vertical" margin={{ left: 20, right: 20 }}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis type="number" className="text-xs" tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }} />
                <YAxis dataKey="name" type="category" width={140} className="text-xs" tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }} />
                <RechartsTooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "8px",
                    fontSize: "12px",
                  }}
                  formatter={(value: number, name: string) => [
                    name === "Eng. Rate" ? `${value.toFixed(2)}%` : formatNumber(value),
                    name
                  ]}
                />
                <Bar dataKey="Eng. Rate" fill="hsl(var(--chart-1))" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </Card>
        </TabsContent>

        <TabsContent value="distribution">
          <Card className="border-border/50 p-4">
            <h3 className="text-sm font-semibold mb-4">Distribuição de Gatilhos nos Conteúdos</h3>
            <ResponsiveContainer width="100%" height={350}>
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  outerRadius={120}
                  innerRadius={60}
                  paddingAngle={2}
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  labelLine={false}
                >
                  {pieData.map((_, i) => (
                    <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                  ))}
                </Pie>
                <RechartsTooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "8px",
                    fontSize: "12px",
                  }}
                />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </Card>
        </TabsContent>

        <TabsContent value="comparison">
          <Card className="border-border/50 p-4">
            <h3 className="text-sm font-semibold mb-4">Engajamento: Meu Conteúdo vs Competidores</h3>
            {radarData.length > 0 ? (
              <ResponsiveContainer width="100%" height={380}>
                <RadarChart data={radarData}>
                  <PolarGrid className="stroke-border" />
                  <PolarAngleAxis dataKey="trigger" tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }} />
                  <PolarRadiusAxis tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 10 }} />
                  <Radar name="Meu Conteúdo" dataKey="Meu Conteúdo" stroke="hsl(var(--chart-1))" fill="hsl(var(--chart-1))" fillOpacity={0.3} />
                  <Radar name="Competidores" dataKey="Competidores" stroke="hsl(var(--chart-2))" fill="hsl(var(--chart-2))" fillOpacity={0.3} />
                  <Legend />
                  <RechartsTooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                      fontSize: "12px",
                    }}
                    formatter={(value: number) => [`${value.toFixed(2)}%`, ""]}
                  />
                </RadarChart>
              </ResponsiveContainer>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-8">Dados insuficientes para comparação</p>
            )}
          </Card>
        </TabsContent>
      </Tabs>

      {/* Detailed trigger cards */}
      <div className="space-y-3">
        <h3 className="text-sm font-semibold flex items-center gap-2">
          <Brain className="h-4 w-4 text-primary" />
          Ranking Detalhado de Gatilhos
        </h3>
        {allStats.map((stat, i) => {
          const isExpanded = expandedTrigger === stat.trigger
          return (
            <Card key={stat.trigger} className="border-border/50 overflow-hidden">
              <button
                className="w-full p-4 flex items-center gap-4 hover:bg-muted/30 transition-colors text-left"
                onClick={() => setExpandedTrigger(isExpanded ? null : stat.trigger)}
              >
                <div className="flex items-center justify-center h-8 w-8 rounded-lg bg-primary/10 text-lg shrink-0">
                  {stat.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-sm">#{i + 1} {stat.label}</span>
                    <Badge variant="outline" className="text-[10px] font-mono">{stat.count} conteúdos</Badge>
                  </div>
                </div>
                <div className="flex items-center gap-6 text-sm shrink-0">
                  <div className="text-center">
                    <p className="font-mono font-bold text-primary">{stat.avgEngRate.toFixed(1)}%</p>
                    <p className="text-[10px] text-muted-foreground">Eng. Rate</p>
                  </div>
                  <div className="text-center">
                    <p className="font-mono font-bold">{formatNumber(stat.avgViews)}</p>
                    <p className="text-[10px] text-muted-foreground">Views</p>
                  </div>
                  <div className="text-center">
                    <p className="font-mono font-bold">{formatNumber(stat.avgLikes)}</p>
                    <p className="text-[10px] text-muted-foreground">Likes</p>
                  </div>
                  <div className="text-center">
                    <p className="font-mono font-bold">{formatNumber(stat.avgComments)}</p>
                    <p className="text-[10px] text-muted-foreground">Coment.</p>
                  </div>
                  {isExpanded ? <ChevronUp className="h-4 w-4 text-muted-foreground" /> : <ChevronDown className="h-4 w-4 text-muted-foreground" />}
                </div>
              </button>

              {isExpanded && (
                <div className="px-4 pb-4 border-t border-border/50 pt-3 space-y-3">
                  {/* Comparison: My vs Competitors */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="rounded-lg border border-border/50 p-3">
                      <p className="text-xs font-medium text-muted-foreground mb-2">📱 Meu Conteúdo</p>
                      {(() => {
                        const my = myStats.find(s => s.trigger === stat.trigger)
                        if (!my) return <p className="text-xs text-muted-foreground">Sem dados</p>
                        return (
                          <div className="flex items-center gap-4 text-sm">
                            <span className="font-mono">{my.count} itens</span>
                            <span className="font-mono text-primary">{my.avgEngRate.toFixed(1)}% eng.</span>
                            <span className="font-mono">{formatNumber(my.avgViews)} views</span>
                          </div>
                        )
                      })()}
                    </div>
                    <div className="rounded-lg border border-border/50 p-3">
                      <p className="text-xs font-medium text-muted-foreground mb-2">🏆 Competidores</p>
                      {(() => {
                        const comp = compStats.find(s => s.trigger === stat.trigger)
                        if (!comp) return <p className="text-xs text-muted-foreground">Sem dados</p>
                        return (
                          <div className="flex items-center gap-4 text-sm">
                            <span className="font-mono">{comp.count} itens</span>
                            <span className="font-mono text-primary">{comp.avgEngRate.toFixed(1)}% eng.</span>
                            <span className="font-mono">{formatNumber(comp.avgViews)} views</span>
                          </div>
                        )
                      })()}
                    </div>
                  </div>

                  {/* Top content for this trigger */}
                  {stat.topContent && (
                    <div className="rounded-lg border border-border/50 p-3">
                      <p className="text-xs font-medium text-muted-foreground mb-1">🏅 Melhor conteúdo com este gatilho</p>
                      <p className="text-sm truncate">@{stat.topContent.user}: {stat.topContent.caption.slice(0, 120)}...</p>
                      <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1"><Eye className="h-3 w-3" />{formatNumber(stat.topContent.views)}</span>
                        <span className="flex items-center gap-1"><Heart className="h-3 w-3" />{formatNumber(stat.topContent.likes)}</span>
                        <span className="flex items-center gap-1"><MessageCircle className="h-3 w-3" />{formatNumber(stat.topContent.comments)}</span>
                        <span className="font-mono text-primary">{stat.topContent.engRate.toFixed(1)}%</span>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </Card>
          )
        })}
      </div>
    </div>
  )
}
