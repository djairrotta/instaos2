import { useState, useRef, useEffect } from "react"
import { supabase } from "@/integrations/supabase/client"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { cn } from "@/lib/utils"
import { Loader2, Send, Brain, CheckCircle2, Zap, RefreshCw } from "lucide-react"

interface Message {
  role: "architect" | "user"
  content: string
  options?: string[]
  isComplete?: boolean
}

interface SquadResult {
  name: string
  agents: { type: string; tier: string }[]
  platforms: string[]
  formats: string[]
  performanceMode: string
  autonomy: string
}

export function ArchitectChat({ onSquadCreated }: { onSquadCreated?: (squad: SquadResult) => void }) {
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [sessionId, setSessionId] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [started, setStarted] = useState(false)
  const [squadResult, setSquadResult] = useState<SquadResult | null>(null)
  const bottomRef = useRef<HTMLDivElement>(null)
  const SUPA_URL = import.meta.env.VITE_SUPABASE_URL

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  async function getSession() {
    const { data: { session } } = await supabase.auth.getSession()
    return session?.access_token
  }

  async function start() {
    setLoading(true)
    setStarted(true)
    try {
      const token = await getSession()
      const res = await fetch(`${SUPA_URL}/functions/v1/architect-agent`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ action: "start" }),
      })
      const d = await res.json()
      if (!d.success) throw new Error(d.error)
      setSessionId(d.sessionId)
      setMessages([{ role: "architect", content: d.message, options: d.options }])
    } catch (e: any) {
      toast.error(e.message)
      setStarted(false)
    } finally {
      setLoading(false)
    }
  }

  async function send(text?: string) {
    const answer = text || input.trim()
    if (!answer || !sessionId) return
    setInput("")
    setMessages(prev => [...prev, { role: "user", content: answer }])
    setLoading(true)
    try {
      const token = await getSession()
      const res = await fetch(`${SUPA_URL}/functions/v1/architect-agent`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ action: "answer", sessionId, answer }),
      })
      const d = await res.json()
      if (!d.success) throw new Error(d.error)

      if (d.phase === "complete" && d.squadConfig) {
        setSquadResult(d.squadConfig)
        setMessages(prev => [...prev, { role: "architect", content: d.message, isComplete: true }])
        onSquadCreated?.(d.squadConfig)
      } else {
        setMessages(prev => [...prev, { role: "architect", content: d.message, options: d.options }])
      }
    } catch (e: any) {
      toast.error(e.message)
    } finally {
      setLoading(false)
    }
  }

  function reset() {
    setMessages([])
    setSessionId(null)
    setStarted(false)
    setSquadResult(null)
    setInput("")
  }

  if (!started) {
    return (
      <div className="flex flex-col items-center justify-center py-12 gap-4">
        <div className="w-16 h-16 rounded-2xl bg-yellow-500/10 border border-yellow-500/30 flex items-center justify-center">
          <Brain className="w-8 h-8 text-yellow-400" />
        </div>
        <div className="text-center">
          <h3 className="font-bold text-base mb-1">Arquiteto de Squads</h3>
          <p className="text-sm text-muted-foreground max-w-sm">
            Crie um squad de agentes personalizado para qualquer nicho e plataforma em 4 perguntas
          </p>
        </div>
        <Button onClick={start} disabled={loading} className="gap-2 bg-yellow-500 hover:bg-yellow-400 text-black font-semibold">
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Brain className="w-4 h-4" />}
          Criar Novo Squad
        </Button>
      </div>
    )
  }

  return (
    <div className="flex flex-col h-full">
      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.map((msg, i) => (
          <div key={i} className={cn("flex gap-2.5", msg.role === "user" ? "justify-end" : "justify-start")}>
            {msg.role === "architect" && (
              <div className="w-7 h-7 rounded-full bg-yellow-500/20 border border-yellow-500/30 flex items-center justify-center flex-shrink-0 mt-0.5">
                <Brain className="w-3.5 h-3.5 text-yellow-400" />
              </div>
            )}
            <div className={cn(
              "max-w-[85%] rounded-2xl px-4 py-3 text-sm",
              msg.role === "architect"
                ? "bg-card border border-border text-foreground rounded-tl-sm"
                : "bg-yellow-500/20 text-foreground rounded-tr-sm border border-yellow-500/30"
            )}>
              <p className="leading-relaxed whitespace-pre-wrap">{msg.content}</p>

              {/* Options as clickable buttons */}
              {msg.options && msg.options.length > 0 && (
                <div className="mt-3 space-y-1.5">
                  {msg.options.map((opt, j) => (
                    <button key={j} onClick={() => send(String(j + 1))}
                      className="w-full text-left px-3 py-2 rounded-lg bg-muted/40 hover:bg-yellow-500/10 hover:border-yellow-500/30 border border-border text-xs transition-all">
                      {opt}
                    </button>
                  ))}
                </div>
              )}

              {/* Squad result */}
              {msg.isComplete && squadResult && (
                <div className="mt-3 rounded-xl border border-green-500/30 bg-green-500/5 p-3 space-y-2">
                  <div className="flex items-center gap-1.5 text-green-400 text-xs font-semibold">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Squad Criado com Sucesso
                  </div>
                  <div className="space-y-1 text-[10px] text-muted-foreground">
                    <p>🤖 {squadResult.agents.length} agentes configurados</p>
                    <p>📱 Plataformas: {squadResult.platforms.join(", ")}</p>
                    <p>{squadResult.performanceMode === "high" ? "🏆" : "⚡"} Modo: {squadResult.performanceMode === "high" ? "Alta Performance" : "Econômico"}</p>
                    <p>🔄 Pipeline: {squadResult.autonomy === "interactive" ? "Interativo (aprovação por etapa)" : "Autônomo"}</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}

        {loading && (
          <div className="flex gap-2.5">
            <div className="w-7 h-7 rounded-full bg-yellow-500/20 border border-yellow-500/30 flex items-center justify-center flex-shrink-0">
              <Brain className="w-3.5 h-3.5 text-yellow-400" />
            </div>
            <div className="bg-card border border-border rounded-2xl rounded-tl-sm px-4 py-3">
              <div className="flex gap-1 items-center">
                {[0,1,2].map(i => (
                  <div key={i} className="w-1.5 h-1.5 rounded-full bg-yellow-400/60 animate-pulse"
                    style={{ animationDelay: `${i * 0.2}s` }} />
                ))}
              </div>
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      {!squadResult && (
        <div className="p-3 border-t border-border flex gap-2">
          <Textarea
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send() } }}
            placeholder="Digite sua resposta..."
            rows={2}
            className="text-xs resize-none flex-1"
          />
          <Button onClick={() => send()} disabled={loading || !input.trim()} size="sm"
            className="self-end gap-1 bg-yellow-500 hover:bg-yellow-400 text-black h-9 px-3">
            <Send className="w-3.5 h-3.5" />
          </Button>
        </div>
      )}

      {squadResult && (
        <div className="p-3 border-t border-border">
          <Button onClick={reset} variant="outline" size="sm" className="w-full gap-1.5 text-xs">
            <RefreshCw className="w-3 h-3" />
            Criar Outro Squad
          </Button>
        </div>
      )}
    </div>
  )
}
