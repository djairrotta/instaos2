import { useState, useEffect } from "react"
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { supabase } from "@/integrations/supabase/client"
import { toast } from "sonner"

interface DeepScanSettings {
  max_inbox_pages: number
  max_thread_pages: number
  delay_between_pages_min: number
  delay_between_pages_max: number
  delay_between_threads_min: number
  delay_between_threads_max: number
  delay_between_links_min: number
  delay_between_links_max: number
  delay_between_profiles_min: number
  delay_between_profiles_max: number
  time_limit_seconds: number
  max_retries: number
}

const DEFAULT_SETTINGS: DeepScanSettings = {
  max_inbox_pages: 15,
  max_thread_pages: 30,
  delay_between_pages_min: 3,
  delay_between_pages_max: 7,
  delay_between_threads_min: 2,
  delay_between_threads_max: 5,
  delay_between_links_min: 1,
  delay_between_links_max: 3,
  delay_between_profiles_min: 10,
  delay_between_profiles_max: 20,
  time_limit_seconds: 350,
  max_retries: 20,
}

const SLOW_PRESET: DeepScanSettings = {
  max_inbox_pages: 10,
  max_thread_pages: 20,
  delay_between_pages_min: 7,
  delay_between_pages_max: 15,
  delay_between_threads_min: 5,
  delay_between_threads_max: 10,
  delay_between_links_min: 3,
  delay_between_links_max: 6,
  delay_between_profiles_min: 20,
  delay_between_profiles_max: 40,
  time_limit_seconds: 350,
  max_retries: 20,
}

const ULTRA_SLOW_PRESET: DeepScanSettings = {
  max_inbox_pages: 5,
  max_thread_pages: 10,
  delay_between_pages_min: 15,
  delay_between_pages_max: 30,
  delay_between_threads_min: 10,
  delay_between_threads_max: 20,
  delay_between_links_min: 5,
  delay_between_links_max: 10,
  delay_between_profiles_min: 30,
  delay_between_profiles_max: 60,
  time_limit_seconds: 350,
  max_retries: 10,
}

const EXHAUSTIVE_PRESET: DeepScanSettings = {
  max_inbox_pages: 100,
  max_thread_pages: 200,
  delay_between_pages_min: 5,
  delay_between_pages_max: 12,
  delay_between_threads_min: 3,
  delay_between_threads_max: 8,
  delay_between_links_min: 2,
  delay_between_links_max: 5,
  delay_between_profiles_min: 15,
  delay_between_profiles_max: 30,
  time_limit_seconds: 350,
  max_retries: 50,
}

interface Props {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function DeepScanSettingsModal({ open, onOpenChange }: Props) {
  const [settings, setSettings] = useState<DeepScanSettings>(DEFAULT_SETTINGS)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (!open) return
    ;(async () => {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return
      const { data } = await supabase
        .from("system_config")
        .select("config_value")
        .eq("user_id", user.id)
        .eq("config_key", "deep_scan_settings")
        .maybeSingle()
      if (data?.config_value) {
        try {
          setSettings({ ...DEFAULT_SETTINGS, ...JSON.parse(data.config_value) })
        } catch { /* use defaults */ }
      }
    })()
  }, [open])

  const handleSave = async () => {
    setLoading(true)
    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) throw new Error("Login necessário")
      await supabase.from("system_config").upsert({
        user_id: user.id,
        config_key: "deep_scan_settings",
        config_value: JSON.stringify(settings),
      }, { onConflict: "user_id,config_key" })
      toast.success("Configurações do Deep Scan salvas!")
      onOpenChange(false)
    } catch (e: any) {
      toast.error("Erro ao salvar", { description: e.message })
    } finally {
      setLoading(false)
    }
  }

  const applyPreset = (preset: DeepScanSettings) => setSettings(preset)

  const update = (key: keyof DeepScanSettings, value: number) =>
    setSettings(prev => ({ ...prev, [key]: value }))

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">⚙️ Parâmetros do Deep Scan</DialogTitle>
          <DialogDescription>
            Ajuste os delays e limites para evitar bloqueios do Instagram (429).
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-5">
          {/* Presets */}
          <div>
            <Label className="text-sm font-medium mb-2 block">Presets</Label>
            <div className="flex gap-2 flex-wrap">
              <Button variant="outline" size="sm" onClick={() => applyPreset(DEFAULT_SETTINGS)}>
                🏃 Normal
              </Button>
              <Button variant="outline" size="sm" onClick={() => applyPreset(SLOW_PRESET)}>
                🐢 Devagar
              </Button>
              <Button variant="outline" size="sm" onClick={() => applyPreset(ULTRA_SLOW_PRESET)}>
                🦥 Ultra Devagar
              </Button>
              <Button variant="outline" size="sm" className="border-destructive/50 text-destructive hover:bg-destructive/10" onClick={() => applyPreset(EXHAUSTIVE_PRESET)}>
                🐌 Exaustivo (horas)
              </Button>
            </div>
          </div>

          {/* Limits */}
          <div className="space-y-3">
            <Label className="text-sm font-semibold">Limites</Label>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs text-muted-foreground">Páginas do Inbox (máx)</Label>
                <Input type="number" min={1} max={500} value={settings.max_inbox_pages}
                  onChange={e => update("max_inbox_pages", Number(e.target.value))} />
              </div>
              <div>
                <Label className="text-xs text-muted-foreground">Páginas por Thread (máx)</Label>
                <Input type="number" min={1} max={500} value={settings.max_thread_pages}
                  onChange={e => update("max_thread_pages", Number(e.target.value))} />
              </div>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Tempo limite por perfil</Label>
              <div className="flex items-center gap-3">
                <Slider min={60} max={14400} step={60} value={[settings.time_limit_seconds]}
                  onValueChange={([v]) => update("time_limit_seconds", v)} className="flex-1" />
                <span className="text-sm font-mono w-20 text-right">
                  {settings.time_limit_seconds >= 3600 
                    ? `${Math.floor(settings.time_limit_seconds / 3600)}h${Math.floor((settings.time_limit_seconds % 3600) / 60)}m`
                    : `${Math.floor(settings.time_limit_seconds / 60)}min`}
                </span>
              </div>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Máx. de auto-retries por perfil</Label>
              <div className="flex items-center gap-3">
                <Slider min={1} max={100} step={1} value={[settings.max_retries]}
                  onValueChange={([v]) => update("max_retries", v)} className="flex-1" />
                <span className="text-sm font-mono w-12 text-right">{settings.max_retries}x</span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">Evita loop infinito se algo der errado</p>
            </div>
          </div>

          {/* Delays */}
          <div className="space-y-3">
            <Label className="text-sm font-semibold">Delays (segundos)</Label>

            <div className="rounded-md border p-3 space-y-3">
              <p className="text-xs font-medium text-muted-foreground">Entre páginas do Inbox</p>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">Mín (s)</Label>
                  <Input type="number" min={1} max={120} value={settings.delay_between_pages_min}
                    onChange={e => update("delay_between_pages_min", Number(e.target.value))} />
                </div>
                <div>
                  <Label className="text-xs">Máx (s)</Label>
                  <Input type="number" min={1} max={120} value={settings.delay_between_pages_max}
                    onChange={e => update("delay_between_pages_max", Number(e.target.value))} />
                </div>
              </div>
            </div>

            <div className="rounded-md border p-3 space-y-3">
              <p className="text-xs font-medium text-muted-foreground">Entre threads</p>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">Mín (s)</Label>
                  <Input type="number" min={1} max={120} value={settings.delay_between_threads_min}
                    onChange={e => update("delay_between_threads_min", Number(e.target.value))} />
                </div>
                <div>
                  <Label className="text-xs">Máx (s)</Label>
                  <Input type="number" min={1} max={120} value={settings.delay_between_threads_max}
                    onChange={e => update("delay_between_threads_max", Number(e.target.value))} />
                </div>
              </div>
            </div>

            <div className="rounded-md border p-3 space-y-3">
              <p className="text-xs font-medium text-muted-foreground">Entre links processados</p>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">Mín (s)</Label>
                  <Input type="number" min={1} max={120} value={settings.delay_between_links_min}
                    onChange={e => update("delay_between_links_min", Number(e.target.value))} />
                </div>
                <div>
                  <Label className="text-xs">Máx (s)</Label>
                  <Input type="number" min={1} max={120} value={settings.delay_between_links_max}
                    onChange={e => update("delay_between_links_max", Number(e.target.value))} />
                </div>
              </div>
            </div>

            <div className="rounded-md border border-primary/30 p-3 space-y-3 bg-primary/5">
              <p className="text-xs font-medium text-primary">🔄 Entre perfis (sequencial)</p>
              <p className="text-xs text-muted-foreground">Pausa entre cada perfil para evitar bloqueios</p>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">Mín (s)</Label>
                  <Input type="number" min={10} max={600} value={settings.delay_between_profiles_min}
                    onChange={e => update("delay_between_profiles_min", Number(e.target.value))} />
                </div>
                <div>
                  <Label className="text-xs">Máx (s)</Label>
                  <Input type="number" min={10} max={600} value={settings.delay_between_profiles_max}
                    onChange={e => update("delay_between_profiles_max", Number(e.target.value))} />
                </div>
              </div>
            </div>
          </div>

          <Button onClick={handleSave} disabled={loading} className="w-full">
            {loading ? "Salvando..." : "💾 Salvar Configurações"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
