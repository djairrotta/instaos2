import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { X, Save, Loader2, Tag, FileText } from "lucide-react"
import { supabase } from "@/integrations/supabase/client"
import { toast } from "sonner"

interface NicheSettingsModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function NicheSettingsModal({ open, onOpenChange }: NicheSettingsModalProps) {
  const [keywords, setKeywords] = useState<string[]>([])
  const [keywordInput, setKeywordInput] = useState("")
  const [nicheDescription, setNicheDescription] = useState("")
  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (open) loadSettings()
  }, [open])

  const loadSettings = async () => {
    setLoading(true)
    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return

      const { data: configs } = await supabase
        .from("system_config")
        .select("config_key, config_value")
        .eq("user_id", user.id)
        .in("config_key", ["niche_keywords", "niche_description"])

      for (const cfg of configs || []) {
        if (cfg.config_key === "niche_keywords") {
          setKeywords(cfg.config_value.split(",").map((k: string) => k.trim()).filter(Boolean))
        } else if (cfg.config_key === "niche_description") {
          setNicheDescription(cfg.config_value)
        }
      }
    } catch (e) {
      console.error("Error loading niche settings:", e)
    } finally {
      setLoading(false)
    }
  }

  const addKeyword = () => {
    const word = keywordInput.trim().toLowerCase()
    if (word && !keywords.includes(word)) {
      setKeywords([...keywords, word])
      setKeywordInput("")
    }
  }

  const removeKeyword = (kw: string) => {
    setKeywords(keywords.filter(k => k !== kw))
  }

  const handleSave = async () => {
    setSaving(true)
    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) throw new Error("Faça login primeiro")

      await supabase.from("system_config").upsert({
        user_id: user.id,
        config_key: "niche_keywords",
        config_value: keywords.join(", "),
      }, { onConflict: "user_id,config_key" })

      await supabase.from("system_config").upsert({
        user_id: user.id,
        config_key: "niche_description",
        config_value: nicheDescription,
      }, { onConflict: "user_id,config_key" })

      toast.success("Configurações de nicho salvas!")
      onOpenChange(false)
    } catch (e: any) {
      toast.error("Erro ao salvar", { description: e.message })
    } finally {
      setSaving(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Tag className="h-5 w-5" />
            Configurações de Nicho
          </DialogTitle>
          <DialogDescription>
            Defina seu nicho e palavras-chave para a classificação automática de relevância dos conteúdos capturados.
          </DialogDescription>
        </DialogHeader>

        {loading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <div className="space-y-6">
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <FileText className="h-4 w-4" />
                Descrição do Nicho
              </Label>
              <Textarea
                value={nicheDescription}
                onChange={(e) => setNicheDescription(e.target.value)}
                placeholder="Ex: Advocacia digital, direito trabalhista e previdenciário, com foco em conteúdo educativo para redes sociais..."
                rows={3}
              />
              <p className="text-xs text-muted-foreground">
                Descreva seu nicho de atuação. A IA usa isso para classificar a relevância dos conteúdos capturados.
              </p>
            </div>

            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Tag className="h-4 w-4" />
                Palavras-chave do Nicho
              </Label>
              <div className="flex gap-2">
                <Input
                  value={keywordInput}
                  onChange={(e) => setKeywordInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault()
                      addKeyword()
                    }
                  }}
                  placeholder="Digite uma palavra-chave e pressione Enter"
                />
                <Button variant="secondary" onClick={addKeyword} disabled={!keywordInput.trim()}>
                  Adicionar
                </Button>
              </div>
              {keywords.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-2">
                  {keywords.map((kw) => (
                    <Badge key={kw} variant="secondary" className="gap-1 px-3 py-1">
                      {kw}
                      <button onClick={() => removeKeyword(kw)} className="hover:text-destructive">
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              )}
              <p className="text-xs text-muted-foreground">
                Conteúdos que contêm essas palavras são automaticamente aprovados como relevantes.
              </p>
            </div>

            <Button onClick={handleSave} disabled={saving} className="w-full gap-2">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              Salvar Configurações
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
