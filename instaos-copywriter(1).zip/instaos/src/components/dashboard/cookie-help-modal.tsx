import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { AlertTriangle } from "lucide-react"

interface CookieHelpModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function CookieHelpModal({ open, onOpenChange }: CookieHelpModalProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl flex items-center gap-2">🍪 Como obter os Cookies do Instagram</DialogTitle>
        </DialogHeader>

        <div className="space-y-6 text-sm">
          {/* Intro */}
          <div className="rounded-lg border border-amber-500/30 bg-amber-500/5 p-4">
            <div className="flex items-start gap-2">
              <AlertTriangle className="h-5 w-5 text-amber-500 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-amber-500">Por que precisa dos cookies completos?</p>
                <p className="text-muted-foreground mt-1">
                  O Instagram exige <strong>3 cookies</strong> para acessar DMs: <code className="rounded bg-muted px-1.5 py-0.5 text-xs font-mono">sessionid</code>, <code className="rounded bg-muted px-1.5 py-0.5 text-xs font-mono">csrftoken</code> e <code className="rounded bg-muted px-1.5 py-0.5 text-xs font-mono">ds_user_id</code>. 
                  Sem todos os três, o Instagram redireciona para login.
                </p>
              </div>
            </div>
          </div>

          {/* Recommended method — Network tab */}
          <div className="space-y-4">
            <h3 className="font-bold text-base">⭐ Método Recomendado (aba Network — copia tudo de uma vez)</h3>
            <div className="space-y-3">
              <Step n={1} title="Abra o Instagram e o DevTools">
                <p>Acesse <code className="rounded bg-muted px-1.5 py-0.5 text-xs font-mono">https://www.instagram.com</code> logado e pressione <Kbd>F12</Kbd> → aba <strong>"Network"</strong> (Rede).</p>
              </Step>

              <Step n={2} title="Recarregue a página">
                <p>Pressione <Kbd>F5</Kbd> para recarregar. Várias requisições vão aparecer na lista.</p>
              </Step>

              <Step n={3} title="Clique em qualquer requisição para instagram.com">
                <p>Clique na <strong>primeira requisição</strong> da lista (geralmente <code className="rounded bg-muted px-1.5 py-0.5 text-xs font-mono">www.instagram.com</code>).</p>
              </Step>

              <Step n={4} title="Copie o valor do Cookie">
                <div className="space-y-2">
                  <p>Na aba <strong>"Headers"</strong>, procure <strong>"Request Headers"</strong> → <strong>"Cookie"</strong>.</p>
                  <p>Clique com o <strong>botão direito</strong> no valor gigante do Cookie → <strong>"Copy value"</strong>.</p>
                  <p className="text-muted-foreground">O valor copiado já contém <strong>todos os cookies</strong> necessários (sessionid, csrftoken, ds_user_id e outros).</p>
                </div>
              </Step>

              <Step n={5} title="Cole no IG OS">
                <div className="space-y-2">
                  <p>Cole o valor inteiro no campo <strong>"Atualizar Cookies"</strong> da sidebar. O sistema extrai automaticamente os 3 cookies necessários.</p>
                  <p className="text-muted-foreground">Exemplo do formato copiado:</p>
                  <div className="rounded bg-muted p-3 font-mono text-xs break-all select-all">
                    csrftoken=NOFZBn...; ds_user_id=70917...; sessionid=70917...%3AzAqw...; rur="RVA\054..."
                  </div>
                </div>
              </Step>
            </div>
          </div>

          {/* Manual method */}
          <div className="space-y-4">
            <h3 className="font-bold text-base">📋 Método Manual (Chrome / Edge / Brave)</h3>

            <div className="space-y-3">
              <Step n={1} title="Abra o Instagram no navegador">
                <p>Acesse <code className="rounded bg-muted px-1.5 py-0.5 text-xs font-mono">https://www.instagram.com</code> e faça login na sua conta normalmente.</p>
              </Step>

              <Step n={2} title="Abra o DevTools (Ferramentas de Desenvolvedor)">
                <p>Pressione <Kbd>F12</Kbd> ou <Kbd>Ctrl + Shift + I</Kbd> (Windows/Linux) ou <Kbd>Cmd + Option + I</Kbd> (Mac).</p>
              </Step>

              <Step n={3} title="Vá na aba 'Application' (Aplicação)">
                <p>No painel do DevTools, clique na aba <strong>"Application"</strong> (pode estar escondida no menu <strong>"»"</strong>).</p>
              </Step>

              <Step n={4} title="Encontre os Cookies">
                <p>No menu lateral esquerdo, expanda <strong>"Cookies"</strong> e clique em <strong>"https://www.instagram.com"</strong>.</p>
              </Step>

              <Step n={5} title="Copie os 3 cookies necessários">
                <div className="space-y-2">
                  <p>Na lista de cookies, procure e copie o <strong>nome=valor</strong> de cada um:</p>
                  <div className="rounded bg-muted p-3 font-mono text-xs break-all space-y-1">
                    <div><span className="text-green-500 font-bold">sessionid</span>=<span className="text-primary">1234567890%3AbCdEfG...</span></div>
                    <div><span className="text-green-500 font-bold">csrftoken</span>=<span className="text-primary">aBcDeFgHiJkLmN...</span></div>
                    <div><span className="text-green-500 font-bold">ds_user_id</span>=<span className="text-primary">12345678</span></div>
                  </div>
                  <p className="text-muted-foreground">Junte tudo num formato assim e cole no IG OS:</p>
                  <div className="rounded bg-muted p-2 font-mono text-xs break-all">
                    sessionid=VALOR; csrftoken=VALOR; ds_user_id=VALOR
                  </div>
                </div>
              </Step>
            </div>
          </div>

          {/* Firefox */}
          <div className="space-y-4">
            <h3 className="font-bold text-base">🦊 Para Firefox</h3>
            <p className="text-muted-foreground">
              O processo é idêntico, mas a aba se chama <strong>"Storage"</strong> (Armazenamento) em vez de "Application".
            </p>
          </div>

          {/* Cookie extensions */}
          <div className="space-y-4">
            <h3 className="font-bold text-base">🧩 Usando Extensões (mais fácil)</h3>
            <p className="text-muted-foreground">
              Instale uma extensão de cookies no Chrome como:
            </p>
            <ul className="list-disc pl-6 text-muted-foreground space-y-1">
              <li><strong>EditThisCookie</strong> — permite ver e copiar cookies facilmente</li>
              <li><strong>Cookie Editor</strong> — interface limpa para gerenciar cookies</li>
              <li><strong>Get cookies.txt</strong> — exporta todos os cookies de uma vez</li>
            </ul>
            <p className="text-muted-foreground">
              Com a extensão, copie os valores de <code className="text-xs rounded bg-muted px-1 py-0.5 font-mono">sessionid</code>, <code className="text-xs rounded bg-muted px-1 py-0.5 font-mono">csrftoken</code> e <code className="text-xs rounded bg-muted px-1 py-0.5 font-mono">ds_user_id</code> e junte no formato: <code className="text-xs rounded bg-muted px-1 py-0.5 font-mono">sessionid=X; csrftoken=Y; ds_user_id=Z</code>
            </p>
          </div>

          {/* Important notes */}
          <div className="rounded-lg border border-destructive/30 bg-destructive/5 p-4 space-y-2">
            <p className="font-semibold text-destructive flex items-center gap-2">⚠️ Avisos Importantes</p>
            <ul className="list-disc pl-6 text-muted-foreground space-y-1.5">
              <li>Os cookies <strong>expiram periodicamente</strong> (geralmente a cada 24-48h). Quando expirarem, repita o processo.</li>
              <li><strong>Não compartilhe</strong> seus cookies com ninguém — eles dão acesso completo à sua conta.</li>
              <li>Se você <strong>fizer logout</strong> do Instagram no navegador, os cookies serão invalidados.</li>
              <li>Use preferencialmente um <strong>navegador secundário</strong> onde mantenha o Instagram logado sem usar.</li>
              <li>Os cookies são armazenados de forma <strong>criptografada</strong> no backend do IG OS.</li>
              <li>O <strong>método via Console</strong> (recomendado) já copia os 3 cookies necessários de uma vez!</li>
            </ul>
          </div>

          {/* Troubleshooting */}
          <div className="space-y-3">
            <h3 className="font-bold text-base">🔧 Problemas Comuns</h3>
            <div className="space-y-2">
              <div className="flex items-start gap-2">
                <Badge variant="outline" className="shrink-0 mt-0.5">Erro</Badge>
                <div>
                  <p className="font-medium">"Cookie expirado — o Instagram redirecionou para login"</p>
                  <p className="text-muted-foreground">Certifique-se de que copiou os <strong>3 cookies</strong> (sessionid, csrftoken, ds_user_id). Apenas o sessionid não é suficiente. Use o método via Console para copiar todos de uma vez.</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <Badge variant="outline" className="shrink-0 mt-0.5">Erro</Badge>
                <div>
                  <p className="font-medium">Cookie continua aparecendo como "Expirado"</p>
                  <p className="text-muted-foreground">Faça logout e login novamente no Instagram, depois copie os cookies frescos usando o comando do Console.</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <Badge variant="outline" className="shrink-0 mt-0.5">Erro</Badge>
                <div>
                  <p className="font-medium">Não encontro o cookie "csrftoken" ou "ds_user_id"</p>
                  <p className="text-muted-foreground">Esses cookies são definidos ao navegar pelo site. Tente recarregar a página do Instagram e abrir os cookies novamente. O método via Console é mais confiável.</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <Badge variant="outline" className="shrink-0 mt-0.5">Erro</Badge>
                <div>
                  <p className="font-medium">Erro 429 ao capturar DMs</p>
                  <p className="text-muted-foreground">O Instagram está limitando as requisições. Aguarde 2-4 horas antes de tentar novamente.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

function Step({ n, title, children }: { n: number; title: string; children?: React.ReactNode }) {
  return (
    <div className="flex gap-3">
      <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs font-bold">
        {n}
      </div>
      <div className="flex-1 pt-0.5">
        <p className="font-semibold">{title}</p>
        {children && <div className="mt-1 text-muted-foreground">{children}</div>}
      </div>
    </div>
  )
}

function Kbd({ children }: { children: React.ReactNode }) {
  return (
    <kbd className="rounded border border-border bg-muted px-1.5 py-0.5 text-xs font-mono font-semibold">
      {children}
    </kbd>
  )
}
