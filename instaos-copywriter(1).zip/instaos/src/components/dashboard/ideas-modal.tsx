import { useState, useEffect, useCallback, useMemo } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Lightbulb, Loader2, Trash2, RefreshCw, Maximize2, Minimize2, X, Sparkles, Copy, Filter } from "lucide-react"
import { toast } from "sonner"
import { supabase } from "@/integrations/supabase/client"

interface IdeasModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

interface Idea {
  id: string
  title: string
  description: string
  format: string
  hook: string
  psychological_trigger: string
  inspired_by: string
  createdAt: string
}

export function IdeasModal({ open, onOpenChange }: IdeasModalProps) {
  const [ideas, setIdeas] = useState<Idea[]>([])
  const [loading, setLoading] = useState(false)
  const [generating, setGenerating] = useState(false)
  const [isMaximized, setIsMaximized] = useState(false)
  const [deleting, setDeleting] = useState<string | null>(null)
  const [filterFormat, setFilterFormat] = useState<string>("all")
  const [filterTrigger, setFilterTrigger] = useState<string>("all")
  const [filterSource, setFilterSource] = useState<string>("all")

  const minioPath = useCallback(async () => {
    const { data: { user } } = await supabase.auth.getUser()
    return user ? `ideas/${user.id}/ideas.json` : null
  }, [])

  const loadIdeas = useCallback(async () => {
    setLoading(true)
    try {
      const path = await minioPath()
      if (!path) return
      const { data } = await supabase.functions.invoke("save-to-minio", {
        body: { action: "get", path },
      })
      if (data?.success && data.content) {
        const parsed = JSON.parse(data.content)
        setIdeas(Array.isArray(parsed) ? parsed : [])
      }
    } catch {
      // No ideas yet
    } finally {
      setLoading(false)
    }
  }, [minioPath])

  const saveIdeas = useCallback(async (newIdeas: Idea[]) => {
    const path = await minioPath()
    if (!path) return
    await supabase.functions.invoke("save-to-minio", {
      body: { action: "save", path, data: newIdeas },
    })
  }, [minioPath])

  useEffect(() => {
    if (open) loadIdeas()
  }, [open, loadIdeas])

  const handleGenerate = async () => {
    setGenerating(true)
    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) throw new Error("Faça login")

      // Gather context from DB + DM-captured content from MinIO
      const [compRes, reelsRes, stratRes, compReelsRes, dmIdeasRes] = await Promise.all([
        supabase.from("competidores").select("name, niche, bio, followers_count").eq("user_id", user.id).eq("status", true).limit(10),
        supabase.from("meus_reels").select("caption, hook_analysis, views, eng_rate, content_type").eq("user_id", user.id).order("views", { ascending: false }).limit(10),
        supabase.from("estrategias").select("title, key_takeaway").eq("user_id", user.id).order("created_at", { ascending: false }).limit(3),
        supabase.from("reels_competidores").select("caption, hook_analysis, views, eng_rate, content_type, owner_username, viral_points, psychological_triggers").eq("user_id", user.id).order("views", { ascending: false }).limit(20),
        supabase.functions.invoke("save-to-minio", {
          body: { action: "get", path: `kanban/${user.id}/board.json` },
        }).catch(() => ({ data: null })),
      ])

      // Extract DM-sourced content from kanban
      let dmContext = ""
      try {
        if (dmIdeasRes?.data?.success && dmIdeasRes.data.content) {
          const board = JSON.parse(dmIdeasRes.data.content)
          const allCards = Object.values(board.columns || {}).flatMap((col: any) => col.cards || [])
          const dmCards = allCards.filter((c: any) => c.source === "dm" || c.title?.includes("DM")).slice(0, 10)
          if (dmCards.length > 0) {
            dmContext = "CONTEÚDOS CAPTURADOS VIA DM (links enviados pelo usuário):\n" + dmCards.map((c: any) => `- ${c.title}: ${c.description?.slice(0, 120) || ""}`).join("\n") + "\n\n"
          }
        }
      } catch { /* no DM content */ }

      const nicho = compRes.data?.map(c => c.niche).filter(Boolean).join(", ") || "não identificado"

      let context = `Você é um especialista em criação de conteúdo para Instagram no nicho: ${nicho}.

REGRAS OBRIGATÓRIAS:
- As ideias DEVEM ser baseadas EXCLUSIVAMENTE nos conteúdos dos competidores analisados abaixo e nos conteúdos capturados via DM
- Analise os hooks, gatilhos psicológicos e padrões virais dos competidores e crie variações adaptadas
- NÃO gere ideias genéricas. Cada ideia deve referenciar um padrão ou tema específico encontrado nos dados
- Adapte o que está funcionando para os competidores ao estilo e nicho do usuário

`
      if (compRes.data?.length) {
        context += "COMPETIDORES MONITORADOS:\n" + compRes.data.map(c => `- @${c.name} (${c.niche || "sem nicho"}, ${c.followers_count || 0} seguidores): ${c.bio || ""}`).join("\n") + "\n\n"
      }
      if (compReelsRes.data?.length) {
        context += "CONTEÚDOS DOS COMPETIDORES QUE ESTÃO VIRALIZANDO:\n" + compReelsRes.data.map(r => `- [@${r.owner_username || "?"}] [${r.content_type}] ${r.caption?.slice(0, 150) || "sem legenda"} (${r.views || 0} views, eng: ${Number(r.eng_rate || 0).toFixed(1)}%) Hook: ${r.hook_analysis?.slice(0, 100) || "N/A"} | Viral: ${r.viral_points?.slice(0, 100) || "N/A"} | Gatilhos: ${r.psychological_triggers?.slice(0, 100) || "N/A"}`).join("\n") + "\n\n"
      }
      if (dmContext) {
        context += dmContext
      }
      if (reelsRes.data?.length) {
        context += "MEUS TOP CONTEÚDOS (referência de estilo):\n" + reelsRes.data.map(r => `- [${r.content_type}] ${r.caption?.slice(0, 80) || "sem legenda"} (${r.views || 0} views, eng: ${Number(r.eng_rate || 0).toFixed(1)}%) Hook: ${r.hook_analysis?.slice(0, 60) || "N/A"}`).join("\n") + "\n\n"
      }
      if (stratRes.data?.length) {
        context += "ÚLTIMAS ESTRATÉGIAS:\n" + stratRes.data.map(s => `- ${s.title}: ${s.key_takeaway || ""}`).join("\n") + "\n\n"
      }

      context += `\nGere 5 ideias. Para CADA ideia retorne em JSON array com objetos: { "title": "título curto e específico ao nicho", "description": "descrição de 2-3 frases explicando a ideia baseada no padrão identificado do competidor", "format": "reel|post|carrossel|story", "hook": "gancho sugerido inspirado nos hooks que estão viralizando", "psychological_trigger": "gatilho psicológico principal usado (ex: curiosidade, urgência, prova social, autoridade, escassez, reciprocidade)", "inspired_by": "fonte de inspiração: @username do competidor específico ou 'DM' se baseado em conteúdo capturado via DM — seja específico, cite o @ do competidor cujo conteúdo inspirou esta ideia" }\nRetorne APENAS o JSON array, sem markdown.`

      // Use agent config if available
      const { data: agentConfig } = await supabase.from("agent_configs")
        .select("provider, model, custom_prompt")
        .eq("user_id", user.id).eq("agent_type", "idea_generator").maybeSingle()

      const { data, error } = await supabase.functions.invoke("generate-content", {
        body: {
          agent: "idea_generator",
          context,
          provider: agentConfig?.provider || "groq",
          model: agentConfig?.model || "llama-3.3-70b-versatile",
          custom_prompt: agentConfig?.custom_prompt || undefined,
        },
      })

      if (error) throw error
      if (!data?.success) throw new Error(data?.error || "Falha na geração")

      // Parse the result
      let newIdeas: Idea[] = []
      try {
        const cleaned = data.result.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim()
        const parsed = JSON.parse(cleaned)
        newIdeas = (Array.isArray(parsed) ? parsed : []).map((item: any, i: number) => ({
          id: `idea-${Date.now()}-${i}`,
          title: item.title || `Ideia ${i + 1}`,
          description: item.description || "",
          format: item.format || "reel",
          hook: item.hook || "",
          psychological_trigger: item.psychological_trigger || "",
          inspired_by: item.inspired_by || "",
          createdAt: new Date().toISOString(),
        }))
      } catch {
        newIdeas = [{
          id: `idea-${Date.now()}`,
          title: "Ideia gerada",
          description: data.result.slice(0, 300),
          format: "reel",
          hook: "",
          psychological_trigger: "",
          inspired_by: "",
          createdAt: new Date().toISOString(),
        }]
      }

      const updatedIdeas = [...newIdeas, ...ideas]
      setIdeas(updatedIdeas)
      await saveIdeas(updatedIdeas)
      toast.success(`${newIdeas.length} ideias geradas!`)
    } catch (e: any) {
      toast.error("Erro ao gerar ideias", { description: e.message })
    } finally {
      setGenerating(false)
    }
  }

  const handleDelete = async (id: string) => {
    setDeleting(id)
    try {
      const updated = ideas.filter(i => i.id !== id)
      setIdeas(updated)
      await saveIdeas(updated)
      toast.success("Ideia removida")
    } catch (e: any) {
      toast.error("Erro ao remover", { description: e.message })
    } finally {
      setDeleting(null)
    }
  }

  const handleClearAll = async () => {
    try {
      setIdeas([])
      const path = await minioPath()
      if (path) {
        await supabase.functions.invoke("save-to-minio", {
          body: { action: "delete", path },
        })
      }
      toast.success("Todas as ideias removidas")
    } catch (e: any) {
      toast.error("Erro", { description: e.message })
    }
  }

  const formatLabels: Record<string, string> = {
    reel: "🎬 Reel", post: "📷 Post", carrossel: "🎠 Carrossel", story: "📱 Story",
  }

  // Derive unique filter options
  const triggerOptions = useMemo(() => {
    const set = new Set(ideas.map(i => i.psychological_trigger).filter(Boolean))
    return Array.from(set).sort()
  }, [ideas])

  const sourceOptions = useMemo(() => {
    const set = new Set(ideas.map(i => i.inspired_by).filter(Boolean))
    return Array.from(set).sort()
  }, [ideas])

  const filteredIdeas = useMemo(() => {
    return ideas.filter(idea => {
      if (filterFormat !== "all" && idea.format !== filterFormat) return false
      if (filterTrigger !== "all" && idea.psychological_trigger !== filterTrigger) return false
      if (filterSource !== "all" && idea.inspired_by !== filterSource) return false
      return true
    })
  }, [ideas, filterFormat, filterTrigger, filterSource])

  const hasActiveFilters = filterFormat !== "all" || filterTrigger !== "all" || filterSource !== "all"

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        showCloseButton={false}
        className={`${isMaximized ? "!max-w-[95vw] !max-h-[95vh] !w-[95vw] !h-[95vh]" : "max-w-2xl !h-[85vh]"} flex flex-col gap-0 p-0 overflow-hidden`}
      >
        <DialogHeader className="px-5 py-4 border-b border-border shrink-0">
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle className="flex items-center gap-2 text-lg">
                <Lightbulb className="h-5 w-5 text-amber-500" /> Banco de Ideias
              </DialogTitle>
              <DialogDescription className="text-xs">
                Ideias geradas com IA baseadas nos seus dados. Persistidas no MinIO.
              </DialogDescription>
            </div>
            <div className="flex items-center gap-1">
              <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setIsMaximized(!isMaximized)}>
                {isMaximized ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
              </Button>
              <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onOpenChange(false)}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </DialogHeader>

        <div className="px-5 py-3 border-b border-border flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <Button onClick={handleGenerate} disabled={generating} size="sm" className="gap-2">
              {generating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
              {generating ? "Gerando..." : "Gerar Ideias com IA"}
            </Button>
            <Button variant="ghost" size="sm" onClick={loadIdeas} disabled={loading}>
              <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
            </Button>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="text-xs">{filteredIdeas.length}/{ideas.length} ideias</Badge>
            {ideas.length > 0 && (
              <Button variant="ghost" size="sm" className="text-xs text-destructive hover:text-destructive" onClick={handleClearAll}>
                <Trash2 className="h-3 w-3 mr-1" /> Limpar tudo
              </Button>
            )}
          </div>
        </div>

        {/* Filters */}
        {ideas.length > 0 && (
          <div className="px-5 py-2 border-b border-border flex items-center gap-2 flex-wrap shrink-0">
            <Filter className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
            <Select value={filterFormat} onValueChange={setFilterFormat}>
              <SelectTrigger className="h-7 w-[130px] text-xs">
                <SelectValue placeholder="Formato" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos formatos</SelectItem>
                <SelectItem value="reel">🎬 Reel</SelectItem>
                <SelectItem value="post">📷 Post</SelectItem>
                <SelectItem value="carrossel">🎠 Carrossel</SelectItem>
                <SelectItem value="story">📱 Story</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterTrigger} onValueChange={setFilterTrigger}>
              <SelectTrigger className="h-7 w-[160px] text-xs">
                <SelectValue placeholder="Gatilho" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos gatilhos</SelectItem>
                {triggerOptions.map(t => (
                  <SelectItem key={t} value={t}>{t}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterSource} onValueChange={setFilterSource}>
              <SelectTrigger className="h-7 w-[150px] text-xs">
                <SelectValue placeholder="Fonte" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas fontes</SelectItem>
                {sourceOptions.map(s => (
                  <SelectItem key={s} value={s}>{s.toLowerCase().includes("dm") ? `📩 ${s}` : `👤 ${s}`}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {hasActiveFilters && (
              <Button variant="ghost" size="sm" className="h-7 text-xs px-2" onClick={() => { setFilterFormat("all"); setFilterTrigger("all"); setFilterSource("all") }}>
                <X className="h-3 w-3 mr-1" /> Limpar filtros
              </Button>
            )}
          </div>
        )}

        <ScrollArea className="flex-1 min-h-0">
          <div className="p-5 space-y-3">
            {loading && ideas.length === 0 ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              </div>
            ) : ideas.length === 0 ? (
              <div className="text-center py-12">
                <Lightbulb className="h-12 w-12 mx-auto mb-4 text-muted-foreground/30" />
                <p className="text-sm font-medium text-muted-foreground">Nenhuma ideia salva</p>
                <p className="text-xs text-muted-foreground mt-1">Clique em "Gerar Ideias com IA" para criar sugestões baseadas nos seus dados</p>
              </div>
            ) : filteredIdeas.length === 0 ? (
              <div className="text-center py-12">
                <Filter className="h-10 w-10 mx-auto mb-3 text-muted-foreground/30" />
                <p className="text-sm font-medium text-muted-foreground">Nenhuma ideia com esses filtros</p>
                <p className="text-xs text-muted-foreground mt-1">Tente ajustar os filtros acima</p>
              </div>
            ) : (
              filteredIdeas.map((idea) => (
                <Card key={idea.id} className="p-4 space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <Badge variant="outline" className="text-xs">{formatLabels[idea.format] || idea.format}</Badge>
                        {idea.inspired_by && (
                          <Badge variant="secondary" className="text-xs gap-1">
                            {idea.inspired_by.toLowerCase().includes("dm") ? "📩" : "👤"} {idea.inspired_by}
                          </Badge>
                        )}
                        <span className="font-medium text-sm">{idea.title}</span>
                      </div>
                      <p className="text-sm text-muted-foreground">{idea.description}</p>
                      {idea.hook && (
                        <p className="text-xs mt-2 text-primary/80 italic">🪝 Hook: "{idea.hook}"</p>
                      )}
                      {idea.psychological_trigger && (
                        <p className="text-xs mt-1 text-amber-600 dark:text-amber-400">🧠 Gatilho: {idea.psychological_trigger}</p>
                      )}
                      <p className="text-[10px] text-muted-foreground mt-2">
                        {new Date(idea.createdAt).toLocaleDateString("pt-BR", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}
                      </p>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => {
                        navigator.clipboard.writeText(`${idea.title}\n${idea.description}\nHook: ${idea.hook}\nGatilho: ${idea.psychological_trigger}\nInspirado por: ${idea.inspired_by}`)
                        toast.success("Copiado!")
                      }}>
                        <Copy className="h-3.5 w-3.5" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:text-destructive"
                        onClick={() => handleDelete(idea.id)} disabled={deleting === idea.id}>
                        {deleting === idea.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Trash2 className="h-3.5 w-3.5" />}
                      </Button>
                    </div>
                  </div>
                </Card>
              ))
            )}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  )
}
