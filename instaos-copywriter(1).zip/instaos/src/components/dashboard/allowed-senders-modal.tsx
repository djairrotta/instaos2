import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { toast } from "sonner"
import { supabase } from "@/integrations/supabase/client"
import { UserPlus, Trash2, ShieldCheck } from "lucide-react"

interface AllowedSender {
  id: string
  ig_username: string
  note: string | null
  is_active: boolean
  created_at: string
}

interface AllowedSendersModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function AllowedSendersModal({ open, onOpenChange }: AllowedSendersModalProps) {
  const [senders, setSenders] = useState<AllowedSender[]>([])
  const [newUsername, setNewUsername] = useState("")
  const [newNote, setNewNote] = useState("")
  const [loading, setLoading] = useState(false)

  const loadSenders = async () => {
    const { data, error } = await supabase
      .from("allowed_senders")
      .select("*")
      .order("created_at", { ascending: false })
    if (data) setSenders(data as AllowedSender[])
    if (error) console.error(error)
  }

  useEffect(() => {
    if (open) loadSenders()
  }, [open])

  const handleAdd = async () => {
    if (!newUsername.trim()) return
    setLoading(true)
    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) throw new Error("Não autenticado")

      const username = newUsername.trim().replace("@", "").toLowerCase()
      const { error } = await supabase.from("allowed_senders").insert({
        user_id: user.id,
        ig_username: username,
        note: newNote.trim() || null,
      })
      if (error) {
        if (error.code === "23505") {
          toast.error("Usuário já está na lista!")
        } else {
          throw error
        }
      } else {
        toast.success(`@${username} adicionado à lista!`)
        setNewUsername("")
        setNewNote("")
        await loadSenders()
      }
    } catch (e: any) {
      toast.error("Erro ao adicionar", { description: e.message })
    } finally {
      setLoading(false)
    }
  }

  const handleToggle = async (id: string, isActive: boolean) => {
    const { error } = await supabase
      .from("allowed_senders")
      .update({ is_active: !isActive })
      .eq("id", id)
    if (error) {
      toast.error("Erro ao atualizar")
    } else {
      await loadSenders()
    }
  }

  const handleDelete = async (id: string, username: string) => {
    const { error } = await supabase.from("allowed_senders").delete().eq("id", id)
    if (error) {
      toast.error("Erro ao remover")
    } else {
      toast.success(`@${username} removido`)
      await loadSenders()
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-primary" />
            Usuários Autorizados (DM Bot)
          </DialogTitle>
        </DialogHeader>

        <p className="text-sm text-muted-foreground">
          O bot só responderá e processará reels enviados por esses usuários via DM.
        </p>

        {/* Add new sender */}
        <div className="flex flex-col gap-2 mt-2">
          <div className="flex gap-2">
            <Input
              placeholder="@username"
              value={newUsername}
              onChange={(e) => setNewUsername(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleAdd()}
              className="flex-1"
            />
            <Button onClick={handleAdd} disabled={loading || !newUsername.trim()} size="sm">
              <UserPlus className="h-4 w-4 mr-1" /> Adicionar
            </Button>
          </div>
          <Input
            placeholder="Nota (opcional) - ex: 'Sócio', 'Minha conta'"
            value={newNote}
            onChange={(e) => setNewNote(e.target.value)}
            className="text-sm"
          />
        </div>

        {/* Sender list */}
        <div className="mt-4 space-y-2 max-h-[300px] overflow-y-auto">
          {senders.length === 0 && (
            <p className="text-sm text-muted-foreground text-center py-4">
              Nenhum usuário autorizado. Adicione acima.
            </p>
          )}
          {senders.map((s) => (
            <div key={s.id} className="flex items-center justify-between rounded-lg border border-border p-3">
              <div className="flex items-center gap-3">
                <Switch
                  checked={s.is_active}
                  onCheckedChange={() => handleToggle(s.id, s.is_active)}
                />
                <div>
                  <span className="font-medium">@{s.ig_username}</span>
                  {s.note && (
                    <Badge variant="secondary" className="ml-2 text-xs">{s.note}</Badge>
                  )}
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 text-destructive hover:text-destructive"
                onClick={() => handleDelete(s.id, s.ig_username)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  )
}
