import { useState, useCallback, useRef, useEffect, useMemo } from "react"
import JSZip from "jszip"
import ReactMarkdown from "react-markdown"
import { MarkdownWithImages, extractImageSources } from "./markdown-with-images"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Sparkles, Upload, X, FileText, ImageIcon, Film, Loader2, Copy, ExternalLink, Maximize2, Minimize2, Send, Users, BarChart3, Lightbulb, Mic, Clapperboard, User, Download, PenLine } from "lucide-react"
import { toast } from "sonner"
import { cn } from "@/lib/utils"
import { PublishModal } from "./publish-modal"
import { supabase } from "@/integrations/supabase/client"
import { N8N_DEFAULTS } from "./agent-settings-modal"

export type GenerationType = "video" | "carrossel" | "post" | "story" | "reel" | "script" | "copy"

interface PrefilledData {
  hookAnalysis?: string
  transcript?: string
  caption?: string
  viralPoints?: string
  psychTriggers?: string
  relevanceReason?: string
  ownerUsername?: string
  contentType?: string
  url?: string
}

interface AiGenerationModalProps {
  open: boolean; onOpenChange: (open: boolean) => void
  generationType: GenerationType | null
  prefilledData?: PrefilledData
}

interface UploadedFile { id: string; name: string; size: number; type: string; preview?: string }
interface AnalyzedContent { id: string; type: "competidor" | "meu-reel" | "reel-competidor" | "estrategia" | "paradigma-voz" | "paradigma-face" | "paradigma-corpo" | "paradigma-estilo" | "paradigma-ref"; title: string; content: string; source?: string }

// Map generation type to agent type
const generationToAgent: Record<GenerationType, string> = {
  video: "video_generator",
  reel: "reel_creator",
  carrossel: "image_creator",
  post: "caption_writer",
  story: "story_creator",
  script: "script_writer",
  copy: "copywriter",
}

// Agent type display labels (matching Agentes IA menu)
const agentTypeLabels: Record<string, string> = {
  video_generator: "Gerador de Vídeo",
  reel_creator: "Criador de Reel",
  image_creator: "Criador de Imagem",
  caption_writer: "Legendas",
  story_creator: "Stories",
  script_writer: "Roteirista",
  copywriter: "Copywriter",
}

const generationTypeLabels: Record<GenerationType, string> = { video: "Video", carrossel: "Carrossel", post: "Post", story: "Story", reel: "Reel", script: "Roteiro", copy: "Copy" }
const generationTypeIcons: Record<GenerationType, React.ReactNode> = {
  video: <Film className="h-5 w-5" />, carrossel: <ImageIcon className="h-5 w-5" />,
  post: <ImageIcon className="h-5 w-5" />, story: <Sparkles className="h-5 w-5" />, reel: <Film className="h-5 w-5" />,
  script: <FileText className="h-5 w-5" />, copy: <Copy className="h-5 w-5" />,
}

export function AiGenerationModal({ open, onOpenChange, generationType, prefilledData }: AiGenerationModalProps) {
  const [prompt, setPrompt] = useState("")

  // Update prompt when prefilledData changes (e.g. clicking "Criar Conteúdo Como" buttons)
  useEffect(() => {
    if (!open || !prefilledData) return
    const hasData = prefilledData.hookAnalysis || prefilledData.transcript || prefilledData.caption
    if (!hasData) return
    const parts: string[] = []
    parts.push(`Crie um conteúdo baseado nesta postagem${prefilledData.ownerUsername ? ` de @${prefilledData.ownerUsername}` : ""}:`)
    if (prefilledData.caption) parts.push(`\nCaption: ${prefilledData.caption}`)
    if (prefilledData.hookAnalysis) parts.push(`\nHook: ${prefilledData.hookAnalysis}`)
    if (prefilledData.transcript) parts.push(`\nTranscrição: ${prefilledData.transcript}`)
    if (prefilledData.viralPoints) parts.push(`\nPontos Virais: ${prefilledData.viralPoints}`)
    if (prefilledData.psychTriggers) parts.push(`\nGatilhos Psicológicos: ${prefilledData.psychTriggers}`)
    if (prefilledData.relevanceReason) parts.push(`\nMotivo da Classificação: ${prefilledData.relevanceReason}`)
    setPrompt(parts.join(""))
    setChatMessages([])
    setGeneratedResult(null)
    setGeneratedCaption(null)
    setFollowUpPrompt("")
  }, [open, prefilledData])
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([])
  const [selectedContent, setSelectedContent] = useState<string[]>([])
  const [isGenerating, setIsGenerating] = useState(false)
  const [isDragging, setIsDragging] = useState(false)
  const [generatedResult, setGeneratedResult] = useState<string | null>(null)
  const [chatMessages, setChatMessages] = useState<Array<{ role: "user" | "assistant"; content: string }>>([])
  const [followUpPrompt, setFollowUpPrompt] = useState("")
  const [showPublishModal, setShowPublishModal] = useState(false)
  const [isMaximized, setIsMaximized] = useState(false)
  const [sendingToQueue, setSendingToQueue] = useState(false)
  const [agentConfig, setAgentConfig] = useState<{ provider: string; model: string; custom_prompt?: string; custom_prompt_2?: string; custom_prompt_3?: string } | null>(null)
  const [analyzedContent, setAnalyzedContent] = useState<AnalyzedContent[]>([])
  const [loadingContent, setLoadingContent] = useState(false)
  const [minioFiles, setMinioFiles] = useState<Array<{ name: string; path: string; size: number }>>([])
  const [loadingMinioFiles, setLoadingMinioFiles] = useState(false)
  const [clearingMemory, setClearingMemory] = useState(false)
  const [generatedCaption, setGeneratedCaption] = useState<string | null>(null)
  const [generatingCaption, setGeneratingCaption] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Load agent config + real reference content
  useEffect(() => {
    if (!open || !generationType) return
    const loadData = async () => {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return

      // Agent config
      const agentType = generationToAgent[generationType]
      const { data: configData } = await supabase.from("agent_configs").select("provider, model, custom_prompt, custom_prompt_2, custom_prompt_3").eq("user_id", user.id).eq("agent_type", agentType).maybeSingle()
      if (configData) {
        setAgentConfig({ provider: configData.provider, model: configData.model, custom_prompt: configData.custom_prompt || "", custom_prompt_2: (configData as any).custom_prompt_2 || "", custom_prompt_3: (configData as any).custom_prompt_3 || "" })
      } else {
        // Use defaults from agent settings when no config saved in DB
        const defaults = N8N_DEFAULTS[agentType]
        if (defaults) {
          setAgentConfig({ provider: defaults.provider, model: defaults.model })
        } else {
          setAgentConfig(null)
        }
      }

      // Load real reference content
      setLoadingContent(true)
      try {
        const items: AnalyzedContent[] = []

        // Competidores
        const { data: comps } = await supabase.from("competidores").select("id, name, page_url, niche, bio, followers_count").eq("user_id", user.id).eq("status", true).limit(20)
        comps?.forEach(c => items.push({
          id: `comp-${c.id}`, type: "competidor", title: `@${c.name}`,
          content: [c.bio, c.niche ? `Nicho: ${c.niche}` : null, c.followers_count ? `${c.followers_count.toLocaleString()} seguidores` : null].filter(Boolean).join(" | "),
          source: c.page_url,
        }))

        // Reels dos competidores (top por engajamento)
        const { data: compReels } = await supabase.from("reels_competidores").select("id, caption, owner_username, url, hook_analysis, transcript, views, eng_rate").eq("user_id", user.id).order("eng_rate", { ascending: false }).limit(20)
        compReels?.forEach(r => items.push({
          id: `cr-${r.id}`, type: "reel-competidor", title: r.caption?.slice(0, 60) || `Reel de @${r.owner_username}`,
          content: [r.hook_analysis ? `Hook: ${r.hook_analysis.slice(0, 100)}` : null, r.transcript ? `Transcript: ${r.transcript.slice(0, 100)}` : null, r.views ? `${r.views.toLocaleString()} views` : null, r.eng_rate ? `Eng: ${Number(r.eng_rate).toFixed(1)}%` : null].filter(Boolean).join(" | "),
          source: r.url || undefined,
        }))

        // Meus reels (top por engajamento)
        const { data: myReels } = await supabase.from("meus_reels").select("id, caption, hook_analysis, transcript, views, eng_rate").eq("user_id", user.id).order("eng_rate", { ascending: false }).limit(15)
        myReels?.forEach(r => items.push({
          id: `mr-${r.id}`, type: "meu-reel", title: r.caption?.slice(0, 60) || "Meu Reel",
          content: [r.hook_analysis ? `Hook: ${r.hook_analysis.slice(0, 100)}` : null, r.transcript ? `Transcript: ${r.transcript.slice(0, 100)}` : null, r.views ? `${r.views.toLocaleString()} views` : null, r.eng_rate ? `Eng: ${Number(r.eng_rate).toFixed(1)}%` : null].filter(Boolean).join(" | "),
        }))

        // Estratégias
        const { data: strats } = await supabase.from("estrategias").select("id, title, key_takeaway, created_at").eq("user_id", user.id).order("created_at", { ascending: false }).limit(5)
        strats?.forEach(s => items.push({
          id: `str-${s.id}`, type: "estrategia", title: s.title,
          content: s.key_takeaway || "Relatório de estratégia disponível",
          source: `Gerado em ${new Date(s.created_at).toLocaleDateString("pt-BR")}`,
        }))

        // Paradigmas do MinIO - Voz
        try {
          const { data: vozData } = await supabase.functions.invoke("save-to-minio", {
            body: { action: "list", path: `paradigmas/${user.id}/voz/` },
          })
          if (vozData?.success && vozData.files?.length > 0) {
            vozData.files.forEach((f: any) => {
              const name = f.key.split("/").pop() || f.key
              items.push({
                id: `pv-${f.key}`, type: "paradigma-voz", title: name,
                content: `Amostra de voz • ${f.size ? (f.size / 1024).toFixed(1) + " KB" : ""}`,
                source: "MinIO / Agente de Voz",
              })
            })
          }
        } catch { /* ignore */ }

        // Paradigmas do MinIO - Animação (face, body, style, reference)
        const animCategories = [
          { folder: "face", type: "paradigma-face" as const, label: "Face" },
          { folder: "body", type: "paradigma-corpo" as const, label: "Corpo" },
          { folder: "style", type: "paradigma-estilo" as const, label: "Vídeo Estilo" },
          { folder: "reference", type: "paradigma-ref" as const, label: "Ref. Visual" },
        ]
        for (const cat of animCategories) {
          try {
            const { data: catData } = await supabase.functions.invoke("save-to-minio", {
              body: { action: "list", path: `paradigmas/${user.id}/animacao/${cat.folder}/` },
            })
            if (catData?.success && catData.files?.length > 0) {
              catData.files.forEach((f: any) => {
                const name = f.key.split("/").pop() || f.key
                const isVideo = /\.(mp4|mov|webm|avi)$/i.test(name)
                items.push({
                  id: `pa-${f.key}`, type: cat.type, title: name,
                  content: `${cat.label} • ${isVideo ? "Vídeo" : "Imagem"} • ${f.size ? (f.size / 1024).toFixed(1) + " KB" : ""}`,
                  source: "MinIO / Agente de Animação",
                })
              })
            }
          } catch { /* ignore */ }
        }

        setAnalyzedContent(items)
      } catch (e) {
        console.error("Error loading reference content:", e)
      } finally {
        setLoadingContent(false)
      }
    }
    loadData()
  }, [open, generationType])

  // Load previously uploaded files from MinIO
  useEffect(() => {
    if (!open || !generationType) return
    const loadMinioUploads = async () => {
      setLoadingMinioFiles(true)
      try {
        const { data: { user } } = await supabase.auth.getUser()
        if (!user) return
        const { data } = await supabase.functions.invoke("save-to-minio", {
          body: { action: "list", path: `uploads/${user.id}/ai-generation/` },
        })
        if (data?.success && data.files?.length > 0) {
          setMinioFiles(data.files.map((f: any) => ({
            name: f.key.split("/").pop() || f.key,
            path: f.key,
            size: f.size || 0,
          })))
        } else {
          setMinioFiles([])
        }
      } catch { setMinioFiles([]) }
      finally { setLoadingMinioFiles(false) }
    }
    loadMinioUploads()
  }, [open, generationType])

  const handleFiles = async (files: File[]) => {
    const newFiles: UploadedFile[] = files.map((file) => ({
      id: Math.random().toString(36).substr(2, 9), name: file.name, size: file.size, type: file.type,
      preview: file.type.startsWith("image/") ? URL.createObjectURL(file) : undefined,
    }))
    setUploadedFiles((prev) => [...prev, ...newFiles])

    // Save to MinIO for persistence
    const { data: { user } } = await supabase.auth.getUser()
    if (user) {
      for (const file of files) {
        try {
          const reader = new FileReader()
          reader.onload = async () => {
            const base64 = (reader.result as string).split(",")[1]
            const path = `uploads/${user.id}/ai-generation/${Date.now()}-${file.name}`
            await supabase.functions.invoke("save-to-minio", {
              body: { action: "save", path, data: base64 },
            })
            setMinioFiles(prev => [...prev, { name: file.name, path, size: file.size }])
          }
          reader.readAsDataURL(file)
        } catch { /* ignore upload error */ }
      }
    }
    toast.success(`${files.length} arquivo(s) adicionado(s)`)
  }

  const handleClearMemory = async () => {
    setClearingMemory(true)
    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return
      for (const f of minioFiles) {
        await supabase.functions.invoke("save-to-minio", {
          body: { action: "delete", path: f.path },
        })
      }
      setMinioFiles([])
      setUploadedFiles([])
      toast.success("Memória de uploads limpa!")
    } catch (e: any) {
      toast.error("Erro ao limpar memória", { description: e.message })
    } finally {
      setClearingMemory(false)
    }
  }

  const handleGenerate = useCallback(async () => {
    if (!generationType) return
    if (!agentConfig) {
      toast.error("Agente não configurado", { description: "Configure o provedor e modelo no menu Agentes IA antes de gerar." }); return
    }
    if (!prompt.trim() && selectedContent.length === 0 && chatMessages.length === 0) {
      toast.error("Adicione um prompt ou selecione conteudo analisado"); return
    }
    setIsGenerating(true)
    const userMessage = followUpPrompt || prompt
    if (userMessage.trim()) setChatMessages(prev => [...prev, { role: "user", content: userMessage }])

    try {
      const agentType = generationToAgent[generationType]
      const provider = agentConfig.provider
      const model = agentConfig.model

      // Build context with reference content
      let context = userMessage
      const selectedRefs = analyzedContent.filter(c => selectedContent.includes(c.id))
      if (selectedRefs.length > 0) {
        context += "\n\n--- CONTEÚDO DE REFERÊNCIA ---\n"
        selectedRefs.forEach(ref => {
          context += `\n[${ref.type.toUpperCase()}] ${ref.title}: ${ref.content}\n`
        })
      }

      // Carousel generation can take ~2min (multiple image generations), so we use fetch with longer timeout
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
      const supabaseKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY

      // Map generation type to format for injection
      const FORMAT_BY_TYPE: Record<string, string> = {
        reel: "instagram-reels",
        video: "instagram-reels",
        carrossel: "instagram-feed",
        post: "instagram-feed",
        story: "instagram-stories",
        script: "youtube-script",
        copy: "instagram-feed",
      }
      const inferredFormat = FORMAT_BY_TYPE[generationType || ""] || ""

      const session = (await supabase.auth.getSession()).data.session

      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 180000) // 3 min timeout

      const response = await fetch(`${supabaseUrl}/functions/v1/generate-content`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${session?.access_token || supabaseKey}`,
          "apikey": supabaseKey,
        },
        body: JSON.stringify({
          agent: agentType, context, provider, model,
          custom_prompt: agentConfig?.custom_prompt || undefined,
          custom_prompt_2: agentConfig?.custom_prompt_2 || undefined,
          custom_prompt_3: agentConfig?.custom_prompt_3 || undefined,
        }),
        signal: controller.signal,
      })

      clearTimeout(timeoutId)

      if (!response.ok) {
        const errText = await response.text()
        throw new Error(`Erro ${response.status}: ${errText}`)
      }

      const data = await response.json()

      if (!data?.success) throw new Error(data?.error || "Geração falhou")
      if (!data?.success) throw new Error(data?.error || "Geração falhou")

      const result = data.result
      setGeneratedResult(result)
      setChatMessages(prev => [...prev, { role: "assistant", content: result }])
      setFollowUpPrompt("")

      // Save to history
      const { data: { user } } = await supabase.auth.getUser()
      if (user) {
        await supabase.from("generated_content").insert({
          user_id: user.id,
          generation_type: generationType,
          agent_type: generationToAgent[generationType],
          provider,
          model,
          prompt: userMessage,
          result,
        })
      }

      toast.success(`${generationTypeLabels[generationType]} gerado com sucesso!`, {
        description: `via ${provider} / ${model.split("/").pop()}`,
      })
    } catch (error: any) {
      toast.error("Erro na geração", { description: error.message })
    } finally {
      setIsGenerating(false)
    }
  }, [prompt, followUpPrompt, selectedContent, generationType, chatMessages, agentConfig, analyzedContent])

  const handleSendToQueue = async () => {
    if (!generatedResult || !generationType) return
    setSendingToQueue(true)
    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) throw new Error("Usuário não autenticado")

      const contentTypeMap: Record<GenerationType, string> = {
        video: "video", reel: "reel", carrossel: "carousel", post: "post", story: "story", script: "post", copy: "post",
      }

      const { error } = await supabase.from("publish_queue").insert({
        user_id: user.id,
        content_type: contentTypeMap[generationType],
        caption: generatedResult,
        status: "pending_approval",
      })
      if (error) throw error
      toast.success("Enviado para a fila de publicação!", { description: "Acesse a Fila de Publicação para aprovar e publicar." })
    } catch (e: any) {
      toast.error("Erro ao enviar para fila", { description: e.message })
    } finally {
      setSendingToQueue(false)
    }
  }

  const [downloadingZip, setDownloadingZip] = useState(false)

  const handleDownloadImagesZip = async () => {
    if (!generatedResult) return
    const srcs = extractImageSources(generatedResult)
    if (srcs.length === 0) {
      toast.error("Nenhuma imagem encontrada no conteúdo gerado")
      return
    }
    setDownloadingZip(true)
    try {
      const zip = new JSZip()
      for (let i = 0; i < srcs.length; i++) {
        const src = srcs[i]
        if (src.startsWith("data:")) {
          // Handle base64 data URI
          const [header, b64] = src.split(",")
          const mime = header.match(/data:(.*?);/)?.[1] || "image/png"
          const ext = mime.includes("png") ? "png" : mime.includes("webp") ? "webp" : "jpg"
          const binary = atob(b64)
          const bytes = new Uint8Array(binary.length)
          for (let j = 0; j < binary.length; j++) bytes[j] = binary.charCodeAt(j)
          zip.file(`slide-${i + 1}.${ext}`, bytes)
        } else {
          const res = await fetch(src)
          const blob = await res.blob()
          const ext = blob.type.includes("png") ? "png" : blob.type.includes("webp") ? "webp" : "jpg"
          zip.file(`slide-${i + 1}.${ext}`, blob)
        }
      }
      const content = await zip.generateAsync({ type: "blob" })
      const link = document.createElement("a")
      link.href = URL.createObjectURL(content)
      link.download = `carrossel-${Date.now()}.zip`
      link.click()
      URL.revokeObjectURL(link.href)
      toast.success(`${srcs.length} imagens baixadas!`)
    } catch (e: any) {
      toast.error("Erro ao baixar imagens", { description: e.message })
    } finally {
      setDownloadingZip(false)
    }
  }

  const handleGenerateCaption = async () => {
    if (!generatedResult || !generationType) return
    setGeneratingCaption(true)
    try {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
      const supabaseKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY
      const session = (await supabase.auth.getSession()).data.session

      const { data: { user } } = await supabase.auth.getUser()
      let copyProvider = agentConfig?.provider || "openrouter"
      let copyModel = agentConfig?.model || "google/gemini-2.5-flash"
      let copyCustomPrompt: string | undefined

      if (user) {
        const { data: copyConfig } = await supabase
          .from("agent_configs")
          .select("provider, model, custom_prompt")
          .eq("user_id", user.id)
          .eq("agent_type", "copywriter")
          .eq("is_active", true)
          .maybeSingle()
        if (copyConfig) {
          copyProvider = copyConfig.provider
          copyModel = copyConfig.model
          if (copyConfig.custom_prompt?.trim()) copyCustomPrompt = copyConfig.custom_prompt
        }
      }

      const contentTypeName = generationTypeLabels[generationType]
      const contentSummary = generatedResult.replace(/!\[.*?\]\(data:[^)]+\)/g, "[IMAGEM GERADA]").slice(0, 3000)

      const response = await fetch(`${supabaseUrl}/functions/v1/generate-content`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${session?.access_token || supabaseKey}`,
          "apikey": supabaseKey,
        },
        body: JSON.stringify({
          agent: "copywriter",
          context: `Tipo de mídia: ${contentTypeName} para Instagram\n\nConteúdo gerado que precisa de legenda:\n${contentSummary}\n\nCrie UMA legenda otimizada para este ${contentTypeName.toLowerCase()} com:\n1. Gancho forte na primeira linha (máx 125 chars)\n2. Corpo com valor e storytelling\n3. CTA para gerar engajamento e comentários\n4. 15-20 hashtags relevantes (mix de big, medium, niche)`,
          provider: copyProvider,
          model: copyModel,
          custom_prompt: copyCustomPrompt,
        }),
      })

      if (!response.ok) {
        const errText = await response.text()
        throw new Error(`Erro ${response.status}: ${errText}`)
      }

      const data = await response.json()
      if (!data?.success) throw new Error(data?.error || "Falha ao gerar legenda")

      setGeneratedCaption(data.result)
      toast.success("Legenda gerada!", { description: `via ${copyProvider} / ${copyModel.split("/").pop()}` })
    } catch (e: any) {
      toast.error("Erro ao gerar legenda", { description: e.message })
    } finally {
      setGeneratingCaption(false)
    }
  }

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + " B"
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB"
    return (bytes / (1024 * 1024)).toFixed(1) + " MB"
  }

  if (!generationType) return null

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent showCloseButton={false} className="overflow-y-auto" style={isMaximized ? { maxWidth: '96vw', width: '96vw', height: '96vh', maxHeight: '96vh' } : { maxWidth: '56rem', maxHeight: '90vh' }}>
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle className="flex items-center gap-2 text-2xl">{generationTypeIcons[generationType]}Gerar {generationTypeLabels[generationType]} com IA</DialogTitle>
              <DialogDescription className="flex items-center gap-2 flex-wrap">
                Configure os parametros e deixe a IA criar seu conteudo
                {generationType && (
                  <Badge variant="secondary" className="text-xs">
                    🤖 {agentTypeLabels[generationToAgent[generationType]] || generationToAgent[generationType]}
                  </Badge>
                )}
                {agentConfig && (
                  <Badge variant="outline" className="text-xs">
                    {agentConfig.provider} / {agentConfig.model.split("/").pop()?.slice(0, 20)}
                  </Badge>
                )}
              </DialogDescription>
            </div>
            <div className="flex items-center gap-1">
              <Button variant="ghost" size="icon" onClick={() => setIsMaximized(!isMaximized)}>{isMaximized ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}</Button>
              <Button variant="ghost" size="icon" onClick={() => onOpenChange(false)}><X className="h-4 w-4" /></Button>
            </div>
          </div>
        </DialogHeader>

        <div className="space-y-6 mt-4">
          <Tabs defaultValue="prompt" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="prompt">Prompt</TabsTrigger>
              <TabsTrigger value="reference">Conteudo de Referencia</TabsTrigger>
            </TabsList>
            <TabsContent value="prompt" className="space-y-4">
              <div className="space-y-2">
                <Label>Descreva o que voce quer criar</Label>
                <Textarea placeholder={`Ex: Crie um ${generationTypeLabels[generationType].toLowerCase()} sobre dicas de produtividade...`} value={prompt} onChange={(e) => setPrompt(e.target.value)} rows={6} className="resize-none" />
              </div>
              <div className="space-y-2">
                <Label>Arquivos de Referencia (opcional)</Label>
                <div className={cn("border-2 border-dashed rounded-lg p-8 text-center transition-colors", isDragging ? "border-primary bg-primary/5" : "border-border hover:border-primary/50")}
                  onDragOver={(e) => { e.preventDefault(); setIsDragging(true) }} onDragLeave={(e) => { e.preventDefault(); setIsDragging(false) }}
                  onDrop={(e) => { e.preventDefault(); setIsDragging(false); handleFiles(Array.from(e.dataTransfer.files)) }}>
                  <Upload className="h-10 w-10 mx-auto mb-3 text-muted-foreground" />
                  <p className="text-sm font-medium mb-1">Arraste arquivos aqui ou clique para selecionar</p>
                  <Button type="button" variant="outline" size="sm" onClick={() => fileInputRef.current?.click()}>Selecionar Arquivos</Button>
                  <input ref={fileInputRef} type="file" multiple className="hidden" onChange={(e) => handleFiles(Array.from(e.target.files || []))} accept="image/*,video/*,.pdf,.doc,.docx,.txt" />
                </div>
                {uploadedFiles.length > 0 && (
                  <div className="grid grid-cols-2 gap-2 mt-3">
                    {uploadedFiles.map((file) => (
                      <Card key={file.id} className="p-3">
                        <div className="flex items-start gap-3">
                          {file.preview ? <img src={file.preview} alt={file.name} className="w-12 h-12 object-cover rounded" /> : <div className="w-12 h-12 bg-muted rounded flex items-center justify-center"><FileText className="h-6 w-6 text-muted-foreground" /></div>}
                          <div className="flex-1 min-w-0"><p className="text-sm font-medium truncate">{file.name}</p><p className="text-xs text-muted-foreground">{formatFileSize(file.size)}</p></div>
                          <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0" onClick={() => setUploadedFiles((prev) => prev.filter((f) => f.id !== file.id))}><X className="h-4 w-4" /></Button>
                        </div>
                      </Card>
                    ))}
                  </div>
                )}
                {/* MinIO Memory */}
                {(minioFiles.length > 0 || loadingMinioFiles) && (
                  <div className="space-y-2 mt-3 p-3 rounded-lg border border-border bg-muted/30">
                    <div className="flex items-center justify-between">
                      <Label className="text-xs flex items-center gap-1">📦 Memória MinIO ({minioFiles.length} arquivos)</Label>
                      <Button variant="ghost" size="sm" className="h-6 text-xs text-destructive hover:text-destructive gap-1" onClick={handleClearMemory} disabled={clearingMemory}>
                        {clearingMemory ? <Loader2 className="h-3 w-3 animate-spin" /> : <X className="h-3 w-3" />} Limpar memória
                      </Button>
                    </div>
                    {loadingMinioFiles ? (
                      <div className="flex items-center gap-2 text-xs text-muted-foreground"><Loader2 className="h-3 w-3 animate-spin" /> Carregando...</div>
                    ) : (
                      <div className="flex flex-wrap gap-1.5">
                        {minioFiles.map((f, i) => (
                          <Badge key={i} variant="secondary" className="text-[10px] gap-1">
                            <FileText className="h-3 w-3" /> {f.name} <span className="text-muted-foreground">({formatFileSize(f.size)})</span>
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </TabsContent>
            <TabsContent value="reference" className="space-y-4">
              <p className="text-sm text-muted-foreground">Selecione competidores, reels ou estratégias do seu banco de dados como referência</p>
              {loadingContent ? (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                  <span className="ml-2 text-sm text-muted-foreground">Carregando dados...</span>
                </div>
              ) : analyzedContent.length === 0 ? (
                <Card className="p-8 text-center">
                  <FileText className="h-10 w-10 mx-auto mb-3 text-muted-foreground" />
                  <p className="text-sm font-medium">Nenhum conteúdo de referência</p>
                  <p className="text-xs text-muted-foreground mt-1">Execute o pipeline para popular competidores, reels e estratégias</p>
                </Card>
              ) : (
                <div className="space-y-2 max-h-[400px] overflow-y-auto">
                  {selectedContent.length > 0 && (
                    <div className="flex items-center justify-between mb-2">
                      <Badge variant="default" className="text-xs">{selectedContent.length} selecionado(s)</Badge>
                      <Button variant="ghost" size="sm" className="text-xs h-6" onClick={() => setSelectedContent([])}>Limpar seleção</Button>
                    </div>
                  )}
                  {analyzedContent.map((content) => {
                    const typeConfig: Record<string, { label: string; icon: React.ReactNode }> = {
                      "competidor": { label: "Competidor", icon: <Users className="h-3 w-3" /> },
                      "meu-reel": { label: "Meu Reel", icon: <Film className="h-3 w-3" /> },
                      "reel-competidor": { label: "Reel Competidor", icon: <BarChart3 className="h-3 w-3" /> },
                      "estrategia": { label: "Estratégia", icon: <Lightbulb className="h-3 w-3" /> },
                      "paradigma-voz": { label: "Voz", icon: <Mic className="h-3 w-3" /> },
                      "paradigma-face": { label: "Face", icon: <User className="h-3 w-3" /> },
                      "paradigma-corpo": { label: "Corpo", icon: <ImageIcon className="h-3 w-3" /> },
                      "paradigma-estilo": { label: "Estilo", icon: <Clapperboard className="h-3 w-3" /> },
                      "paradigma-ref": { label: "Ref. Visual", icon: <ImageIcon className="h-3 w-3" /> },
                    }
                    const tc = typeConfig[content.type] || { label: content.type, icon: <FileText className="h-3 w-3" /> }
                    return (
                      <Card key={content.id} className={cn("p-4 cursor-pointer transition-colors", selectedContent.includes(content.id) ? "border-primary bg-primary/5" : "hover:border-primary/50")}
                        onClick={() => setSelectedContent((prev) => prev.includes(content.id) ? prev.filter((i) => i !== content.id) : [...prev, content.id])}>
                        <div className="flex items-start gap-3">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <Badge variant="secondary" className="text-xs gap-1">{tc.icon}{tc.label}</Badge>
                              <span className="font-medium text-sm truncate">{content.title}</span>
                            </div>
                            <p className="text-sm text-muted-foreground line-clamp-2">{content.content}</p>
                            {content.source && (
                              <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                                {content.source.startsWith("http") ? <ExternalLink className="h-3 w-3" /> : <FileText className="h-3 w-3" />}
                                <span className="truncate">{content.source}</span>
                              </div>
                            )}
                          </div>
                          <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0" onClick={(e) => { e.stopPropagation(); navigator.clipboard.writeText(content.content); toast.success("Copiado!") }}><Copy className="h-4 w-4" /></Button>
                        </div>
                      </Card>
                    )
                  })}
                </div>
              )}
            </TabsContent>
          </Tabs>

          {generatedResult && (
            <div className="space-y-4 p-4 border rounded-lg bg-muted/50">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">Resultado</h3>
                <div className="flex gap-2">
                  <Button variant="ghost" size="sm" onClick={() => { navigator.clipboard.writeText(generatedResult); toast.success("Copiado!") }}>
                    <Copy className="h-4 w-4 mr-1" /> Copiar
                  </Button>
                  <Button variant="ghost" size="sm" onClick={handleDownloadImagesZip} disabled={downloadingZip}>
                    {downloadingZip ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Download className="h-4 w-4 mr-1" />} Baixar ZIP
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleSendToQueue} disabled={sendingToQueue}>
                    {sendingToQueue ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Send className="h-4 w-4 mr-1" />} Enviar para Fila
                  </Button>
                  <Button variant="default" size="sm" onClick={() => setShowPublishModal(true)}>
                    <Upload className="h-4 w-4 mr-2" />Publicar
                  </Button>
                </div>
              </div>
              <MarkdownWithImages
                content={generatedResult}
                className="bg-background p-4 rounded-lg max-h-[400px] overflow-y-auto prose prose-sm dark:prose-invert max-w-none [&_img]:rounded-lg [&_img]:border [&_img]:max-w-full [&_h1]:text-lg [&_h2]:text-base [&_h3]:text-sm [&_p]:text-sm [&_li]:text-sm [&_hr]:my-3"
              />

              {/* Copywriter Section */}
              <div className="border rounded-lg p-4 space-y-3 bg-background">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <PenLine className="h-4 w-4 text-primary" />
                    <h4 className="font-semibold text-sm">Legenda da Postagem</h4>
                    <Badge variant="secondary" className="text-[10px]">Copywriter</Badge>
                  </div>
                  <Button
                    variant={generatedCaption ? "outline" : "default"}
                    size="sm"
                    onClick={handleGenerateCaption}
                    disabled={generatingCaption}
                  >
                    {generatingCaption ? (
                      <><Loader2 className="h-4 w-4 mr-1 animate-spin" />Gerando...</>
                    ) : generatedCaption ? (
                      <><PenLine className="h-4 w-4 mr-1" />Regerar Legenda</>
                    ) : (
                      <><PenLine className="h-4 w-4 mr-1" />Gerar Legenda</>
                    )}
                  </Button>
                </div>
                {!generatedCaption && !generatingCaption && (
                  <p className="text-xs text-muted-foreground">
                    Clique em "Gerar Legenda" para criar a copy da postagem com hashtags usando o agente Copywriter.
                  </p>
                )}
                {generatingCaption && (
                  <div className="flex items-center gap-2 py-4 justify-center text-sm text-muted-foreground">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Gerando legenda com o agente Copywriter...
                  </div>
                )}
                {generatedCaption && (
                  <div className="space-y-2">
                    <div className="bg-muted/30 rounded-lg p-3 max-h-[300px] overflow-y-auto prose prose-sm dark:prose-invert max-w-none [&_p]:text-sm [&_li]:text-sm">
                      <MarkdownWithImages content={generatedCaption} />
                    </div>
                    <div className="flex gap-2 justify-end">
                      <Button variant="ghost" size="sm" className="text-xs" onClick={() => { navigator.clipboard.writeText(generatedCaption); toast.success("Legenda copiada!") }}>
                        <Copy className="h-3 w-3 mr-1" /> Copiar Legenda
                      </Button>
                    </div>
                  </div>
                )}
              </div>

              <div className="space-y-3">
                <Label>Ajustar ou refazer</Label>
                <div className="flex gap-2">
                  <Textarea placeholder="Ex: Deixe mais curto, mude o tom..." value={followUpPrompt} onChange={(e) => setFollowUpPrompt(e.target.value)} rows={2} className="resize-none" />
                  <Button onClick={handleGenerate} disabled={isGenerating || !followUpPrompt.trim()} className="shrink-0">
                    {isGenerating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
                  </Button>
                </div>
              </div>
            </div>
          )}

          {!generatedResult && (
            <div className="flex justify-end gap-3 pt-4 border-t">
              <Button variant="outline" onClick={() => onOpenChange(false)} disabled={isGenerating}>Cancelar</Button>
              <Button onClick={handleGenerate} disabled={isGenerating}>
                {isGenerating ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Gerando...</> : <><Sparkles className="h-4 w-4 mr-2" />Gerar {generationTypeLabels[generationType]}</>}
              </Button>
            </div>
          )}
        </div>
        <PublishModal open={showPublishModal} onOpenChange={setShowPublishModal} contentType={generationType} generatedContent={generatedResult || undefined} />
      </DialogContent>
    </Dialog>
  )
}
