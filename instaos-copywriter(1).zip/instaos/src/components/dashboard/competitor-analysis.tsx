import { useState, useCallback, useEffect } from "react"
import { createPortal } from "react-dom"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Users, TrendingUp, BarChart3, Loader2, Brain, Target, Lightbulb,
  ThumbsUp, ThumbsDown, Sparkles, RefreshCw, ChevronDown, ChevronUp,
  Eye, Heart, MessageCircle, Zap, Trash2, X, Maximize2, Minimize2, GripHorizontal
} from "lucide-react"
import { cn } from "@/lib/utils"
import { Checkbox } from "@/components/ui/checkbox"
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { toast } from "sonner"
import { supabase } from "@/integrations/supabase/client"

interface CompetitorProfile {
  id: string
  name: string
  bio?: string
  followersCount?: number
  followingCount?: number
  postsCount?: number
  profilePicUrl?: string
  predominantContentType?: string
  avgPostsPerWeek?: number
  niche?: string
}

interface AnalysisResult {
  score_geral: number
  resumo: string
  pontos_fortes: string[]
  pontos_fracos: string[]
  metricas: {
    engajamento_medio: number
    melhor_tipo_conteudo: string
    frequencia_ideal: string
    melhor_horario: string
    crescimento_estimado: string
  }
  estrategia_conteudo: {
    pilares: string[]
    tom_voz: string
    publico_alvo: string
    diferencial: string
  }
  recomendacoes: string[]
  top_conteudos: { caption_resumo: string; tipo: string; engajamento: number; por_que_funcionou: string }[]
}

interface CompetitorCard {
  competitor: CompetitorProfile
  analysis: AnalysisResult | null
  loading: boolean
  expanded: boolean
}

interface CompetitorAnalysisProps {
  competitors: CompetitorProfile[]
  onRefreshData?: () => Promise<void>
}

function formatNumber(n?: number): string {
  if (!n) return "0"
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + "M"
  if (n >= 1_000) return (n / 1_000).toFixed(1) + "K"
  return n.toString()
}

function getScoreColor(score: number): string {
  if (score >= 80) return "text-emerald-500"
  if (score >= 60) return "text-amber-500"
  return "text-red-500"
}

function getScoreLabel(score: number): string {
  if (score >= 80) return "Excelente"
  if (score >= 60) return "Bom"
  if (score >= 40) return "Regular"
  return "Fraco"
}

export function CompetitorAnalysis({ competitors, onRefreshData }: CompetitorAnalysisProps) {
  const [cards, setCards] = useState<Record<string, CompetitorCard>>({})
  const [analyzingAll, setAnalyzingAll] = useState(false)
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [deleting, setDeleting] = useState(false)

  const analyzeCompetitor = useCallback(async (comp: CompetitorProfile) => {
    setCards(prev => ({
      ...prev,
      [comp.id]: { competitor: comp, analysis: null, loading: true, expanded: true }
    }))

    try {
      // Fetch competitor's reels for analysis context
      const { data: reelsData } = await supabase
        .from("reels_competidores")
        .select("*")
        .eq("owner_username", comp.name)
        .order("views", { ascending: false })
        .limit(15)

      const { data, error } = await supabase.functions.invoke("analyze-content", {
        body: {
          action: "profile_analysis",
          profileData: comp,
          reelsData: reelsData || [],
          model: "google/gemini-2.5-flash",
        },
      })

      if (error) throw error
      if (!data?.success) throw new Error(data?.error || "Analysis failed")

      let analysis: AnalysisResult
      try {
        const cleaned = data.result.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim()
        analysis = JSON.parse(cleaned)
      } catch {
        throw new Error("Falha ao parsear resultado da IA")
      }

      setCards(prev => ({
        ...prev,
        [comp.id]: { competitor: comp, analysis, loading: false, expanded: true }
      }))
      setModalCompId(comp.id)

      toast.success(`Análise de @${comp.name} concluída!`)
    } catch (e: any) {
      toast.error(`Erro ao analisar @${comp.name}`, { description: e.message })
      setCards(prev => ({
        ...prev,
        [comp.id]: { ...prev[comp.id], loading: false }
      }))
    }
  }, [])

  const analyzeAll = useCallback(async () => {
    setAnalyzingAll(true)
    const validComps = competitors.filter(c => c.followersCount && c.followersCount > 0)
    for (const comp of validComps.slice(0, 5)) {
      await analyzeCompetitor(comp)
    }
    setAnalyzingAll(false)
    toast.success("Análise completa de todos os competidores!")
  }, [competitors, analyzeCompetitor])

  const [modalCompId, setModalCompId] = useState<string | null>(null)

  const openAnalysisModal = (id: string) => {
    setModalCompId(id)
  }

  const toggleSelected = (id: string) => {
    setSelected(prev => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  const toggleSelectAll = () => {
    if (selected.size === validComps.length) {
      setSelected(new Set())
    } else {
      setSelected(new Set(validComps.map(c => c.id)))
    }
  }

  const handleBulkDelete = async () => {
    if (selected.size === 0) return
    setDeleting(true)
    try {
      // Delete reels first, then competitors
      const ids = Array.from(selected)
      await supabase.from("reels_competidores").delete().in("competidor_id", ids)
      const { error } = await supabase.from("competidores").delete().in("id", ids)
      if (error) throw error
      toast.success(`${ids.length} competidor(es) removido(s)`)
      setSelected(new Set())
      setCards(prev => {
        const next = { ...prev }
        ids.forEach(id => delete next[id])
        return next
      })
      if (onRefreshData) await onRefreshData()
    } catch (e: any) {
      toast.error("Erro ao deletar competidores", { description: e.message })
    } finally {
      setDeleting(false)
    }
  }

  const validComps = competitors.filter(c => c.followersCount && c.followersCount > 0)

  if (competitors.length === 0) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-12 text-muted-foreground">
          <p>Nenhum competidor cadastrado. Adicione competidores para analisar.</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header with actions */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <Brain className="h-5 w-5 text-primary" />
            Análise de Perfil com IA
          </h3>
          <p className="text-sm text-muted-foreground">
            Selecione um competidor para gerar análise profunda com agentes de IA
          </p>
        </div>
        <div className="flex items-center gap-2">
          {validComps.length > 0 && (
            <Button variant="outline" size="sm" onClick={toggleSelectAll} className="gap-2">
              <Checkbox
                checked={selected.size === validComps.length && validComps.length > 0}
                className="pointer-events-none"
              />
              {selected.size === validComps.length ? "Desmarcar" : "Selecionar Todos"}
            </Button>
          )}
          {selected.size > 0 && (
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" size="sm" className="gap-2" disabled={deleting}>
                  {deleting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
                  Deletar ({selected.size})
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Deletar {selected.size} competidor(es)?</AlertDialogTitle>
                  <AlertDialogDescription>
                    Esta ação removerá os competidores selecionados e todos os reels associados. Não pode ser desfeita.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                  <AlertDialogAction onClick={handleBulkDelete}>Confirmar</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
          <Button
            onClick={analyzeAll}
            disabled={analyzingAll || validComps.length === 0}
            className="gap-2"
          >
            {analyzingAll ? (
              <><Loader2 className="h-4 w-4 animate-spin" />Analisando...</>
            ) : (
              <><Sparkles className="h-4 w-4" />Analisar Todos</>
            )}
          </Button>
        </div>
      </div>

      {/* Competitor Selection Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-3">
        {validComps.map(comp => {
          const card = cards[comp.id]
          const hasAnalysis = card?.analysis
          const isLoading = card?.loading

          return (
            <Card
              key={comp.id}
              className={`cursor-pointer transition-all hover:border-primary/50 ${hasAnalysis ? "border-primary/30 bg-primary/5" : ""} ${selected.has(comp.id) ? "ring-2 ring-destructive/50" : ""}`}
              onClick={() => {
                if (hasAnalysis) {
                  openAnalysisModal(comp.id)
                } else if (!isLoading) {
                  analyzeCompetitor(comp)
                }
              }}
            >
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center gap-3 min-w-0">
                  <Checkbox
                    checked={selected.has(comp.id)}
                    onClick={(e) => { e.stopPropagation(); toggleSelected(comp.id); }}
                    className="shrink-0"
                  />
                  {comp.profilePicUrl ? (
                    <img
                      src={comp.profilePicUrl}
                      alt=""
                      className="h-10 w-10 rounded-full object-cover border border-border shrink-0"
                      onError={(e) => { e.currentTarget.style.display = 'none'; e.currentTarget.nextElementSibling?.classList.remove('hidden'); }}
                    />
                  ) : null}
                  <div className={`h-10 w-10 rounded-full bg-muted flex items-center justify-center shrink-0 ${comp.profilePicUrl ? 'hidden' : ''}`}>
                    <Users className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="font-semibold text-sm truncate">@{comp.name}</p>
                    <p className="text-xs text-muted-foreground">{formatNumber(comp.followersCount)} seguidores</p>
                  </div>
                </div>
                {comp.niche && (
                  <p className="text-xs text-muted-foreground truncate">📌 {comp.niche}</p>
                )}
                <div className="flex items-center justify-between pt-1 border-t border-border/50">
                  {isLoading && (
                    <div className="flex items-center gap-2 text-primary text-xs">
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      <span>Analisando...</span>
                    </div>
                  )}
                  {hasAnalysis && (
                    <div className="flex items-center gap-2">
                      <span className={`text-lg font-bold ${getScoreColor(card.analysis!.score_geral)}`}>
                        {card.analysis!.score_geral}
                      </span>
                      <span className="text-[10px] text-muted-foreground">{getScoreLabel(card.analysis!.score_geral)}</span>
                    </div>
                  )}
                  {!isLoading && !hasAnalysis && <span className="text-[10px] text-muted-foreground">Clique para analisar</span>}
                  {!isLoading && (
                    <Badge variant="outline" className="text-[10px] shrink-0">
                      <Zap className="h-3 w-3 mr-1" />{hasAnalysis ? "Ver" : "Analisar"}
                    </Badge>
                  )}
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Analysis Modal */}
      {modalCompId && cards[modalCompId]?.analysis && (
        <AnalysisModal
          comp={cards[modalCompId].competitor}
          analysis={cards[modalCompId].analysis!}
          onClose={() => setModalCompId(null)}
          onRefresh={() => analyzeCompetitor(cards[modalCompId].competitor)}
        />
      )}
    </div>
  )
}

function AnalysisModal({ comp, analysis, onClose, onRefresh }: {
  comp: CompetitorProfile
  analysis: AnalysisResult
  onClose: () => void
  onRefresh: () => void
}) {
  const [isMaximized, setIsMaximized] = useState(false)
  const [pos, setPos] = useState({ x: 0, y: 0 })
  const [dragging, setDragging] = useState(false)
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 })

  useEffect(() => {
    if (!dragging) return
    const onMove = (e: MouseEvent) => {
      setPos({ x: e.clientX - dragStart.x, y: e.clientY - dragStart.y })
    }
    const onUp = () => setDragging(false)
    window.addEventListener("mousemove", onMove)
    window.addEventListener("mouseup", onUp)
    return () => { window.removeEventListener("mousemove", onMove); window.removeEventListener("mouseup", onUp) }
  }, [dragging, dragStart])

  const onMouseDown = (e: React.MouseEvent) => {
    if (isMaximized) return
    setDragging(true)
    setDragStart({ x: e.clientX - pos.x, y: e.clientY - pos.y })
  }

  return createPortal(
    <>
      <div className="fixed inset-0 z-50 bg-black/50" onClick={onClose} />
      <div
        className={cn(
          "fixed z-50 flex flex-col border bg-background shadow-lg rounded-lg",
          isMaximized ? "inset-2" : "w-[90vw] max-w-2xl h-[85vh]"
        )}
        style={isMaximized ? {} : { left: `calc(50% + ${pos.x}px)`, top: `calc(50% + ${pos.y}px)`, transform: "translate(-50%, -50%)" }}
      >
        {/* Header */}
        <div
          onMouseDown={onMouseDown}
          className="flex items-center justify-between px-4 py-3 border-b shrink-0 cursor-move select-none"
        >
          <div className="flex items-center gap-3 min-w-0">
            <GripHorizontal className="h-4 w-4 text-muted-foreground shrink-0" />
            {comp.profilePicUrl && (
              <img src={comp.profilePicUrl} alt="" className="h-8 w-8 rounded-full object-cover border" />
            )}
            <div className="min-w-0">
              <p className="font-semibold text-sm truncate">@{comp.name}</p>
              <p className="text-xs text-muted-foreground">{formatNumber(comp.followersCount)} seguidores</p>
            </div>
            <span className={`text-xl font-bold ${getScoreColor(analysis.score_geral)}`}>
              {analysis.score_geral}/100
            </span>
          </div>
          <div className="flex items-center gap-1 shrink-0">
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onRefresh}><RefreshCw className="h-3.5 w-3.5" /></Button>
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setIsMaximized(!isMaximized)}>
              {isMaximized ? <Minimize2 className="h-3.5 w-3.5" /> : <Maximize2 className="h-3.5 w-3.5" />}
            </Button>
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onClose}><X className="h-3.5 w-3.5" /></Button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto min-h-0 p-4 space-y-4">
          <p className="text-sm text-muted-foreground">{analysis.resumo}</p>
          <Progress value={analysis.score_geral} className="h-2" />

          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="overview" className="text-xs gap-1"><BarChart3 className="h-3 w-3" />Visão Geral</TabsTrigger>
              <TabsTrigger value="strategy" className="text-xs gap-1"><Target className="h-3 w-3" />Estratégia</TabsTrigger>
              <TabsTrigger value="content" className="text-xs gap-1"><Eye className="h-3 w-3" />Conteúdos</TabsTrigger>
              <TabsTrigger value="actions" className="text-xs gap-1"><Lightbulb className="h-3 w-3" />Ações</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-4 mt-4">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="rounded-lg border bg-card p-3 text-center">
                  <TrendingUp className="h-4 w-4 mx-auto mb-1 text-primary" />
                  <p className="text-lg font-bold">{analysis.metricas.engajamento_medio}%</p>
                  <p className="text-[10px] text-muted-foreground">Engajamento Médio</p>
                </div>
                <div className="rounded-lg border bg-card p-3 text-center">
                  <BarChart3 className="h-4 w-4 mx-auto mb-1 text-primary" />
                  <p className="text-lg font-bold capitalize">{analysis.metricas.melhor_tipo_conteudo}</p>
                  <p className="text-[10px] text-muted-foreground">Melhor Tipo</p>
                </div>
                <div className="rounded-lg border bg-card p-3 text-center">
                  <RefreshCw className="h-4 w-4 mx-auto mb-1 text-primary" />
                  <p className="text-lg font-bold">{analysis.metricas.frequencia_ideal}</p>
                  <p className="text-[10px] text-muted-foreground">Frequência</p>
                </div>
                <div className="rounded-lg border bg-card p-3 text-center">
                  <Sparkles className="h-4 w-4 mx-auto mb-1 text-primary" />
                  <p className="text-sm font-medium">{analysis.metricas.melhor_horario}</p>
                  <p className="text-[10px] text-muted-foreground">Melhor Horário</p>
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <h4 className="text-sm font-medium flex items-center gap-2"><ThumbsUp className="h-4 w-4 text-emerald-500" /> Pontos Fortes</h4>
                  <ul className="space-y-1.5">
                    {analysis.pontos_fortes.map((p, i) => (
                      <li key={i} className="text-sm text-muted-foreground flex items-start gap-2"><span className="text-emerald-500 mt-0.5">✓</span>{p}</li>
                    ))}
                  </ul>
                </div>
                <div className="space-y-2">
                  <h4 className="text-sm font-medium flex items-center gap-2"><ThumbsDown className="h-4 w-4 text-amber-500" /> Oportunidades</h4>
                  <ul className="space-y-1.5">
                    {analysis.pontos_fracos.map((p, i) => (
                      <li key={i} className="text-sm text-muted-foreground flex items-start gap-2"><span className="text-amber-500 mt-0.5">△</span>{p}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="strategy" className="space-y-4 mt-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="rounded-lg border p-4 space-y-2">
                  <h4 className="text-sm font-medium">Pilares de Conteúdo</h4>
                  <div className="flex flex-wrap gap-1.5">
                    {analysis.estrategia_conteudo.pilares.map((p, i) => (
                      <Badge key={i} variant="secondary" className="text-xs">{p}</Badge>
                    ))}
                  </div>
                </div>
                <div className="rounded-lg border p-4 space-y-2">
                  <h4 className="text-sm font-medium">Tom de Voz</h4>
                  <p className="text-sm text-muted-foreground">{analysis.estrategia_conteudo.tom_voz}</p>
                </div>
                <div className="rounded-lg border p-4 space-y-2">
                  <h4 className="text-sm font-medium">Público-Alvo</h4>
                  <p className="text-sm text-muted-foreground">{analysis.estrategia_conteudo.publico_alvo}</p>
                </div>
                <div className="rounded-lg border p-4 space-y-2">
                  <h4 className="text-sm font-medium">Diferencial</h4>
                  <p className="text-sm text-muted-foreground">{analysis.estrategia_conteudo.diferencial}</p>
                </div>
              </div>
              <div className="rounded-lg border p-4 space-y-2">
                <h4 className="text-sm font-medium">Crescimento Estimado</h4>
                <p className="text-sm text-muted-foreground">{analysis.metricas.crescimento_estimado}</p>
              </div>
            </TabsContent>

            <TabsContent value="content" className="mt-4">
              <div className="space-y-3">
                {analysis.top_conteudos.map((c, i) => (
                  <div key={i} className="rounded-lg border p-3 space-y-1.5">
                    <div className="flex items-center justify-between">
                      <Badge variant="outline" className="text-[10px] capitalize">{c.tipo}</Badge>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground"><Heart className="h-3 w-3" /> {c.engajamento}</div>
                    </div>
                    <p className="text-sm">{c.caption_resumo}</p>
                    <p className="text-xs text-muted-foreground italic">{c.por_que_funcionou}</p>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="actions" className="mt-4">
              <div className="space-y-2">
                {analysis.recomendacoes.map((r, i) => (
                  <div key={i} className="flex items-start gap-3 rounded-lg border p-3">
                    <div className="h-6 w-6 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                      <span className="text-xs font-bold text-primary">{i + 1}</span>
                    </div>
                    <p className="text-sm">{r}</p>
                  </div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </>,
    document.body
  )
}
