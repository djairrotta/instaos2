import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { Minimize2, Maximize2, X, ChevronUp } from "lucide-react"
import { useState, useEffect, useRef } from "react"

interface PipelineLogsModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  logs: string[]
  isRunning: boolean
}

function getLogIcon(log: string) {
  if (log.startsWith("🤖")) return "agent"
  if (log.includes("❌")) return "error"
  if (log.includes("⚠️")) return "warn"
  if (log.includes("✅")) return "success"
  if (log.includes("📌")) return "phase"
  if (log.includes("🎉")) return "complete"
  return "info"
}

function getLogStyle(type: string) {
  switch (type) {
    case "agent": return "text-purple-400 bg-purple-500/10 border-purple-500/20"
    case "error": return "text-red-400 bg-red-500/10 border-red-500/20"
    case "warn": return "text-yellow-400 bg-yellow-500/10 border-yellow-500/20"
    case "success": return "text-green-400 bg-green-500/10 border-green-500/20"
    case "phase": return "text-blue-400 bg-blue-500/10 border-blue-500/20 font-semibold"
    case "complete": return "text-emerald-400 bg-emerald-500/10 border-emerald-500/20 font-bold"
    default: return "text-muted-foreground bg-muted/30 border-border/50"
  }
}

export function PipelineLogsModal({ open, onOpenChange, logs, isRunning }: PipelineLogsModalProps) {
  const [isMaximized, setIsMaximized] = useState(false)
  const [isMinimized, setIsMinimized] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [logs])

  // Reset minimized state when modal closes
  useEffect(() => {
    if (!open) setIsMinimized(false)
  }, [open])

  const agentLogs = logs.filter(l => l.startsWith("🤖"))
  const errorLogs = logs.filter(l => l.includes("❌") || l.includes("⚠️"))

  // Minimized floating bar
  if (isMinimized && open) {
    return (
      <div className="fixed bottom-4 right-4 z-50 flex items-center gap-3 rounded-lg border border-border bg-card px-4 py-2.5 shadow-lg cursor-pointer hover:shadow-xl transition-shadow"
        onClick={() => setIsMinimized(false)}
      >
        <span className="text-sm font-medium">📋 Pipeline</span>
        {isRunning ? (
          <Badge variant="outline" className="animate-pulse text-xs border-primary text-primary">
            ⏳ {logs.length} logs
          </Badge>
        ) : (
          <Badge variant="outline" className="text-xs border-green-500 text-green-500">
            ✅ {logs.length} logs
          </Badge>
        )}
        <button
          onClick={(e) => { e.stopPropagation(); onOpenChange(false) }}
          className="p-1 rounded-md hover:bg-muted"
        >
          <X className="h-3.5 w-3.5" />
        </button>
        <ChevronUp className="h-4 w-4 text-muted-foreground" />
      </div>
    )
  }

  return (
    <Dialog open={open && !isMinimized} onOpenChange={onOpenChange}>
      <DialogContent
        className={`${isMaximized ? "!max-w-[95vw] !max-h-[95vh] !w-[95vw] !h-[95vh]" : "max-w-2xl max-h-[80vh]"} flex flex-col gap-0 p-0 overflow-hidden`}
        showCloseButton={false}
      >
        <DialogHeader className="px-4 py-3 border-b border-border flex flex-row items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <DialogTitle className="text-base font-semibold">
              📋 Pipeline Logs
            </DialogTitle>
            {isRunning && (
              <Badge variant="outline" className="animate-pulse text-xs border-primary text-primary">
                ⏳ Executando...
              </Badge>
            )}
            {!isRunning && logs.length > 0 && (
              <Badge variant="outline" className="text-xs border-green-500 text-green-500">
                ✅ Completo
              </Badge>
            )}
          </div>
          <div className="flex items-center gap-1">
            <button onClick={() => setIsMinimized(true)} className="p-1.5 rounded-md hover:bg-muted" title="Minimizar">
              <Minimize2 className="h-4 w-4" />
            </button>
            <button onClick={() => setIsMaximized(!isMaximized)} className="p-1.5 rounded-md hover:bg-muted" title={isMaximized ? "Restaurar" : "Maximizar"}>
              <Maximize2 className="h-4 w-4" />
            </button>
            <button onClick={() => onOpenChange(false)} className="p-1.5 rounded-md hover:bg-muted" title="Fechar">
              <X className="h-4 w-4" />
            </button>
          </div>
        </DialogHeader>

        {/* Agent summary bar */}
        {agentLogs.length > 0 && (
          <div className="px-4 py-2 border-b border-border bg-muted/30 shrink-0">
            <p className="text-xs font-medium text-muted-foreground mb-1.5">Agentes Ativos:</p>
            <div className="flex flex-wrap gap-1.5">
              {agentLogs.map((log, i) => {
                const match = log.match(/\[(\w+)\] → modelo: ([^\s|]+)/)
                if (!match) return null
                return (
                  <Badge key={i} variant="secondary" className="text-[10px] font-mono gap-1">
                    <span className="text-purple-400">🤖 {match[1]}</span>
                    <span className="text-muted-foreground">|</span>
                    <span className="text-blue-400">{match[2]}</span>
                  </Badge>
                )
              })}
            </div>
          </div>
        )}

        {/* Stats bar */}
        <div className="px-4 py-1.5 border-b border-border bg-muted/20 flex items-center gap-4 text-xs text-muted-foreground shrink-0">
          <span>Total: {logs.length} logs</span>
          {errorLogs.length > 0 && <span className="text-yellow-500">⚠️ {errorLogs.length} avisos/erros</span>}
        </div>

        {/* Logs */}
        <ScrollArea className="flex-1 min-h-0" ref={scrollRef}>
          <div className="p-3 space-y-1 font-mono text-xs">
            {logs.length === 0 && isRunning && (
              <p className="text-muted-foreground text-center py-8 animate-pulse">Aguardando logs do pipeline...</p>
            )}
            {logs.map((log, i) => {
              const type = getLogIcon(log)
              return (
                <div key={i} className={`px-2.5 py-1.5 rounded border ${getLogStyle(type)} leading-relaxed`}>
                  <span className="text-muted-foreground/50 mr-2 select-none">{String(i + 1).padStart(3, "0")}</span>
                  {log}
                </div>
              )
            })}
            {isRunning && logs.length > 0 && (
              <div className="px-2.5 py-1.5 rounded border border-border/50 text-muted-foreground animate-pulse">
                <span className="text-muted-foreground/50 mr-2 select-none">{String(logs.length + 1).padStart(3, "0")}</span>
                ⏳ Processando...
              </div>
            )}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  )
}
