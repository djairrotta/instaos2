import { useState, useEffect, useCallback, useMemo } from "react"
import { supabase } from "@/integrations/supabase/client"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { cn } from "@/lib/utils"
import {
  Sparkles, Calendar, ChevronLeft, ChevronRight, Loader2,
  Plus, Trash2, Edit2, Check, X, Film, Images, ImageIcon,
  Brain, Zap, Cpu, Gauge, Play, TrendingUp, Target, Lightbulb,
  ChevronDown, ChevronUp, RefreshCw, ArrowRight, BookOpen,
  BarChart3, Clock,
} from "lucide-react"

// ── Types ────────────────────────────────────────────────────────────────────
interface StrategyPost {
  id: string
  week: number
  day_of_week: string
  format: "reel" | "carrossel" | "post"
  pillar: string
  title: string
  hook: string
  hook_type: string
  angle: string
  cta: string
  notes?: string
  // added by user/editor
  scheduled_date?: string
  agent_copy?: string
  agent_video?: string
  agent_carousel?: string
  ai_model?: string
  status?: "planned" | "generating" | "ready" | "published"
}

interface ContentStrategy {
  id: string
  name: string
  summary: string
  weeks: number
  posts_per_week: number
  distribution: { reel: number; carrossel: number; post: number }
  pillars: { name: string; description: string; posts_count: number; color: string }[]
  weekly_themes: { week: number; theme: string; focus: string }[]
  posts: StrategyPost[]
  insights: string[]
  status: string
  start_date?: string
  created_at: string
}

// ── Constants ────────────────────────────────────────────────────────────────
const FORMAT_ICON: Record<string, React.ReactNode> = {
  reel:      <Film className="w-3 h-3" />,
  carrossel: <Images className="w-3 h-3" />,
  post:      <ImageIcon className="w-3 h-3" />,
}

const FORMAT_COLOR: Record<string, string> = {
  reel:      "text-blue-400 bg-blue-500/10 border-blue-500/25",
  carrossel: "text-yellow-400 bg-yellow-500/10 border-yellow-500/25",
  post:      "text-green-400 bg-green-500/10 border-green-500/25",
}

const HOOK_EMOJI: Record<string, string> = {
  Curiosidade: "🤔", Dor: "😣", Promessa: "✨", Choque: "😮",
  "Prova Social": "👥", Tendência: "📈", Urgência: "⏰",
}

const WEEKDAYS = ["segunda","terça","quarta","quinta","sexta","sábado","domingo"]
const WEEKDAY_SHORT = ["Seg","Ter","Qua","Qui","Sex","Sáb","Dom"]

const AI_AGENTS = [
  { value: "carousel_planner", label: "Carousel Planner", tier: "powerful", icon: "✨" },
  { value: "script_writer",    label: "Script Writer",    tier: "powerful", icon: "🎙️" },
  { value: "caption_writer",   label: "Caption Writer",   tier: "powerful", icon: "✍️" },
  { value: "copywriter",       label: "Copywriter",       tier: "powerful", icon: "🖊️" },
  { value: "hook_analyst",     label: "Hook Analyst",     tier: "fast",     icon: "🎣" },
  { value: "idea_generator",   label: "Idea Generator",   tier: "fast",     icon: "💡" },
]

const AI_MODELS = [
  { value: "claude-opus-4-20250514",    label: "Claude Opus 4",         provider: "anthropic" },
  { value: "claude-sonnet-4-20250514",  label: "Claude Sonnet 4",       provider: "anthropic" },
  { value: "anthropic/claude-opus-4",   label: "Claude Opus 4 (OR)",    provider: "openrouter" },
  { value: "google/gemini-2.5-flash-preview-05-20", label: "Gemini 2.5 Flash", provider: "openrouter" },
  { value: "meta-llama/llama-4-scout",  label: "Llama 4 Scout",         provider: "openrouter" },
]

// ── Helpers ──────────────────────────────────────────────────────────────────
function getMonthCalendar(year: number, month: number) {
  const firstDay = new Date(year, month, 1)
  const lastDay  = new Date(year, month + 1, 0)
  const days: (Date | null)[] = []
  // Pad start (Monday = 0)
  let startPad = (firstDay.getDay() + 6) % 7
  for (let i = 0; i < startPad; i++) days.push(null)
  for (let d = 1; d <= lastDay.getDate(); d++) days.push(new Date(year, month, d))
  return days
}

function dateKey(d: Date) {
  return d.toISOString().split("T")[0]
}

function pillarColor(color: string) {
  return color || "#C9A84C"
}

// ── Post Card (calendar cell item) ───────────────────────────────────────────
function PostChip({ post, onClick }: { post: StrategyPost; onClick: () => void }) {
  return (
    <button onClick={onClick}
      className={cn(
        "w-full text-left rounded-md px-1.5 py-1 text-[10px] border transition-all hover:scale-[1.02] flex items-center gap-1 overflow-hidden",
        FORMAT_COLOR[post.format]
      )}>
      {FORMAT_ICON[post.format]}
      <span className="truncate font-medium">{post.title || post.hook?.slice(0, 30)}</span>
    </button>
  )
}

// ── Post Editor Modal ─────────────────────────────────────────────────────────
function PostEditor({ post, onSave, onClose }: {
  post: StrategyPost
  onSave: (updates: Partial<StrategyPost>) => void
  onClose: () => void
}) {
  const [editing, setEditing] = useState({ ...post })

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      onClick={e => { if (e.target === e.currentTarget) onClose() }}>
      <div className="bg-background border border-border rounded-2xl w-full max-w-lg max-h-[85vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center gap-3 px-5 py-4 border-b border-border">
          <span className="text-lg">{FORMAT_ICON[editing.format]}</span>
          <div className="flex-1">
            <p className="text-xs text-muted-foreground">Semana {editing.week} · {editing.day_of_week}</p>
            <p className="text-sm font-semibold">{editing.title}</p>
          </div>
          <Badge variant="outline" className={cn("text-[10px]", FORMAT_COLOR[editing.format])}>
            {editing.format}
          </Badge>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground ml-2">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          {/* Hook */}
          <div>
            <Label className="text-xs mb-1 block">🎣 Gancho de Abertura</Label>
            <div className="flex items-start gap-2 p-3 rounded-lg bg-yellow-500/5 border border-yellow-500/20">
              <span className="text-sm flex-shrink-0">{HOOK_EMOJI[editing.hook_type] || "🎯"}</span>
              <p className="text-sm text-yellow-300/90 italic flex-1">{editing.hook}</p>
            </div>
          </div>

          {/* Angle + CTA */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs mb-1 block">Ângulo</Label>
              <p className="text-xs text-muted-foreground bg-muted/20 rounded-lg p-2">{editing.angle}</p>
            </div>
            <div>
              <Label className="text-xs mb-1 block">CTA</Label>
              <p className="text-xs text-muted-foreground bg-muted/20 rounded-lg p-2">{editing.cta}</p>
            </div>
          </div>

          {/* Date */}
          <div>
            <Label className="text-xs mb-1 block">📅 Data de Publicação</Label>
            <Input type="date" value={editing.scheduled_date || ""}
              onChange={e => setEditing(p => ({ ...p, scheduled_date: e.target.value }))}
              className="text-xs h-8" />
          </div>

          {/* Agents */}
          <div className="rounded-xl border border-border bg-muted/10 p-3.5 space-y-3">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground/50 font-semibold">
              🤖 Agentes de IA para Geração
            </p>

            {editing.format === "carrossel" || editing.format === "post" ? (
              <div>
                <Label className="text-xs mb-1.5 block text-muted-foreground">Agente Carrossel / Copy</Label>
                <Select value={editing.agent_copy || ""} onValueChange={v => setEditing(p => ({ ...p, agent_copy: v }))}>
                  <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Selecionar agente" /></SelectTrigger>
                  <SelectContent>
                    {AI_AGENTS.filter(a => ["carousel_planner","caption_writer","copywriter"].includes(a.value)).map(a => (
                      <SelectItem key={a.value} value={a.value} className="text-xs">
                        {a.icon} {a.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            ) : null}

            {editing.format === "reel" ? (
              <div>
                <Label className="text-xs mb-1.5 block text-muted-foreground">Agente Roteiro / Vídeo</Label>
                <Select value={editing.agent_video || ""} onValueChange={v => setEditing(p => ({ ...p, agent_video: v }))}>
                  <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Selecionar agente" /></SelectTrigger>
                  <SelectContent>
                    {AI_AGENTS.filter(a => ["script_writer","copywriter","hook_analyst"].includes(a.value)).map(a => (
                      <SelectItem key={a.value} value={a.value} className="text-xs">
                        {a.icon} {a.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            ) : null}

            <div>
              <Label className="text-xs mb-1.5 block text-muted-foreground">Modelo de IA</Label>
              <Select value={editing.ai_model || ""} onValueChange={v => setEditing(p => ({ ...p, ai_model: v }))}>
                <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Modelo padrão" /></SelectTrigger>
                <SelectContent>
                  {AI_MODELS.map(m => (
                    <SelectItem key={m.value} value={m.value} className="text-xs">
                      {m.label} <span className="text-muted-foreground">({m.provider})</span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Notes */}
          <div>
            <Label className="text-xs mb-1 block">Notas de Produção</Label>
            <Textarea value={editing.notes || ""} onChange={e => setEditing(p => ({ ...p, notes: e.target.value }))}
              placeholder="Referências, ideias visuais, dados específicos..." rows={2} className="text-xs" />
          </div>

          {/* Actions */}
          <div className="flex gap-2 pt-1">
            <Button onClick={() => onSave(editing)} size="sm"
              className="flex-1 gap-1.5 text-xs bg-yellow-500 hover:bg-yellow-400 text-black font-semibold h-8">
              <Check className="w-3.5 h-3.5" />Salvar
            </Button>
            <Button onClick={onClose} variant="outline" size="sm" className="text-xs h-8">Cancelar</Button>
          </div>
        </div>
      </div>
    </div>
  )
}

// ── Strategy Brief Form ───────────────────────────────────────────────────────
function StrategyForm({ onGenerated }: { onGenerated: (s: ContentStrategy) => void }) {
  const [prompt, setPrompt] = useState("")
  const [weeks, setWeeks] = useState(4)
  const [postsPerWeek, setPostsPerWeek] = useState(5)
  const [distReel, setDistReel] = useState(3)
  const [distCarrossel, setDistCarrossel] = useState(2)
  const [pillar1, setPillar1] = useState("")
  const [pillar2, setPillar2] = useState("")
  const [pillar3, setPillar3] = useState("")
  const [apiKey, setApiKey] = useState("")
  const [generating, setGenerating] = useState(false)
  const [showAdvanced, setShowAdvanced] = useState(false)

  const distPost = Math.max(0, postsPerWeek - distReel - distCarrossel)
  const SUPA_URL = import.meta.env.VITE_SUPABASE_URL

  async function generate() {
    if (!prompt.trim()) { toast.error("Descreva o que você quer na estratégia"); return }
    setGenerating(true)
    try {
      const { data: { session } } = await supabase.auth.getSession()

      // Try to get saved API key
      let keyToUse = apiKey
      if (!keyToUse) {
        const { data: keyRow } = await supabase
          .from("user_api_keys")
          .select("api_key")
          .eq("provider", "anthropic")
          .maybeSingle()
        keyToUse = (keyRow as any)?.api_key || ""
      }

      const res = await fetch(`${SUPA_URL}/functions/v1/strategy-planner`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.access_token}` },
        body: JSON.stringify({
          action: "generate",
          prompt,
          weeks,
          postsPerWeek,
          distribution: { reel: distReel, carrossel: distCarrossel, post: distPost },
          pillar1, pillar2, pillar3,
          anthropicApiKey: keyToUse || undefined,
        }),
      })
      const d = await res.json()
      if (!d.success) throw new Error(d.error)
      toast.success(`Estratégia gerada! ${d.strategy.posts?.length || 0} publicações planejadas.`)
      onGenerated(d.strategy)
    } catch (e: any) {
      toast.error(e.message)
    } finally {
      setGenerating(false)
    }
  }

  return (
    <div className="space-y-5 max-w-2xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-yellow-500/20 to-yellow-500/5 border border-yellow-500/30 flex items-center justify-center">
          <Sparkles className="w-5 h-5 text-yellow-400" />
        </div>
        <div>
          <h3 className="font-bold text-sm">Gerar Estratégia com IA</h3>
          <p className="text-xs text-muted-foreground">Claude Opus 4 · Anthropic API</p>
        </div>
      </div>

      {/* Main prompt */}
      <div>
        <Label className="text-xs mb-1.5 block">Brief para o Agente</Label>
        <Textarea
          value={prompt}
          onChange={e => setPrompt(e.target.value)}
          placeholder={`Descreva o que você quer na estratégia. Exemplos:\n\n"Quero focar em juros abusivos no cartão de crédito para o mês de abril, com conteúdo educativo que gere leads para consultoria. Temos o Día do Consumidor em 15/03 — aproveitar a data."\n\n"Lançamento do meu e-book sobre revisão de contrato de financiamento. Preciso de conteúdo de aquecimento na semana 1, teaser na semana 2 e venda nas semanas 3-4."`}
          rows={5}
          className="text-xs"
        />
      </div>

      {/* Volume */}
      <div className="rounded-xl border border-border bg-card p-4 space-y-3">
        <p className="text-xs font-semibold text-muted-foreground">Volume de Publicações</p>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label className="text-[10px] mb-1 block text-muted-foreground">Semanas de planejamento</Label>
            <div className="flex items-center gap-2">
              <button onClick={() => setWeeks(Math.max(1, weeks-1))} className="w-7 h-7 rounded-md border border-border hover:bg-accent flex items-center justify-center text-sm">−</button>
              <span className="text-sm font-bold w-8 text-center">{weeks}</span>
              <button onClick={() => setWeeks(Math.min(12, weeks+1))} className="w-7 h-7 rounded-md border border-border hover:bg-accent flex items-center justify-center text-sm">+</button>
            </div>
          </div>
          <div>
            <Label className="text-[10px] mb-1 block text-muted-foreground">Posts por semana</Label>
            <div className="flex items-center gap-2">
              <button onClick={() => setPostsPerWeek(Math.max(1, postsPerWeek-1))} className="w-7 h-7 rounded-md border border-border hover:bg-accent flex items-center justify-center text-sm">−</button>
              <span className="text-sm font-bold w-8 text-center">{postsPerWeek}</span>
              <button onClick={() => setPostsPerWeek(Math.min(14, postsPerWeek+1))} className="w-7 h-7 rounded-md border border-border hover:bg-accent flex items-center justify-center text-sm">+</button>
            </div>
          </div>
        </div>

        {/* Format distribution */}
        <div>
          <Label className="text-[10px] mb-2 block text-muted-foreground">Distribuição de formatos ({postsPerWeek}/semana)</Label>
          <div className="flex gap-2">
            {[
              { label: "🎬 Reels", val: distReel, set: setDistReel, max: postsPerWeek },
              { label: "🎠 Carrosséis", val: distCarrossel, set: setDistCarrossel, max: postsPerWeek },
              { label: "📸 Posts", val: distPost, readOnly: true },
            ].map(f => (
              <div key={f.label} className="flex-1 text-center">
                <p className="text-[10px] text-muted-foreground mb-1">{f.label}</p>
                <div className="flex items-center justify-center gap-1">
                  {!f.readOnly && <button onClick={() => f.set!(Math.max(0, f.val-1))} className="w-5 h-5 rounded border border-border hover:bg-accent text-[10px] flex items-center justify-center">−</button>}
                  <span className={cn("text-sm font-bold w-6 text-center", f.readOnly && "text-muted-foreground")}>{f.val}</span>
                  {!f.readOnly && <button onClick={() => f.set!(Math.min(f.max!, f.val+1))} className="w-5 h-5 rounded border border-border hover:bg-accent text-[10px] flex items-center justify-center">+</button>}
                </div>
              </div>
            ))}
          </div>
          {/* Bar viz */}
          <div className="flex gap-0.5 h-2 rounded-full overflow-hidden mt-2">
            <div className="bg-blue-500/60 transition-all" style={{ width: `${(distReel/postsPerWeek)*100}%` }} />
            <div className="bg-yellow-500/60 transition-all" style={{ width: `${(distCarrossel/postsPerWeek)*100}%` }} />
            <div className="bg-green-500/60 transition-all" style={{ width: `${(distPost/postsPerWeek)*100}%` }} />
          </div>
          <p className="text-[10px] text-muted-foreground mt-1 text-center">
            Total: <strong>{weeks * postsPerWeek}</strong> publicações em {weeks} semanas
          </p>
        </div>
      </div>

      {/* Pillars (advanced) */}
      <button onClick={() => setShowAdvanced(v => !v)}
        className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground">
        {showAdvanced ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
        {showAdvanced ? "Ocultar" : "Mostrar"} pilares de conteúdo e API key
      </button>

      {showAdvanced && (
        <div className="space-y-3 rounded-xl border border-border bg-muted/10 p-4">
          <p className="text-xs font-semibold text-muted-foreground">Pilares de Conteúdo (opcional)</p>
          <div className="space-y-2">
            {[
              { label: "Pilar 1", val: pillar1, set: setPillar1, placeholder: "Ex: Educação jurídica — direitos do consumidor" },
              { label: "Pilar 2", val: pillar2, set: setPillar2, placeholder: "Ex: Casos reais e resultados de clientes" },
              { label: "Pilar 3", val: pillar3, set: setPillar3, placeholder: "Ex: Bastidores do escritório e vida de advogado" },
            ].map(p => (
              <div key={p.label}>
                <Label className="text-[10px] mb-0.5 block text-muted-foreground">{p.label}</Label>
                <Input value={p.val} onChange={e => p.set(e.target.value)} placeholder={p.placeholder} className="text-xs h-8" />
              </div>
            ))}
          </div>
          <div>
            <Label className="text-[10px] mb-0.5 block text-muted-foreground">Anthropic API Key (usa a salva em Agentes se vazio)</Label>
            <Input type="password" value={apiKey} onChange={e => setApiKey(e.target.value)}
              placeholder="sk-ant-..." className="text-xs h-8 font-mono" />
          </div>
        </div>
      )}

      <Button onClick={generate} disabled={generating || !prompt.trim()}
        className="w-full gap-2 bg-gradient-to-r from-yellow-500 to-yellow-400 hover:from-yellow-400 hover:to-yellow-300 text-black font-bold h-10">
        {generating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
        {generating ? "Gerando estratégia com Claude Opus 4..." : "Gerar Estratégia com IA"}
      </Button>
    </div>
  )
}

// ── Editorial Calendar ────────────────────────────────────────────────────────
function EditorialCalendar({ strategy, onUpdatePost }: {
  strategy: ContentStrategy
  onUpdatePost: (postId: string, updates: Partial<StrategyPost>) => void
}) {
  const [currentDate, setCurrentDate] = useState(new Date())
  const [editingPost, setEditingPost] = useState<StrategyPost | null>(null)
  const [activatingDate, setActivatingDate] = useState("")
  const [activating, setActivating] = useState(false)
  const [selectedWeek, setSelectedWeek] = useState<number | "all">("all")
  const SUPA_URL = import.meta.env.VITE_SUPABASE_URL

  const year  = currentDate.getFullYear()
  const month = currentDate.getMonth()
  const days  = getMonthCalendar(year, month)

  // Map posts to date keys
  const postsByDate = useMemo(() => {
    const map: Record<string, StrategyPost[]> = {}
    for (const post of strategy.posts) {
      if (post.scheduled_date) {
        if (!map[post.scheduled_date]) map[post.scheduled_date] = []
        map[post.scheduled_date].push(post)
      }
    }
    return map
  }, [strategy.posts])

  // Posts by week (for week view)
  const postsByWeek = useMemo(() => {
    const map: Record<number, StrategyPost[]> = {}
    for (const post of strategy.posts) {
      if (!map[post.week]) map[post.week] = []
      map[post.week].push(post)
    }
    return map
  }, [strategy.posts])

  // Counts
  const total = strategy.posts.length
  const scheduled = strategy.posts.filter(p => p.scheduled_date).length
  const withAgent = strategy.posts.filter(p => p.agent_copy || p.agent_video).length

  async function activate() {
    if (!activatingDate) { toast.error("Selecione a data de início"); return }
    setActivating(true)
    try {
      const { data: { session } } = await supabase.auth.getSession()
      const res = await fetch(`${SUPA_URL}/functions/v1/strategy-planner`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.access_token}` },
        body: JSON.stringify({ action: "activate", strategyId: strategy.id, startDate: activatingDate }),
      })
      const d = await res.json()
      if (!d.success) throw new Error(d.error)
      toast.success("Estratégia ativada! Datas calculadas automaticamente.")
      window.location.reload()
    } catch (e: any) { toast.error(e.message) }
    finally { setActivating(false) }
  }

  const monthName = new Date(year, month, 1).toLocaleDateString("pt-BR", { month: "long", year: "numeric" })

  return (
    <div className="space-y-4">
      {/* Strategy header */}
      <div className="rounded-xl border border-border bg-card p-4">
        <div className="flex items-start gap-3 mb-3">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <h3 className="font-bold text-sm">{strategy.name}</h3>
              <Badge variant="outline" className={cn("text-[10px]",
                strategy.status === "active" ? "text-green-400 border-green-500/30" :
                strategy.status === "draft"  ? "text-yellow-400 border-yellow-500/30" :
                "text-muted-foreground"
              )}>
                {strategy.status}
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground">{strategy.summary}</p>
          </div>
          <div className="text-right flex-shrink-0">
            <p className="text-[10px] text-muted-foreground">{strategy.weeks} semanas</p>
            <p className="text-xs font-bold">{total} posts</p>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-2 mb-3">
          {[
            { label: "Agendados", val: scheduled, total, color: "text-blue-400" },
            { label: "Com agente", val: withAgent, total, color: "text-yellow-400" },
            { label: "Prontos",    val: strategy.posts.filter(p => p.status === "ready").length, total, color: "text-green-400" },
          ].map(s => (
            <div key={s.label} className="text-center rounded-lg bg-muted/20 p-2">
              <p className={cn("text-base font-bold", s.color)}>{s.val}</p>
              <p className="text-[9px] text-muted-foreground">{s.label}</p>
              <div className="h-1 bg-muted/30 rounded-full mt-1 overflow-hidden">
                <div className="h-full bg-current rounded-full" style={{ width: `${(s.val/s.total)*100}%`, opacity: 0.6 }} />
              </div>
            </div>
          ))}
        </div>

        {/* Pillars */}
        {strategy.pillars.length > 0 && (
          <div className="flex gap-1.5 flex-wrap">
            {strategy.pillars.map((p, i) => (
              <span key={i} className="text-[10px] px-2 py-0.5 rounded-full border"
                style={{ borderColor: p.color + "40", color: p.color, backgroundColor: p.color + "10" }}>
                {p.name} ({p.posts_count})
              </span>
            ))}
          </div>
        )}

        {/* Activate */}
        {strategy.status === "draft" && (
          <div className="flex items-center gap-2 mt-3 pt-3 border-t border-border">
            <Input type="date" value={activatingDate} onChange={e => setActivatingDate(e.target.value)}
              className="text-xs h-8 flex-1" placeholder="Data de início" />
            <Button onClick={activate} disabled={activating || !activatingDate} size="sm"
              className="gap-1 text-xs bg-green-600 hover:bg-green-500 text-white h-8 flex-shrink-0">
              {activating ? <Loader2 className="w-3 h-3 animate-spin" /> : <Play className="w-3 h-3" />}
              Ativar
            </Button>
          </div>
        )}
      </div>

      {/* Week tabs */}
      <div className="flex gap-1 overflow-x-auto pb-1">
        <button onClick={() => setSelectedWeek("all")}
          className={cn("px-3 py-1 rounded-lg text-xs font-medium transition-colors flex-shrink-0",
            selectedWeek === "all" ? "bg-yellow-500/20 text-yellow-400 border border-yellow-500/30" : "border border-border text-muted-foreground hover:text-foreground"
          )}>
          Todas
        </button>
        {Array.from({ length: strategy.weeks }, (_, i) => i + 1).map(w => {
          const theme = strategy.weekly_themes?.find(t => t.week === w)
          return (
            <button key={w} onClick={() => setSelectedWeek(w)}
              className={cn("px-3 py-1 rounded-lg text-xs font-medium transition-colors flex-shrink-0",
                selectedWeek === w ? "bg-yellow-500/20 text-yellow-400 border border-yellow-500/30" : "border border-border text-muted-foreground hover:text-foreground"
              )}>
              S{w}{theme ? ` · ${theme.theme.slice(0, 12)}` : ""}
            </button>
          )
        })}
      </div>

      {/* View: Calendar (if activated) or Week grid */}
      {strategy.status === "active" && scheduled > 0 ? (
        <div className="rounded-xl border border-border bg-card overflow-hidden">
          {/* Month nav */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-border">
            <button onClick={() => setCurrentDate(new Date(year, month - 1, 1))} className="text-muted-foreground hover:text-foreground">
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-sm font-semibold capitalize">{monthName}</span>
            <button onClick={() => setCurrentDate(new Date(year, month + 1, 1))} className="text-muted-foreground hover:text-foreground">
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Day headers */}
          <div className="grid grid-cols-7 border-b border-border">
            {["Seg","Ter","Qua","Qui","Sex","Sáb","Dom"].map(d => (
              <div key={d} className="text-center text-[10px] text-muted-foreground/60 py-2 font-semibold">{d}</div>
            ))}
          </div>

          {/* Days */}
          <div className="grid grid-cols-7">
            {days.map((day, i) => {
              const key = day ? dateKey(day) : ""
              const posts = day ? (postsByDate[key] || []) : []
              const isToday = day ? dateKey(day) === dateKey(new Date()) : false
              return (
                <div key={i} className={cn(
                  "min-h-[80px] p-1.5 border-b border-r border-border/40 last:border-r-0",
                  !day && "bg-muted/5",
                  isToday && "bg-yellow-500/5"
                )}>
                  {day && (
                    <>
                      <p className={cn("text-[11px] mb-1 font-mono",
                        isToday ? "text-yellow-400 font-bold" : "text-muted-foreground/60"
                      )}>{day.getDate()}</p>
                      <div className="space-y-0.5">
                        {posts.map(p => (
                          <PostChip key={p.id} post={p} onClick={() => setEditingPost(p)} />
                        ))}
                      </div>
                    </>
                  )}
                </div>
              )
            })}
          </div>
        </div>
      ) : (
        /* Week grid view */
        <div className="space-y-3">
          {Object.entries(postsByWeek)
            .filter(([w]) => selectedWeek === "all" || Number(w) === selectedWeek)
            .map(([week, posts]) => {
              const theme = strategy.weekly_themes?.find(t => t.week === Number(week))
              return (
                <div key={week} className="rounded-xl border border-border bg-card overflow-hidden">
                  <div className="flex items-center gap-3 px-4 py-2.5 border-b border-border/50 bg-muted/10">
                    <span className="text-xs font-bold text-yellow-400">Semana {week}</span>
                    {theme && <span className="text-xs text-muted-foreground">· {theme.theme}</span>}
                    <span className="ml-auto text-[10px] text-muted-foreground">{posts.length} posts</span>
                  </div>
                  <div className="p-3 grid grid-cols-1 gap-1.5">
                    {WEEKDAYS.map(day => {
                      const dayPosts = posts.filter(p => p.day_of_week === day)
                      return (
                        <div key={day} className="flex items-start gap-2">
                          <span className="text-[10px] text-muted-foreground/50 w-8 pt-0.5 flex-shrink-0 font-mono">
                            {WEEKDAY_SHORT[WEEKDAYS.indexOf(day)]}
                          </span>
                          <div className="flex-1 flex gap-1.5 flex-wrap">
                            {dayPosts.length === 0 ? (
                              <span className="text-[10px] text-muted-foreground/30 italic">—</span>
                            ) : dayPosts.map(p => (
                              <button key={p.id} onClick={() => setEditingPost(p)}
                                className={cn(
                                  "flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-[11px] font-medium transition-all hover:scale-[1.02]",
                                  FORMAT_COLOR[p.format]
                                )}>
                                {FORMAT_ICON[p.format]}
                                <span className="max-w-[160px] truncate">{p.title}</span>
                                {p.hook_type && (
                                  <span className="opacity-60">{HOOK_EMOJI[p.hook_type]}</span>
                                )}
                                {(p.agent_copy || p.agent_video) && (
                                  <Brain className="w-3 h-3 opacity-50" />
                                )}
                              </button>
                            ))}
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </div>
              )
            })}
        </div>
      )}

      {/* Post editor */}
      {editingPost && (
        <PostEditor
          post={editingPost}
          onSave={updates => {
            onUpdatePost(editingPost.id, updates)
            setEditingPost(null)
          }}
          onClose={() => setEditingPost(null)}
        />
      )}

      {/* Insights */}
      {strategy.insights?.length > 0 && (
        <div className="rounded-xl border border-border bg-card p-4">
          <p className="text-[10px] uppercase tracking-wider text-muted-foreground/40 mb-2.5">💡 Insights Estratégicos</p>
          <ul className="space-y-1.5">
            {strategy.insights.map((ins, i) => (
              <li key={i} className="flex items-start gap-2 text-xs text-muted-foreground">
                <span className="text-yellow-400 flex-shrink-0 mt-0.5">→</span>
                {ins}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  )
}

// ── Main Component ─────────────────────────────────────────────────────────────
export function ContentPlanner() {
  const [strategies, setStrategies] = useState<ContentStrategy[]>([])
  const [activeStrategy, setActiveStrategy] = useState<ContentStrategy | null>(null)
  const [view, setView] = useState<"generate" | "calendar">("generate")
  const [loading, setLoading] = useState(true)
  const [deleting, setDeleting] = useState<string | null>(null)
  const SUPA_URL = import.meta.env.VITE_SUPABASE_URL

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const { data: { session } } = await supabase.auth.getSession()
      const res = await fetch(`${SUPA_URL}/functions/v1/strategy-planner`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.access_token}` },
        body: JSON.stringify({ action: "list" }),
      })
      const d = await res.json()
      if (d.success) {
        setStrategies(d.strategies || [])
        // Auto-select active strategy
        const active = d.strategies?.find((s: ContentStrategy) => s.status === "active")
        if (active && !activeStrategy) {
          setActiveStrategy(active)
          setView("calendar")
        }
      }
    } finally { setLoading(false) }
  }, [])

  useEffect(() => { load() }, [load])

  async function loadFull(strategyId: string) {
    const { data: { session } } = await supabase.auth.getSession()
    const res = await fetch(`${SUPA_URL}/functions/v1/strategy-planner`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.access_token}` },
      body: JSON.stringify({ action: "get", strategyId }),
    })
    const d = await res.json()
    if (d.success) { setActiveStrategy(d.strategy); setView("calendar") }
  }

  async function updatePost(postId: string, updates: Partial<StrategyPost>) {
    if (!activeStrategy) return
    // Optimistic update
    const updatedPosts = activeStrategy.posts.map(p => p.id === postId ? { ...p, ...updates } : p)
    setActiveStrategy({ ...activeStrategy, posts: updatedPosts })

    const { data: { session } } = await supabase.auth.getSession()
    await fetch(`${SUPA_URL}/functions/v1/strategy-planner`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.access_token}` },
      body: JSON.stringify({ action: "update_post", strategyId: activeStrategy.id, postId, updates }),
    })
  }

  async function deleteStrategy(id: string) {
    setDeleting(id)
    try {
      const { data: { session } } = await supabase.auth.getSession()
      await fetch(`${SUPA_URL}/functions/v1/strategy-planner`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.access_token}` },
        body: JSON.stringify({ action: "delete", strategyId: id }),
      })
      if (activeStrategy?.id === id) { setActiveStrategy(null); setView("generate") }
      load()
    } finally { setDeleting(null) }
  }

  return (
    <div className="flex h-full">
      {/* Sidebar — strategy list */}
      <div className="w-64 flex-shrink-0 border-r border-border flex flex-col">
        <div className="p-4 border-b border-border">
          <h2 className="font-bold text-sm flex items-center gap-2">
            <Calendar className="w-4 h-4 text-yellow-400" />
            Planejamento
          </h2>
        </div>
        <div className="p-3">
          <Button onClick={() => { setActiveStrategy(null); setView("generate") }} size="sm"
            className="w-full gap-1.5 text-xs bg-yellow-500/20 text-yellow-400 border border-yellow-500/30 hover:bg-yellow-500/30 h-8">
            <Plus className="w-3.5 h-3.5" />Nova Estratégia
          </Button>
        </div>
        <div className="flex-1 overflow-y-auto px-3 space-y-1.5 pb-4">
          {loading ? (
            Array.from({length:3}).map((_,i) => <div key={i} className="h-16 rounded-lg bg-muted/20 animate-pulse" />)
          ) : strategies.length === 0 ? (
            <p className="text-xs text-muted-foreground/50 text-center py-4">Nenhuma estratégia ainda</p>
          ) : strategies.map(s => (
            <div key={s.id}
              className={cn(
                "rounded-xl border p-3 cursor-pointer transition-all group",
                activeStrategy?.id === s.id
                  ? "border-yellow-500/40 bg-yellow-500/5"
                  : "border-border bg-card hover:border-yellow-500/20"
              )}
              onClick={() => loadFull(s.id)}>
              <div className="flex items-start gap-1.5">
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold truncate">{s.name}</p>
                  <div className="flex items-center gap-1 mt-0.5">
                    <Badge variant="outline" className={cn("text-[9px] px-1 py-0",
                      s.status === "active" ? "text-green-400 border-green-500/30" :
                      s.status === "draft"  ? "text-yellow-400 border-yellow-500/30" :
                      "text-muted-foreground"
                    )}>{s.status}</Badge>
                    <span className="text-[9px] text-muted-foreground">{s.weeks}sem</span>
                  </div>
                </div>
                <button onClick={e => { e.stopPropagation(); deleteStrategy(s.id) }}
                  disabled={deleting === s.id}
                  className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-red-400 transition-all">
                  {deleting === s.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <Trash2 className="w-3 h-3" />}
                </button>
              </div>
              <div className="flex gap-1 mt-1.5">
                {(s.pillars || []).slice(0,3).map((p: any, i: number) => (
                  <div key={i} className="w-2 h-2 rounded-full" style={{ backgroundColor: p.color || "#C9A84C" }} />
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-6 max-w-4xl mx-auto">
          {view === "generate" && (
            <StrategyForm
              onGenerated={strategy => {
                setStrategies(prev => [strategy, ...prev])
                setActiveStrategy(strategy)
                setView("calendar")
              }}
            />
          )}
          {view === "calendar" && activeStrategy && (
            <EditorialCalendar strategy={activeStrategy} onUpdatePost={updatePost} />
          )}
          {view === "calendar" && !activeStrategy && (
            <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
              <Calendar className="w-12 h-12 opacity-20 mb-3" />
              <p className="text-sm">Selecione uma estratégia</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
