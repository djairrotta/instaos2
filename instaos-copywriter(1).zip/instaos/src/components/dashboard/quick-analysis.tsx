import { useState, KeyboardEvent } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Zap, Loader2, UserPlus, X } from "lucide-react"

interface QuickAnalysisProps {
  onAnalyze: (urls: string[]) => void
  onAddCompetitor: (urls: string[]) => void
  isLoading?: boolean
}

export function QuickAnalysis({ onAnalyze, onAddCompetitor, isLoading }: QuickAnalysisProps) {
  const [url, setUrl] = useState("")
  const [urls, setUrls] = useState<string[]>([])

  const handleAddUrl = () => {
    if (url.trim() && !urls.includes(url.trim())) {
      setUrls([...urls, url.trim()])
      setUrl("")
    }
  }

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      e.preventDefault()
      handleAddUrl()
    }
  }

  const handleRemoveUrl = (urlToRemove: string) => {
    setUrls(urls.filter((u) => u !== urlToRemove))
  }

  const handleAnalyze = () => {
    const allUrls = url.trim() ? [...urls, url.trim()] : urls
    if (allUrls.length > 0) {
      onAnalyze(allUrls)
      setUrls([])
      setUrl("")
    }
  }

  const handleAddCompetitor = () => {
    const allUrls = url.trim() ? [...urls, url.trim()] : urls
    if (allUrls.length > 0) {
      onAddCompetitor(allUrls)
      setUrls([])
      setUrl("")
    }
  }

  return (
    <div className="space-y-3">
      <div className="relative flex gap-2">
        <div className="relative flex-1">
          <Input
            placeholder="Cole a URL do Reel ou @usuario para adicionar..."
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            onKeyDown={handleKeyDown}
            onBlur={handleAddUrl}
            className="h-12 pr-4 text-base"
          />
        </div>
        <Button
          onClick={handleAnalyze}
          disabled={urls.length === 0 && !url.trim() || isLoading}
          className="gap-2 h-12 px-6"
        >
          {isLoading ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Zap className="h-4 w-4" />
          )}
          Analisar
        </Button>
        <Button
          onClick={handleAddCompetitor}
          disabled={urls.length === 0 && !url.trim() || isLoading}
          className="gap-2 h-12 px-6"
          variant="secondary"
        >
          <UserPlus className="h-4 w-4" />
          Competidor
        </Button>
      </div>

      {urls.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {urls.map((savedUrl, index) => (
            <Badge
              key={index}
              variant="secondary"
              className="px-3 py-1.5 text-sm gap-2 max-w-[300px]"
            >
              <span className="truncate">{savedUrl}</span>
              <button onClick={() => handleRemoveUrl(savedUrl)} className="hover:text-destructive">
                <X className="h-3 w-3" />
              </button>
            </Badge>
          ))}
        </div>
      )}
    </div>
  )
}
