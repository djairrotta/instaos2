import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar as CalendarIcon, Clock, Upload, Loader2, Send } from "lucide-react"
import { useState } from "react"
import { toast } from "sonner"
import { format } from "date-fns"
import { cn } from "@/lib/utils"
import { supabase } from "@/integrations/supabase/client"

interface PublishModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  contentType: string | null
  generatedContent?: string
}

const hours = Array.from({ length: 24 }, (_, i) => i.toString().padStart(2, "0"))
const minutes = ["00", "15", "30", "45"]

export function PublishModal({ open, onOpenChange, contentType, generatedContent }: PublishModalProps) {
  const [caption, setCaption] = useState(generatedContent || "")
  const [scheduledDate, setScheduledDate] = useState<Date | undefined>()
  const [scheduledHour, setScheduledHour] = useState("09")
  const [scheduledMinute, setScheduledMinute] = useState("00")
  const [loading, setLoading] = useState(false)

  const contentTypeMap: Record<string, string> = {
    video: "video", reel: "reel", carrossel: "carousel", post: "post", story: "story",
  }

  const handleSendToQueue = async (withSchedule: boolean) => {
    setLoading(true)
    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) throw new Error("Usuário não autenticado")

      let scheduled_at: string | null = null
      if (withSchedule) {
        if (!scheduledDate) { toast.error("Selecione uma data para agendar"); setLoading(false); return }
        const dt = new Date(scheduledDate)
        dt.setHours(parseInt(scheduledHour), parseInt(scheduledMinute), 0, 0)
        if (dt <= new Date()) { toast.error("A data deve ser no futuro"); setLoading(false); return }
        scheduled_at = dt.toISOString()
      }

      const { error } = await supabase.from("publish_queue").insert({
        user_id: user.id,
        content_type: contentTypeMap[contentType || "post"] || "post",
        caption: caption || generatedContent || null,
        status: withSchedule ? "scheduled" : "pending_approval",
        scheduled_at,
      })
      if (error) throw error

      toast.success(withSchedule ? "Publicação agendada!" : "Enviado para a fila!", {
        description: withSchedule
          ? `Agendado para ${format(new Date(scheduled_at!), "dd/MM/yyyy 'às' HH:mm")}`
          : "Acesse a Fila de Publicação para aprovar.",
      })
      onOpenChange(false)
      setCaption("")
      setScheduledDate(undefined)
    } catch (e: any) {
      toast.error("Erro", { description: e.message })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Publicar {contentType}
          </DialogTitle>
          <DialogDescription>
            Envie para a fila ou agende a publicação automática
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 mt-4">
          <div className="space-y-2">
            <Label>Legenda</Label>
            <Textarea
              placeholder="Escreva a legenda do post..."
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              rows={4}
            />
          </div>

          <div className="space-y-2">
            <Label>Agendar para (opcional)</Label>
            <div className="flex gap-2">
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className={cn("flex-1 justify-start text-left font-normal", !scheduledDate && "text-muted-foreground")}>
                    <CalendarIcon className="h-4 w-4 mr-2" />
                    {scheduledDate ? format(scheduledDate, "dd/MM/yyyy") : "Selecionar data"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={scheduledDate}
                    onSelect={setScheduledDate}
                    disabled={(date) => date < new Date(new Date().setHours(0, 0, 0, 0))}
                    initialFocus
                    className={cn("p-3 pointer-events-auto")}
                  />
                </PopoverContent>
              </Popover>
              <Select value={scheduledHour} onValueChange={setScheduledHour}>
                <SelectTrigger className="w-[72px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {hours.map(h => <SelectItem key={h} value={h}>{h}h</SelectItem>)}
                </SelectContent>
              </Select>
              <span className="flex items-center text-muted-foreground">:</span>
              <Select value={scheduledMinute} onValueChange={setScheduledMinute}>
                <SelectTrigger className="w-[72px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {minutes.map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex gap-2 pt-4 border-t">
            <Button variant="outline" className="flex-1 gap-2" onClick={() => handleSendToQueue(false)} disabled={loading}>
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
              Enviar para Fila
            </Button>
            <Button className="flex-1 gap-2" onClick={() => handleSendToQueue(true)} disabled={loading || !scheduledDate}>
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Clock className="h-4 w-4" />}
              Agendar
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
