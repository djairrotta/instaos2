import { useState, useMemo, useCallback } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from "@/components/ui/dialog"
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Search, ChevronLeft, ChevronRight, ExternalLink, Filter, ArrowUpDown, ArrowUp, ArrowDown,
  HelpCircle, Paperclip, Type, User, Link, FileText, BarChart2, Eye,
  Heart, MessageCircle, Percent, Calendar, List, LayoutGrid, Table2, SlidersHorizontal,
  Users, ImageIcon, TrendingUp, Film, Image, Layers, Zap, Brain, ScanEye, Loader2, Download,
  CheckCircle, XCircle, Clock, Shield, Sparkles, Copy, Play, RefreshCw, Trash2,
} from "lucide-react"
import {
  Tooltip, TooltipContent, TooltipProvider, TooltipTrigger,
} from "@/components/ui/tooltip"
import { supabase } from "@/integrations/supabase/client"
import { toast } from "sonner"

export type DataTableTab = "competidores" | "meus_reels" | "reels_competidores" | "estrategia"

export interface CompetitorRow {
  id: string; name: string; pageUrl: string; niche: string; selected?: boolean
  bio?: string; followersCount?: number; followingCount?: number; postsCount?: number
  profilePicUrl?: string; predominantContentType?: string; avgPostsPerWeek?: number
}

export interface ReelRow {
  id: string; thumbnail?: string; caption: string; user: string; url: string
  transcript?: string; hookAnalysis?: string; views: number; likes: number
  comments: number; engRate: number; postDate: string; contentType?: string
  viralPoints?: string[]; psychTriggers?: string[]
  imageUrls?: string[]; imageAnalysis?: string
  videoUrl?: string
  relevanceStatus?: string; relevanceScore?: number; relevanceReason?: string
}

export interface StrategyRow {
  id: string; topic: string; format: string; hook: string; status: string; priority: string
  rawReport?: string; createdAt?: string
}

interface DataTableProps {
  competitorData: CompetitorRow[]
  meusReelsData: ReelRow[]
  reelsCompetidoresData: ReelRow[]
  strategyData: StrategyRow[]
  onCompetitorSelect?: (id: string, selected: boolean) => void
  onReelRelevanceUpdate?: (id: string, status: string, table: "meus_reels" | "reels_competidores") => void
  onCopyReelWithAI?: (data: { hookAnalysis: string; transcript: string; caption?: string; viralPoints?: string; psychTriggers?: string; relevanceReason?: string; ownerUsername?: string; contentType?: string; url?: string }, generationType?: string) => void
  onRefreshData?: () => Promise<void>
  onImportMyProfile?: (username?: string) => void
  importingProfile?: boolean
}

const CONTENT_TYPE_OPTIONS = [
  { value: "all", label: "Todos os tipos", icon: Layers },
  { value: "reel", label: "Reels", icon: Film },
  { value: "post", label: "Posts", icon: Image },
  { value: "carousel", label: "Carrosséis", icon: Layers },
]

function EditableNicheCell({ competitorId, value }: { competitorId: string; value: string }) {
  const [editing, setEditing] = useState(false)
  const [niche, setNiche] = useState(value)
  const [saving, setSaving] = useState(false)

  const save = async () => {
    if (niche === value) { setEditing(false); return }
    setSaving(true)
    try {
      const { error } = await supabase.from("competidores").update({ niche }).eq("id", competitorId)
      if (error) throw error
      toast.success("Nicho atualizado!")
      setEditing(false)
    } catch (e: any) {
      toast.error("Erro ao salvar", { description: e.message })
    } finally {
      setSaving(false)
    }
  }

  if (editing) {
    return (
      <div className="flex items-center gap-1">
        <Input
          value={niche}
          onChange={(e) => setNiche(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter") save(); if (e.key === "Escape") { setNiche(value); setEditing(false) } }}
          onBlur={save}
          className="h-7 text-xs w-28"
          autoFocus
          disabled={saving}
        />
      </div>
    )
  }

  return (
    <button
      className="text-sm text-muted-foreground hover:text-foreground hover:underline underline-offset-2 transition-colors text-left"
      onClick={() => setEditing(true)}
      title="Clique para editar o nicho"
    >
      {value || <span className="italic text-muted-foreground/50">+ nicho</span>}
    </button>
  )
}

function ImportProfileButton({ onImport, importing }: { onImport: (username?: string) => void; importing: boolean }) {
  const [showInput, setShowInput] = useState(false)
  const [username, setUsername] = useState("")

  if (importing) {
    return (
      <Button variant="outline" size="sm" className="h-8 gap-1.5 text-xs border-primary/30 bg-primary/5" disabled>
        <Loader2 className="h-3.5 w-3.5 animate-spin" />
        Importando...
      </Button>
    )
  }

  if (showInput) {
    return (
      <div className="flex items-center gap-1">
        <Input
          value={username}
          onChange={(e) => setUsername(e.target.value.replace(/^@/, ""))}
          placeholder="@username"
          className="h-8 text-xs w-32"
          autoFocus
          onKeyDown={(e) => {
            if (e.key === "Enter" && username.trim()) { onImport(username.trim()); setShowInput(false); setUsername("") }
            if (e.key === "Escape") { setShowInput(false); setUsername("") }
          }}
        />
        <Button size="sm" className="h-8 text-xs px-2" onClick={() => { if (username.trim()) { onImport(username.trim()); setShowInput(false); setUsername("") } }} disabled={!username.trim()}>
          <Download className="h-3.5 w-3.5" />
        </Button>
      </div>
    )
  }

  return (
    <div className="flex items-center gap-1">
      <Button variant="outline" size="sm" className="h-8 gap-1.5 text-xs border-primary/30 bg-primary/5 hover:bg-primary/10" onClick={() => onImport()}>
        <Download className="h-3.5 w-3.5" />
        Importar Meu Perfil
      </Button>
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button variant="ghost" size="sm" className="h-8 px-1.5 text-xs" onClick={() => setShowInput(true)}>
              <User className="h-3.5 w-3.5" />
            </Button>
          </TooltipTrigger>
          <TooltipContent>Digitar @username manualmente</TooltipContent>
        </Tooltip>
      </TooltipProvider>
    </div>
  )
}

export function DataTable({ competitorData, meusReelsData, reelsCompetidoresData, strategyData, onCompetitorSelect, onReelRelevanceUpdate, onCopyReelWithAI, onRefreshData, onImportMyProfile, importingProfile }: DataTableProps) {
  const [activeTab, setActiveTab] = useState<DataTableTab>("competidores")
  const [search, setSearch] = useState("")
  const [currentPage, setCurrentPage] = useState(1)
  const [contentTypeFilter, setContentTypeFilter] = useState("all")
  const [triggerFilter, setTriggerFilter] = useState("all")
  const [analyzingIds, setAnalyzingIds] = useState<Set<string>>(new Set())
  const [transcribingIds, setTranscribingIds] = useState<Set<string>>(new Set())
  const [analysisModal, setAnalysisModal] = useState<{ open: boolean; title: string; content: string; images: string[] }>({ open: false, title: "", content: "", images: [] })
  const [sortKey, setSortKey] = useState<string | null>(null)
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc")
  const [exporting, setExporting] = useState(false)
  const [relevanceFilter, setRelevanceFilter] = useState<string>("all")
  const [detailModal, setDetailModal] = useState<{ open: boolean; reel: ReelRow | null }>({ open: false, reel: null })
  const [refreshingProfileIds, setRefreshingProfileIds] = useState<Set<string>>(new Set())
  const [refreshingAll, setRefreshingAll] = useState(false)
  const [refreshAllProgress, setRefreshAllProgress] = useState({ done: 0, total: 0 })
  const [nicheFilter, setNicheFilter] = useState("all")
  const [deletingIrrelevant, setDeletingIrrelevant] = useState(false)
  const [selectedCompetitorIds, setSelectedCompetitorIds] = useState<Set<string>>(new Set())
  const [deletingSelected, setDeletingSelected] = useState(false)
  const itemsPerPage = 10

  const toggleCompetitorSelection = useCallback((id: string, selected: boolean) => {
    setSelectedCompetitorIds(prev => {
      const next = new Set(prev)
      if (selected) next.add(id)
      else next.delete(id)
      return next
    })
    onCompetitorSelect?.(id, selected)
  }, [onCompetitorSelect])

  const handleDeleteSelectedCompetitors = useCallback(async () => {
    if (selectedCompetitorIds.size === 0) return
    setDeletingSelected(true)
    try {
      const ids = Array.from(selectedCompetitorIds)
      for (const id of ids) {
        await supabase.from("reels_competidores").delete().eq("competidor_id", id)
        const { error } = await supabase.from("competidores").delete().eq("id", id)
        if (error) throw error
      }
      toast.success(`${ids.length} competidor(es) removido(s) com sucesso`)
      setSelectedCompetitorIds(new Set())
      if (onRefreshData) await onRefreshData()
    } catch (e: any) {
      toast.error("Erro ao deletar competidores", { description: e.message })
    } finally {
      setDeletingSelected(false)
    }
  }, [selectedCompetitorIds, onRefreshData])

  const toggleSort = useCallback((key: string) => {
    if (sortKey === key) {
      setSortDir(d => d === "desc" ? "asc" : "desc")
    } else {
      setSortKey(key)
      setSortDir("desc")
    }
  }, [sortKey])

  const SortHeader = ({ label, sortField, icon }: { label: string; sortField: string; icon?: React.ReactNode }) => (
    <button className="flex items-center gap-1.5 text-muted-foreground hover:text-foreground transition-colors group" onClick={() => toggleSort(sortField)}>
      {icon}
      <span>{label}</span>
      {sortKey === sortField ? (
        sortDir === "desc" ? <ArrowDown className="h-3 w-3 text-primary" /> : <ArrowUp className="h-3 w-3 text-primary" />
      ) : (
        <ArrowUpDown className="h-3 w-3 opacity-0 group-hover:opacity-50 transition-opacity" />
      )}
    </button>
  )

  const tabs = [
    { id: "competidores" as const, label: "Lista de Competidores", icon: Table2 },
    { id: "meus_reels" as const, label: "Meu Conteúdo", icon: Table2 },
    { id: "reels_competidores" as const, label: "Conteúdo Competidores", icon: Table2 },
    { id: "estrategia" as const, label: "Estrategia de Conteudo", icon: LayoutGrid },
  ]

  const formatNumber = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + "M"
    if (num >= 1000) return (num / 1000).toFixed(1) + "K"
    return num.toString()
  }

  const filterByContentType = (items: ReelRow[]) => {
    let filtered = items
    if (contentTypeFilter !== "all") filtered = filtered.filter(item => (item.contentType || "reel") === contentTypeFilter)
    if (triggerFilter !== "all") {
      filtered = filtered.filter(item => {
        const triggers = item.psychTriggers || []
        return triggers.some(t => t.toLowerCase().includes(triggerFilter.toLowerCase()))
      })
    }
    if (relevanceFilter !== "all") {
      filtered = filtered.filter(item => (item.relevanceStatus || "pending") === relevanceFilter)
    }
    return filtered
  }

  const handleImageAnalysis = useCallback(async (row: ReelRow) => {
    if (!row.imageUrls || row.imageUrls.length === 0) {
      toast.error("Sem imagens para analisar")
      return
    }

    setAnalyzingIds(prev => new Set(prev).add(row.id))
    try {
      const { data, error } = await supabase.functions.invoke("analyze-content", {
        body: {
          action: "image_analysis",
          imageUrls: row.imageUrls,
          content: row.caption,
          contentType: row.contentType || "post",
        },
      })

      if (error) throw error
      if (!data?.success) throw new Error(data?.error || "Analysis failed")

      setAnalysisModal({
        open: true,
        title: `Análise Visual — @${row.user}`,
        content: data.result,
        images: row.imageUrls || [],
      })

      toast.success("Análise de imagem concluída!")
    } catch (err: any) {
      toast.error("Erro na análise de imagem", { description: err.message })
    } finally {
      setAnalyzingIds(prev => {
        const next = new Set(prev)
        next.delete(row.id)
        return next
      })
    }
  }, [])

  const handleVideoTranscription = useCallback(async (row: ReelRow) => {
    if (!row.videoUrl) {
      toast.error("Sem URL de vídeo para transcrever")
      return
    }
    setTranscribingIds(prev => new Set(prev).add(row.id))
    try {
      const { data, error } = await supabase.functions.invoke("analyze-content", {
        body: {
          action: "video_analysis",
          videoUrl: row.videoUrl,
          content: row.caption,
          contentType: "reel",
        },
      })
      if (error) throw error
      if (!data?.success) throw new Error(data?.error || "Transcription failed")
      setAnalysisModal({
        open: true,
        title: `Transcrição & Análise de Vídeo — @${row.user}`,
        content: data.result,
        images: row.thumbnail ? [row.thumbnail] : [],
      })
      toast.success("Transcrição de vídeo concluída!")
    } catch (err: any) {
      toast.error("Erro na transcrição", { description: err.message })
    } finally {
      setTranscribingIds(prev => {
        const next = new Set(prev)
        next.delete(row.id)
        return next
      })
    }
  }, [])

  const availableNiches = useMemo(() => {
    const niches = new Set<string>()
    competitorData.forEach(c => { if (c.niche) niches.add(c.niche) })
    return Array.from(niches).sort()
  }, [competitorData])

  const filteredCompetitors = useMemo(() => {
    let items = competitorData
    if (nicheFilter !== "all") items = items.filter(c => c.niche === nicheFilter)
    if (search) items = items.filter((item) => item.name.toLowerCase().includes(search.toLowerCase()) || item.niche.toLowerCase().includes(search.toLowerCase()))
    return items
  }, [competitorData, search, nicheFilter])

  const sortReels = useCallback((items: ReelRow[]) => {
    if (!sortKey) return items
    const sorted = [...items]
    sorted.sort((a, b) => {
      let va = 0, vb = 0
      if (sortKey === "views") { va = a.views; vb = b.views }
      else if (sortKey === "likes") { va = a.likes; vb = b.likes }
      else if (sortKey === "comments") { va = a.comments; vb = b.comments }
      else if (sortKey === "engRate") { va = a.engRate; vb = b.engRate }
      else return 0
      return sortDir === "desc" ? vb - va : va - vb
    })
    return sorted
  }, [sortKey, sortDir])

  const filteredMeusReels = useMemo(() => {
    let items = meusReelsData
    if (search) items = items.filter((item) => item.caption.toLowerCase().includes(search.toLowerCase()) || item.user.toLowerCase().includes(search.toLowerCase()))
    return sortReels(filterByContentType(items))
  }, [meusReelsData, search, contentTypeFilter, relevanceFilter, triggerFilter, sortReels])

  const filteredReelsCompetidores = useMemo(() => {
    let items = reelsCompetidoresData
    if (search) items = items.filter((item) => item.caption.toLowerCase().includes(search.toLowerCase()) || item.user.toLowerCase().includes(search.toLowerCase()))
    return sortReels(filterByContentType(items))
  }, [reelsCompetidoresData, search, contentTypeFilter, relevanceFilter, triggerFilter, sortReels])

  const filteredStrategy = useMemo(() => {
    if (!search) return strategyData
    return strategyData.filter((item) => item.topic.toLowerCase().includes(search.toLowerCase()) || item.format.toLowerCase().includes(search.toLowerCase()))
  }, [strategyData, search])

  const getCurrentData = () => {
    switch (activeTab) {
      case "competidores": return filteredCompetitors
      case "meus_reels": return filteredMeusReels
      case "reels_competidores": return filteredReelsCompetidores
      case "estrategia": return filteredStrategy
      default: return []
    }
  }

  const currentData = getCurrentData()
  const totalPages = Math.ceil(currentData.length / itemsPerPage)
  const paginatedData = currentData.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage)

  const handleRefreshProfile = useCallback(async (competitorId: string, name: string) => {
    setRefreshingProfileIds(prev => new Set(prev).add(competitorId))
    try {
      const { data, error } = await supabase.functions.invoke("process-instagram-link", {
        body: { url: `https://www.instagram.com/${name}/`, type: "profile" },
      })
      if (error) throw error
      if (!data?.success) throw new Error(data?.error || "Falha na extração")

      const profileData = data.profile || data.data
      if (profileData) {
        await supabase.from("competidores").update({
          bio: profileData.biography || profileData.bio || null,
          followers_count: profileData.followersCount ?? profileData.followers_count ?? null,
          following_count: profileData.followsCount ?? profileData.following_count ?? null,
          posts_count: profileData.postsCount ?? profileData.posts_count ?? null,
          profile_pic_url: profileData.profilePicUrl ?? profileData.profile_pic_url ?? null,
          predominant_content_type: profileData.predominantContentType ?? null,
          last_profile_update: new Date().toISOString(),
        }).eq("id", competitorId)
        toast.success(`Perfil de @${name} atualizado!`)
        if (onRefreshData) await onRefreshData()
      } else {
        toast.warning("Perfil extraído mas sem dados novos")
      }
    } catch (e: any) {
      toast.error(`Erro ao atualizar @${name}`, { description: e.message })
    } finally {
      setRefreshingProfileIds(prev => {
        const next = new Set(prev)
        next.delete(competitorId)
        return next
      })
    }
  }, [onRefreshData])

  const [deletingIds, setDeletingIds] = useState<Set<string>>(new Set())

  const handleDeleteCompetitor = useCallback(async (id: string, name: string) => {
    setDeletingIds(prev => new Set(prev).add(id))
    try {
      // Delete related reels first
      await supabase.from("reels_competidores").delete().eq("competidor_id", id)
      const { error } = await supabase.from("competidores").delete().eq("id", id)
      if (error) throw error
      toast.success(`@${name} removido com sucesso`)
      if (onRefreshData) await onRefreshData()
    } catch (e: any) {
      toast.error(`Erro ao deletar @${name}`, { description: e.message })
    } finally {
      setDeletingIds(prev => {
        const next = new Set(prev)
        next.delete(id)
        return next
      })
    }
  }, [onRefreshData])

  const handleRefreshAllProfiles = useCallback(async () => {
    if (competitorData.length === 0) return
    setRefreshingAll(true)
    setRefreshAllProgress({ done: 0, total: competitorData.length })
    let success = 0
    let failed = 0
    for (const comp of competitorData) {
      try {
        setRefreshingProfileIds(prev => new Set(prev).add(comp.id))
        const { data, error } = await supabase.functions.invoke("process-instagram-link", {
          body: { url: `https://www.instagram.com/${comp.name}/`, type: "profile", user_id: (await supabase.auth.getUser()).data.user?.id },
        })
        if (error || !data?.success) failed++
        else success++
      } catch { failed++ }
      finally {
        setRefreshingProfileIds(prev => { const n = new Set(prev); n.delete(comp.id); return n })
        setRefreshAllProgress(prev => ({ ...prev, done: prev.done + 1 }))
      }
    }
    if (onRefreshData) await onRefreshData()
    setRefreshingAll(false)
    toast.success(`Perfis atualizados: ${success} ok, ${failed} erros`)
  }, [competitorData, onRefreshData])

  const handleExportPDF = async () => {
    setExporting(true)
    try {
      const { default: jsPDF } = await import("jspdf")
      const { default: autoTable } = await import("jspdf-autotable")

      const doc = new jsPDF({ orientation: "landscape" })
      const pageWidth = doc.internal.pageSize.getWidth()
      const tabLabel = tabs.find(t => t.id === activeTab)?.label || activeTab

      doc.setFontSize(16)
      doc.text(`Dados de Pesquisa — ${tabLabel}`, pageWidth / 2, 18, { align: "center" })
      doc.setFontSize(9)
      doc.text(`${currentData.length} itens | Gerado em ${new Date().toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit" })}`, pageWidth / 2, 25, { align: "center" })
      if (search) doc.text(`Filtro: "${search}"`, pageWidth / 2, 30, { align: "center" })
      if (contentTypeFilter !== "all") doc.text(`Tipo: ${contentTypeFilter}`, pageWidth / 2, search ? 35 : 30, { align: "center" })

      if (activeTab === "competidores") {
        autoTable(doc, {
          startY: 38,
          head: [["Competidor", "Bio", "Seguidores", "Seguindo", "Posts", "Posts/Sem", "Tipo", "Nicho"]],
          body: (currentData as CompetitorRow[]).map(r => [
            `@${r.name}`,
            (r.bio || "—").slice(0, 60),
            r.followersCount ? formatNumber(r.followersCount) : "—",
            r.followingCount ? formatNumber(r.followingCount) : "—",
            r.postsCount ? formatNumber(r.postsCount) : "—",
            r.avgPostsPerWeek?.toString() || "—",
            r.predominantContentType || "—",
            r.niche || "—",
          ]),
          theme: "grid",
          headStyles: { fillColor: [59, 130, 246], fontSize: 8 },
          bodyStyles: { fontSize: 7 },
          alternateRowStyles: { fillColor: [245, 247, 250] },
        })
      } else if (activeTab === "meus_reels" || activeTab === "reels_competidores") {
        autoTable(doc, {
          startY: 38,
          head: [["User", "Tipo", "Caption", "Views", "Likes", "Comments", "Eng. Rate", "Data", "Pontos Virais"]],
          body: (currentData as ReelRow[]).map(r => [
            `@${r.user}`,
            r.contentType || "reel",
            (r.caption || "").slice(0, 50),
            formatNumber(r.views),
            formatNumber(r.likes),
            formatNumber(r.comments),
            `${r.engRate.toFixed(1)}%`,
            r.postDate || "—",
            r.viralPoints?.join(", ").slice(0, 40) || "—",
          ]),
          theme: "grid",
          headStyles: { fillColor: [59, 130, 246], fontSize: 8 },
          bodyStyles: { fontSize: 7 },
          alternateRowStyles: { fillColor: [245, 247, 250] },
        })
      } else if (activeTab === "estrategia") {
        autoTable(doc, {
          startY: 38,
          head: [["Tópico", "Formato", "Hook", "Status", "Prioridade"]],
          body: (currentData as StrategyRow[]).map(r => [
            r.topic, r.format, r.hook, r.status, r.priority,
          ]),
          theme: "grid",
          headStyles: { fillColor: [59, 130, 246], fontSize: 8 },
          bodyStyles: { fontSize: 7 },
          alternateRowStyles: { fillColor: [245, 247, 250] },
        })
      }

      doc.save(`dados-${activeTab}-${new Date().toISOString().slice(0, 10)}.pdf`)
      toast.success("PDF exportado com sucesso!")
    } catch (e: any) {
      toast.error("Erro ao exportar PDF", { description: e.message })
    } finally {
      setExporting(false)
    }
  }

  const showContentTypeFilter = activeTab === "meus_reels" || activeTab === "reels_competidores"

  const typeCounts = useMemo(() => {
    const source = activeTab === "meus_reels" ? meusReelsData : reelsCompetidoresData
    const counts: Record<string, number> = { all: source.length, reel: 0, post: 0, carousel: 0 }
    source.forEach(r => { const t = r.contentType || "reel"; counts[t] = (counts[t] || 0) + 1 })
    return counts
  }, [activeTab, meusReelsData, reelsCompetidoresData])

  const TRIGGER_LABELS: Record<string, { label: string; icon: string }> = {
    "curiosidade": { label: "Curiosidade", icon: "🔍" },
    "urgência": { label: "Urgência", icon: "⏰" },
    "escassez": { label: "Escassez", icon: "⚡" },
    "prova social": { label: "Prova Social", icon: "👥" },
    "identificação": { label: "Identificação", icon: "🤝" },
    "contraste": { label: "Contraste", icon: "🔄" },
    "surpresa": { label: "Surpresa", icon: "😮" },
    "reciprocidade": { label: "Reciprocidade", icon: "🎁" },
    "storytelling": { label: "Storytelling", icon: "📖" },
    "polêmica": { label: "Polêmica", icon: "🔥" },
    "aspiração": { label: "Aspiração", icon: "🌟" },
    "simplicidade": { label: "Simplicidade", icon: "✨" },
    "autoridade": { label: "Autoridade", icon: "🏆" },
    "fomo": { label: "FOMO", icon: "😰" },
  }

  const triggerCounts = useMemo(() => {
    const source = activeTab === "meus_reels" ? meusReelsData : reelsCompetidoresData
    const counts: Record<string, number> = {}
    source.forEach(r => {
      (r.psychTriggers || []).forEach(t => {
        const normalized = Object.keys(TRIGGER_LABELS).find(k => t.toLowerCase().includes(k)) || t.toLowerCase().split(":")[0].trim()
        counts[normalized] = (counts[normalized] || 0) + 1
      })
    })
    return Object.entries(counts).sort((a, b) => b[1] - a[1])
  }, [activeTab, meusReelsData, reelsCompetidoresData])

  const relevanceCounts = useMemo(() => {
    const source = activeTab === "meus_reels" ? meusReelsData : reelsCompetidoresData
    const counts = { all: source.length, approved: 0, pending: 0, rejected: 0 }
    source.forEach(r => {
      const s = (r.relevanceStatus || "pending") as keyof typeof counts
      if (s in counts) counts[s]++
    })
    return counts
  }, [activeTab, meusReelsData, reelsCompetidoresData])

  const handleDeleteIrrelevant = useCallback(async () => {
    setDeletingIrrelevant(true)
    try {
      const table = activeTab === "meus_reels" ? "meus_reels" : "reels_competidores"
      const source = activeTab === "meus_reels" ? meusReelsData : reelsCompetidoresData
      const irrelevantIds = source.filter(r => r.relevanceStatus === "rejected").map(r => r.id)
      if (irrelevantIds.length === 0) { toast.info("Nenhum conteúdo irrelevante para apagar"); return }
      for (let i = 0; i < irrelevantIds.length; i += 50) {
        const batch = irrelevantIds.slice(i, i + 50)
        const { error } = await supabase.from(table).delete().in("id", batch)
        if (error) throw error
      }
      toast.success(`${irrelevantIds.length} conteúdo(s) irrelevante(s) apagado(s)!`)
      if (onRefreshData) await onRefreshData()
    } catch (e: any) {
      toast.error("Erro ao apagar", { description: e.message })
    } finally {
      setDeletingIrrelevant(false)
    }
  }, [activeTab, meusReelsData, reelsCompetidoresData, onRefreshData])

  const RELEVANCE_OPTIONS = [
    { value: "all", label: "Todos", icon: Layers, color: "" },
    { value: "approved", label: "Relevantes", icon: CheckCircle, color: "text-emerald-600 dark:text-emerald-400" },
    { value: "pending", label: "Pendentes", icon: Clock, color: "text-amber-600 dark:text-amber-400" },
    { value: "rejected", label: "Irrelevantes", icon: XCircle, color: "text-destructive" },
  ]

  const renderCompetidoresTable = () => (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow className="border-b border-border/50 hover:bg-transparent">
            <TableHead className="w-12"><Checkbox /></TableHead>
            <TableHead className="min-w-[50px]"><div className="flex items-center gap-2 text-muted-foreground"><ImageIcon className="h-3.5 w-3.5" /><span>Foto</span></div></TableHead>
            <TableHead><div className="flex items-center gap-2 text-muted-foreground"><Type className="h-3.5 w-3.5" /><span>Nome</span></div></TableHead>
            <TableHead><div className="flex items-center gap-2 text-muted-foreground"><FileText className="h-3.5 w-3.5" /><span>Bio</span></div></TableHead>
            <TableHead><div className="flex items-center gap-2 text-muted-foreground"><Users className="h-3.5 w-3.5" /><span>Seguidores</span></div></TableHead>
            <TableHead><div className="flex items-center gap-2 text-muted-foreground"><Users className="h-3.5 w-3.5" /><span>Seguindo</span></div></TableHead>
            <TableHead><div className="flex items-center gap-2 text-muted-foreground"><BarChart2 className="h-3.5 w-3.5" /><span>Posts</span></div></TableHead>
            <TableHead><div className="flex items-center gap-2 text-muted-foreground"><TrendingUp className="h-3.5 w-3.5" /><span>Posts/Sem</span></div></TableHead>
            <TableHead><div className="flex items-center gap-2 text-muted-foreground"><List className="h-3.5 w-3.5" /><span>Tipo Predominante</span></div></TableHead>
            <TableHead><div className="flex items-center gap-2 text-muted-foreground"><Link className="h-3.5 w-3.5" /><span>URL</span></div></TableHead>
            <TableHead><div className="flex items-center gap-2 text-muted-foreground"><List className="h-3.5 w-3.5" /><span>Nicho</span></div></TableHead>
            <TableHead className="w-24"><div className="flex items-center gap-2 text-muted-foreground"><RefreshCw className="h-3.5 w-3.5" /><span>Ações</span></div></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {paginatedData.length > 0 ? (paginatedData as CompetitorRow[]).map((row) => (
            <TableRow key={row.id} className={`hover:bg-muted/30 ${selectedCompetitorIds.has(row.id) ? "bg-destructive/5" : ""}`}>
              <TableCell><Checkbox checked={selectedCompetitorIds.has(row.id)} onCheckedChange={(checked) => toggleCompetitorSelection(row.id, !!checked)} /></TableCell>
              <TableCell>
                {row.profilePicUrl ? (
                  <div className="h-10 w-10 rounded-full bg-muted overflow-hidden"><img src={row.profilePicUrl} alt="" className="h-full w-full object-cover" /></div>
                ) : (
                  <div className="h-10 w-10 rounded-full bg-muted flex items-center justify-center"><User className="h-4 w-4 text-muted-foreground" /></div>
                )}
              </TableCell>
              <TableCell className="font-medium">@{row.name}</TableCell>
              <TableCell className="max-w-[200px] truncate text-muted-foreground text-sm">{row.bio || "-"}</TableCell>
              <TableCell className="font-mono text-sm">{row.followersCount ? formatNumber(row.followersCount) : "-"}</TableCell>
              <TableCell className="font-mono text-sm">{row.followingCount ? formatNumber(row.followingCount) : "-"}</TableCell>
              <TableCell className="font-mono text-sm">{row.postsCount ? formatNumber(row.postsCount) : "-"}</TableCell>
              <TableCell className="font-mono text-sm">{row.avgPostsPerWeek ? `${row.avgPostsPerWeek}/sem` : "-"}</TableCell>
              <TableCell><Badge variant="outline" className="text-xs capitalize">{row.predominantContentType || "-"}</Badge></TableCell>
              <TableCell><a href={row.pageUrl} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline flex items-center gap-1"><ExternalLink className="h-3 w-3" /></a></TableCell>
              <TableCell onClick={e => e.stopPropagation()}>
                <EditableNicheCell competitorId={row.id} value={row.niche || ""} />
              </TableCell>
              <TableCell onClick={e => e.stopPropagation()}>
                <div className="flex items-center gap-1">
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-7 text-xs gap-1.5"
                    disabled={refreshingProfileIds.has(row.id)}
                    onClick={() => handleRefreshProfile(row.id, row.name)}
                  >
                    {refreshingProfileIds.has(row.id) ? <Loader2 className="h-3 w-3 animate-spin" /> : <RefreshCw className="h-3 w-3" />}
                  </Button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-7 text-xs text-destructive hover:text-destructive"
                        disabled={deletingIds.has(row.id)}
                      >
                        {deletingIds.has(row.id) ? <Loader2 className="h-3 w-3 animate-spin" /> : <Trash2 className="h-3 w-3" />}
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Deletar @{row.name}?</AlertDialogTitle>
                        <AlertDialogDescription>
                          Isso removerá o competidor e todos os reels associados. Esta ação não pode ser desfeita.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancelar</AlertDialogCancel>
                        <AlertDialogAction
                          className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                          onClick={() => handleDeleteCompetitor(row.id, row.name)}
                        >
                          Deletar
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </TableCell>
            </TableRow>
          )) : (
            <TableRow><TableCell colSpan={12} className="h-32 text-center"><div className="flex flex-col items-center gap-2 text-muted-foreground"><HelpCircle className="h-5 w-5" /><span>Nenhum resultado</span></div></TableCell></TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  )

  const renderReelsTable = (data: ReelRow[]) => (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
         <TableRow className="border-b border-border/50 hover:bg-transparent">
            <TableHead className="min-w-[80px]"><div className="flex items-center gap-2 text-muted-foreground"><Paperclip className="h-3.5 w-3.5" /><span>Thumb...</span></div></TableHead>
            <TableHead className="min-w-[70px]"><div className="flex items-center gap-2 text-muted-foreground"><List className="h-3.5 w-3.5" /><span>Tipo</span></div></TableHead>
            <TableHead className="min-w-[120px]"><div className="flex items-center gap-2 text-muted-foreground"><Type className="h-3.5 w-3.5" /><span>Caption</span></div></TableHead>
            <TableHead className="min-w-[100px]"><div className="flex items-center gap-2 text-muted-foreground"><User className="h-3.5 w-3.5" /><span>User</span></div></TableHead>
            <TableHead className="min-w-[80px]"><div className="flex items-center gap-2 text-muted-foreground"><Link className="h-3.5 w-3.5" /><span>URL</span></div></TableHead>
            <TableHead className="min-w-[100px]"><div className="flex items-center gap-2 text-muted-foreground"><FileText className="h-3.5 w-3.5" /><span>Transcript</span></div></TableHead>
            <TableHead className="min-w-[120px]"><div className="flex items-center gap-2 text-muted-foreground"><BarChart2 className="h-3.5 w-3.5" /><span>Hook Analysis</span></div></TableHead>
            <TableHead className="min-w-[80px]"><SortHeader label="Views" sortField="views" icon={<span className="font-mono text-xs">#</span>} /></TableHead>
            <TableHead className="min-w-[80px]"><SortHeader label="Likes" sortField="likes" icon={<span className="font-mono text-xs">#</span>} /></TableHead>
            <TableHead className="min-w-[80px]"><SortHeader label="Comme..." sortField="comments" icon={<span className="font-mono text-xs">#</span>} /></TableHead>
            <TableHead className="min-w-[80px]"><SortHeader label="Eng. Rate" sortField="engRate" icon={<span className="font-mono text-xs">E</span>} /></TableHead>
            <TableHead className="min-w-[100px]"><div className="flex items-center gap-2 text-muted-foreground"><Calendar className="h-3.5 w-3.5" /><span>Post Date</span></div></TableHead>
            <TableHead className="min-w-[140px]"><div className="flex items-center gap-2 text-muted-foreground"><Zap className="h-3.5 w-3.5 text-amber-500" /><span>Pontos Virais</span></div></TableHead>
            <TableHead className="min-w-[140px]"><div className="flex items-center gap-2 text-muted-foreground"><Brain className="h-3.5 w-3.5 text-purple-500" /><span>Gatilhos Psicológicos</span></div></TableHead>
            <TableHead className="min-w-[100px]"><div className="flex items-center gap-2 text-muted-foreground"><ScanEye className="h-3.5 w-3.5 text-cyan-500" /><span>Análise Visual</span></div></TableHead>
            <TableHead className="min-w-[110px]"><div className="flex items-center gap-2 text-muted-foreground"><Film className="h-3.5 w-3.5 text-emerald-500" /><span>Transcrição Vídeo</span></div></TableHead>
            <TableHead className="min-w-[130px]"><div className="flex items-center gap-2 text-muted-foreground"><Shield className="h-3.5 w-3.5 text-primary" /><span>Relevância</span></div></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {data.length > 0 ? data.map((row) => {
            const hasImages = row.imageUrls && row.imageUrls.length > 0
            const isPost = row.contentType === "post" || row.contentType === "carousel"
            const canAnalyze = hasImages || (isPost && row.thumbnail)
            const isAnalyzing = analyzingIds.has(row.id)

            return (
              <TableRow key={row.id} className="hover:bg-muted/30 cursor-pointer" onClick={() => setDetailModal({ open: true, reel: row })}>
                <TableCell>{row.thumbnail ? <div className="h-12 w-12 rounded bg-muted overflow-hidden"><img src={row.thumbnail} alt="" className="h-full w-full object-cover" /></div> : <div className="h-12 w-12 rounded bg-muted" />}</TableCell>
                <TableCell><Badge variant="outline" className="text-xs capitalize">{row.contentType || "reel"}</Badge></TableCell>
                <TableCell className="max-w-[200px] truncate text-primary underline-offset-2 hover:underline">{row.caption || "(sem caption)"}</TableCell>
                <TableCell className="text-muted-foreground">@{row.user}</TableCell>
                <TableCell onClick={e => e.stopPropagation()}><a href={row.url} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline"><ExternalLink className="h-4 w-4" /></a></TableCell>
                <TableCell className="max-w-[150px] truncate text-muted-foreground">{row.transcript || "-"}</TableCell>
                <TableCell className="max-w-[150px] truncate text-muted-foreground">{row.hookAnalysis || "-"}</TableCell>
                <TableCell className="font-mono text-sm">{formatNumber(row.views)}</TableCell>
                <TableCell className="font-mono text-sm">{formatNumber(row.likes)}</TableCell>
                <TableCell className="font-mono text-sm">{formatNumber(row.comments)}</TableCell>
                <TableCell className="font-mono text-sm">{row.engRate.toFixed(1)}%</TableCell>
                <TableCell className="text-muted-foreground text-sm">{row.postDate}</TableCell>
                <TableCell>
                  {row.viralPoints && row.viralPoints.length > 0 ? (
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <div className="flex flex-wrap gap-1 max-w-[160px]">
                            {row.viralPoints.slice(0, 2).map((vp, i) => (
                              <Badge key={i} variant="secondary" className="text-[10px] bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20 truncate max-w-[70px]">
                                <Zap className="h-2.5 w-2.5 mr-0.5 shrink-0" />{vp}
                              </Badge>
                            ))}
                            {row.viralPoints.length > 2 && (
                              <Badge variant="outline" className="text-[10px]">+{row.viralPoints.length - 2}</Badge>
                            )}
                          </div>
                        </TooltipTrigger>
                        <TooltipContent side="left" className="max-w-xs">
                          <p className="text-xs font-semibold mb-1">Pontos Virais</p>
                          <ul className="text-xs space-y-0.5">{row.viralPoints.map((vp, i) => <li key={i}>⚡ {vp}</li>)}</ul>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  ) : <span className="text-muted-foreground text-xs">—</span>}
                </TableCell>
                <TableCell>
                  {row.psychTriggers && row.psychTriggers.length > 0 ? (
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <div className="flex flex-wrap gap-1 max-w-[160px]">
                            {row.psychTriggers.slice(0, 2).map((pt, i) => (
                              <Badge key={i} variant="secondary" className="text-[10px] bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/20 truncate max-w-[70px]">
                                <Brain className="h-2.5 w-2.5 mr-0.5 shrink-0" />{pt}
                              </Badge>
                            ))}
                            {row.psychTriggers.length > 2 && (
                              <Badge variant="outline" className="text-[10px]">+{row.psychTriggers.length - 2}</Badge>
                            )}
                          </div>
                        </TooltipTrigger>
                        <TooltipContent side="left" className="max-w-xs">
                          <p className="text-xs font-semibold mb-1">Gatilhos Psicológicos</p>
                          <ul className="text-xs space-y-0.5">{row.psychTriggers.map((pt, i) => <li key={i}>🧠 {pt}</li>)}</ul>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  ) : <span className="text-muted-foreground text-xs">—</span>}
                </TableCell>
                <TableCell onClick={e => e.stopPropagation()}>
                  {row.imageAnalysis ? (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 text-xs gap-1 text-cyan-600 dark:text-cyan-400 hover:text-cyan-700"
                      onClick={() => setAnalysisModal({ open: true, title: `Análise Visual — @${row.user}`, content: row.imageAnalysis!, images: row.imageUrls || [] })}
                    >
                      <Eye className="h-3 w-3" /> Ver
                    </Button>
                  ) : canAnalyze ? (
                    <Button
                      variant="outline"
                      size="sm"
                      className="h-7 text-xs gap-1"
                      disabled={isAnalyzing}
                      onClick={() => {
                        const urls = row.imageUrls && row.imageUrls.length > 0
                          ? row.imageUrls
                          : row.thumbnail ? [row.thumbnail] : []
                        handleImageAnalysis({ ...row, imageUrls: urls })
                      }}
                    >
                      {isAnalyzing ? <Loader2 className="h-3 w-3 animate-spin" /> : <ScanEye className="h-3 w-3" />}
                      {isAnalyzing ? "..." : "Analisar"}
                    </Button>
                  ) : (
                    <span className="text-muted-foreground text-xs">—</span>
                  )}
                </TableCell>
                <TableCell onClick={e => e.stopPropagation()}>
                  {row.contentType === "reel" && row.videoUrl ? (
                    <Button
                      variant="outline"
                      size="sm"
                      className="h-7 text-xs gap-1"
                      disabled={transcribingIds.has(row.id)}
                      onClick={() => handleVideoTranscription(row)}
                    >
                      {transcribingIds.has(row.id) ? <Loader2 className="h-3 w-3 animate-spin" /> : <Film className="h-3 w-3" />}
                      {transcribingIds.has(row.id) ? "..." : row.transcript ? "Re-analisar" : "Transcrever"}
                    </Button>
                  ) : row.contentType === "reel" && !row.videoUrl ? (
                    <span className="text-muted-foreground text-xs">Sem vídeo</span>
                  ) : (
                    <span className="text-muted-foreground text-xs">—</span>
                  )}
                </TableCell>
                <TableCell onClick={e => e.stopPropagation()}>
                  {(() => {
                    const status = row.relevanceStatus || "pending"
                    const table = activeTab === "meus_reels" ? "meus_reels" as const : "reels_competidores" as const
                    return (
                      <div className="flex flex-col gap-1">
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Badge
                                variant={status === "approved" ? "default" : status === "rejected" ? "destructive" : "secondary"}
                                className={`text-[10px] cursor-help ${status === "approved" ? "bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 border-emerald-500/30" : ""}`}
                              >
                                {status === "approved" ? <><CheckCircle className="h-2.5 w-2.5 mr-0.5" />Relevante</> : 
                                 status === "rejected" ? <><XCircle className="h-2.5 w-2.5 mr-0.5" />Irrelevante</> :
                                 <><Clock className="h-2.5 w-2.5 mr-0.5" />Pendente</>}
                              </Badge>
                            </TooltipTrigger>
                            <TooltipContent side="left" className="max-w-xs">
                              <p className="text-xs">{row.relevanceReason || "Aguardando classificação"}</p>
                              {row.relevanceScore !== undefined && row.relevanceScore > 0 && (
                                <p className="text-xs text-muted-foreground mt-1">Score: {row.relevanceScore}%</p>
                              )}
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                        <div className="flex gap-0.5">
                          {status !== "approved" && (
                            <Button variant="ghost" size="sm" className="h-5 w-5 p-0 text-emerald-600 hover:text-emerald-700"
                              onClick={() => onReelRelevanceUpdate?.(row.id, "approved", table)}>
                              <CheckCircle className="h-3 w-3" />
                            </Button>
                          )}
                          {status !== "rejected" && (
                            <Button variant="ghost" size="sm" className="h-5 w-5 p-0 text-destructive hover:text-destructive/80"
                              onClick={() => onReelRelevanceUpdate?.(row.id, "rejected", table)}>
                              <XCircle className="h-3 w-3" />
                            </Button>
                          )}
                        </div>
                      </div>
                    )
                  })()}
                </TableCell>
              </TableRow>
            )
          }) : (
            <TableRow><TableCell colSpan={17} className="h-32 text-center"><div className="flex flex-col items-center gap-2 text-muted-foreground"><HelpCircle className="h-5 w-5" /><span>Nenhum resultado</span></div></TableCell></TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  )

  const parseReport = useCallback((raw: string | undefined) => {
    if (!raw) return null
    try {
      const cleaned = raw.replace(/^```json\s*/i, "").replace(/```\s*$/, "").trim()
      return JSON.parse(cleaned)
    } catch {
      // Try to find JSON object in the string
      const match = raw.match(/\{[\s\S]*\}/)
      if (match) {
        try { return JSON.parse(match[0]) } catch { return null }
      }
      return null
    }
  }, [])

  const [selectedStrategyId, setSelectedStrategyId] = useState<string | null>(null)

  const renderEstrategiaView = () => {
    // If a specific strategy is selected, show its details
    const selectedStrategy = selectedStrategyId ? filteredStrategy.find(s => s.id === selectedStrategyId) : null

    if (selectedStrategy) {
      const report = parseReport(selectedStrategy.rawReport)
      const topVideos = report?.videos_top_concorrentes || report?.videos_top_dos_concorrentes || report?.top_videos || []
      const patterns = report?.padroes_de_sucesso || report?.winning_patterns || []
      const hookIdeas = report?.ideias_de_gancho || report?.hook_ideas || []
      const keyTakeaway = report?.conclusao || report?.key_takeaway || selectedStrategy.hook

      // Group top videos by creator for per-competitor breakdown
      const videosByCreator: Record<string, any[]> = {}
      topVideos.forEach((v: any) => {
        const creator = (v.creator || v.criador || "Desconhecido").replace(/^@/, "")
        if (!videosByCreator[creator]) videosByCreator[creator] = []
        videosByCreator[creator].push(v)
      })
      const creatorNames = Object.keys(videosByCreator)

      return (
        <div className="p-6 space-y-6">
          {/* Back button + header */}
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" className="gap-1.5" onClick={() => setSelectedStrategyId(null)}>
              <ChevronLeft className="h-4 w-4" /> Voltar
            </Button>
            <div className="flex-1">
              <h3 className="text-lg font-semibold">{selectedStrategy.topic}</h3>
              <div className="flex items-center gap-2 flex-wrap mt-1">
                <p className="text-xs text-muted-foreground">{selectedStrategy.createdAt ? new Date(selectedStrategy.createdAt).toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit" }) : ""}</p>
                {creatorNames.length > 0 && (
                  <div className="flex items-center gap-1">
                    <span className="text-xs text-muted-foreground">•</span>
                    {creatorNames.slice(0, 5).map((c, i) => (
                      <Badge key={i} variant="outline" className="text-[10px] px-1.5 py-0">@{c}</Badge>
                    ))}
                    {creatorNames.length > 5 && <span className="text-[10px] text-muted-foreground">+{creatorNames.length - 5}</span>}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Key Takeaway */}
          {keyTakeaway && (
            <Card className="border-primary/30 bg-primary/5">
              <div className="p-4">
                <h4 className="text-sm font-semibold flex items-center gap-2 mb-2 text-primary">
                  <Zap className="h-4 w-4" /> Conclusão Principal
                </h4>
                <p className="text-sm leading-relaxed">{keyTakeaway}</p>
              </div>
            </Card>
          )}

          {/* Per-Competitor Breakdown */}
          {creatorNames.length > 1 && (
            <div>
              <h4 className="text-sm font-semibold flex items-center gap-2 mb-3">
                <Users className="h-4 w-4 text-primary" /> Análise por Competidor
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {creatorNames.map((creator) => {
                  const videos = videosByCreator[creator]
                  const totalViews = videos.reduce((sum: number, v: any) => sum + (v.views || 0), 0)
                  return (
                    <Card key={creator} className="border-border/50">
                      <div className="p-4 space-y-3">
                        <div className="flex items-center justify-between">
                          <h5 className="text-sm font-semibold flex items-center gap-2">
                            <User className="h-4 w-4 text-muted-foreground" />
                            @{creator}
                          </h5>
                          <Badge variant="secondary" className="text-[10px]">{videos.length} vídeo{videos.length > 1 ? "s" : ""}</Badge>
                        </div>
                        {totalViews > 0 && (
                          <p className="text-xs text-muted-foreground flex items-center gap-1">
                            <Eye className="h-3 w-3" /> {formatNumber(totalViews)} views totais
                          </p>
                        )}
                        <div className="space-y-2">
                          {videos.slice(0, 3).map((v: any, i: number) => (
                            <div key={i} className="text-xs border-l-2 border-primary/20 pl-2 space-y-0.5">
                              <p className="font-medium">"{v.hook || v.gancho}"</p>
                              {(v.por_que_funcionou || v.why_it_worked) && (
                                <p className="text-muted-foreground line-clamp-2">{v.por_que_funcionou || v.why_it_worked}</p>
                              )}
                              <div className="flex items-center gap-2 text-muted-foreground">
                                {v.views > 0 && <span className="flex items-center gap-0.5"><Eye className="h-2.5 w-2.5" />{formatNumber(v.views)}</span>}
                                {v.url && (
                                  <a href={v.url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-0.5 text-primary hover:underline" onClick={e => e.stopPropagation()}>
                                    <ExternalLink className="h-2.5 w-2.5" /> Ver
                                  </a>
                                )}
                              </div>
                            </div>
                          ))}
                          {videos.length > 3 && <p className="text-[10px] text-muted-foreground">+{videos.length - 3} mais vídeos</p>}
                        </div>
                      </div>
                    </Card>
                  )
                })}
              </div>
            </div>
          )}

          {/* Top Videos */}
          {topVideos.length > 0 && (
            <div>
              <h4 className="text-sm font-semibold flex items-center gap-2 mb-3">
                <TrendingUp className="h-4 w-4 text-primary" /> Top {topVideos.length} Vídeos dos Competidores
              </h4>
              <div className="space-y-3">
                {topVideos.map((v: any, i: number) => (
                  <Card key={i} className="border-border/50 overflow-hidden">
                    <div className="p-4">
                      <div className="flex items-start gap-3">
                        <div className="flex items-center justify-center h-8 w-8 rounded-full bg-primary/10 text-primary font-bold text-sm shrink-0">
                          {v.rank || i + 1}
                        </div>
                        <div className="flex-1 min-w-0 space-y-2">
                          <div className="flex items-center gap-2 flex-wrap">
                            <p className="text-sm font-medium leading-snug">"{v.hook || v.gancho}"</p>
                          </div>
                          <div className="flex items-center gap-3 text-xs text-muted-foreground flex-wrap">
                            {(v.creator || v.criador) && <span className="font-medium">@{(v.creator || v.criador).replace(/^@/, "")}</span>}
                            {v.views && <span className="flex items-center gap-1"><Eye className="h-3 w-3" />{formatNumber(v.views)}</span>}
                            {v.posted_date && <span className="flex items-center gap-1"><Calendar className="h-3 w-3" />{v.posted_date}</span>}
                            {v.url && (
                              <a href={v.url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-primary hover:underline">
                                <ExternalLink className="h-3 w-3" /> Ver
                              </a>
                            )}
                          </div>
                          {(v.por_que_funcionou || v.why_it_worked) && (
                            <p className="text-xs text-muted-foreground bg-muted/50 rounded-lg p-2.5 leading-relaxed">
                              {v.por_que_funcionou || v.why_it_worked}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* Winning Patterns */}
          {patterns.length > 0 && (
            <div>
              <h4 className="text-sm font-semibold flex items-center gap-2 mb-3">
                <Brain className="h-4 w-4 text-purple-500" /> Padrões Vencedores
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {patterns.map((p: any, i: number) => (
                  <Card key={i} className="border-border/50">
                    <div className="p-4 space-y-2">
                      <div className="flex items-center gap-2">
                        <Badge variant="secondary" className="bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/20">
                          🧠 Padrão {i + 1}
                        </Badge>
                      </div>
                      <h5 className="text-sm font-semibold">{p.pattern_name || p.name}</h5>
                      <p className="text-xs text-muted-foreground leading-relaxed">{p.explanation || p.description}</p>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* Hook Ideas */}
          {hookIdeas.length > 0 && (
            <div>
              <h4 className="text-sm font-semibold flex items-center gap-2 mb-3">
                <Sparkles className="h-4 w-4 text-amber-500" /> Ideias de Hooks ({hookIdeas.length})
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {hookIdeas.map((h: any, i: number) => (
                  <Card key={i} className="border-border/50 hover:border-primary/30 transition-colors cursor-pointer group" onClick={() => {
                    navigator.clipboard.writeText(h.hook || h.text)
                    toast.success("Hook copiado!")
                  }}>
                    <div className="p-4 space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <p className="text-sm font-medium leading-snug">"{h.hook || h.text}"</p>
                        <Copy className="h-3.5 w-3.5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity shrink-0 mt-0.5" />
                      </div>
                      {(h.why_it_works || h.reason) && (
                        <p className="text-xs text-muted-foreground leading-relaxed">{h.why_it_works || h.reason}</p>
                      )}
                      {(h.reference_content || h.referencia) && (
                        <p className="text-[10px] text-muted-foreground/60 italic">Ref: {h.reference_content || h.referencia}</p>
                      )}
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* Fallback if no structured data */}
          {!topVideos.length && !patterns.length && !hookIdeas.length && !keyTakeaway && (
            <Card className="border-border/50">
              <div className="p-4">
                <p className="text-sm text-muted-foreground whitespace-pre-wrap">{selectedStrategy.rawReport || "Sem dados detalhados para este relatório."}</p>
              </div>
            </Card>
          )}
        </div>
      )
    }

    // List view of all strategies
    return (
      <div className="p-6">
        {filteredStrategy.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {(paginatedData as StrategyRow[]).map((item) => {
              const report = parseReport(item.rawReport)
              const topVideos = report?.videos_top_concorrentes || report?.videos_top_dos_concorrentes || report?.top_videos || []
              const patterns = report?.padroes_de_sucesso || report?.winning_patterns || []
              const hookIdeas = report?.ideias_de_gancho || report?.hook_ideas || []
              const keyTakeaway = report?.conclusao || report?.key_takeaway || item.hook
              
              // Extract unique competitor names from top videos
              const creators = [...new Set(
                topVideos
                  .map((v: any) => v.creator || v.criador)
                  .filter(Boolean)
                  .map((c: string) => c.replace(/^@/, ""))
              )] as string[]

              return (
                <Card key={item.id} className="border-border/50 hover:border-primary/30 transition-colors cursor-pointer group overflow-hidden" onClick={() => setSelectedStrategyId(item.id)}>
                  <div className="p-4 space-y-3">
                    <div className="flex items-start justify-between">
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-sm truncate">{item.topic}</h4>
                        <p className="text-xs text-muted-foreground">{item.createdAt ? new Date(item.createdAt).toLocaleDateString("pt-BR") : ""}</p>
                      </div>
                      <ChevronRight className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity shrink-0 mt-0.5" />
                    </div>

                    {/* Key takeaway summary */}
                    {keyTakeaway && (
                      <p className="text-xs text-muted-foreground leading-relaxed line-clamp-2 border-l-2 border-primary/20 pl-2">
                        {keyTakeaway}
                      </p>
                    )}

                    {/* Competitors analyzed */}
                    {creators.length > 0 && (
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <Users className="h-3 w-3 text-muted-foreground shrink-0" />
                        {creators.slice(0, 4).map((c, i) => (
                          <Badge key={i} variant="outline" className="text-[10px] px-1.5 py-0">@{c}</Badge>
                        ))}
                        {creators.length > 4 && (
                          <span className="text-[10px] text-muted-foreground">+{creators.length - 4}</span>
                        )}
                      </div>
                    )}

                    {/* Stats badges */}
                    <div className="flex flex-wrap gap-1.5">
                      {topVideos.length > 0 && <Badge variant="secondary" className="text-[10px]"><TrendingUp className="h-3 w-3 mr-1" />{topVideos.length} Top Vídeos</Badge>}
                      {patterns.length > 0 && <Badge variant="secondary" className="text-[10px]"><Brain className="h-3 w-3 mr-1" />{patterns.length} Padrões</Badge>}
                      {hookIdeas.length > 0 && <Badge variant="secondary" className="text-[10px]"><Sparkles className="h-3 w-3 mr-1" />{hookIdeas.length} Hooks</Badge>}
                      {!topVideos.length && !patterns.length && !hookIdeas.length && <Badge variant="outline" className="text-[10px]">Relatório</Badge>}
                    </div>
                  </div>
                </Card>
              )
            })}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-32 text-muted-foreground"><HelpCircle className="h-5 w-5 mb-2" /><span>Nenhum resultado</span></div>
        )}
      </div>
    )
  }

  const renderContent = () => {
    switch (activeTab) {
      case "competidores": return renderCompetidoresTable()
      case "meus_reels": return renderReelsTable(paginatedData as ReelRow[])
      case "reels_competidores": return renderReelsTable(paginatedData as ReelRow[])
      case "estrategia": return renderEstrategiaView()
      default: return null
    }
  }

  return (
    <>
      <Card className="border-border/50">
        <div className="flex items-center justify-between p-4 border-b border-border/50">
          <div className="flex items-center gap-2">
            <div className="flex h-6 w-6 items-center justify-center rounded bg-rose-500/10">
              <svg className="h-4 w-4 text-rose-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
              </svg>
            </div>
            <h2 className="font-semibold">Dados de Pesquisa</h2>
          </div>
          <div className="flex items-center gap-2">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 gap-1.5 text-xs text-destructive border-destructive/30 hover:bg-destructive/10"
                    disabled={competitorData.length === 0}
                    onClick={() => {
                      const competitorsWithRelevant = new Set<string>()
                      reelsCompetidoresData.forEach(r => {
                        if (r.relevanceStatus === "approved") {
                          competitorsWithRelevant.add(r.user)
                        }
                      })
                      const withoutRelevant = competitorData.filter(c => !competitorsWithRelevant.has(c.name))
                      if (withoutRelevant.length === 0) {
                        toast.info("Todos os competidores possuem conteúdo relevante")
                        return
                      }
                      const newSelected = new Set<string>()
                      withoutRelevant.forEach(c => newSelected.add(c.id))
                      setSelectedCompetitorIds(newSelected)
                      setActiveTab("competidores")
                      setCurrentPage(1)
                      toast.success(`${withoutRelevant.length} competidor(es) sem conteúdo relevante selecionado(s)`)
                    }}
                  >
                    <XCircle className="h-3.5 w-3.5" />
                    Selecionar Sem Relevantes
                    <Badge variant="outline" className="ml-0.5 h-4 px-1 text-[10px] font-mono text-destructive border-destructive/30">
                      {(() => {
                        const withRelevant = new Set<string>()
                        reelsCompetidoresData.forEach(r => { if (r.relevanceStatus === "approved") withRelevant.add(r.user) })
                        return competitorData.filter(c => !withRelevant.has(c.name)).length
                      })()}
                    </Badge>
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Seleciona competidores que não possuem nenhum conteúdo classificado como relevante</TooltipContent>
              </Tooltip>
            </TooltipProvider>

            {selectedCompetitorIds.size > 0 && (
              <>
                <Button
                  variant="outline"
                  size="sm"
                  className="h-8 gap-1.5 text-xs"
                  onClick={() => setSelectedCompetitorIds(new Set())}
                >
                  <XCircle className="h-3.5 w-3.5" />
                  Desmarcar Todos
                </Button>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button
                      variant="destructive"
                      size="sm"
                      className="h-8 gap-1.5 text-xs"
                      disabled={deletingSelected}
                    >
                      {deletingSelected ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Trash2 className="h-3.5 w-3.5" />}
                      Deletar Selecionados
                      <Badge variant="secondary" className="ml-0.5 h-4 px-1 text-[10px] font-mono">
                        {selectedCompetitorIds.size}
                      </Badge>
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Deletar {selectedCompetitorIds.size} competidor(es)?</AlertDialogTitle>
                      <AlertDialogDescription>
                        Isso removerá permanentemente <strong>{selectedCompetitorIds.size}</strong> competidor(es) selecionado(s) e todos os seus reels associados. Esta ação não pode ser desfeita.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancelar</AlertDialogCancel>
                      <AlertDialogAction onClick={handleDeleteSelectedCompetitors} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                        Deletar {selectedCompetitorIds.size} competidor(es)
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </>
            )}
          </div>
        </div>

        <div className="flex flex-col gap-2 px-4 py-2 border-b border-border/50">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1 flex-wrap">
              {tabs.map((tab) => (
                <Button key={tab.id} variant="ghost" size="sm" className={`gap-2 ${activeTab === tab.id ? "bg-muted text-foreground" : "text-muted-foreground hover:text-foreground"}`} onClick={() => { setActiveTab(tab.id); setCurrentPage(1); setContentTypeFilter("all"); setTriggerFilter("all") }}>
                  <tab.icon className="h-4 w-4" />{tab.label}
                </Button>
              ))}
            </div>
            <div className="flex items-center gap-2">
              <div className="relative w-48">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                <Input
                  placeholder="Buscar..."
                  value={search}
                  onChange={(e) => { setSearch(e.target.value); setCurrentPage(1) }}
                  className="h-8 pl-8 text-sm"
                />
              </div>
              {activeTab === "competidores" && (
                <Button variant="outline" size="sm" className="h-8 gap-1.5 text-xs" onClick={handleRefreshAllProfiles} disabled={refreshingAll || competitorData.length === 0}>
                  {refreshingAll ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />}
                  {refreshingAll ? `${refreshAllProgress.done}/${refreshAllProgress.total}` : "Atualizar Todos"}
                </Button>
              )}
              {activeTab === "meus_reels" && onImportMyProfile && (
                <ImportProfileButton onImport={onImportMyProfile} importing={importingProfile || false} />
              )}
              <Button variant="outline" size="sm" className="h-8 gap-1.5 text-xs" onClick={handleExportPDF} disabled={exporting || currentData.length === 0}>
                <Download className="h-3.5 w-3.5" />
                {exporting ? "Exportando..." : "PDF"}
              </Button>
            </div>
          </div>

          {activeTab === "competidores" && availableNiches.length > 0 && (
            <div className="flex items-center gap-2 flex-wrap">
              <Filter className="h-3.5 w-3.5 text-muted-foreground" />
              <span className="text-xs text-muted-foreground">Nicho:</span>
              <Button variant={nicheFilter === "all" ? "default" : "outline"} size="sm" className="h-7 text-xs" onClick={() => { setNicheFilter("all"); setCurrentPage(1) }}>
                Todos ({competitorData.length})
              </Button>
              {availableNiches.map(n => {
                const count = competitorData.filter(c => c.niche === n).length
                return (
                  <Button key={n} variant={nicheFilter === n ? "default" : "outline"} size="sm" className="h-7 text-xs capitalize" onClick={() => { setNicheFilter(n); setCurrentPage(1) }}>
                    {n} ({count})
                  </Button>
                )
              })}
            </div>
          )}

          {showContentTypeFilter && (
            <div className="flex items-center gap-2">
              <Filter className="h-3.5 w-3.5 text-muted-foreground" />
              <span className="text-xs text-muted-foreground">Tipo:</span>
              {CONTENT_TYPE_OPTIONS.map(opt => {
                const count = typeCounts[opt.value] || 0
                const isActive = contentTypeFilter === opt.value
                return (
                  <Button
                    key={opt.value}
                    variant={isActive ? "default" : "outline"}
                    size="sm"
                    className="h-7 text-xs gap-1.5 px-2.5"
                    onClick={() => { setContentTypeFilter(opt.value); setCurrentPage(1) }}
                  >
                    <opt.icon className="h-3 w-3" />
                    {opt.label}
                    <Badge variant={isActive ? "secondary" : "outline"} className="ml-0.5 h-4 px-1 text-[10px] font-mono">
                      {count}
                    </Badge>
                  </Button>
                )
              })}
            </div>
          )}

          {showContentTypeFilter && triggerCounts.length > 0 && (
            <div className="flex items-center gap-2 flex-wrap">
              <Brain className="h-3.5 w-3.5 text-purple-500 shrink-0" />
              <span className="text-xs text-muted-foreground shrink-0">Gatilho:</span>
              <Button
                variant={triggerFilter === "all" ? "default" : "outline"}
                size="sm"
                className="h-6 text-[11px] gap-1 px-2"
                onClick={() => { setTriggerFilter("all"); setCurrentPage(1) }}
              >
                Todos
              </Button>
              {triggerCounts.slice(0, 10).map(([trigger, count]) => {
                const meta = TRIGGER_LABELS[trigger]
                const isActive = triggerFilter === trigger
                return (
                  <Button
                    key={trigger}
                    variant={isActive ? "default" : "outline"}
                    size="sm"
                    className="h-6 text-[11px] gap-1 px-2"
                    onClick={() => { setTriggerFilter(trigger); setCurrentPage(1) }}
                  >
                    <span>{meta?.icon || "🧠"}</span>
                    <span>{meta?.label || trigger}</span>
                    <Badge variant={isActive ? "secondary" : "outline"} className="ml-0.5 h-4 px-1 text-[10px] font-mono">
                      {count}
                    </Badge>
                  </Button>
                )
              })}
            </div>
          )}

          {showContentTypeFilter && (
            <div className="flex items-center gap-2 flex-wrap">
              <Shield className="h-3.5 w-3.5 text-primary shrink-0" />
              <span className="text-xs text-muted-foreground shrink-0">Relevância:</span>
              {RELEVANCE_OPTIONS.map(opt => {
                const count = relevanceCounts[opt.value as keyof typeof relevanceCounts] || 0
                const isActive = relevanceFilter === opt.value
                return (
                  <Button
                    key={opt.value}
                    variant={isActive ? "default" : "outline"}
                    size="sm"
                    className={`h-6 text-[11px] gap-1 px-2 ${!isActive && opt.color}`}
                    onClick={() => { setRelevanceFilter(opt.value); setCurrentPage(1) }}
                  >
                    <opt.icon className="h-3 w-3" />
                    <span>{opt.label}</span>
                    <Badge variant={isActive ? "secondary" : "outline"} className="ml-0.5 h-4 px-1 text-[10px] font-mono">
                      {count}
                    </Badge>
                  </Button>
                )
              })}
              {relevanceCounts.rejected > 0 && (
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="outline" size="sm" className="h-6 text-[11px] gap-1 px-2 text-destructive border-destructive/30 hover:bg-destructive/10" disabled={deletingIrrelevant}>
                      {deletingIrrelevant ? <Loader2 className="h-3 w-3 animate-spin" /> : <Trash2 className="h-3 w-3" />}
                      <span>Apagar Irrelevantes</span>
                      <Badge variant="outline" className="ml-0.5 h-4 px-1 text-[10px] font-mono text-destructive border-destructive/30">
                        {relevanceCounts.rejected}
                      </Badge>
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Apagar conteúdos irrelevantes?</AlertDialogTitle>
                      <AlertDialogDescription>
                        Isso vai apagar permanentemente <strong>{relevanceCounts.rejected}</strong> conteúdo(s) marcado(s) como irrelevante(s) da tabela {activeTab === "meus_reels" ? "Meus Reels" : "Conteúdo Competidores"}. Esta ação não pode ser desfeita.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancelar</AlertDialogCancel>
                      <AlertDialogAction onClick={handleDeleteIrrelevant} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                        Apagar {relevanceCounts.rejected} irrelevante(s)
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              )}
            </div>
          )}
        </div>

        <CardContent className="p-0">{renderContent()}</CardContent>

        {activeTab !== "estrategia" && (
          <div className="flex items-center justify-between border-t border-border/50 p-4">
            <p className="text-sm text-muted-foreground">Mostrando {paginatedData.length} de {currentData.length} itens</p>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="icon" className="h-8 w-8" disabled={currentPage === 1} onClick={() => setCurrentPage(p => p - 1)}><ChevronLeft className="h-4 w-4" /></Button>
              <span className="text-sm font-medium">{currentPage} / {totalPages || 1}</span>
              <Button variant="outline" size="icon" className="h-8 w-8" disabled={currentPage >= totalPages} onClick={() => setCurrentPage(p => p + 1)}><ChevronRight className="h-4 w-4" /></Button>
            </div>
          </div>
        )}
      </Card>

      {/* Image Analysis Modal */}
      <Dialog open={analysisModal.open} onOpenChange={(open) => setAnalysisModal(prev => ({ ...prev, open }))}>
        <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ScanEye className="h-5 w-5 text-cyan-500" />
              {analysisModal.title}
            </DialogTitle>
          </DialogHeader>

          {analysisModal.images.length > 0 && (
            <div className="flex gap-2 overflow-x-auto pb-2">
              {analysisModal.images.slice(0, 5).map((img, i) => (
                <div key={i} className="h-24 w-24 shrink-0 rounded-lg bg-muted overflow-hidden border border-border">
                  <img src={img} alt={`Slide ${i + 1}`} className="h-full w-full object-cover" />
                </div>
              ))}
              {analysisModal.images.length > 5 && (
                <div className="h-24 w-24 shrink-0 rounded-lg bg-muted flex items-center justify-center border border-border">
                  <span className="text-sm text-muted-foreground">+{analysisModal.images.length - 5}</span>
                </div>
              )}
            </div>
          )}

          <div className="prose prose-sm dark:prose-invert max-w-none whitespace-pre-wrap text-sm leading-relaxed">
            {analysisModal.content}
          </div>
        </DialogContent>
      </Dialog>
      {/* Reel Detail Modal */}
      <Dialog open={detailModal.open} onOpenChange={(open) => setDetailModal(prev => ({ ...prev, open }))}>
        <DialogContent className="max-w-2xl max-h-[90vh] flex flex-col p-0 overflow-hidden">
          <DialogHeader className="px-6 pt-6 pb-2 shrink-0">
            <DialogTitle className="flex items-center gap-2">
              <Film className="h-5 w-5 text-primary" />
              Detalhes do Conteúdo
            </DialogTitle>
            <DialogDescription className="sr-only">Resumo completo do conteúdo capturado</DialogDescription>
          </DialogHeader>
          {detailModal.reel && (() => {
            const r = detailModal.reel
            return (
              <div className="flex-1 overflow-y-auto px-6 pb-6">
                <div className="space-y-5">
                  {/* Header with thumbnail + meta */}
                  <div className="flex gap-4">
                    {r.thumbnail && (
                      <div className="h-28 w-28 shrink-0 rounded-lg bg-muted overflow-hidden border border-border">
                        <img src={r.thumbnail} alt="" className="h-full w-full object-cover" />
                      </div>
                    )}
                    <div className="flex-1 space-y-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge variant="outline" className="capitalize">{r.contentType || "reel"}</Badge>
                        <Badge
                          variant={r.relevanceStatus === "approved" ? "default" : r.relevanceStatus === "rejected" ? "destructive" : "secondary"}
                          className={r.relevanceStatus === "approved" ? "bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 border-emerald-500/30" : ""}
                        >
                          {r.relevanceStatus === "approved" ? "Relevante" : r.relevanceStatus === "rejected" ? "Irrelevante" : "Pendente"}
                          {r.relevanceScore ? ` (${r.relevanceScore}%)` : ""}
                        </Badge>
                      </div>
                      <p className="text-sm font-medium">@{r.user}</p>
                      <p className="text-xs text-muted-foreground">{r.postDate}</p>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1"><Eye className="h-3.5 w-3.5" />{formatNumber(r.views)}</span>
                        <span className="flex items-center gap-1"><Heart className="h-3.5 w-3.5" />{formatNumber(r.likes)}</span>
                        <span className="flex items-center gap-1"><MessageCircle className="h-3.5 w-3.5" />{formatNumber(r.comments)}</span>
                        <span className="flex items-center gap-1"><TrendingUp className="h-3.5 w-3.5" />{r.engRate.toFixed(1)}%</span>
                      </div>
                    </div>
                  </div>

                  {/* Caption */}
                  <div>
                    <h4 className="text-xs font-semibold uppercase text-muted-foreground mb-1">Caption</h4>
                    <p className="text-sm bg-muted/50 rounded-lg p-3 whitespace-pre-wrap">{r.caption || "(sem caption)"}</p>
                  </div>

                  {/* Relevance Reason */}
                  {r.relevanceReason && (
                    <div>
                      <h4 className="text-xs font-semibold uppercase text-muted-foreground mb-1 flex items-center gap-1"><Shield className="h-3 w-3" />Motivo da Classificação</h4>
                      <p className="text-sm bg-muted/50 rounded-lg p-3">{r.relevanceReason}</p>
                    </div>
                  )}

                  {/* Transcript */}
                  {r.transcript && (
                    <div>
                      <h4 className="text-xs font-semibold uppercase text-muted-foreground mb-1 flex items-center gap-1"><FileText className="h-3 w-3" />Transcrição</h4>
                      <p className="text-sm bg-muted/50 rounded-lg p-3 whitespace-pre-wrap max-h-48 overflow-y-auto">{r.transcript}</p>
                    </div>
                  )}

                  {/* Hook Analysis */}
                  {r.hookAnalysis && (
                    <div>
                      <h4 className="text-xs font-semibold uppercase text-muted-foreground mb-1 flex items-center gap-1"><Zap className="h-3 w-3" />Análise do Hook</h4>
                      <p className="text-sm bg-muted/50 rounded-lg p-3 whitespace-pre-wrap">{r.hookAnalysis}</p>
                    </div>
                  )}

                  {/* Viral Points */}
                  {r.viralPoints && r.viralPoints.length > 0 && (
                    <div>
                      <h4 className="text-xs font-semibold uppercase text-muted-foreground mb-1 flex items-center gap-1"><Zap className="h-3 w-3 text-amber-500" />Pontos Virais</h4>
                      <div className="max-h-40 overflow-y-auto rounded-md bg-muted/30 p-2 space-y-1.5">
                        {r.viralPoints.map((vp, i) => (
                          <div key={i} className="text-xs bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20 rounded px-2 py-1.5 whitespace-pre-wrap break-words">
                            ⚡ {vp}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Psych Triggers */}
                  {r.psychTriggers && r.psychTriggers.length > 0 && (
                    <div>
                      <h4 className="text-xs font-semibold uppercase text-muted-foreground mb-1 flex items-center gap-1"><Brain className="h-3 w-3 text-purple-500" />Gatilhos Psicológicos</h4>
                      <div className="flex flex-wrap gap-1.5">
                        {r.psychTriggers.map((pt, i) => (
                          <Badge key={i} variant="secondary" className="text-xs bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/20">
                            🧠 {pt}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                   {/* Actions */}
                  <div className="space-y-3 pt-2 border-t border-border/50">
                    <div className="flex flex-wrap gap-2">
                      <Button variant="outline" size="sm" className="gap-1.5" asChild>
                        <a href={r.url} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="h-3.5 w-3.5" />Ver no Instagram
                        </a>
                      </Button>
                      {r.videoUrl && (
                        <Button variant="outline" size="sm" className="gap-1.5" asChild>
                          <a href={r.videoUrl} target="_blank" rel="noopener noreferrer">
                            <Play className="h-3.5 w-3.5" />Assistir Vídeo
                          </a>
                        </Button>
                      )}
                      <Button variant="default" size="sm" className="gap-1.5" onClick={() => {
                        navigator.clipboard.writeText(`Hook: ${r.hookAnalysis || ''}\n\nCaption: ${r.caption}\n\nTranscrição: ${r.transcript || ''}`)
                        toast.success("Conteúdo copiado!")
                      }}>
                        <Copy className="h-3.5 w-3.5" />Copiar Resumo
                      </Button>
                    </div>

                    <div>
                      <p className="text-xs font-semibold uppercase text-muted-foreground mb-2 flex items-center gap-1.5">
                        <Sparkles className="h-3.5 w-3.5" /> Criar conteúdo como:
                      </p>
                      <div className="flex flex-wrap gap-1.5">
                        {[
                          { type: "reel", label: "Reel", icon: "🎬" },
                          { type: "carrossel", label: "Carrossel", icon: "📸" },
                          { type: "post", label: "Post", icon: "📝" },
                          { type: "video", label: "Vídeo", icon: "🎥" },
                          { type: "story", label: "Story", icon: "📱" },
                          { type: "copy", label: "Legenda", icon: "✍️" },
                          { type: "script", label: "Roteiro", icon: "🎯" },
                        ].map(f => (
                          <Button
                            key={f.type}
                            variant="secondary"
                            size="sm"
                            className="gap-1.5 text-xs h-8"
                            onClick={() => {
                              setDetailModal({ open: false, reel: null })
                              if (onCopyReelWithAI && (r.hookAnalysis || r.transcript || r.caption)) {
                                onCopyReelWithAI({
                                  hookAnalysis: r.hookAnalysis || "",
                                  transcript: r.transcript || "",
                                  caption: r.caption || "",
                                  viralPoints: r.viralPoints?.join("\n") || "",
                                  psychTriggers: r.psychTriggers?.join(", ") || "",
                                  relevanceReason: r.relevanceReason || "",
                                  ownerUsername: r.user || "",
                                  contentType: r.contentType || "",
                                  url: r.url || "",
                                }, f.type)
                              } else {
                                toast.info("Este conteúdo ainda não possui dados suficientes para gerar.")
                              }
                            }}
                          >
                            <span>{f.icon}</span>{f.label}
                          </Button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )
          })()}
        </DialogContent>
      </Dialog>
    </>
  )
}
