import { useState, useEffect } from "react"
import { supabase } from "@/integrations/supabase/client"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { cn } from "@/lib/utils"
import {
  Loader2, Zap, Copy, Brain, Target, ChevronDown, ChevronUp,
  Film, Images, ImageIcon, TrendingUp, AlertTriangle, CheckCircle2,
  Lightbulb, Sparkles, ArrowRight, Eye, BarChart3,
} from "lucide-react"

// ── Types ────────────────────────────────────────────────────────────────────
interface PostAnalysis {
  id: string
  owner_username: string
  caption: string
  content_type: string
  thumbnail_url?: string
  url?: string
  views: number
  likes: number
  comments: number
  viral_score: number
  hook_type?: string
  hook_analysis?: string
  adapted_hook?: string
  transcript?: string
  viral_analysis?: {
    hook?: string
    score_ia?: number
    engagement_score?: number
    hook_type?: string
    power_words?: string[]
    emotional_trigger?: string
    structure?: string
    why_viral?: string
    weak_points?: string
    adapted_hook?: string
    content_ideas?: string[]
    call_to_action?: string
    best_format?: string
    estimated_reach?: string
  }
}

interface CopyResult {
  phase: "hooks" | "copy"
  hooks?: {
    hook_a: string
    hook_a_rationale: string
    hook_a_driver: string
    hook_b: string
    hook_b_rationale: string
    hook_b_driver: string
    hook_c: string
    hook_c_rationale: string
    hook_c_driver: string
    diagnosis: {
      awareness_level: string
      sophistication: string
      big_idea: string
      dominant_driver: string
      framework: string
    }
  }
  copy?: {
    hook_selected: string
    framework: string
    caption: string
    hashtags: string[]
    cta_type: string
    objection_handler: string
  }
  raw?: string
}

// ── Helpers ──────────────────────────────────────────────────────────────────
function fmtNum(n: number) {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + "M"
  if (n >= 1_000) return (n / 1_000).toFixed(1) + "K"
  return String(n || 0)
}

function ScoreMeter({ score, label }: { score: number; label: string }) {
  const color = score >= 75 ? "#22c55e" : score >= 50 ? "#eab308" : score >= 30 ? "#f97316" : "#6b7280"
  return (
    <div>
      <div className="flex justify-between mb-1">
        <span className="text-[10px] text-muted-foreground">{label}</span>
        <span className="text-[10px] font-mono font-bold" style={{ color }}>{score}</span>
      </div>
      <div className="h-1.5 bg-muted/20 rounded-full overflow-hidden">
        <div className="h-full rounded-full transition-all" style={{ width: `${score}%`, backgroundColor: color }} />
      </div>
    </div>
  )
}

const HOOK_EMOJI: Record<string, string> = {
  Curiosidade:"🤔", Dor:"😣", Promessa:"✨", Choque:"😮",
  "Prova Social":"👥", Tendência:"📈", Urgência:"⏰",
}

// ── Analysis Section ──────────────────────────────────────────────────────────
function AnalysisSection({ post }: { post: PostAnalysis }) {
  const [showTranscript, setShowTranscript] = useState(false)
  const va = post.viral_analysis

  const engScore = va?.engagement_score || 0
  const iaScore  = va?.score_ia || 0
  const viral    = post.viral_score || 0

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex gap-3">
        <div className="w-14 h-14 rounded-xl overflow-hidden bg-muted/20 border border-border flex-shrink-0">
          {post.thumbnail_url
            ? <img src={post.thumbnail_url} className="w-full h-full object-cover" alt="" onError={e => { (e.target as HTMLImageElement).style.display = "none" }} />
            : <div className="w-full h-full flex items-center justify-center text-2xl opacity-30">
                {post.content_type === "reel" ? "🎬" : post.content_type?.includes("carros") ? "🎠" : "📸"}
              </div>
          }
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-0.5">
            <span className="text-sm font-bold">@{post.owner_username}</span>
            {post.hook_type && (
              <Badge variant="outline" className="text-[9px] px-1.5 py-0 text-yellow-400 border-yellow-500/30">
                {HOOK_EMOJI[post.hook_type]} {post.hook_type}
              </Badge>
            )}
          </div>
          <p className="text-[11px] text-muted-foreground line-clamp-2">{post.caption}</p>
          <div className="flex items-center gap-2.5 mt-1 text-[10px] text-muted-foreground/60">
            <span>👁 {fmtNum(post.views)}</span>
            <span>❤ {fmtNum(post.likes)}</span>
            <span>💬 {fmtNum(post.comments)}</span>
          </div>
        </div>
      </div>

      {/* Score breakdown */}
      {va && (
        <div className="rounded-xl border border-border bg-muted/10 p-3.5 space-y-2.5">
          <p className="text-[9px] uppercase tracking-widest text-muted-foreground/40 font-semibold">Score Viral</p>
          <ScoreMeter score={viral}    label="Score Final" />
          <ScoreMeter score={iaScore}  label="Qualidade do Gancho (IA)" />
          <ScoreMeter score={engScore} label="Engajamento Real (métricas)" />
          <p className="text-[9px] text-muted-foreground/50 text-right">
            Final = Gancho×60% + Engajamento×40%
          </p>
        </div>
      )}

      {/* Hook extraction */}
      {va?.hook && (
        <div className="rounded-xl border border-yellow-500/20 bg-yellow-500/5 p-3.5">
          <p className="text-[9px] uppercase tracking-widest text-yellow-400/60 mb-2">🎣 Gancho Original Identificado</p>
          <p className="text-sm italic text-yellow-300 font-medium">"{va.hook}"</p>
          {va.power_words?.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-2">
              {va.power_words.map((w, i) => (
                <span key={i} className="text-[10px] px-2 py-0.5 rounded bg-yellow-500/15 text-yellow-400 border border-yellow-500/20">⚡ {w}</span>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Psychological analysis */}
      {va && (
        <div className="rounded-xl border border-border bg-card p-3.5 space-y-2.5">
          <p className="text-[9px] uppercase tracking-widest text-muted-foreground/40 font-semibold">🧠 Análise Psicológica</p>

          {va.emotional_trigger && (
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-muted-foreground/50 w-28">Gatilho emocional</span>
              <Badge variant="outline" className="text-[10px] text-purple-400 border-purple-500/30">{va.emotional_trigger}</Badge>
            </div>
          )}
          {va.structure && (
            <div className="flex items-start gap-2">
              <span className="text-[10px] text-muted-foreground/50 w-28 flex-shrink-0">Estrutura</span>
              <p className="text-[10px] text-foreground/80">{va.structure}</p>
            </div>
          )}
          {va.estimated_reach && (
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-muted-foreground/50 w-28">Alcance estimado</span>
              <Badge variant="outline" className={cn("text-[10px]",
                va.estimated_reach === "viral" ? "text-green-400 border-green-500/30" :
                va.estimated_reach === "alto" ? "text-yellow-400 border-yellow-500/30" : "text-muted-foreground"
              )}>{va.estimated_reach}</Badge>
            </div>
          )}
        </div>
      )}

      {/* Why viral + weak points */}
      {va?.why_viral && (
        <div className="space-y-2">
          <div className="flex gap-2 p-3 rounded-lg bg-green-500/5 border border-green-500/15">
            <CheckCircle2 className="w-3.5 h-3.5 text-green-400 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-[9px] uppercase tracking-wider text-green-400/60 mb-0.5">Por que funciona</p>
              <p className="text-[11px] text-muted-foreground leading-relaxed">{va.why_viral}</p>
            </div>
          </div>
          {va.weak_points && (
            <div className="flex gap-2 p-3 rounded-lg bg-orange-500/5 border border-orange-500/15">
              <AlertTriangle className="w-3.5 h-3.5 text-orange-400 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-[9px] uppercase tracking-wider text-orange-400/60 mb-0.5">Ponto fraco</p>
                <p className="text-[11px] text-muted-foreground">{va.weak_points}</p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Adapted hook */}
      {post.adapted_hook && (
        <div className="rounded-xl border border-blue-500/20 bg-blue-500/5 p-3.5">
          <p className="text-[9px] uppercase tracking-widest text-blue-400/60 mb-2">🎯 Gancho Adaptado para o seu Nicho</p>
          <div className="flex items-start gap-2">
            <p className="text-sm italic text-blue-300 flex-1">"{post.adapted_hook}"</p>
            <button onClick={() => { navigator.clipboard.writeText(post.adapted_hook!); toast.success("Copiado!") }}
              className="text-muted-foreground hover:text-blue-400 flex-shrink-0">
              <Copy className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Content ideas */}
      {va?.content_ideas?.length > 0 && (
        <div>
          <p className="text-[9px] uppercase tracking-widest text-muted-foreground/40 mb-2">💡 Ideias Adaptadas</p>
          <div className="space-y-1">
            {va.content_ideas.map((idea, i) => (
              <div key={i} className="flex gap-2 text-[11px] text-muted-foreground">
                <span className="text-yellow-400 font-mono flex-shrink-0">{String(i+1).padStart(2,"0")}</span>
                {idea}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Transcript toggle */}
      {post.transcript && post.transcript !== "transcription failed" && (
        <div>
          <button onClick={() => setShowTranscript(v => !v)}
            className="flex items-center gap-1.5 text-[11px] text-muted-foreground hover:text-foreground">
            {showTranscript ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            {showTranscript ? "Ocultar" : "Ver"} transcrição completa
          </button>
          {showTranscript && (
            <div className="mt-2 rounded-lg bg-muted/10 border border-border p-3 text-[11px] text-muted-foreground leading-relaxed whitespace-pre-wrap max-h-48 overflow-y-auto">
              {post.transcript}
            </div>
          )}
        </div>
      )}
    </div>
  )
}

// ── Copy Generator with OpenSquad Copywriter ──────────────────────────────────
function CopyGenerator({ post }: { post: PostAnalysis }) {
  const [phase, setPhase] = useState<"setup" | "hooks" | "copy">("setup")
  const [format, setFormat] = useState<"reel" | "carrossel" | "post">(
    post.content_type === "reel" ? "reel" : post.content_type?.includes("carousel") ? "carrossel" : "post"
  )
  const [funnel, setFunnel] = useState<"awareness" | "consideration" | "conversion">("awareness")
  const [extraContext, setExtraContext] = useState("")
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<CopyResult | null>(null)
  const [selectedHook, setSelectedHook] = useState<"a" | "b" | "c" | null>(null)
  const [generatingCopy, setGeneratingCopy] = useState(false)

  const SUPA_URL = import.meta.env.VITE_SUPABASE_URL
  const va = post.viral_analysis

  async function generateHooks() {
    setLoading(true)
    try {
      const { data: { session } } = await supabase.auth.getSession()

      // Load tone of voice
      const { data: toneData } = await supabase
        .from("tone_of_voice")
        .select("tone_name,injection_string")
        .eq("is_active", true)
        .limit(2)
      const toneStr = (toneData || []).map((t: any) => t.tone_name).join(", ") || "educativo e direto"

      const context = `## CONTEÚDO DE REFERÊNCIA (para adaptar, NÃO copiar)
Post original de @${post.owner_username} — ${post.content_type}
Caption: ${(post.caption || "").slice(0, 400)}
Gancho identificado: "${va?.hook || post.hook_analysis || ""}"
Tipo de gancho: ${post.hook_type || va?.hook_type || ""}
Power words: ${va?.power_words?.join(", ") || ""}
Por que funciona: ${va?.why_viral || ""}
Gatilho psicológico: ${va?.emotional_trigger || ""}
Gancho adaptado: "${post.adapted_hook || ""}"

## PERFIL DO CRIADOR
Nicho: Direito bancário e advocacia consumidor
Tom de voz: ${toneStr}
Público: pessoas com dívidas bancárias, consumidores com problemas em contratos

## PARÂMETROS
Formato de destino: ${format}
Estágio do funil: ${funnel}
${extraContext ? `Contexto adicional: ${extraContext}` : ""}

## INSTRUÇÃO
Execute o PRÉ-DIAGNÓSTICO completo (awareness level, sofisticação, big idea, driver dominante).
Depois apresente 3 opções de hook (FASE 1) — cada uma com driver diferente e tipo estrutural diferente.

Retorne JSON:
{
  "phase": "hooks",
  "diagnosis": {
    "awareness_level": "...",
    "sophistication": "Estágio N — ...",
    "big_idea": "Inimigo: X | Mecanismo: Y | Promessa: Z",
    "dominant_driver": "...",
    "framework_recommendation": "AIDA|PAS|BAB|Star-Story-Solution|4Ps"
  },
  "hooks": {
    "hook_a": "texto do hook A",
    "hook_a_driver": "driver psicológico",
    "hook_a_type": "tipo estrutural",
    "hook_a_rationale": "por que vai funcionar com este público",
    "hook_b": "texto do hook B",
    "hook_b_driver": "driver psicológico",
    "hook_b_type": "tipo estrutural",
    "hook_b_rationale": "por que vai funcionar",
    "hook_c": "texto do hook C",
    "hook_c_driver": "driver psicológico",
    "hook_c_type": "tipo estrutural",
    "hook_c_rationale": "por que vai funcionar"
  }
}`

      const res = await fetch(`${SUPA_URL}/functions/v1/generate-content`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.access_token}` },
        body: JSON.stringify({
          agent: "copywriter",
          context,
          provider: "openrouter",
          model: "anthropic/claude-opus-4",
          format: format === "carrossel" ? "instagram-feed" : format === "reel" ? "instagram-reels" : "instagram-feed",
        }),
      })
      const d = await res.json()
      const raw = (d.result || "").replace(/```json|```/g, "").trim()
      const parsed = JSON.parse(raw)
      setResult({ phase: "hooks", hooks: parsed.hooks, raw: JSON.stringify(parsed.diagnosis, null, 2) })
      setPhase("hooks")
    } catch (e: any) {
      toast.error("Erro ao gerar hooks: " + e.message)
    } finally { setLoading(false) }
  }

  async function generateCopy(hookKey: "a" | "b" | "c") {
    if (!result?.hooks) return
    setSelectedHook(hookKey)
    setGeneratingCopy(true)
    try {
      const { data: { session } } = await supabase.auth.getSession()
      const hook = result.hooks[`hook_${hookKey}` as keyof typeof result.hooks]

      // Parse diagnosis from raw
      let diagnosis: any = {}
      try { diagnosis = JSON.parse(result.raw || "{}") } catch {}

      const context = `## HOOK SELECIONADO
"${hook}"
Driver: ${result.hooks[`hook_${hookKey}_driver` as keyof typeof result.hooks]}

## DIAGNÓSTICO
${JSON.stringify(diagnosis, null, 2)}

## CONTEÚDO DE REFERÊNCIA
Post original: @${post.owner_username}
Caption: ${(post.caption || "").slice(0, 300)}
Formato de destino: ${format}
Estágio do funil: ${funnel}

## INSTRUÇÃO
Execute FASE 2: escreva a copy completa.
- Use o framework recomendado: ${diagnosis.framework_recommendation || "PAS"}
- Neutralize a principal objeção ANTES do CTA
- CTA na intensidade correta para estágio ${funnel}
- Máximo 2200 chars para caption | Inclua 5-15 hashtags no final

Retorne JSON:
{
  "phase": "copy",
  "framework_used": "...",
  "caption": "copy completa pronta para publicar",
  "hashtags": ["#tag1", "#tag2"],
  "cta_type": "suave|médio|forte",
  "cta_text": "texto exato do CTA",
  "objection_handler": "objeção neutralizada no texto",
  "notes": "notas sobre as escolhas feitas"
}`

      const res = await fetch(`${SUPA_URL}/functions/v1/generate-content`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.access_token}` },
        body: JSON.stringify({
          agent: "copywriter",
          context,
          provider: "openrouter",
          model: "anthropic/claude-opus-4",
          format: format === "carrossel" ? "instagram-feed" : "instagram-reels",
        }),
      })
      const d = await res.json()
      const raw = (d.result || "").replace(/```json|```/g, "").trim()
      const parsed = JSON.parse(raw)
      setResult(prev => ({ ...prev!, phase: "copy", copy: parsed }))
      setPhase("copy")
    } catch (e: any) {
      toast.error("Erro ao gerar copy: " + e.message)
    } finally { setGeneratingCopy(false) }
  }

  function reset() { setPhase("setup"); setResult(null); setSelectedHook(null) }

  return (
    <div className="space-y-4">
      {/* Phase: setup */}
      {phase === "setup" && (
        <div className="space-y-3">
          <div className="rounded-xl border border-border bg-muted/10 p-3.5">
            <p className="text-[9px] uppercase tracking-widest text-muted-foreground/40 mb-3">⚙️ Parâmetros da Copy</p>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <p className="text-[10px] text-muted-foreground mb-1">Formato</p>
                <div className="flex rounded-lg border border-border overflow-hidden">
                  {(["reel","carrossel","post"] as const).map(f => (
                    <button key={f} onClick={() => setFormat(f)}
                      className={cn("flex-1 py-1.5 text-[10px] font-medium transition-colors",
                        format === f ? "bg-yellow-500/20 text-yellow-400" : "text-muted-foreground hover:text-foreground"
                      )}>
                      {f === "reel" ? "🎬" : f === "carrossel" ? "🎠" : "📸"} {f}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <p className="text-[10px] text-muted-foreground mb-1">Estágio do Funil</p>
                <Select value={funnel} onValueChange={(v: any) => setFunnel(v)}>
                  <SelectTrigger className="h-[34px] text-[10px]"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="awareness" className="text-xs">🎯 Awareness — CTA suave</SelectItem>
                    <SelectItem value="consideration" className="text-xs">🤔 Consideração — CTA médio</SelectItem>
                    <SelectItem value="conversion" className="text-xs">💰 Conversão — CTA forte</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="mt-2">
              <p className="text-[10px] text-muted-foreground mb-1">Contexto adicional (opcional)</p>
              <Textarea value={extraContext} onChange={e => setExtraContext(e.target.value)}
                placeholder="Ex: Foco em Código de Defesa do Consumidor, mencionar taxa SELIC, campanha de lançamento..."
                rows={2} className="text-xs" />
            </div>
          </div>
          <Button onClick={generateHooks} disabled={loading}
            className="w-full gap-2 bg-yellow-500 hover:bg-yellow-400 text-black font-bold h-9 text-xs">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Brain className="w-4 h-4" />}
            {loading ? "Diagnosticando e gerando hooks..." : "Gerar 3 Opções de Hook (Copywriter OpenSquad)"}
          </Button>
        </div>
      )}

      {/* Phase: hooks */}
      {phase === "hooks" && result?.hooks && (
        <div className="space-y-3">
          {/* Diagnosis */}
          {result.raw && (
            <div className="rounded-xl border border-purple-500/20 bg-purple-500/5 p-3.5">
              <p className="text-[9px] uppercase tracking-widest text-purple-400/60 mb-2">🧠 Diagnóstico Pré-Copy (Eugene Schwartz)</p>
              {(() => {
                try {
                  const d = JSON.parse(result.raw)
                  return (
                    <div className="space-y-1.5 text-[11px]">
                      {d.awareness_level && <p><span className="text-muted-foreground/60">Nível de Consciência:</span> <span className="text-foreground/80">{d.awareness_level}</span></p>}
                      {d.sophistication && <p><span className="text-muted-foreground/60">Sofisticação:</span> <span className="text-foreground/80">{d.sophistication}</span></p>}
                      {d.big_idea && <p><span className="text-muted-foreground/60">Big Idea:</span> <span className="text-foreground/80">{d.big_idea}</span></p>}
                      {d.dominant_driver && <p><span className="text-muted-foreground/60">Driver Dominante:</span> <span className="text-yellow-400">{d.dominant_driver}</span></p>}
                      {d.framework_recommendation && <p><span className="text-muted-foreground/60">Framework:</span> <span className="text-blue-400">{d.framework_recommendation}</span></p>}
                    </div>
                  )
                } catch { return null }
              })()}
            </div>
          )}

          {/* 3 hooks */}
          <p className="text-[10px] text-muted-foreground font-semibold">Escolha o hook para gerar a copy completa:</p>
          {(["a","b","c"] as const).map(k => {
            const h = result.hooks!
            const hook     = h[`hook_${k}` as keyof typeof h] as string
            const driver   = h[`hook_${k}_driver` as keyof typeof h] as string
            const typeS    = h[`hook_${k}_type` as keyof typeof h] as string
            const rational = h[`hook_${k}_rationale` as keyof typeof h] as string
            return (
              <div key={k} className={cn(
                "rounded-xl border p-3.5 cursor-pointer transition-all group",
                selectedHook === k ? "border-yellow-500/50 bg-yellow-500/5" : "border-border hover:border-yellow-500/25"
              )}>
                <div className="flex items-start gap-2.5 mb-2">
                  <span className="w-5 h-5 rounded-full bg-yellow-500/20 border border-yellow-500/30 text-yellow-400 text-[10px] font-bold flex items-center justify-center flex-shrink-0 mt-0.5">
                    {k.toUpperCase()}
                  </span>
                  <p className="text-sm font-medium text-foreground flex-1 leading-snug">"{hook}"</p>
                </div>
                <div className="ml-7 flex flex-wrap gap-1.5 mb-2">
                  <Badge variant="outline" className="text-[9px] text-purple-400 border-purple-500/25">{driver}</Badge>
                  {typeS && <Badge variant="outline" className="text-[9px] text-muted-foreground">{typeS}</Badge>}
                </div>
                {rational && (
                  <p className="ml-7 text-[10px] text-muted-foreground italic">{rational}</p>
                )}
                <button onClick={() => generateCopy(k)} disabled={generatingCopy}
                  className="ml-7 mt-2 flex items-center gap-1.5 text-[10px] text-yellow-400 hover:text-yellow-300 font-semibold">
                  {generatingCopy && selectedHook === k ? <Loader2 className="w-3 h-3 animate-spin" /> : <ArrowRight className="w-3 h-3" />}
                  {generatingCopy && selectedHook === k ? "Gerando copy..." : "Usar este hook → gerar copy completa"}
                </button>
              </div>
            )
          })}
          <Button onClick={reset} variant="ghost" size="sm" className="text-xs w-full">← Mudar parâmetros</Button>
        </div>
      )}

      {/* Phase: copy */}
      {phase === "copy" && result?.copy && (
        <div className="space-y-3">
          {/* Framework used */}
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-xs text-blue-400 border-blue-500/30">
              📐 {result.copy.framework_used}
            </Badge>
            <Badge variant="outline" className={cn("text-xs",
              result.copy.cta_type === "forte" ? "text-red-400 border-red-500/30" :
              result.copy.cta_type === "médio" ? "text-yellow-400 border-yellow-500/30" :
              "text-green-400 border-green-500/30"
            )}>
              CTA {result.copy.cta_type}
            </Badge>
          </div>

          {/* Full caption */}
          <div className="rounded-xl border border-border bg-card">
            <div className="flex items-center justify-between px-3.5 py-2.5 border-b border-border/50">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground/50 font-semibold">Copy Final</p>
              <button onClick={() => { navigator.clipboard.writeText(result.copy!.caption); toast.success("Copy copiada!") }}
                className="flex items-center gap-1 text-[10px] text-muted-foreground hover:text-foreground">
                <Copy className="w-3 h-3" /> Copiar
              </button>
            </div>
            <div className="p-3.5">
              <p className="text-xs text-foreground leading-relaxed whitespace-pre-wrap">{result.copy.caption}</p>
            </div>
          </div>

          {/* Hashtags */}
          {result.copy.hashtags?.length > 0 && (
            <div className="flex flex-wrap gap-1">
              {result.copy.hashtags.map((h, i) => (
                <span key={i} className="text-[10px] px-2 py-0.5 rounded bg-muted/20 border border-border text-muted-foreground">{h}</span>
              ))}
              <button onClick={() => { navigator.clipboard.writeText(result.copy!.hashtags.join(" ")); toast.success("Hashtags copiadas!") }}
                className="text-[10px] px-2 py-0.5 text-yellow-400 hover:text-yellow-300">
                copiar todas
              </button>
            </div>
          )}

          {/* Objection handler + notes */}
          {result.copy.objection_handler && (
            <div className="rounded-lg bg-muted/10 border border-border p-2.5">
              <p className="text-[9px] text-muted-foreground/50 uppercase tracking-wider mb-1">Objeção neutralizada</p>
              <p className="text-[11px] text-muted-foreground">{result.copy.objection_handler}</p>
            </div>
          )}

          <div className="flex gap-2">
            <Button onClick={reset} variant="outline" size="sm" className="text-xs flex-1 h-8">← Nova copy</Button>
            <Button onClick={() => { navigator.clipboard.writeText(result.copy!.caption + "\n\n" + result.copy!.hashtags.join(" ")); toast.success("Tudo copiado!") }}
              size="sm" className="text-xs flex-1 h-8 bg-yellow-500 hover:bg-yellow-400 text-black gap-1">
              <Copy className="w-3 h-3" /> Copiar copy + hashtags
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}

// ── Main: Viral Analysis Panel ────────────────────────────────────────────────
export function ViralAnalysisPanel({ postId, onClose }: { postId: string; onClose?: () => void }) {
  const [post, setPost] = useState<PostAnalysis | null>(null)
  const [loading, setLoading] = useState(true)
  const [tab, setTab] = useState<"analysis" | "copy">("analysis")

  useEffect(() => {
    async function load() {
      const { data } = await supabase
        .from("reels_competidores")
        .select("id,owner_username,caption,content_type,thumbnail_url,url,views,likes,comments,viral_score,hook_type,hook_analysis,adapted_hook,transcript,viral_analysis")
        .eq("id", postId)
        .single()
      setPost(data as PostAnalysis)
      setLoading(false)
    }
    load()
  }, [postId])

  if (loading) return (
    <div className="flex items-center justify-center py-12">
      <Loader2 className="w-5 h-5 animate-spin text-yellow-400" />
    </div>
  )

  if (!post) return (
    <div className="text-center py-8 text-muted-foreground text-sm">Post não encontrado</div>
  )

  return (
    <div className="flex flex-col h-full">
      {/* Tabs */}
      <div className="flex items-center gap-1 p-3 border-b border-border bg-muted/10">
        {([
          { id: "analysis", label: "📊 Análise Viral" },
          { id: "copy",     label: "✍️ Gerar Copy" },
        ] as const).map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={cn("px-3 py-1.5 rounded-lg text-xs font-medium transition-all",
              tab === t.id ? "bg-background border border-border text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
            )}>
            {t.label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4">
        {tab === "analysis" && <AnalysisSection post={post} />}
        {tab === "copy"     && <CopyGenerator   post={post} />}
      </div>
    </div>
  )
}
