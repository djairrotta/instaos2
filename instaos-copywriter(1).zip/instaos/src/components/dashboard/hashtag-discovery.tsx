import { useState, useEffect, useCallback } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Search, ExternalLink, Eye, Heart, MessageCircle, Hash, CheckCircle, XCircle, Clock, RefreshCw, Filter, Copy, TrendingUp, Rocket, Loader2 } from "lucide-react"
import { supabase } from "@/integrations/supabase/client"
import { toast } from "sonner"

interface HashtagItem {
  id: string
  caption: string
  owner_username: string
  url: string
  thumbnail_url: string
  video_url: string
  views: number
  likes: number
  comments: number
  eng_rate: number
  post_date: string
  content_type: string
  relevance_status: string
  relevance_reason: string
  viral_points: string
  hook_analysis: string
}

interface HashtagDiscoveryProps {
  onRelevanceUpdate?: (id: string, status: string) => void
  onRefresh?: () => void
}

const STATUS_CONFIG: Record<string, { label: string; icon: React.ReactNode; color: string }> = {
  pending: { label: "Pendente", icon: <Clock className="h-3.5 w-3.5" />, color: "bg-yellow-500/10 text-yellow-600 dark:text-yellow-400 border-yellow-500/20" },
  approved: { label: "Aprovado", icon: <CheckCircle className="h-3.5 w-3.5" />, color: "bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/20" },
  rejected: { label: "Rejeitado", icon: <XCircle className="h-3.5 w-3.5" />, color: "bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/20" },
}

export function HashtagDiscovery({ onRelevanceUpdate, onRefresh }: HashtagDiscoveryProps) {
  const [items, setItems] = useState<HashtagItem[]>([])
  const [loading, setLoading] = useState(true)
  const [discovering, setDiscovering] = useState(false)
  const [search, setSearch] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [contentFilter, setContentFilter] = useState<string>("all")

  const loadData = useCallback(async () => {
    setLoading(true)
    try {
      const { data, error } = await supabase
        .from("reels_competidores")
        .select("*")
        .like("relevance_reason", "%hashtag%")
        .order("views", { ascending: false })
        .limit(200)

      if (error) throw error

      setItems((data || []).map((r: any) => ({
        id: r.id,
        caption: r.caption || "",
        owner_username: r.owner_username || "",
        url: r.url || "",
        thumbnail_url: r.thumbnail_url || "",
        video_url: r.video_url || "",
        views: r.views || 0,
        likes: r.likes || 0,
        comments: r.comments || 0,
        eng_rate: Number(r.eng_rate || 0),
        post_date: r.post_date || "",
        content_type: r.content_type || "reel",
        relevance_status: r.relevance_status || "pending",
        relevance_reason: r.relevance_reason || "",
        viral_points: r.viral_points || "",
        hook_analysis: r.hook_analysis || "",
      })))
    } catch (e: any) {
      toast.error("Erro ao carregar dados de hashtags", { description: e.message })
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { loadData() }, [loadData])

  const handleStatusChange = async (id: string, newStatus: string) => {
    try {
      const { error } = await supabase
        .from("reels_competidores")
        .update({ relevance_status: newStatus })
        .eq("id", id)
      if (error) throw error
      setItems(prev => prev.map(i => i.id === id ? { ...i, relevance_status: newStatus } : i))
      toast.success(`Status atualizado para ${STATUS_CONFIG[newStatus]?.label || newStatus}`)
      onRelevanceUpdate?.(id, newStatus)
    } catch (e: any) {
      toast.error("Erro ao atualizar status", { description: e.message })
    }
  }

  const runHashtagDiscovery = async () => {
    setDiscovering(true)
    const toastId = toast.loading("Iniciando descoberta por hashtags...")
    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) throw new Error("Usuário não autenticado")

      // Load niche keywords from system_config
      const { data: kwData } = await supabase
        .from("system_config")
        .select("config_value")
        .eq("user_id", user.id)
        .eq("config_key", "niche_keywords")
        .maybeSingle()

      // Also gather niches from competitors
      const { data: compData } = await supabase
        .from("competidores")
        .select("niche")
        .eq("user_id", user.id)
        .eq("status", true)

      const keywords = kwData?.config_value?.split(",").map((k: string) => k.trim()).filter(Boolean) || []
      const compNiches = (compData || []).map((c: any) => c.niche).filter(Boolean)
      const allHashtags = [...new Set([...keywords, ...compNiches])]

      if (allHashtags.length === 0) {
        toast.error("Configure suas keywords de nicho primeiro (Configurações de Nicho)", { id: toastId })
        setDiscovering(false)
        return
      }

      toast.loading(`Buscando ${allHashtags.length} hashtags: ${allHashtags.slice(0, 5).join(", ")}...`, { id: toastId })

      // Call scrape-reels with hashtag action
      const { data: scrapeResult, error: scrapeError } = await supabase.functions.invoke("scrape-reels", {
        body: {
          action: "hashtag",
          hashtags: allHashtags,
          limit: 30,
          contentTypes: ["reel", "post", "carousel"],
        },
      })

      if (scrapeError) throw scrapeError
      if (!scrapeResult?.success) throw new Error(scrapeResult?.error || "Falha na busca")

      const newReels = scrapeResult.reels || []
      if (newReels.length === 0) {
        toast.info("Nenhum conteúdo novo encontrado para as hashtags", { id: toastId })
        setDiscovering(false)
        return
      }

      // Deduplicate against existing URLs
      const { data: existingUrls } = await supabase
        .from("reels_competidores")
        .select("url")
        .eq("user_id", user.id)

      const existing = new Set((existingUrls || []).map((r: any) => r.url))
      const unique = newReels.filter((r: any) => r.url && !existing.has(r.url))

      if (unique.length === 0) {
        toast.info("Todos os conteúdos encontrados já existem no banco", { id: toastId })
        setDiscovering(false)
        return
      }

      toast.loading(`Salvando ${unique.length} novos conteúdos...`, { id: toastId })

      // Insert into reels_competidores
      const rows = unique.map((r: any) => ({
        user_id: user.id,
        caption: r.caption || "",
        owner_username: r.owner_username || "",
        url: r.url || "",
        thumbnail_url: r.thumbnail_url || "",
        video_url: r.video_url || "",
        views: r.views || 0,
        likes: r.likes || 0,
        comments: r.comments || 0,
        eng_rate: r.eng_rate || 0,
        post_date: r.post_date || null,
        content_type: r.content_type || "reel",
        image_urls: r.image_urls || [],
        relevance_status: "pending",
        relevance_reason: `Descoberto via hashtag ${r.hashtag_source || ""}`.trim(),
      }))

      const { error: insertError } = await supabase.from("reels_competidores").insert(rows)
      if (insertError) throw insertError

      toast.success(`${unique.length} novos conteúdos descobertos e salvos!`, { id: toastId })
      await loadData()
      onRefresh?.()
    } catch (e: any) {
      toast.error("Erro na descoberta por hashtags", { id: toastId, description: e.message })
    } finally {
      setDiscovering(false)
    }
  }

  const filtered = items.filter(item => {
    if (statusFilter !== "all" && item.relevance_status !== statusFilter) return false
    if (contentFilter !== "all" && item.content_type !== contentFilter) return false
    if (search) {
      const q = search.toLowerCase()
      return item.caption.toLowerCase().includes(q) ||
        item.owner_username.toLowerCase().includes(q) ||
        item.viral_points.toLowerCase().includes(q) ||
        item.relevance_reason.toLowerCase().includes(q)
    }
    return true
  })

  const stats = {
    total: items.length,
    pending: items.filter(i => i.relevance_status === "pending").length,
    approved: items.filter(i => i.relevance_status === "approved").length,
    rejected: items.filter(i => i.relevance_status === "rejected").length,
  }

  // Extract unique hashtags from viral_points/relevance_reason
  const hashtags = [...new Set(items.map(i => {
    const match = i.relevance_reason.match(/#\w+/)
    return match ? match[0] : i.viral_points?.startsWith("#") ? i.viral_points.split(" ")[0] : null
  }).filter(Boolean))] as string[]

  const formatNum = (n: number) => n >= 1_000_000 ? `${(n / 1_000_000).toFixed(1)}M` : n >= 1_000 ? `${(n / 1_000).toFixed(1)}K` : String(n)

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <Hash className="h-5 w-5 text-primary" />
            Descoberta por Hashtags
            <Badge variant="secondary" className="text-xs">{stats.total}</Badge>
          </CardTitle>
          <div className="flex gap-2">
            <Button variant="default" size="sm" className="h-8 text-xs gap-1.5" onClick={runHashtagDiscovery} disabled={discovering}>
              {discovering ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Rocket className="h-3.5 w-3.5" />}
              {discovering ? "Descobrindo..." : "Descobrir Agora"}
            </Button>
            <Button variant="outline" size="sm" className="h-8 text-xs gap-1.5" onClick={() => { loadData(); onRefresh?.() }}>
              <RefreshCw className="h-3.5 w-3.5" /> Atualizar
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Stats */}
        <div className="flex gap-2 flex-wrap">
          {hashtags.slice(0, 8).map(tag => (
            <Badge key={tag} variant="outline" className="text-xs gap-1 cursor-pointer hover:bg-accent" onClick={() => setSearch(tag)}>
              {tag}
            </Badge>
          ))}
        </div>

        <div className="grid grid-cols-3 gap-3">
          <button onClick={() => setStatusFilter("pending")} className={`rounded-lg border p-3 text-center transition-colors ${statusFilter === "pending" ? "border-yellow-500 bg-yellow-500/10" : "hover:bg-muted"}`}>
            <p className="text-xl font-bold">{stats.pending}</p>
            <p className="text-[10px] text-muted-foreground">Pendentes</p>
          </button>
          <button onClick={() => setStatusFilter("approved")} className={`rounded-lg border p-3 text-center transition-colors ${statusFilter === "approved" ? "border-green-500 bg-green-500/10" : "hover:bg-muted"}`}>
            <p className="text-xl font-bold">{stats.approved}</p>
            <p className="text-[10px] text-muted-foreground">Aprovados</p>
          </button>
          <button onClick={() => setStatusFilter("rejected")} className={`rounded-lg border p-3 text-center transition-colors ${statusFilter === "rejected" ? "border-red-500 bg-red-500/10" : "hover:bg-muted"}`}>
            <p className="text-xl font-bold">{stats.rejected}</p>
            <p className="text-[10px] text-muted-foreground">Rejeitados</p>
          </button>
        </div>

        {/* Filters */}
        <div className="flex gap-2 flex-wrap">
          <div className="relative flex-1 min-w-[180px]">
            <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-muted-foreground" />
            <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar por caption, @user, #hashtag..." className="pl-8 h-9 text-xs" />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[130px] h-9 text-xs"><Filter className="h-3 w-3 mr-1" /><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos</SelectItem>
              <SelectItem value="pending">Pendentes</SelectItem>
              <SelectItem value="approved">Aprovados</SelectItem>
              <SelectItem value="rejected">Rejeitados</SelectItem>
            </SelectContent>
          </Select>
          <Select value={contentFilter} onValueChange={setContentFilter}>
            <SelectTrigger className="w-[120px] h-9 text-xs"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos tipos</SelectItem>
              <SelectItem value="reel">Reels</SelectItem>
              <SelectItem value="post">Posts</SelectItem>
              <SelectItem value="carousel">Carrosseis</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Table */}
        {loading ? (
          <div className="text-center py-8 text-sm text-muted-foreground">Carregando...</div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-8 space-y-2">
            <Hash className="h-8 w-8 text-muted-foreground mx-auto" />
            <p className="text-sm text-muted-foreground">
              {items.length === 0
                ? "Nenhum conteúdo descoberto por hashtag ainda. Rode o pipeline para iniciar a descoberta."
                : "Nenhum resultado com os filtros selecionados."}
            </p>
          </div>
        ) : (
          <ScrollArea className="h-[400px]">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-xs w-[50px]">Tipo</TableHead>
                  <TableHead className="text-xs">Conteúdo</TableHead>
                  <TableHead className="text-xs w-[90px]">Hashtag</TableHead>
                  <TableHead className="text-xs w-[70px] text-right"><Eye className="h-3 w-3 inline" /></TableHead>
                  <TableHead className="text-xs w-[70px] text-right"><Heart className="h-3 w-3 inline" /></TableHead>
                  <TableHead className="text-xs w-[50px] text-right">Eng%</TableHead>
                  <TableHead className="text-xs w-[120px]">Status</TableHead>
                  <TableHead className="text-xs w-[60px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map(item => {
                  const statusCfg = STATUS_CONFIG[item.relevance_status] || STATUS_CONFIG.pending
                  const hashtag = item.relevance_reason.match(/#\w+/)?.[0] || item.viral_points?.split(" ")[0] || ""
                  return (
                    <TableRow key={item.id} className="group">
                      <TableCell>
                        <Badge variant="outline" className="text-[10px]">
                          {item.content_type === "reel" ? "🎬" : item.content_type === "carousel" ? "🎠" : "📷"} {item.content_type}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <div className="max-w-[250px]">
                                <p className="text-xs font-medium truncate">@{item.owner_username}</p>
                                <p className="text-[10px] text-muted-foreground truncate">{item.caption.slice(0, 80) || "Sem legenda"}</p>
                              </div>
                            </TooltipTrigger>
                            <TooltipContent side="bottom" className="max-w-sm">
                              <p className="text-xs whitespace-pre-wrap">{item.caption.slice(0, 500)}</p>
                              {item.hook_analysis && <p className="text-xs mt-2 text-muted-foreground border-t pt-1">🪝 {item.hook_analysis.slice(0, 200)}</p>}
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary" className="text-[10px]">{hashtag}</Badge>
                      </TableCell>
                      <TableCell className="text-right text-xs font-mono">{formatNum(item.views)}</TableCell>
                      <TableCell className="text-right text-xs font-mono">{formatNum(item.likes)}</TableCell>
                      <TableCell className="text-right text-xs font-mono">{item.eng_rate.toFixed(1)}%</TableCell>
                      <TableCell>
                        <Select value={item.relevance_status} onValueChange={v => handleStatusChange(item.id, v)}>
                          <SelectTrigger className={`h-7 text-[10px] border ${statusCfg.color}`}>
                            <span className="flex items-center gap-1">{statusCfg.icon} {statusCfg.label}</span>
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="pending"><span className="flex items-center gap-1"><Clock className="h-3 w-3" /> Pendente</span></SelectItem>
                            <SelectItem value="approved"><span className="flex items-center gap-1"><CheckCircle className="h-3 w-3" /> Aprovado</span></SelectItem>
                            <SelectItem value="rejected"><span className="flex items-center gap-1"><XCircle className="h-3 w-3" /> Rejeitado</span></SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          {item.url && (
                            <Button variant="ghost" size="icon" className="h-6 w-6" asChild>
                              <a href={item.url} target="_blank" rel="noopener noreferrer"><ExternalLink className="h-3 w-3" /></a>
                            </Button>
                          )}
                          <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => { navigator.clipboard.writeText(item.url); toast.success("URL copiada") }}>
                            <Copy className="h-3 w-3" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  )
}
