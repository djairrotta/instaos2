import { useState, useRef, useMemo } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Users, Film, TrendingUp, Download, Filter, Trash2,
  Heart, MessageCircle, Eye, Zap, Brain, ExternalLink,
  ChevronDown, ChevronUp, Sparkles, Trophy, Crown, Medal,
} from "lucide-react"
import { toast } from "sonner"

interface CompetitorProfile {
  id?: string
  name: string
  bio?: string
  followersCount?: number
  followingCount?: number
  postsCount?: number
  profilePicUrl?: string
  predominantContentType?: string
  avgPostsPerWeek?: number
}

interface ReelData {
  user: string
  contentType?: string
  engRate: number
  views: number
  likes: number
  comments: number
  postDate?: string | null
  caption?: string
  url?: string
  hookAnalysis?: string
  viralPoints?: string[]
  psychTriggers?: string[]
  relevanceScore?: number
}

interface CompetitorComparisonProps {
  myUsername: string
  competitors: CompetitorProfile[]
  reelsData?: ReelData[]
  onDeleteCompetitors?: (ids: string[]) => void
}

type TimePeriod = "all" | "1w" | "1m" | "3m"

const PERIOD_LABELS: Record<TimePeriod, string> = {
  all: "Todos",
  "1w": "Última semana",
  "1m": "Último mês",
  "3m": "Últimos 3 meses",
}

function getDateThreshold(period: TimePeriod): Date | null {
  if (period === "all") return null
  const now = new Date()
  if (period === "1w") return new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)
  if (period === "1m") return new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000)
  if (period === "3m") return new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000)
  return null
}

function formatNumber(n?: number): string {
  if (!n) return "0"
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + "M"
  if (n >= 1_000) return (n / 1_000).toFixed(1) + "K"
  return n.toString()
}


function ViralContentCard({ reel, rank }: { reel: ReelData; rank: number }) {
  const [expanded, setExpanded] = useState(false)

  return (
    <Card className="overflow-hidden border-border/60">
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center gap-3 p-3 hover:bg-muted/50 transition-colors text-left"
      >
        <div className="flex h-7 w-7 items-center justify-center rounded-full bg-primary/10 text-primary font-bold text-xs shrink-0">
          #{rank}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-xs text-muted-foreground truncate">
            {reel.caption ? reel.caption.slice(0, 80) + (reel.caption.length > 80 ? "…" : "") : "Sem legenda"}
          </p>
          <div className="flex items-center gap-3 mt-1 text-[11px] text-muted-foreground">
            <span className="flex items-center gap-0.5"><Eye className="h-3 w-3" /> {formatNumber(reel.views)}</span>
            <span className="flex items-center gap-0.5"><Heart className="h-3 w-3" /> {formatNumber(reel.likes)}</span>
            <span className="flex items-center gap-0.5"><MessageCircle className="h-3 w-3" /> {formatNumber(reel.comments)}</span>
            <span className="flex items-center gap-0.5"><TrendingUp className="h-3 w-3" /> {reel.engRate.toFixed(1)}%</span>
            {reel.contentType && <Badge variant="outline" className="text-[10px] h-4 capitalize">{reel.contentType}</Badge>}
          </div>
        </div>
        {reel.url && (
          <a href={reel.url} target="_blank" rel="noopener noreferrer" onClick={e => e.stopPropagation()} className="shrink-0">
            <ExternalLink className="h-3.5 w-3.5 text-muted-foreground hover:text-primary" />
          </a>
        )}
        {expanded ? <ChevronUp className="h-4 w-4 shrink-0 text-muted-foreground" /> : <ChevronDown className="h-4 w-4 shrink-0 text-muted-foreground" />}
      </button>

      {expanded && (
        <div className="border-t p-3 space-y-3 bg-muted/20">
          {/* Metrics Grid */}
          <div className="grid grid-cols-4 gap-2">
            <div className="rounded-lg bg-background p-2 text-center border border-border/50">
              <p className="text-sm font-bold">{formatNumber(reel.views)}</p>
              <p className="text-[10px] text-muted-foreground">👁️ Views</p>
            </div>
            <div className="rounded-lg bg-background p-2 text-center border border-border/50">
              <p className="text-sm font-bold">{formatNumber(reel.likes)}</p>
              <p className="text-[10px] text-muted-foreground">❤️ Curtidas</p>
            </div>
            <div className="rounded-lg bg-background p-2 text-center border border-border/50">
              <p className="text-sm font-bold">{formatNumber(reel.comments)}</p>
              <p className="text-[10px] text-muted-foreground">💬 Comentários</p>
            </div>
            <div className="rounded-lg bg-background p-2 text-center border border-border/50">
              <p className="text-sm font-bold">{reel.engRate.toFixed(1)}%</p>
              <p className="text-[10px] text-muted-foreground">📈 Engajamento</p>
            </div>
          </div>

          {/* Hook Analysis */}
          {reel.hookAnalysis && (
            <div className="space-y-1">
              <p className="text-xs font-semibold flex items-center gap-1.5">
                <Sparkles className="h-3.5 w-3.5 text-orange-500" /> Análise do Gancho
              </p>
              <p className="text-xs text-muted-foreground bg-background rounded p-2 border border-border/50 leading-relaxed">
                {reel.hookAnalysis}
              </p>
            </div>
          )}

          {/* Viral Points */}
          {reel.viralPoints && reel.viralPoints.length > 0 && (
            <div className="space-y-1">
              <p className="text-xs font-semibold flex items-center gap-1.5">
                <Zap className="h-3.5 w-3.5 text-yellow-500" /> Estratégia / Pontos Virais
              </p>
              <div className="flex flex-wrap gap-1">
                {reel.viralPoints.map((v, i) => (
                  <Badge key={i} variant="outline" className="text-[10px] bg-yellow-500/5 border-yellow-500/30">⚡ {v}</Badge>
                ))}
              </div>
            </div>
          )}

          {/* Psychological Triggers */}
          {reel.psychTriggers && reel.psychTriggers.length > 0 && (
            <div className="space-y-1">
              <p className="text-xs font-semibold flex items-center gap-1.5">
                <Brain className="h-3.5 w-3.5 text-purple-500" /> Gatilhos Psicológicos
              </p>
              <div className="flex flex-wrap gap-1">
                {reel.psychTriggers.map((t, i) => (
                  <Badge key={i} variant="outline" className="text-[10px] bg-purple-500/5 border-purple-500/30">🧠 {t}</Badge>
                ))}
              </div>
            </div>
          )}

          {/* Caption */}
          {reel.caption && (
            <div className="space-y-1">
              <p className="text-xs font-semibold">📝 Legenda</p>
              <p className="text-xs text-muted-foreground bg-background rounded p-2 border border-border/50 leading-relaxed whitespace-pre-line">
                {reel.caption.slice(0, 500)}{reel.caption.length > 500 ? "…" : ""}
              </p>
            </div>
          )}

          {reel.postDate && (
            <p className="text-[10px] text-muted-foreground">
              📅 Publicado em: {new Date(reel.postDate).toLocaleDateString("pt-BR")}
            </p>
          )}
        </div>
      )}
    </Card>
  )
}

function CompetitorReport({ comp, reels }: { comp: CompetitorProfile; reels: ReelData[] }) {
  const [expanded, setExpanded] = useState(false)

  const stats = useMemo(() => {
    if (reels.length === 0) return null

    const byType: Record<string, number> = {}
    reels.forEach(r => {
      const t = r.contentType === "carousel" ? "Carrossel" : r.contentType === "post" ? "Post" : "Reel"
      byType[t] = (byType[t] || 0) + 1
    })

    // Sort by viral score (views + likes + comments weighted)
    const topViral = [...reels].sort((a, b) => {
      const scoreA = (a.views || 0) + (a.likes || 0) * 3 + (a.comments || 0) * 5
      const scoreB = (b.views || 0) + (b.likes || 0) * 3 + (b.comments || 0) * 5
      return scoreB - scoreA
    }).slice(0, 5)

    const allTriggers: Record<string, number> = {}
    const allViralPoints: Record<string, number> = {}

    reels.forEach(r => {
      if (r.psychTriggers) r.psychTriggers.forEach(t => { allTriggers[t] = (allTriggers[t] || 0) + 1 })
      if (r.viralPoints) r.viralPoints.forEach(v => { allViralPoints[v] = (allViralPoints[v] || 0) + 1 })
    })

    const topTriggers = Object.entries(allTriggers).sort((a, b) => b[1] - a[1]).slice(0, 5)
    const topViralPoints = Object.entries(allViralPoints).sort((a, b) => b[1] - a[1]).slice(0, 5)

    const avgEng = reels.reduce((s, r) => s + r.engRate, 0) / reels.length
    const avgViews = reels.reduce((s, r) => s + r.views, 0) / reels.length
    const avgLikes = reels.reduce((s, r) => s + r.likes, 0) / reels.length
    const totalViews = reels.reduce((s, r) => s + r.views, 0)
    const totalLikes = reels.reduce((s, r) => s + r.likes, 0)
    const totalComments = reels.reduce((s, r) => s + r.comments, 0)

    return {
      total: reels.length, byType, topViral,
      topTriggers, topViralPoints,
      avgEng, avgViews, avgLikes, totalViews, totalLikes, totalComments,
    }
  }, [reels])

  return (
    <Card className="overflow-hidden">
      <CardContent className="p-0">
        {/* Header */}
        <button
          onClick={() => setExpanded(!expanded)}
          className="w-full flex items-center gap-3 p-4 hover:bg-muted/50 transition-colors text-left"
        >
          {comp.profilePicUrl ? (
            <img src={comp.profilePicUrl} alt="" className="h-10 w-10 rounded-full object-cover border-2 border-border shrink-0"
              onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = 'none' }} />
          ) : (
            <div className="h-10 w-10 rounded-full bg-muted flex items-center justify-center shrink-0">
              <Users className="h-4 w-4 text-muted-foreground" />
            </div>
          )}
          <div className="flex-1 min-w-0">
            <p className="font-semibold text-sm truncate">@{comp.name}</p>
            <div className="flex items-center gap-3 text-xs text-muted-foreground mt-0.5">
              <span>{formatNumber(comp.followersCount)} seguidores</span>
              <span>{formatNumber(comp.postsCount)} posts</span>
              <span>{reels.length} reels analisados</span>
            </div>
          </div>
          {stats && (
            <div className="flex items-center gap-2 shrink-0">
              <Badge variant="outline" className="text-xs gap-1">
                <TrendingUp className="h-3 w-3" /> {stats.avgEng.toFixed(1)}%
              </Badge>
            </div>
          )}
          {expanded ? <ChevronUp className="h-4 w-4 shrink-0 text-muted-foreground" /> : <ChevronDown className="h-4 w-4 shrink-0 text-muted-foreground" />}
        </button>

        {/* Expanded Report */}
        {expanded && stats && (
          <div className="border-t p-4 space-y-4">
            {/* Summary Stats */}
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
              <div className="rounded-lg bg-muted/50 p-3 text-center">
                <p className="text-lg font-bold">{stats.total}</p>
                <p className="text-[10px] text-muted-foreground uppercase">Total</p>
              </div>
              <div className="rounded-lg bg-muted/50 p-3 text-center">
                <p className="text-lg font-bold">{formatNumber(stats.totalViews)}</p>
                <p className="text-[10px] text-muted-foreground uppercase">👁️ Views</p>
              </div>
              <div className="rounded-lg bg-muted/50 p-3 text-center">
                <p className="text-lg font-bold">{formatNumber(stats.totalLikes)}</p>
                <p className="text-[10px] text-muted-foreground uppercase">❤️ Curtidas</p>
              </div>
              <div className="rounded-lg bg-muted/50 p-3 text-center">
                <p className="text-lg font-bold">{formatNumber(stats.totalComments)}</p>
                <p className="text-[10px] text-muted-foreground uppercase">💬 Comentários</p>
              </div>
              <div className="rounded-lg bg-muted/50 p-3 text-center">
                <p className="text-lg font-bold">{stats.avgEng.toFixed(1)}%</p>
                <p className="text-[10px] text-muted-foreground uppercase">📈 Eng. Médio</p>
              </div>
              <div className="rounded-lg bg-muted/50 p-3 text-center">
                <p className="text-lg font-bold">{formatNumber(Math.round(stats.avgViews))}</p>
                <p className="text-[10px] text-muted-foreground uppercase">Views Médio</p>
              </div>
            </div>

            {/* Top Viral Content */}
            <div className="space-y-2">
              <h4 className="text-sm font-semibold flex items-center gap-2">
                <Film className="h-4 w-4 text-primary" />
                🔥 Top Conteúdos Mais Virais
              </h4>
              <div className="space-y-2">
                {stats.topViral.map((reel, i) => (
                  <ViralContentCard key={i} reel={reel} rank={i + 1} />
                ))}
              </div>
            </div>

            {/* Patterns Summary */}
            {(stats.topTriggers.length > 0 || stats.topViralPoints.length > 0) && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {stats.topTriggers.length > 0 && (
                  <Card className="border-border/60">
                    <CardHeader className="p-3 pb-1">
                      <CardTitle className="text-xs font-semibold flex items-center gap-1.5">
                        <Brain className="h-3.5 w-3.5 text-purple-500" /> Gatilhos Mais Usados
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-3 pt-1 space-y-1">
                      {stats.topTriggers.map(([trigger, count], i) => (
                        <div key={i} className="flex items-center justify-between text-xs p-1.5 rounded bg-muted/30">
                          <span>🧠 {trigger}</span>
                          <Badge variant="outline" className="text-[10px] shrink-0">{count}x</Badge>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                )}
                {stats.topViralPoints.length > 0 && (
                  <Card className="border-border/60">
                    <CardHeader className="p-3 pb-1">
                      <CardTitle className="text-xs font-semibold flex items-center gap-1.5">
                        <Zap className="h-3.5 w-3.5 text-yellow-500" /> Padrões Vencedores
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-3 pt-1 space-y-1">
                      {stats.topViralPoints.map(([point, count], i) => (
                        <div key={i} className="flex items-center justify-between text-xs p-1.5 rounded bg-muted/30">
                          <span>⚡ {point}</span>
                          <Badge variant="outline" className="text-[10px] shrink-0">{count}x</Badge>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
          </div>
        )}

        {expanded && !stats && (
          <div className="border-t p-4 text-center text-sm text-muted-foreground">
            Nenhum reel analisado para este competidor.
          </div>
        )}
      </CardContent>
    </Card>
  )
}

export function CompetitorComparison({ myUsername, competitors, reelsData = [], onDeleteCompetitors }: CompetitorComparisonProps) {
  const [timePeriod, setTimePeriod] = useState<TimePeriod>("all")
  const [exporting, setExporting] = useState(false)
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set())
  const containerRef = useRef<HTMLDivElement>(null)

  const toggleSelect = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  const handleDeleteSelected = async () => {
    if (selectedIds.size === 0 || !onDeleteCompetitors) return
    onDeleteCompetitors(Array.from(selectedIds))
    setSelectedIds(new Set())
  }

  // Filter reels by time period
  const threshold = getDateThreshold(timePeriod)
  const filteredReels = threshold
    ? reelsData.filter(r => r.postDate && new Date(r.postDate) >= threshold)
    : reelsData

  // Group reels by competitor
  const reelsByComp = useMemo(() => {
    const map: Record<string, ReelData[]> = {}
    filteredReels.forEach(r => {
      const key = r.user.toLowerCase()
      if (!map[key]) map[key] = []
      map[key].push(r)
    })
    return map
  }, [filteredReels])

  const validComps = competitors.filter(c => c.followersCount && c.followersCount > 0)

  if (competitors.length === 0) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-12 text-muted-foreground">
          <p>Nenhum competidor com dados de perfil. Rode o pipeline para coletar.</p>
        </CardContent>
      </Card>
    )
  }

  const handleExportPDF = async () => {
    setExporting(true)
    try {
      const { default: jsPDF } = await import("jspdf")
      const { default: autoTable } = await import("jspdf-autotable")

      const doc = new jsPDF({ orientation: "landscape" })
      const pageWidth = doc.internal.pageSize.getWidth()

      doc.setFontSize(18)
      doc.text("Relatório de Análise de Competidores", pageWidth / 2, 20, { align: "center" })
      doc.setFontSize(10)
      doc.text(`Gerado em: ${new Date().toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit" })}`, pageWidth / 2, 28, { align: "center" })

      autoTable(doc, {
        startY: 38,
        head: [["Competidor", "Seguidores", "Posts", "Posts/Sem", "Reels Analisados", "Eng. Rate Médio"]],
        body: validComps.map(c => {
          const cReels = reelsByComp[c.name.toLowerCase()] || []
          const avgEng = cReels.length > 0 ? (cReels.reduce((s, r) => s + r.engRate, 0) / cReels.length).toFixed(1) + "%" : "—"
          return [
            `@${c.name}`, formatNumber(c.followersCount), formatNumber(c.postsCount),
            c.avgPostsPerWeek?.toString() || "—", cReels.length.toString(), avgEng,
          ]
        }),
        theme: "grid",
        headStyles: { fillColor: [59, 130, 246], fontSize: 9 },
        bodyStyles: { fontSize: 8 },
      })

      doc.save(`analise-competidores-${new Date().toISOString().slice(0, 10)}.pdf`)
      toast.success("PDF exportado!")
    } catch (e: any) {
      toast.error("Erro ao exportar PDF", { description: e.message })
    } finally {
      setExporting(false)
    }
  }

  return (
    <div className="space-y-4" ref={containerRef}>
      {/* Controls Bar */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-muted-foreground" />
          <Select value={timePeriod} onValueChange={(v) => setTimePeriod(v as TimePeriod)}>
            <SelectTrigger className="w-[180px] h-8 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os períodos</SelectItem>
              <SelectItem value="1w">Última semana</SelectItem>
              <SelectItem value="1m">Último mês</SelectItem>
              <SelectItem value="3m">Últimos 3 meses</SelectItem>
            </SelectContent>
          </Select>
          <Badge variant="secondary" className="text-xs">
            {filteredReels.length} reels · {validComps.length} competidores
          </Badge>
        </div>
        <div className="flex items-center gap-2">
          {selectedIds.size > 0 && (
            <Button variant="destructive" size="sm" className="gap-2" onClick={handleDeleteSelected}>
              <Trash2 className="h-4 w-4" />
              Excluir {selectedIds.size}
            </Button>
          )}
          <Button variant="outline" size="sm" className="gap-2" onClick={handleExportPDF} disabled={exporting}>
            <Download className="h-4 w-4" />
            {exporting ? "Exportando..." : "Exportar PDF"}
          </Button>
        </div>
      </div>

      {/* Ranking Comparativo */}
      {validComps.length >= 2 && filteredReels.length > 0 && (() => {
        const ranked = validComps.map(c => {
          const cReels = reelsByComp[c.name.toLowerCase()] || []
          const totalViews = cReels.reduce((s, r) => s + r.views, 0)
          const totalLikes = cReels.reduce((s, r) => s + r.likes, 0)
          const totalComments = cReels.reduce((s, r) => s + r.comments, 0)
          const avgEng = cReels.length > 0 ? cReels.reduce((s, r) => s + r.engRate, 0) / cReels.length : 0
          const viralScore = totalViews + totalLikes * 3 + totalComments * 5
          const bestReel = cReels.length > 0
            ? [...cReels].sort((a, b) => ((b.views || 0) + (b.likes || 0) * 3) - ((a.views || 0) + (a.likes || 0) * 3))[0]
            : null
          return { comp: c, totalViews, totalLikes, totalComments, avgEng, viralScore, reelCount: cReels.length, bestReel }
        }).sort((a, b) => b.viralScore - a.viralScore)

        const maxScore = ranked[0]?.viralScore || 1
        const podiumIcons = [
          <Crown key="1" className="h-5 w-5 text-yellow-500" />,
          <Medal key="2" className="h-5 w-5 text-zinc-400" />,
          <Medal key="3" className="h-5 w-5 text-amber-700" />,
        ]

        return (
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                <Trophy className="h-5 w-5 text-primary" />
                🏆 Ranking de Desempenho — {PERIOD_LABELS[timePeriod]}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {ranked.map((r, i) => (
                <div key={r.comp.id || r.comp.name} className={`flex items-center gap-3 rounded-lg border p-3 transition-colors ${i === 0 ? "bg-primary/5 border-primary/30" : "bg-muted/30 border-border/60"}`}>
                  <div className="flex items-center justify-center h-8 w-8 shrink-0">
                    {i < 3 ? podiumIcons[i] : <span className="text-sm font-bold text-muted-foreground">#{i + 1}</span>}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-sm truncate">@{r.comp.name}</span>
                      {i === 0 && <Badge className="text-[10px] h-4 bg-primary/10 text-primary border-primary/30">Melhor desempenho</Badge>}
                    </div>
                    <div className="flex items-center gap-3 mt-1 text-[11px] text-muted-foreground flex-wrap">
                      <span className="flex items-center gap-0.5"><Eye className="h-3 w-3" /> {formatNumber(r.totalViews)}</span>
                      <span className="flex items-center gap-0.5"><Heart className="h-3 w-3" /> {formatNumber(r.totalLikes)}</span>
                      <span className="flex items-center gap-0.5"><MessageCircle className="h-3 w-3" /> {formatNumber(r.totalComments)}</span>
                      <span className="flex items-center gap-0.5"><TrendingUp className="h-3 w-3" /> {r.avgEng.toFixed(1)}%</span>
                      <span>{r.reelCount} conteúdos</span>
                    </div>
                    {r.bestReel && (
                      <p className="text-[10px] text-muted-foreground mt-1 truncate">
                        🔥 Melhor: {r.bestReel.caption ? r.bestReel.caption.slice(0, 60) + "…" : "Sem legenda"} ({formatNumber(r.bestReel.views)} views)
                      </p>
                    )}
                  </div>
                  {/* Score bar */}
                  <div className="w-24 shrink-0 hidden sm:block">
                    <div className="h-2 rounded-full bg-muted overflow-hidden">
                      <div
                        className="h-full rounded-full bg-primary transition-all"
                        style={{ width: `${Math.max((r.viralScore / maxScore) * 100, 5)}%` }}
                      />
                    </div>
                    <p className="text-[9px] text-muted-foreground text-right mt-0.5">{formatNumber(r.viralScore)} pts</p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        )
      })()}

      {/* Competitor Reports */}
      <div className="space-y-3">
        {validComps.map(comp => (
          <div key={comp.id || comp.name} className="flex items-start gap-2">
            {comp.id && (
              <Checkbox
                checked={selectedIds.has(comp.id)}
                onCheckedChange={() => toggleSelect(comp.id!)}
                className="mt-5 shrink-0"
              />
            )}
            <div className="flex-1">
              <CompetitorReport
                comp={comp}
                reels={reelsByComp[comp.name.toLowerCase()] || []}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
