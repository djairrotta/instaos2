import { useMemo } from "react"
import ReactMarkdown from "react-markdown"

/**
 * Extracts base64 data-URI images from markdown, replaces them with placeholders,
 * then renders markdown text + images separately to avoid parser choking on huge base64 strings.
 */
interface MarkdownWithImagesProps {
  content: string
  className?: string
}

// Splits content into text segments and extracted images
function extractBase64Images(md: string) {
  const parts: Array<{ type: "text"; value: string } | { type: "image"; src: string; alt: string }> = []
  // Match ![alt](data:...) — greedy on the base64 portion up to the closing paren
  const regex = /!\[([^\]]*)\]\((data:[^)]+)\)/g
  let lastIndex = 0
  let match: RegExpExecArray | null

  while ((match = regex.exec(md)) !== null) {
    if (match.index > lastIndex) {
      parts.push({ type: "text", value: md.slice(lastIndex, match.index) })
    }
    parts.push({ type: "image", src: match[2], alt: match[1] })
    lastIndex = regex.lastIndex
  }
  if (lastIndex < md.length) {
    parts.push({ type: "text", value: md.slice(lastIndex) })
  }
  return parts
}

export function MarkdownWithImages({ content, className }: MarkdownWithImagesProps) {
  const parts = useMemo(() => extractBase64Images(content), [content])

  const hasBase64 = parts.some(p => p.type === "image")

  // If no base64 images, render normally with ReactMarkdown
  if (!hasBase64) {
    return (
      <div className={className}>
        <ReactMarkdown
          components={{
            img: ({ src, alt }) => (
              <div className="space-y-1 my-2">
                <img src={src} alt={alt || ""} className="rounded-lg max-w-full border" />
                {alt && <span className="text-xs text-muted-foreground block">{alt}</span>}
              </div>
            ),
            a: ({ href, children }) => (
              <a href={href} target="_blank" rel="noopener noreferrer" className="text-primary underline">
                {children}
              </a>
            ),
            p: ({ children, node }) => {
              const hasImage = node?.children?.some((c: any) => c.tagName === "img")
              if (hasImage) return <div className="text-sm">{children}</div>
              return <p className="text-sm">{children}</p>
            },
          }}
        >
          {content}
        </ReactMarkdown>
      </div>
    )
  }

  // Render segments: text via ReactMarkdown, images directly
  return (
    <div className={className}>
      {parts.map((part, i) => {
        if (part.type === "image") {
          return (
            <div key={i} className="space-y-1 my-3">
              <img src={part.src} alt={part.alt} className="rounded-lg max-w-full border" loading="lazy" />
              {part.alt && <span className="text-xs text-muted-foreground block">{part.alt}</span>}
            </div>
          )
        }
        // Text segment
        return (
          <ReactMarkdown
            key={i}
            components={{
              img: ({ src, alt }) => (
                <div className="space-y-1 my-2">
                  <img src={src} alt={alt || ""} className="rounded-lg max-w-full border" />
                  {alt && <span className="text-xs text-muted-foreground block">{alt}</span>}
                </div>
              ),
              a: ({ href, children }) => (
                <a href={href} target="_blank" rel="noopener noreferrer" className="text-primary underline">
                  {children}
                </a>
              ),
              p: ({ children, node }) => {
                const hasImg = node?.children?.some((c: any) => c.tagName === "img")
                if (hasImg) return <div className="text-sm">{children}</div>
                return <p className="text-sm">{children}</p>
              },
            }}
          >
            {part.value}
          </ReactMarkdown>
        )
      })}
    </div>
  )
}

/** Extract image sources (both URLs and data URIs) from markdown for ZIP download */
export function extractImageSources(md: string): string[] {
  const srcs: string[] = []
  const regex = /!\[.*?\]\(((?:https?:\/\/[^\s)]+|data:[^)]+))\)/g
  let match
  while ((match = regex.exec(md)) !== null) {
    srcs.push(match[1])
  }
  return srcs
}
