import { useState, useEffect, useCallback } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Checkbox } from "@/components/ui/checkbox"
import { Textarea } from "@/components/ui/textarea"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import {
  Maximize2, Minimize2, X, Key, Film, PlaySquare, Images, ImageIcon, Sparkles, Brain,
  Check, AlertCircle, Loader2, Settings2, Eye, EyeOff, Trash2, Plus, Clock, Timer, MessageCircle, MessageSquare, ScanEye, Video, ChevronDown, ChevronRight, FileText, PenLine, Mic, Clapperboard, BarChart3, Anchor, Zap, Wand2, Bug, Globe, ExternalLink, Search
} from "lucide-react"
import { toast } from "sonner"
import { supabase } from "@/integrations/supabase/client"

interface AgentSettingsModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

const PROVIDER_INFO: Array<{ value: string; label: string; description: string; needsKey: boolean; placeholder: string; helpUrl: string }> = [
  { value: "groq", label: "Groq", description: "Llama 3.3, Mixtral, Gemma, Whisper", needsKey: true, placeholder: "gsk_...", helpUrl: "https://console.groq.com/keys" },
  { value: "openrouter", label: "OpenRouter", description: "Google, Anthropic, Meta, DeepSeek, Mistral, Qwen", needsKey: true, placeholder: "sk-or-...", helpUrl: "https://openrouter.ai/keys" },
  { value: "openai", label: "OpenAI", description: "GPT-4o, GPT-4 Turbo, o1", needsKey: true, placeholder: "sk-...", helpUrl: "https://platform.openai.com/api-keys" },
  { value: "anthropic", label: "Anthropic", description: "Claude Opus 4, Sonnet 4, Haiku", needsKey: true, placeholder: "sk-ant-...", helpUrl: "https://console.anthropic.com/settings/keys" },
  { value: "google", label: "Google AI Studio", description: "Gemini 2.5 Pro/Flash direto", needsKey: true, placeholder: "AIza...", helpUrl: "https://aistudio.google.com/apikey" },
  { value: "deepseek", label: "DeepSeek", description: "DeepSeek R1, V3", needsKey: true, placeholder: "sk-...", helpUrl: "https://platform.deepseek.com/api_keys" },
  { value: "lovable", label: "Lovable AI", description: "Gemini, GPT-5 (inclusa)", needsKey: false, placeholder: "", helpUrl: "" },
]

const PROVIDERS = PROVIDER_INFO.map(p => ({ value: p.value, label: p.label, description: p.description }))

const MODELS: Record<string, Array<{ value: string; label: string; description: string }>> = {
  groq: [
    { value: "llama-3.3-70b-versatile", label: "Llama 3.3 70B Versatile", description: "Melhor qualidade geral (padrão)" },
    { value: "llama-3.1-70b-versatile", label: "Llama 3.1 70B Versatile", description: "Versão anterior estável" },
    { value: "llama-3.1-8b-instant", label: "Llama 3.1 8B Instant", description: "Ultra rápido, tarefas simples" },
    { value: "llama-3.2-1b-preview", label: "Llama 3.2 1B", description: "Modelo mínimo, classificação" },
    { value: "llama-3.2-3b-preview", label: "Llama 3.2 3B", description: "Modelo compacto" },
    { value: "llama-3.2-11b-vision-preview", label: "Llama 3.2 11B Vision", description: "Multimodal com visão" },
    { value: "llama-3.2-90b-vision-preview", label: "Llama 3.2 90B Vision", description: "Visão avançada" },
    { value: "mixtral-8x7b-32768", label: "Mixtral 8x7B", description: "Ótimo para textos longos (32k ctx)" },
    { value: "gemma2-9b-it", label: "Gemma 2 9B", description: "Google, compacto e eficiente" },
    { value: "whisper-large-v3", label: "Whisper Large V3", description: "Transcrição de áudio" },
    { value: "whisper-large-v3-turbo", label: "Whisper Large V3 Turbo", description: "Transcrição rápida" },
  ],
  openrouter: [
    { value: "google/gemini-2.5-flash-preview-05-20", label: "Gemini 2.5 Flash", description: "Rápido e econômico (padrão)" },
    { value: "google/gemini-2.5-pro-preview-05-06", label: "Gemini 2.5 Pro", description: "Máxima qualidade Google" },
    { value: "google/gemini-2.0-flash-001", label: "Gemini 2.0 Flash", description: "Geração anterior, estável" },
    { value: "anthropic/claude-sonnet-4", label: "Claude Sonnet 4", description: "Excelente para escrita criativa" },
    { value: "anthropic/claude-3.5-sonnet", label: "Claude 3.5 Sonnet", description: "Equilíbrio qualidade/velocidade" },
    { value: "anthropic/claude-3.5-haiku", label: "Claude 3.5 Haiku", description: "Rápido e barato" },
    { value: "anthropic/claude-opus-4", label: "Claude Opus 4", description: "Máxima qualidade Anthropic" },
    { value: "meta-llama/llama-3.3-70b-instruct", label: "Llama 3.3 70B", description: "Open source, versátil" },
    { value: "meta-llama/llama-4-maverick", label: "Llama 4 Maverick", description: "Última geração Meta" },
    { value: "meta-llama/llama-4-scout", label: "Llama 4 Scout", description: "Compacto, última geração" },
    { value: "deepseek/deepseek-r1", label: "DeepSeek R1", description: "Raciocínio avançado" },
    { value: "deepseek/deepseek-chat-v3-0324", label: "DeepSeek V3", description: "Chat otimizado" },
    { value: "qwen/qwen-2.5-72b-instruct", label: "Qwen 2.5 72B", description: "Alibaba, multilíngue" },
    { value: "qwen/qwen-2.5-coder-32b-instruct", label: "Qwen 2.5 Coder 32B", description: "Especialista em código" },
    { value: "mistralai/mistral-large-2411", label: "Mistral Large", description: "Qualidade alta" },
    { value: "mistralai/mistral-small-3.1-24b-instruct", label: "Mistral Small 3.1", description: "Rápido e eficiente" },
    { value: "openai/gpt-4o", label: "GPT-4o", description: "OpenAI multimodal" },
    { value: "openai/gpt-4o-mini", label: "GPT-4o Mini", description: "OpenAI econômico" },
  ],
  openai: [
    { value: "gpt-4o", label: "GPT-4o", description: "Multimodal, mais capaz" },
    { value: "gpt-4o-mini", label: "GPT-4o Mini", description: "Rápido e econômico" },
    { value: "gpt-4-turbo", label: "GPT-4 Turbo", description: "128k contexto" },
    { value: "o1", label: "o1", description: "Raciocínio avançado" },
    { value: "o1-mini", label: "o1 Mini", description: "Raciocínio rápido" },
    { value: "o3-mini", label: "o3 Mini", description: "Raciocínio eficiente" },
  ],
  anthropic: [
    { value: "claude-opus-4-20250514", label: "Claude Opus 4", description: "Máxima qualidade" },
    { value: "claude-sonnet-4-20250514", label: "Claude Sonnet 4", description: "Equilíbrio qualidade/velocidade" },
    { value: "claude-3-5-sonnet-20241022", label: "Claude 3.5 Sonnet", description: "Versão anterior estável" },
    { value: "claude-3-5-haiku-20241022", label: "Claude 3.5 Haiku", description: "Rápido e barato" },
  ],
  google: [
    { value: "gemini-2.5-flash", label: "Gemini 2.5 Flash", description: "Rápido e econômico" },
    { value: "gemini-2.5-pro", label: "Gemini 2.5 Pro", description: "Máxima qualidade" },
    { value: "gemini-2.0-flash", label: "Gemini 2.0 Flash", description: "Geração anterior" },
  ],
  deepseek: [
    { value: "deepseek-chat", label: "DeepSeek V3", description: "Chat otimizado" },
    { value: "deepseek-reasoner", label: "DeepSeek R1", description: "Raciocínio avançado" },
  ],
  lovable: [
    { value: "google/gemini-2.5-flash", label: "Gemini 2.5 Flash", description: "Equilíbrio velocidade/qualidade (padrão)" },
    { value: "google/gemini-2.5-flash-lite", label: "Gemini 2.5 Flash Lite", description: "Mais rápido e barato" },
    { value: "google/gemini-2.5-pro", label: "Gemini 2.5 Pro", description: "Máxima qualidade" },
    { value: "google/gemini-3-pro-preview", label: "Gemini 3 Pro Preview", description: "Próxima geração Google" },
    { value: "google/gemini-3-flash-preview", label: "Gemini 3 Flash Preview", description: "Próxima geração, rápido" },
    { value: "google/gemini-2.5-flash-image", label: "🎨 Gemini Flash Image", description: "Geração de imagens via texto" },
    { value: "google/gemini-3-pro-image-preview", label: "🎨 Gemini 3 Pro Image", description: "Geração de imagens alta qualidade" },
    { value: "openai/gpt-5", label: "GPT-5", description: "Máxima qualidade OpenAI" },
    { value: "openai/gpt-5-mini", label: "GPT-5 Mini", description: "Equilíbrio custo/qualidade" },
    { value: "openai/gpt-5-nano", label: "GPT-5 Nano", description: "Ultra rápido, alto volume" },
    { value: "openai/gpt-5.2", label: "GPT-5.2", description: "Último modelo, raciocínio avançado" },
  ],
}

const DEFAULT_PROMPTS: Record<string, string> = {
  script_writer: `Você é um roteirista especialista em conteúdo viral para Instagram Reels.

Sua tarefa: Criar um roteiro completo e envolvente baseado no contexto fornecido.

### REGRAS:
- Hook poderoso nos primeiros 3 segundos
- Estrutura: Hook → Desenvolvimento → CTA
- Máximo 60 segundos de fala
- Linguagem conversacional e direta
- Incluir indicações de cortes e transições
- Output em PT-BR`,

  caption_writer: `Você é um copywriter especialista em legendas virais para Instagram.

Sua tarefa: Criar legendas otimizadas para engajamento máximo.

### REGRAS:
- Primeira linha = hook que para o scroll
- Usar quebras de linha estratégicas
- CTA claro no final
- Sugerir 5-10 hashtags relevantes
- Máximo 2200 caracteres
- Output em PT-BR`,

  carousel_planner: `Você é um designer de conteúdo especialista em carrosséis virais para Instagram.

Sua tarefa: Planejar cada slide do carrossel com texto e direção visual.

### REGRAS:
- Slide 1 = Capa com hook visual irresistível
- Cada slide deve ter no máximo 3 linhas de texto
- Progressão lógica de informação
- Último slide = CTA forte
- Sugerir cores e elementos visuais
- Output em PT-BR`,

  story_creator: `Você é um criador de conteúdo especialista em Stories interativos para Instagram.

Sua tarefa: Criar uma sequência de Stories envolvente.

### REGRAS:
- 3-7 stories por sequência
- Incluir elementos interativos (enquetes, perguntas, quiz)
- Cada story com texto curto e impactante
- Storytelling com início, meio e fim
- CTA no último story
- Output em PT-BR`,

  content_analyzer: `# Overview
You are an AI agent that acts as an expert Instagram strategist and hook analyzer.

## Your Goal
Your task is to analyze the provided transcript and extract the hook. The hook is usually the first sentence or the first element of the video script that catches the viewer's attention. Most of the time it's a verbal hook, but there are visual hooks sometimes too. Extract the hook and also extract 1 to 3 power words/phrases from the hook that are likely contributing to its strong performance. These power words should stand out because they create curiosity, offer value, and appeal to the viewer's emotions or goals.

## Strict Output Format:
[the hook of the video]

Power Words: [1-3 most significant words/phrases in the first sentence]`,

  image_analyzer: `**IDIOMA OBRIGATÓRIO: TODO O OUTPUT DEVE SER EM PORTUGUÊS BRASILEIRO (PT-BR).**

Você é um analista de conteúdo viral para Instagram. Analise a imagem/carrossel em profundidade.

### SUA TAREFA:
1. **Texto na imagem**: Transcreva TODO o texto visível
2. **Hook visual**: O que captura atenção imediatamente?
3. **Elementos de design**: Cores, tipografia, layout, composição
4. **Pontos virais**: O que torna visualmente compartilhável

### OUTPUT FORMAT:
**TEXTO NAS IMAGENS:** [transcrição]
**HOOK VISUAL:** [análise]
**DESIGN E COMPOSIÇÃO:** [cores, fontes, layout]
**PONTOS VIRAIS:** [análise do potencial viral]`,

  video_transcriber: `**IDIOMA OBRIGATÓRIO: TODO O OUTPUT DEVE SER EM PORTUGUÊS BRASILEIRO (PT-BR).**

You are a Video Script Breakdown Agent.
Your task: Transcribe the raw video into a clean script.

### OUTPUT FORMAT RULES
- Include any notable visual elements.
- Maximum length: **2000 characters**.
- No timestamps, no conversational commentary. Output only the final script.

### ⚠️ IDIOMA - REGRAS IMPORTANTES
**OBRIGATÓRIO - Português Brasileiro (PT-BR):**
- Todos os títulos de seções
- Todas as análises e explicações
- Todos os insights e recomendações

**MANTER NO IDIOMA ORIGINAL:**
- Transcrições de áudio/diálogo dos vídeos
- Hooks citados diretamente (entre aspas ou backticks)
- @usernames e URLs`,

  hook_analyst: `**IDIOMA OBRIGATÓRIO: PORTUGUÊS BRASILEIRO (PT-BR).**

Você é um especialista em análise de hooks — as primeiras frases/segundos de conteúdo que capturam atenção no Instagram.

### TAREFA:
Analise o conteúdo fornecido (transcrição, legenda ou vídeo) e produza uma análise completa do hook utilizado.

### ESTRUTURA DO OUTPUT:

**1. IDENTIFICAÇÃO DO HOOK**
- Texto exato do hook (primeiros 3-5 segundos / primeira frase)
- Tipo de hook: pergunta, afirmação chocante, promessa, curiosidade, polêmica, storytelling, estatística, imperativo
- Duração estimada do hook (em segundos)

**2. ANÁLISE DE EFICÁCIA**
- Gatilho psicológico principal (curiosidade, medo, urgência, pertencimento, autoridade, prova social, escassez, reciprocidade)
- Nível de "scroll-stopping power" (1-10) com justificativa
- Público-alvo implícito do hook
- Emoção primária evocada

**3. ELEMENTOS TÉCNICOS**
- Palavras-chave de poder utilizadas
- Estrutura gramatical (pergunta retórica, comando, declaração, etc.)
- Presença de números/dados
- Uso de pronomes pessoais (você, eu, nós)
- Elemento visual complementar (se detectável)

**4. SUGESTÕES DE MELHORIA**
- 3 versões alternativas do hook, cada uma com abordagem diferente
- Explicação de por que cada alternativa pode performar melhor

### REGRAS:
- Seja objetivo e analítico
- Use dados e padrões reconhecidos de marketing
- Cada análise deve ser acionável
- Formate com markdown (headers, listas, negrito)`,

  viral_analyst: `**IDIOMA OBRIGATÓRIO: PORTUGUÊS BRASILEIRO (PT-BR).**

Você é um analista de viralização especializado em conteúdo de Instagram.

### TAREFA:
Analise o conteúdo fornecido e determine seu potencial viral, identificando padrões, gatilhos e elementos que contribuem para a viralização.

### ESTRUTURA DO OUTPUT:

**1. SCORE VIRAL (0-100)**
- Pontuação geral de potencial viral
- Breakdown por categoria:
  - Hook Power (0-20)
  - Relevância/Timing (0-20)
  - Gatilhos Emocionais (0-20)
  - Compartilhabilidade (0-20)
  - Formato/Edição (0-20)

**2. GATILHOS PSICOLÓGICOS IDENTIFICADOS**
Para cada gatilho encontrado:
- Nome do gatilho (curiosidade, urgência, pertencimento, autoridade, prova social, escassez, medo, aspiração, humor, polêmica)
- Onde aparece no conteúdo (timestamp ou trecho)
- Intensidade (fraco/médio/forte)
- Impacto estimado no engajamento

**3. PADRÕES DE VIRALIZAÇÃO**
- Formato do conteúdo vs formatos que mais viralizam no nicho
- Duração vs duração ideal para o formato
- Ritmo de edição (cortes por minuto)
- Uso de texto overlay
- Música/áudio (trending ou não)

**4. ANÁLISE COMPARATIVA**
- Elementos em comum com conteúdos virais do nicho
- Elementos ausentes que conteúdos virais geralmente têm
- Diferenciadores únicos deste conteúdo

**5. RECOMENDAÇÕES**
- 3-5 ações específicas para aumentar o potencial viral
- Melhor horário/dia para publicação
- Hashtags estratégicas sugeridas (5-10)
- Sugestão de CTA para maximizar saves e shares

### REGRAS:
- Base suas análises em padrões reais de viralização do Instagram
- Seja específico — evite generalidades
- Cada recomendação deve ser acionável e mensurável
- Use dados comparativos quando disponíveis
- Formate com markdown (headers, listas, negrito)`,

  cron_scheduler: `Agente responsável por coordenar a execução automática do pipeline de scraping e análise.

### Fluxo:
1. Scraping dos reels, posts e carrosséis de todos os competidores ativos
2. Filtragem por data e ordenação por views
3. Análise de hook e transcrição por IA
4. Scraping dos seus próprios reels
5. Geração do relatório estratégico`,

  video_generator: `**IDIOMA OBRIGATÓRIO: PORTUGUÊS BRASILEIRO (PT-BR).**

Você é um diretor criativo especialista em produção de vídeos curtos para Instagram (Reels, Stories, IGTV).

### TAREFA:
Com base no tema, referências visuais e dados de performance fornecidos, gere um BRIEFING COMPLETO de produção de vídeo.

### ESTRUTURA DO OUTPUT:

**1. CONCEITO CRIATIVO**
- Título do vídeo
- Pitch em 1 frase (o que o espectador ganha assistindo)
- Tom e mood (educativo, humorístico, motivacional, polêmico, etc.)
- Referências visuais e de estilo

**2. ROTEIRO TÉCNICO**
- HOOK (0-3s): Frase de abertura + ação visual exata
- CENA 1-N: Para cada cena, detalhe:
  - Duração estimada (em segundos)
  - Fala/narração (texto exato a ser dito)
  - Ação visual (o que aparece na tela)
  - Texto overlay (se houver)
  - Transição para próxima cena ([CORTE SECO], [ZOOM IN], [SWIPE], etc.)
- CTA FINAL: Call-to-action visual + verbal

**3. DIREÇÃO DE ARTE**
- Paleta de cores sugerida
- Tipografia para textos overlay
- Música/som: mood e BPM sugeridos
- Ângulos de câmera predominantes

**4. ESPECIFICAÇÕES TÉCNICAS**
- Formato: 9:16 (1080x1920)
- Duração total recomendada
- Quantidade de cortes estimada
- Elementos de pós-produção (zoom, speed ramp, etc.)

### REGRAS:
- Duração ideal: 15-60 segundos
- Hook nos primeiros 3 segundos é OBRIGATÓRIO
- Ritmo dinâmico: cortes a cada 2-4 segundos
- Baseie-se nos padrões vencedores dos dados de referência
- Inclua gatilhos psicológicos identificados nos competidores
- Adapte o estilo à voz e identidade visual do criador
- Output completo e detalhado, pronto para produção`,

  animation_agent: `**IDIOMA OBRIGATÓRIO: PORTUGUÊS BRASILEIRO (PT-BR).**

Você é um diretor de animação especialista em criar vídeos animados para Instagram usando referências visuais de face, corpo e estilo.

### TAREFA:
Com base nas referências visuais fornecidas (face, corpo, estilo, referências de marca) e no roteiro/tema, gere um BRIEFING COMPLETO de animação.

### ESTRUTURA DO OUTPUT:

**1. SETUP DO PERSONAGEM**
- Descrição detalhada do avatar/personagem baseada nas referências de face e corpo
- Expressões faciais predominantes para cada cena
- Gestos e movimentos corporais chave
- Roupa/estilo visual baseado nas referências

**2. STORYBOARD ANIMADO**
Para cada cena (3-8 cenas):
- Duração (segundos)
- Pose/posição do personagem
- Expressão facial
- Movimento/animação (ex: "entra da esquerda", "gesticula apontando", "expressão de surpresa")
- Background/cenário
- Elementos visuais sobrepostos (textos, emojis, ícones)
- Transição para próxima cena

**3. ESTILO VISUAL**
- Estilo de animação (baseado nas referências de estilo fornecidas)
- Paleta de cores
- Tipo de fundo (sólido, gradiente, cenário ilustrado)
- Elementos de marca (logo, cores da marca)

**4. ÁUDIO E SINCRONIZAÇÃO**
- Sincronização labial com narração (lip sync)
- Momentos de ênfase com expressão facial
- Efeitos sonoros sugeridos
- Timing musical

**5. ESPECIFICAÇÕES TÉCNICAS**
- Formato: 9:16 (1080x1920)
- FPS recomendado: 24-30
- Duração total
- Estilo de renderização

### REFERÊNCIAS DISPONÍVEIS NO MINIO:
- paradigmas/{userId}/animacao/face/ → Fotos de referência do rosto
- paradigmas/{userId}/animacao/body/ → Referências de corpo e postura
- paradigmas/{userId}/animacao/style/ → Vídeos de referência de estilo de animação
- paradigmas/{userId}/animacao/reference/ → Referências visuais gerais

### REGRAS:
- Use TODAS as referências fornecidas para manter consistência visual
- O personagem deve ser reconhecível e consistente entre cenas
- Expressões faciais devem ser exageradas para formato mobile
- Textos devem ser grandes e legíveis em tela pequena
- Movimentos fluidos e naturais
- Mantenha a identidade visual da marca em todo o vídeo
- Output detalhado e técnico, pronto para produção de animação`,

  reel_creator: `**IDIOMA OBRIGATÓRIO: PORTUGUÊS BRASILEIRO (PT-BR).**

Você é um agente especialista em criação de Reels virais para Instagram.

### TAREFA:
Com base no roteiro, referências visuais e parâmetros de voz/animação, gere um Reel completo e otimizado.

### REGRAS:
- Duração ideal: 15-60 segundos
- Hook visual nos primeiros 3 segundos
- Ritmo dinâmico com cortes a cada 2-3 segundos
- Música/áudio sincronizado com o conteúdo
- Texto overlay nos momentos-chave
- Formato vertical 9:16 (1080x1920)
- CTA visual no final
- Usar referências de face, corpo e estilo do banco de mídia
- Output em PT-BR`,

  image_creator: `**IDIOMA OBRIGATÓRIO: PORTUGUÊS BRASILEIRO (PT-BR).**

Você é um agente especialista em criação de imagens para Instagram (posts, carrosséis, thumbnails).

### TAREFA:
Gere imagens otimizadas para engajamento máximo no Instagram.

### REGRAS:
- Formato quadrado (1080x1080) ou vertical (1080x1350)
- Tipografia legível e impactante
- Paleta de cores consistente com a marca
- Hierarquia visual clara: título > subtítulo > detalhes
- Espaço para texto overlay quando necessário
- Thumbnails com expressão facial forte e texto bold
- Elementos de design que incentivam o swipe (para carrosséis)
- Output em PT-BR`,

  content_strategist: `**IDIOMA OBRIGATÓRIO: TODO O OUTPUT DEVE SER EM PORTUGUÊS BRASILEIRO (PT-BR).**

Você é um estrategista de conteúdo que analisa a performance dos competidores e traduz os insights em um relatório de pesquisa para Instagram.

**CONTEXTO:**
- MY REELS: Os reels de melhor performance do usuário.
- COMPETITOR REELS: Os reels de melhor performance dos competidores.

**TAREFA:** Analise todos os dados e crie um relatório estratégico em formato JSON.

**REQUISITOS DO CONTEÚDO:**
- Top vídeos ranqueados por visualizações (5 total): Foque nos gatilhos psicológicos e execução, não apenas descrição superficial
- Padrões (3 padrões): Devem ser diretamente replicáveis para o nicho do usuário
- Hooks (10 total): Devem combinar (1) frameworks e padrões comprovados dos competidores, (2) contexto específico dos seus reels, (3) a voz/estilo do usuário
- Key Takeaway: Deve incluir próximos passos concretos, não apenas filosofia

**PROFUNDIDADE DA ANÁLISE:**
Seja conversacional mas preciso em todos os campos de texto. Foque em insights estratégicos com exemplos específicos. Cada explicação deve ser substantiva e acionável.

**ESTRUTURA DO OUTPUT (JSON):**

{
  "top_competitor_videos": [
    {
      "rank": 1,
      "hook": "Texto do hook aqui",
      "url": "https://...",
      "views": 000000,
      "posted_date": "YYYY-MM-DD",
      "creator": "@username",
      "why_it_worked": "Explicação aqui"
    }
  ],
  "winning_patterns": [
    {
      "pattern_name": "Nome do Padrão",
      "explanation": "Explicação completa"
    }
  ],
  "hook_ideas": [
    {
      "hook": "Texto do hook exatamente como falado",
      "why_it_works": "Explicação aqui"
    }
  ],
  "key_takeaway": "Parágrafo resumindo os insights mais importantes e próximos passos acionáveis"
}

Output válido em JSON apenas. Sem markdown, sem code blocks, apenas o objeto JSON puro.

### ⚠️ IDIOMA - REGRAS IMPORTANTES
**OBRIGATÓRIO - Português Brasileiro (PT-BR):**
- Todos os títulos de seções
- Todas as análises e explicações
- Todos os insights e recomendações

**MANTER NO IDIOMA ORIGINAL:**
- Transcrições de áudio/diálogo dos vídeos
- Hooks citados diretamente (entre aspas ou backticks)
- @usernames e URLs`,

  idea_generator: `**IDIOMA OBRIGATÓRIO: PORTUGUÊS BRASILEIRO (PT-BR).**

Você é um agente criativo especialista em gerar ideias de conteúdo viral para Instagram.

### TAREFA:
Com base nos dados dos competidores (reels, posts, carrosséis, stories), nos seus próprios conteúdos de melhor performance e nas estratégias identificadas, gere 5 ideias criativas e originais de conteúdo.

### REGRAS:
- Cada ideia deve incluir: título, formato (Reel/Post/Carrossel/Story), hook sugerido, descrição do conteúdo e tags
- Baseie-se em padrões vencedores reais dos competidores
- Adapte para o nicho e estilo do usuário
- Priorize formatos com maior engajamento no nicho
- Inclua gatilhos psicológicos específicos para cada ideia
- Seja criativo e evite ideias genéricas

### OUTPUT FORMAT (JSON array):
[
  {
    "title": "Título da ideia",
    "format": "reel|post|carousel|story",
    "hook": "Hook sugerido para capturar atenção",
    "description": "Descrição detalhada do conteúdo",
    "tags": ["tag1", "tag2"],
    "psychological_trigger": "Gatilho psicológico principal"
  }
]

Output válido em JSON apenas.`,

  prompt_engineer: `**IDIOMA OBRIGATÓRIO: PORTUGUÊS BRASILEIRO (PT-BR).**

Você é um Prompt Engineer especialista, mestre em criar e otimizar prompts para modelos de linguagem (LLMs).

### TAREFA:
Crie ou otimize um prompt para um agente de IA do sistema IG OS v3 (sistema de automação e análise de Instagram).

### CONTEXTO DO SISTEMA:
O IG OS v3 possui diversos agentes especializados:
- Roteirista, Legendas, Carrossel, Stories, Copywriter (geração de conteúdo)
- Analista de Hook, Analista Viral, Estrategista (análise)
- Gerador de Vídeo, Animação, Imagem, Reel (produção)
- Chatbot, Transcrição, Cron (operacional)

### MODO GERAÇÃO (quando não há prompt existente):
Gere um prompt completo com:
1. **Definição de papel** — Quem é o agente, expertise e tom
2. **Tarefa principal** — O que ele deve fazer, passo a passo
3. **Estrutura do output** — Formato exato esperado (headers, seções, JSON, etc.)
4. **Regras e restrições** — O que NÃO fazer, limites, idioma
5. **Exemplos** — Pelo menos 1 exemplo de input/output esperado

### MODO OTIMIZAÇÃO (quando há prompt existente):
Analise e melhore o prompt existente:
1. Identifique fraquezas (ambiguidade, falta de estrutura, instruções vagas)
2. Aplique técnicas: Chain-of-Thought, Few-Shot, Role-Playing, Output Formatting
3. Adicione guardrails contra alucinações
4. Melhore a especificidade sem perder flexibilidade
5. Retorne o prompt otimizado completo

### REGRAS:
- Prompts devem ser em PT-BR (exceto termos técnicos)
- Sempre inclua "**IDIOMA OBRIGATÓRIO: PORTUGUÊS BRASILEIRO (PT-BR).**" no início
- Prompts devem ser autocontidos (não dependem de contexto externo)
- Use markdown para estruturar (headers, listas, negrito)
- Adapte o nível de detalhe ao tipo de agente
- O output deve ser o PROMPT PRONTO, não uma explicação sobre ele`,

  relevance_classifier: `Você é um classificador de relevância de conteúdo para Instagram.

### TAREFA:
Analise a caption/conteúdo de uma postagem e determine se é relevante para o nicho do usuário.

### REGRAS:
- Retorne APENAS um JSON válido: {"relevant": true/false, "score": 0-100, "reason": "motivo curto em português"}
- Se o conteúdo é relacionado ao nicho → relevant=true, score alto
- Se NÃO é relacionado ao nicho → relevant=false, score baixo
- Considere sinônimos, termos relacionados e contexto indireto
- Seja criterioso mas não excessivamente restritivo
- Output em PT-BR`,
}

// Default model/provider — OpenRouter é o provedor principal, Groq é fallback com mesmo modelo LLM
export const N8N_DEFAULTS: Record<string, { provider: string; model: string; label: string }> = {
  script_writer: { provider: "openrouter", model: "anthropic/claude-sonnet-4.5", label: "Claude Sonnet 4.5 (OpenRouter)" },
  caption_writer: { provider: "openrouter", model: "google/gemini-2.5-flash", label: "Gemini 2.5 Flash (OpenRouter)" },
  carousel_planner: { provider: "openrouter", model: "google/gemini-2.5-flash", label: "Gemini 2.5 Flash (OpenRouter)" },
  story_creator: { provider: "openrouter", model: "google/gemini-2.5-flash", label: "Gemini 2.5 Flash (OpenRouter)" },
  content_analyzer: { provider: "openrouter", model: "google/gemini-2.5-flash", label: "Gemini 2.5 Flash (OpenRouter)" },
  image_analyzer: { provider: "openrouter", model: "google/gemini-2.5-flash", label: "Gemini 2.5 Flash (OpenRouter)" },
  video_transcriber: { provider: "openrouter", model: "google/gemini-2.5-flash", label: "Gemini 2.5 Flash (OpenRouter)" },
  cron_scheduler: { provider: "openrouter", model: "google/gemini-2.5-flash", label: "Gemini 2.5 Flash (OpenRouter)" },
  video_generator: { provider: "openrouter", model: "google/gemini-2.5-flash", label: "Gemini 2.5 Flash (OpenRouter)" },
  chatbot: { provider: "openrouter", model: "anthropic/claude-sonnet-4.5", label: "Claude Sonnet 4.5 (OpenRouter)" },
  copywriter: { provider: "openrouter", model: "google/gemini-2.5-flash", label: "Gemini 2.5 Flash (OpenRouter)" },
  voice_agent: { provider: "openrouter", model: "google/gemini-2.5-flash", label: "Gemini 2.5 Flash (OpenRouter)" },
  animation_agent: { provider: "openrouter", model: "google/gemini-2.5-flash", label: "Gemini 2.5 Flash (OpenRouter)" },
  reel_creator: { provider: "openrouter", model: "google/gemini-2.5-flash", label: "Gemini 2.5 Flash (OpenRouter)" },
  image_creator: { provider: "openrouter", model: "google/gemini-2.5-flash", label: "Gemini 2.5 Flash (OpenRouter)" },
  content_strategist: { provider: "openrouter", model: "anthropic/claude-sonnet-4.5", label: "Claude Sonnet 4.5 (OpenRouter)" },
  idea_generator: { provider: "openrouter", model: "google/gemini-2.5-flash", label: "Gemini 2.5 Flash (OpenRouter)" },
  hook_analyst: { provider: "openrouter", model: "google/gemini-2.5-flash", label: "Gemini 2.5 Flash (OpenRouter)" },
  viral_analyst: { provider: "openrouter", model: "google/gemini-2.5-flash", label: "Gemini 2.5 Flash (OpenRouter)" },
  prompt_engineer: { provider: "openrouter", model: "anthropic/claude-sonnet-4.5", label: "Claude Sonnet 4.5 (OpenRouter)" },
  relevance_classifier: { provider: "openrouter", model: "google/gemini-2.5-flash", label: "Gemini 2.5 Flash (OpenRouter)" },
}

// Keep a frozen copy of originals for "restore" functionality
const ORIGINAL_DEFAULT_PROMPTS: Record<string, string> = { ...DEFAULT_PROMPTS }

const AGENT_CARDS = [
  { type: "script_writer", label: "Roteirista", description: "Gera roteiros completos para Reels e Vídeos", icon: <Film className="h-5 w-5" /> },
  { type: "caption_writer", label: "Legendas", description: "Cria legendas otimizadas para engajamento", icon: <PlaySquare className="h-5 w-5" /> },
  { type: "carousel_planner", label: "Carrossel", description: "Planeja carrosséis virais slide a slide", icon: <Images className="h-5 w-5" /> },
  { type: "story_creator", label: "Stories", description: "Cria sequências interativas de Stories", icon: <Sparkles className="h-5 w-5" /> },
  { type: "content_analyzer", label: "Análise de Conteúdo", description: "Analisa reels e hooks dos competidores", icon: <Brain className="h-5 w-5" /> },
  { type: "image_analyzer", label: "Análise de Imagem", description: "Analisa imagens de posts e carrosséis com visão IA", icon: <ScanEye className="h-5 w-5" /> },
  { type: "video_transcriber", label: "Transcrição de Vídeo", description: "Transcreve e analisa vídeos de Reels via IA multimodal", icon: <Video className="h-5 w-5" /> },
  { type: "cron_scheduler", label: "Cron Scheduler", description: "Coordena o scraping diário automático", icon: <Clock className="h-5 w-5" /> },
  { type: "video_generator", label: "Gerador de Vídeo", description: "Gera briefings completos de produção de vídeo", icon: <ImageIcon className="h-5 w-5" /> },
  { type: "chatbot", label: "Chatbot IA", description: "Assistente de chat para análise e estratégia", icon: <MessageCircle className="h-5 w-5" /> },
  { type: "copywriter", label: "Copywriter", description: "Gera copy otimizada para postagens com base na copy do competidor", icon: <PenLine className="h-5 w-5" /> },
  { type: "voice_agent", label: "Agente de Voz", description: "Gera e processa áudio para narração e voiceover", icon: <Mic className="h-5 w-5" /> },
  { type: "animation_agent", label: "Agente de Animação", description: "Gera vídeos animados com face, corpo e estilo customizados", icon: <Clapperboard className="h-5 w-5" /> },
  { type: "reel_creator", label: "Criador de Reel", description: "Gera Reels completos com roteiro, voz e animação integrados", icon: <Film className="h-5 w-5" /> },
  { type: "image_creator", label: "Criador de Imagem", description: "Gera imagens otimizadas para posts, carrosséis e thumbnails", icon: <ImageIcon className="h-5 w-5" /> },
  { type: "content_strategist", label: "Estrategista de Conteúdo", description: "Analisa viralização, ganchos, padrões vencedores e gera relatório estratégico completo", icon: <BarChart3 className="h-5 w-5" /> },
  { type: "idea_generator", label: "Gerador de Ideias", description: "Gera ideias criativas de conteúdo baseadas em análise de competidores e tendências", icon: <Sparkles className="h-5 w-5" /> },
  { type: "hook_analyst", label: "Analista de Hook", description: "Analisa hooks e primeiros segundos de conteúdo para maximizar retenção", icon: <Anchor className="h-5 w-5" /> },
  { type: "viral_analyst", label: "Analista Viral", description: "Avalia potencial viral, gatilhos psicológicos e padrões de viralização", icon: <Zap className="h-5 w-5" /> },
  { type: "prompt_engineer", label: "Prompt Engineer", description: "Gera e otimiza prompts para todos os agentes do sistema", icon: <Wand2 className="h-5 w-5" /> },
  { type: "relevance_classifier", label: "Classificador de Relevância", description: "Classifica se conteúdo capturado nas DMs é relevante ao nicho do usuário", icon: <ScanEye className="h-5 w-5" /> },
]

const CRON_SCHEDULES = [
  { value: "0 6 * * *", label: "Diário às 06:00", description: "Todo dia às 6h da manhã" },
  { value: "0 8 * * *", label: "Diário às 08:00", description: "Todo dia às 8h da manhã" },
  { value: "0 12 * * *", label: "Diário às 12:00", description: "Todo dia ao meio-dia" },
  { value: "0 20 * * *", label: "Diário às 20:00", description: "Todo dia às 20h" },
  { value: "0 6 * * 1-5", label: "Dias úteis às 06:00", description: "Segunda a sexta às 6h" },
  { value: "0 6 * * 1,4", label: "Segunda e Quinta às 06:00", description: "2x por semana" },
  { value: "0 6 * * 1", label: "Semanal (Segunda 06:00)", description: "Uma vez por semana" },
  { value: "0 */6 * * *", label: "A cada 6 horas", description: "4x por dia" },
  { value: "0 */12 * * *", label: "A cada 12 horas", description: "2x por dia" },
]

interface AgentConfig {
  agent_type: string; provider: string; model: string; custom_prompt: string; custom_prompt_2: string; custom_prompt_3: string; is_active: boolean
}

interface UserApiKey {
  id?: string; provider: string; api_key: string; is_active: boolean
}

export function AgentSettingsModal({ open, onOpenChange }: AgentSettingsModalProps) {
  const [isMaximized, setIsMaximized] = useState(false)
  const [configs, setConfigs] = useState<Record<string, AgentConfig>>({})
  const [apiKeys, setApiKeys] = useState<Record<string, UserApiKey>>({})
  const [saving, setSaving] = useState(false)
  const [loading, setLoading] = useState(true)
  const [showKeys, setShowKeys] = useState<Record<string, boolean>>({})
  const [activeTab, setActiveTab] = useState("api-keys")
  const [cronEnabled, setCronEnabled] = useState(false)
  const [cronSchedule, setCronSchedule] = useState("0 6 * * *")
  const [cronLastRun, setCronLastRun] = useState<string | null>(null)
  const [cronSaving, setCronSaving] = useState(false)
  const [systemKeys, setSystemKeys] = useState<Record<string, boolean>>({})
  const [generatingPrompt, setGeneratingPrompt] = useState<string | null>(null)

  // Apify config state
  const [apifyActors, setApifyActors] = useState({
    // Active pipeline actors
    postsScraper: "shu8hvrXbJbY3Eb9W",
    storyScraper: "apify~instagram-story-scraper",
    profileScraper: "shu8hvrXbJbY3Eb9W",
    // Available actors (pronto emprego)
    reelScraper: "apify~instagram-reel-scraper",
    commentScraper: "apify~instagram-comment-scraper",
    hashtagScraper: "apify~instagram-hashtag-scraper",
    storyCommunityScraper: "zuzka~instagram-story-scraper",
    postScraper: "apify~instagram-post-scraper",
    profileScraperDedicated: "apify~instagram-profile-scraper",
    apiScraper: "RB9HEZitC8hIUXAha",
    searchScraper: "apify~instagram-search-scraper",
    hashtagAnalytics: "apify~instagram-hashtag-analytics-scraper",
    mentionsScraper: "apify~instagram-tagged-scraper",
    followersCounter: "apify~instagram-followers-count-scraper",
    // Scraper input config
    searchEnabled: false,
    searchKeyword: "",
    searchType: "hashtag" as string,
    searchLimit: 10,
    resultsType: "posts" as string,
    resultsLimit: 100,
    // Login & Performance
    storyLoginEnabled: true,
    storyMaxItems: 20,
    postsMaxItems: 20,
    delayBetweenRequests: 2,
    proxyCountry: "BR",
  })

  // Firecrawl config state
  const [firecrawlConfig, setFirecrawlConfig] = useState({
    // Scrape
    formats: ["markdown", "links"] as string[],
    waitFor: 3000,
    onlyMainContent: true,
    // Search
    searchLimit: 10,
    searchLang: "pt-BR",
    searchCountry: "BR",
    searchTimeFilter: "",
    searchScrapeResults: false,
    // Map
    mapLimit: 5000,
    includeSubdomains: false,
    mapSearch: "",
    // Crawl
    maxCrawlPages: 100,
    maxCrawlDepth: 3,
    crawlIncludePaths: "",
    crawlExcludePaths: "",
    // JSON Extract
    jsonExtractEnabled: false,
    jsonExtractPrompt: "",
    jsonExtractSchema: "",
    // Branding
    brandingEnabled: false,
    // Features toggles
    scrapeEnabled: true,
    searchEnabled: true,
    mapEnabled: true,
    crawlEnabled: true,
  })

  const handleGeneratePrompt = useCallback(async (agentType: string, mode: "generate" | "optimize") => {
    setGeneratingPrompt(agentType)
    try {
      // Use the prompt_engineer's config if available, fallback to defaults
      const peConfig = configs["prompt_engineer"]
      const provider = peConfig?.provider || "openrouter"
      const model = peConfig?.model || "anthropic/claude-sonnet-4.5"

      const agentLabel = AGENT_CARDS.find(c => c.type === agentType)?.label || agentType
      const currentPrompt = configs[agentType]?.custom_prompt?.trim() || ""
      const defaultPrompt = DEFAULT_PROMPTS[agentType] || ""

      let context = ""
      if (mode === "optimize" && currentPrompt) {
        context = `### MODO: OTIMIZAÇÃO\n\n**Agente alvo:** ${agentLabel} (${agentType})\n\n**Prompt atual a otimizar:**\n\`\`\`\n${currentPrompt}\n\`\`\`\n\nAnalise e retorne uma versão melhorada deste prompt.`
      } else {
        context = `### MODO: GERAÇÃO\n\n**Agente alvo:** ${agentLabel} (${agentType})\n\n**Prompt padrão do sistema (para referência):**\n\`\`\`\n${defaultPrompt.slice(0, 2000)}\n\`\`\`\n\nGere um prompt completo, profissional e otimizado para este agente. O prompt deve ser melhor e mais detalhado que o padrão.`
      }

      const { data, error } = await supabase.functions.invoke("generate-content", {
        body: {
          agent: "prompt_engineer",
          context,
          provider,
          model,
          custom_prompt: peConfig?.custom_prompt || undefined,
        },
      })

      if (error) throw error
      if (!data?.success) throw new Error(data?.error || "Falha na geração")

      updateConfig(agentType, "custom_prompt", data.result)
      toast.success(`Prompt ${mode === "optimize" ? "otimizado" : "gerado"} para ${agentLabel}!`, {
        description: `via ${provider} / ${model.split("/").pop()}`
      })
    } catch (e: any) {
      toast.error("Erro ao gerar prompt", { description: e.message })
    } finally {
      setGeneratingPrompt(null)
    }
  }, [configs])

  useEffect(() => {
    if (!open) return
    const load = async () => {
      setLoading(true)
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return

      const [agentRes, keysRes, cronRes, systemKeysRes] = await Promise.all([
        supabase.from("agent_configs").select("*").eq("user_id", user.id),
        supabase.from("user_api_keys").select("*").eq("user_id", user.id),
        supabase.from("pipeline_config").select("cron_enabled, cron_schedule, cron_last_run").eq("user_id", user.id).maybeSingle(),
        supabase.functions.invoke("check-api-keys").then(r => {
          console.log("check-api-keys response:", r);
          return r.data;
        }).catch((e) => { console.error("check-api-keys error:", e); return null; }),
      ])

      if (systemKeysRes?.configured) {
        setSystemKeys(systemKeysRes.configured)
      } else if (systemKeysRes && typeof systemKeysRes === 'object') {
        // In case the response structure is flat
        setSystemKeys(systemKeysRes as Record<string, boolean>)
      }

      // Agent configs
      const configMap: Record<string, AgentConfig> = {}
      for (const card of AGENT_CARDS) {
        const n8nDef = N8N_DEFAULTS[card.type]
        configMap[card.type] = {
          agent_type: card.type,
          provider: n8nDef?.provider || "groq",
          model: n8nDef?.model || "llama-3.3-70b-versatile",
          custom_prompt: "",
          custom_prompt_2: "",
          custom_prompt_3: "",
          is_active: true,
        }
      }
      if (agentRes.data) {
        for (const row of agentRes.data) {
          configMap[row.agent_type] = { agent_type: row.agent_type, provider: row.provider, model: row.model, custom_prompt: row.custom_prompt || "", custom_prompt_2: (row as any).custom_prompt_2 || "", custom_prompt_3: (row as any).custom_prompt_3 || "", is_active: row.is_active }
        }
      }
      setConfigs(configMap)

      // API keys
      const keysMap: Record<string, UserApiKey> = {}
      if (keysRes.data) {
        for (const row of keysRes.data) {
          keysMap[row.provider] = { id: row.id, provider: row.provider, api_key: row.api_key, is_active: row.is_active }
        }
      }
      setApiKeys(keysMap)

      // Cron config
      if (cronRes.data) {
        setCronEnabled(cronRes.data.cron_enabled || false)
        setCronSchedule(cronRes.data.cron_schedule || "0 6 * * *")
        setCronLastRun(cronRes.data.cron_last_run || null)
      }

      // Load Apify config from system_config
      const { data: apifyConfigRow } = await supabase
        .from("system_config")
        .select("config_value")
        .eq("user_id", user.id)
        .eq("config_key", "apify_config")
        .maybeSingle()
      if (apifyConfigRow) {
        try {
          const parsed = JSON.parse(apifyConfigRow.config_value)
          setApifyActors(prev => ({ ...prev, ...parsed }))
        } catch {}
      }

      // Load Firecrawl config from system_config
      const { data: firecrawlConfigRow } = await supabase
        .from("system_config")
        .select("config_value")
        .eq("user_id", user.id)
        .eq("config_key", "firecrawl_config")
        .maybeSingle()
      if (firecrawlConfigRow) {
        try {
          const parsed = JSON.parse(firecrawlConfigRow.config_value)
          setFirecrawlConfig(prev => ({ ...prev, ...parsed }))
        } catch {}
      }

      setLoading(false)
    }
    load()
  }, [open])

  const updateConfig = useCallback((agentType: string, field: keyof AgentConfig, value: any) => {
    setConfigs(prev => {
      const updated = { ...prev }
      const config = { ...updated[agentType] }
      if (field === "provider") {
        config.provider = value
        const providerModels = MODELS[value]
        config.model = providerModels?.[0]?.value || ""
      } else {
        (config as any)[field] = value
      }
      updated[agentType] = config
      return updated
    })
  }, [])

  const updateApiKey = useCallback((provider: string, value: string) => {
    setApiKeys(prev => ({
      ...prev,
      [provider]: { ...prev[provider], provider, api_key: value, is_active: true },
    }))
  }, [])

  const deleteApiKey = useCallback(async (provider: string) => {
    const key = apiKeys[provider]
    if (key?.id) {
      await supabase.from("user_api_keys").delete().eq("id", key.id)
    }
    setApiKeys(prev => {
      const updated = { ...prev }
      delete updated[provider]
      return updated
    })
    toast.success(`API key ${provider} removida`)
  }, [apiKeys])

  const handleSave = useCallback(async () => {
    setSaving(true)
    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) throw new Error("Not authenticated")

      // Save agent configs
      for (const [agentType, config] of Object.entries(configs)) {
        const { error } = await supabase.from("agent_configs").upsert({
          user_id: user.id, agent_type: agentType, provider: config.provider,
          model: config.model, custom_prompt: config.custom_prompt || null,
          custom_prompt_2: config.custom_prompt_2 || null,
          custom_prompt_3: config.custom_prompt_3 || null,
          is_active: config.is_active,
        } as any, { onConflict: "user_id,agent_type" })
        if (error) throw error
      }

      // Save API keys
      for (const [provider, key] of Object.entries(apiKeys)) {
        if (!key.api_key.trim()) continue
        const { error } = await supabase.from("user_api_keys").upsert({
          user_id: user.id, provider, api_key: key.api_key.trim(), is_active: key.is_active,
        }, { onConflict: "user_id,provider" })
        if (error) throw error
      }

      // Save cron config
      const { data: existingConfig } = await supabase
        .from("pipeline_config")
        .select("id")
        .eq("user_id", user.id)
        .maybeSingle()

      if (existingConfig) {
        await supabase.from("pipeline_config").update({
          cron_enabled: cronEnabled,
          cron_schedule: cronSchedule,
        }).eq("user_id", user.id)
      } else {
        await supabase.from("pipeline_config").insert({
          user_id: user.id,
          cron_enabled: cronEnabled,
          cron_schedule: cronSchedule,
        })
      }

      // Save Apify config to system_config
      await supabase.from("system_config").upsert({
        user_id: user.id,
        config_key: "apify_config",
        config_value: JSON.stringify(apifyActors),
      }, { onConflict: "user_id,config_key" })

      // Save Firecrawl config to system_config
      await supabase.from("system_config").upsert({
        user_id: user.id,
        config_key: "firecrawl_config",
        config_value: JSON.stringify(firecrawlConfig),
      }, { onConflict: "user_id,config_key" })

      toast.success("Configurações salvas!")
      onOpenChange(false)
    } catch (error: any) {
      toast.error("Erro ao salvar", { description: error.message })
    } finally {
      setSaving(false)
    }
  }, [configs, apiKeys, cronEnabled, cronSchedule, apifyActors, firecrawlConfig, onOpenChange])

  const connectedProviders = PROVIDER_INFO.filter(p => !p.needsKey || apiKeys[p.value]?.api_key?.trim() || systemKeys[p.value])

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        showCloseButton={false}
        className="overflow-y-auto"
        style={isMaximized
          ? { maxWidth: "96vw", width: "96vw", height: "96vh", maxHeight: "96vh" }
          : { maxWidth: "64rem", maxHeight: "90vh" }
        }
      >
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle className="flex items-center gap-2 text-2xl">
                <Settings2 className="h-6 w-6" /> Configuração de IA
              </DialogTitle>
              <DialogDescription>
                Gerencie suas API keys e configure os agentes de IA.
              </DialogDescription>
            </div>
            <div className="flex items-center gap-1">
              <Button variant="ghost" size="icon" onClick={() => setIsMaximized(!isMaximized)}>
                {isMaximized ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
              </Button>
              <Button variant="ghost" size="icon" onClick={() => onOpenChange(false)}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </DialogHeader>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-4">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="api-keys" className="gap-2"><Key className="h-4 w-4" /> API Keys</TabsTrigger>
              <TabsTrigger value="agents" className="gap-2"><Brain className="h-4 w-4" /> Agentes</TabsTrigger>
              <TabsTrigger value="cron" className="gap-2"><Clock className="h-4 w-4" /> Cron</TabsTrigger>
              <TabsTrigger value="apify" className="gap-2"><Bug className="h-4 w-4" /> Apify</TabsTrigger>
              <TabsTrigger value="firecrawl" className="gap-2"><Globe className="h-4 w-4" /> Firecrawl</TabsTrigger>
            </TabsList>

            {/* API Keys Tab */}
            <TabsContent value="api-keys" className="space-y-4 mt-4">
              <Card className="p-4 border-primary/20 bg-primary/5">
                <div className="flex items-start gap-3">
                  <Key className="h-5 w-5 mt-0.5 text-primary" />
                  <div>
                    <h3 className="font-semibold text-sm">Suas API Keys</h3>
                    <p className="text-xs text-muted-foreground mt-1">
                      Insira suas API keys para usar provedores externos. Keys são salvas de forma segura e acessíveis apenas por você.
                      <strong> Lovable AI</strong> já está inclusa e não precisa de key.
                    </p>
                  </div>
                </div>
              </Card>

              <div className="grid gap-3">
                {PROVIDER_INFO.map(provider => {
                  const key = apiKeys[provider.value]
                  const hasKey = !!key?.api_key?.trim()
                  const visible = showKeys[provider.value]

                  return (
                    <Card key={provider.value} className="p-4">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="font-semibold text-sm">{provider.label}</h4>
                            {!provider.needsKey ? (
                              <Badge variant="default" className="text-xs gap-1">
                                <Check className="h-3 w-3" /> Inclusa
                              </Badge>
                            ) : hasKey ? (
                              <Badge variant="secondary" className="text-xs gap-1 bg-emerald-500/10 text-emerald-600 border-emerald-500/20">
                                <Check className="h-3 w-3" /> Configurada
                              </Badge>
                            ) : systemKeys[provider.value] ? (
                              <Badge variant="secondary" className="text-xs gap-1 bg-emerald-500/10 text-emerald-600 border-emerald-500/20">
                                <Check className="h-3 w-3" /> Configurada (sistema)
                              </Badge>
                            ) : (
                              <Badge variant="outline" className="text-xs gap-1">
                                <AlertCircle className="h-3 w-3" /> Não configurada
                              </Badge>
                            )}
                          </div>
                          <p className="text-xs text-muted-foreground">{provider.description}</p>
                        </div>
                      </div>

                      {provider.needsKey && (
                        <div className="space-y-2 mt-3">
                          <div className="flex gap-2">
                            <div className="relative flex-1">
                              <Input
                                type={visible ? "text" : "password"}
                                placeholder={provider.placeholder}
                                value={key?.api_key || ""}
                                onChange={(e) => updateApiKey(provider.value, e.target.value)}
                                className="pr-10 text-xs h-8"
                              />
                              <Button
                                variant="ghost" size="icon"
                                className="absolute right-0 top-0 h-8 w-8"
                                onClick={() => setShowKeys(prev => ({ ...prev, [provider.value]: !prev[provider.value] }))}
                              >
                                {visible ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                              </Button>
                            </div>
                            {hasKey && (
                              <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive shrink-0" onClick={() => deleteApiKey(provider.value)}>
                                <Trash2 className="h-3.5 w-3.5" />
                              </Button>
                            )}
                          </div>
                          {provider.helpUrl && (
                            <a href={provider.helpUrl} target="_blank" rel="noopener noreferrer" className="text-xs text-primary hover:underline">
                              Obter API key →
                            </a>
                          )}
                        </div>
                      )}
                    </Card>
                  )
                })}
              </div>
            </TabsContent>

            {/* Agents Tab */}
            <TabsContent value="agents" className="space-y-4 mt-4">
              <Card className="p-3 border-primary/20 bg-primary/5">
                <p className="text-xs text-muted-foreground">
                  <strong>{connectedProviders.length}</strong> provedor(es) disponível(is): {connectedProviders.map(p => p.label).join(", ")}
                </p>
              </Card>

              <div className="grid gap-4 md:grid-cols-2">
                {AGENT_CARDS.map(card => {
                  const config = configs[card.type]
                  if (!config) return null
                  const availableProviders = PROVIDER_INFO.filter(p => !p.needsKey || apiKeys[p.value]?.api_key?.trim() || systemKeys[p.value])
                  const providerModels = MODELS[config.provider] || []

                  return (
                    <Card key={card.type} className={`p-4 transition-opacity ${!config.is_active ? "opacity-50" : ""}`}>
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
                            {card.icon}
                          </div>
                          <div>
                            <h4 className="font-semibold text-sm">{card.label}</h4>
                            <p className="text-xs text-muted-foreground">{card.description}</p>
                          </div>
                        </div>
                        <Switch checked={config.is_active} onCheckedChange={(v) => updateConfig(card.type, "is_active", v)} />
                      </div>

                      {/* Active provider/model badge */}
                      <div className="mb-3 flex items-center gap-1.5 rounded-md border border-primary/30 bg-primary/5 px-2.5 py-1.5">
                        <Settings2 className="h-3 w-3 text-primary shrink-0" />
                        <span className="text-[10px] text-foreground leading-tight">
                          <strong>Ativo:</strong> {config.model.split("/").pop()} <span className="text-muted-foreground">({config.provider})</span>
                        </span>
                      </div>

                      <div className="space-y-3">
                        <div className="space-y-1.5">
                          <Label className="text-xs">Provedor</Label>
                          <Select value={config.provider} onValueChange={(v) => updateConfig(card.type, "provider", v)}>
                            <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                            <SelectContent>
                              {availableProviders.map(p => (
                                <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-1.5">
                          <Label className="text-xs">Modelo</Label>
                          <Select value={config.model} onValueChange={(v) => updateConfig(card.type, "model", v)}>
                            <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                            <SelectContent>
                              {providerModels.map(m => (
                                <SelectItem key={m.value} value={m.value}>
                                  <span>{m.label}</span>
                                  <span className="ml-2 text-muted-foreground text-xs">— {m.description}</span>
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>

                        {/* Default prompt - editable collapsible */}
                        <Collapsible defaultOpen>
                          <CollapsibleTrigger asChild>
                            <Button variant="ghost" size="sm" className="w-full justify-start gap-2 h-7 text-xs text-muted-foreground hover:text-foreground px-1">
                              <FileText className="h-3 w-3" />
                              <span>Prompt padrão</span>
                              <ChevronDown className="h-3 w-3 ml-auto transition-transform group-data-[state=open]:rotate-180" />
                            </Button>
                          </CollapsibleTrigger>
                          <CollapsibleContent>
                            <div className="mt-1 space-y-1">
                              <Textarea
                                value={DEFAULT_PROMPTS[card.type] || ""}
                                onChange={(e) => {
                                  DEFAULT_PROMPTS[card.type] = e.target.value
                                  // Force re-render
                                  setConfigs(prev => ({ ...prev }))
                                }}
                                className="text-xs font-mono leading-relaxed min-h-[120px] max-h-[300px] resize-y"
                                placeholder="Prompt padrão do agente..."
                              />
                              <div className="flex justify-end">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-6 text-[10px] text-muted-foreground"
                                  onClick={() => {
                                    DEFAULT_PROMPTS[card.type] = ORIGINAL_DEFAULT_PROMPTS[card.type] || ""
                                    setConfigs(prev => ({ ...prev }))
                                    toast.info("Prompt padrão restaurado")
                                  }}
                                >
                                  Restaurar original
                                </Button>
                              </div>
                            </div>
                          </CollapsibleContent>
                        </Collapsible>

                        {/* Custom prompt 1 + AI generate buttons */}
                        <div className="space-y-1.5">
                          <div className="flex items-center justify-between">
                            <Label className="text-xs font-medium">Prompt customizado 1 (sobrescreve o padrão)</Label>
                            {card.type !== "prompt_engineer" && (
                              <div className="flex gap-1">
                                <Button
                                  variant="outline" size="sm" className="h-6 text-xs gap-1"
                                  disabled={generatingPrompt === card.type}
                                  onClick={() => handleGeneratePrompt(card.type, "generate")}
                                >
                                  {generatingPrompt === card.type ? <Loader2 className="h-3 w-3 animate-spin" /> : <Wand2 className="h-3 w-3" />}
                                  Gerar
                                </Button>
                                {config.custom_prompt?.trim() && (
                                  <Button
                                    variant="outline" size="sm" className="h-6 text-xs gap-1"
                                    disabled={generatingPrompt === card.type}
                                    onClick={() => handleGeneratePrompt(card.type, "optimize")}
                                  >
                                    {generatingPrompt === card.type ? <Loader2 className="h-3 w-3 animate-spin" /> : <Sparkles className="h-3 w-3" />}
                                    Otimizar
                                  </Button>
                                )}
                              </div>
                            )}
                          </div>
                          <Textarea
                            placeholder="Insira seu próprio prompt para substituir o padrão acima..."
                            value={config.custom_prompt}
                            onChange={(e) => updateConfig(card.type, "custom_prompt", e.target.value)}
                            rows={3} className="resize-y text-xs"
                          />
                          {config.custom_prompt?.trim() && (
                            <div className="flex items-center justify-between">
                              <Badge variant="secondary" className="text-xs gap-1">
                                <Check className="h-3 w-3" /> Prompt 1 ativo
                              </Badge>
                              <Button
                                variant="ghost" size="sm" className="h-6 text-xs text-destructive"
                                onClick={() => updateConfig(card.type, "custom_prompt", "")}
                              >
                                Limpar
                              </Button>
                            </div>
                          )}
                        </div>

                        {/* Custom prompt 2 */}
                        <div className="space-y-1.5">
                          <Label className="text-xs font-medium">Prompt customizado 2 (adicional, concatenado)</Label>
                          <Textarea
                            placeholder="Prompt adicional que será concatenado ao prompt principal..."
                            value={config.custom_prompt_2}
                            onChange={(e) => updateConfig(card.type, "custom_prompt_2", e.target.value)}
                            rows={3} className="resize-y text-xs"
                          />
                          {config.custom_prompt_2?.trim() && (
                            <div className="flex items-center justify-between">
                              <Badge variant="secondary" className="text-xs gap-1">
                                <Check className="h-3 w-3" /> Prompt 2 ativo
                              </Badge>
                              <Button
                                variant="ghost" size="sm" className="h-6 text-xs text-destructive"
                                onClick={() => updateConfig(card.type, "custom_prompt_2", "")}
                              >
                                Limpar
                              </Button>
                            </div>
                          )}
                        </div>

                        {/* Custom prompt 3 - togglable */}
                        {config.custom_prompt_3 !== undefined && (
                          config.custom_prompt_3?.trim() || config.custom_prompt?.trim() ? (
                            <div className="space-y-1.5">
                              <Label className="text-xs font-medium">Prompt customizado 3 (extra)</Label>
                              <Textarea
                                placeholder="Terceiro prompt adicional..."
                                value={config.custom_prompt_3}
                                onChange={(e) => updateConfig(card.type, "custom_prompt_3", e.target.value)}
                                rows={3} className="resize-y text-xs"
                              />
                              {config.custom_prompt_3?.trim() && (
                                <div className="flex items-center justify-between">
                                  <Badge variant="secondary" className="text-xs gap-1">
                                    <Check className="h-3 w-3" /> Prompt 3 ativo
                                  </Badge>
                                  <Button
                                    variant="ghost" size="sm" className="h-6 text-xs text-destructive"
                                    onClick={() => updateConfig(card.type, "custom_prompt_3", "")}
                                  >
                                    Limpar
                                  </Button>
                                </div>
                              )}
                            </div>
                          ) : (
                            <Button
                              variant="outline" size="sm" className="w-full text-xs gap-1"
                              onClick={() => updateConfig(card.type, "custom_prompt_3", " ")}
                            >
                              <Plus className="h-3 w-3" /> Adicionar 3º prompt
                            </Button>
                          )
                        )}
                      </div>
                    </Card>
                  )
                })}
              </div>
            </TabsContent>

            {/* Cron Tab */}
            <TabsContent value="cron" className="space-y-4 mt-4">
              <Card className="p-4 border-primary/20 bg-primary/5">
                <div className="flex items-start gap-3">
                  <Clock className="h-5 w-5 mt-0.5 text-primary" />
                  <div>
                    <h3 className="font-semibold text-sm">Agendamento Automático</h3>
                    <p className="text-xs text-muted-foreground mt-1">
                      O Cron Scheduler roda o pipeline completo automaticamente: scraping dos perfis dos competidores,
                      análise de hooks por IA e geração do relatório estratégico.
                    </p>
                  </div>
                </div>
              </Card>

              <Card className="p-5">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                      <Timer className="h-5 w-5" />
                    </div>
                    <div>
                      <h4 className="font-semibold">Pipeline Automático</h4>
                      <p className="text-xs text-muted-foreground">Scraping + Análise + Relatório</p>
                    </div>
                  </div>
                  <Switch checked={cronEnabled} onCheckedChange={setCronEnabled} />
                </div>

                {cronEnabled && (
                  <div className="space-y-4 pt-4 border-t">
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Frequência</Label>
                      <Select value={cronSchedule} onValueChange={setCronSchedule}>
                        <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {CRON_SCHEDULES.map(s => (
                            <SelectItem key={s.value} value={s.value}>
                              <span className="font-medium">{s.label}</span>
                              <span className="ml-2 text-muted-foreground text-xs">— {s.description}</span>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <Card className="p-3 bg-muted/50">
                      <h5 className="text-xs font-semibold mb-2">O que será executado (todos competidores ativos, sequencial):</h5>
                      <ul className="text-xs text-muted-foreground space-y-1">
                        <li>✅ Scraping das últimas 24h de todos os competidores ativos</li>
                        <li>✅ Delay de 30s entre cada competidor</li>
                        <li>✅ Filtragem por data e ordenação por views</li>
                        <li>✅ Análise de hook e transcrição por IA</li>
                        <li>✅ Scraping dos seus próprios reels</li>
                        <li>✅ Relatório estratégico gerado após processar todos</li>
                      </ul>
                    </Card>

                    {cronLastRun && (
                      <p className="text-xs text-muted-foreground">
                        <strong>Última execução:</strong> {new Date(cronLastRun).toLocaleString("pt-BR")}
                      </p>
                    )}
                  </div>
                )}
              </Card>

              {/* DM Poll Cron */}
              <Card className="p-5">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-500/10 text-green-500">
                      <MessageSquare className="h-5 w-5" />
                    </div>
                    <div>
                      <h4 className="font-semibold">Poll DMs Automático</h4>
                      <p className="text-xs text-muted-foreground">A cada 15 min — perfis autorizados</p>
                    </div>
                  </div>
                  <Badge variant="outline" className="text-xs border-green-500 text-green-500">Ativo</Badge>
                </div>

                <Card className="p-3 bg-muted/50">
                  <h5 className="text-xs font-semibold mb-2">O que será executado automaticamente:</h5>
                  <ul className="text-xs text-muted-foreground space-y-1">
                    <li>✅ Busca as 20 mensagens mais recentes de cada thread</li>
                    <li>✅ Filtra por perfis autorizados (allowed_senders)</li>
                    <li>✅ Processa links de reels, posts e perfis</li>
                    <li>✅ Classifica relevância por nicho automaticamente</li>
                    <li>✅ Análise de hook e viral por IA</li>
                    <li>✅ Gera ideias de conteúdo e estratégia</li>
                  </ul>
                </Card>

                <p className="text-xs text-muted-foreground mt-3">
                  <strong>Frequência:</strong> A cada 15 minutos via pg_cron (cron ID: 6)
                </p>
              </Card>
            </TabsContent>

            {/* Apify Tab */}
            <TabsContent value="apify" className="space-y-4 mt-4">
              <Card className="p-4 border-primary/20 bg-primary/5">
                <div className="flex items-start gap-3">
                  <Bug className="h-5 w-5 mt-0.5 text-primary" />
                  <div>
                    <h3 className="font-semibold text-sm">Configuração Apify</h3>
                    <p className="text-xs text-muted-foreground mt-1">
                      Configure os actors da Apify para scraping de Instagram. Cada tipo de conteúdo pode usar um actor diferente.
                    </p>
                  </div>
                </div>
              </Card>

              {/* Actors Ativos (em uso pelo pipeline) */}
              <Card className="p-5">
                <h4 className="font-semibold mb-4 flex items-center gap-2">
                  <Settings2 className="h-4 w-4" /> Actors Ativos (em uso)
                </h4>
                <div className="space-y-4">
                  {[
                    { key: "postsScraper" as const, label: "Posts / Reels / Carrosséis", desc: "Scraping geral do feed — usado no pipeline", placeholder: "shu8hvrXbJbY3Eb9W", status: "pipeline" },
                    { key: "profileScraper" as const, label: "Perfil", desc: "Dados de perfil (bio, seguidores, posts)", placeholder: "shu8hvrXbJbY3Eb9W", status: "pipeline" },
                    { key: "storyScraper" as const, label: "Stories", desc: "Captura de Stories (requer login)", placeholder: "apify~instagram-story-scraper", status: "pipeline" },
                  ].map(actor => (
                    <div key={actor.key} className="flex items-center gap-3">
                      <div className="flex-1 space-y-1">
                        <div className="flex items-center gap-2">
                          <Label className="text-xs font-medium">{actor.label}</Label>
                          <Badge variant="default" className="text-[9px] h-4">Ativo</Badge>
                        </div>
                        <Input
                          value={apifyActors[actor.key]}
                          onChange={(e) => setApifyActors(prev => ({ ...prev, [actor.key]: e.target.value }))}
                          placeholder={actor.placeholder}
                          className="text-xs h-8 font-mono"
                        />
                        <p className="text-[10px] text-muted-foreground">{actor.desc}</p>
                      </div>
                    </div>
                  ))}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <Label className="text-xs font-medium">Login para Stories</Label>
                      <Switch
                        checked={apifyActors.storyLoginEnabled}
                        onCheckedChange={(v) => setApifyActors(prev => ({ ...prev, storyLoginEnabled: v }))}
                      />
                    </div>
                    <p className="text-[10px] text-muted-foreground">
                      {apifyActors.storyLoginEnabled
                        ? "✅ Login ativo — usando INSTAGRAM_USERNAME e INSTAGRAM_PASSWORD dos secrets"
                        : "❌ Login desativado — stories não serão capturados"
                      }
                    </p>
                  </div>
                </div>
              </Card>

              {/* Actors Disponíveis (pronto emprego) */}
              <Card className="p-5">
                <h4 className="font-semibold mb-3 flex items-center gap-2">
                  🧰 Actors Disponíveis (pronto emprego)
                </h4>
                <p className="text-xs text-muted-foreground mb-4">
                  Actors pré-configurados prontos para uso. Edite o ID ou clique em "Usar" para ativar em uma das funções acima.
                </p>
                <div className="space-y-3">
                  {[
                    { key: "reelScraper" as const, label: "Instagram Reel Scraper", desc: "Reels específicos (sem login)", risk: "Baixo", defaultId: "apify~instagram-reel-scraper", assignTo: "postsScraper" as const },
                    { key: "postScraper" as const, label: "Instagram Post Scraper", desc: "Posts com caption, métricas, imagens, menções, coautores, comentários recentes", risk: "Baixo", defaultId: "apify~instagram-post-scraper", assignTo: "postsScraper" as const },
                    { key: "profileScraperDedicated" as const, label: "Instagram Profile Scraper", desc: "Perfil completo: seguidores, bio, URL, posts recentes, highlight reels", risk: "Baixo", defaultId: "apify~instagram-profile-scraper", assignTo: "profileScraper" as const },
                    { key: "apiScraper" as const, label: "Instagram API Scraper", desc: "Scraping sem login — posts, perfis, hashtags, locais", risk: "Baixo", defaultId: "RB9HEZitC8hIUXAha", assignTo: "postsScraper" as const },
                    { key: "commentScraper" as const, label: "Instagram Comment Scraper", desc: "Comentários de posts — análise de sentimento e engajamento", risk: "Baixo", defaultId: "apify~instagram-comment-scraper", assignTo: null },
                    { key: "hashtagScraper" as const, label: "Instagram Hashtag Scraper", desc: "Posts e reels por hashtag — pesquisa de tendências e nichos", risk: "Baixo", defaultId: "apify~instagram-hashtag-scraper", assignTo: null },
                    { key: "hashtagAnalytics" as const, label: "Hashtag Analytics Scraper", desc: "Estatísticas de hashtags: total de posts, posts/dia, hashtags relacionadas", risk: "Baixo", defaultId: "apify~instagram-hashtag-analytics-scraper", assignTo: null },
                    { key: "searchScraper" as const, label: "Instagram Search Scraper", desc: "Busca no Instagram: locais, negócios, usuários e hashtags por keyword", risk: "Baixo", defaultId: "apify~instagram-search-scraper", assignTo: null },
                    { key: "mentionsScraper" as const, label: "Instagram Mentions/Tagged Scraper", desc: "Posts em que o perfil foi marcado/mencionado", risk: "Baixo", defaultId: "apify~instagram-tagged-scraper", assignTo: null },
                    { key: "followersCounter" as const, label: "Followers Count Scraper", desc: "Contagem rápida de seguidores de múltiplos perfis", risk: "Baixo", defaultId: "apify~instagram-followers-count-scraper", assignTo: null },
                    { key: "storyCommunityScraper" as const, label: "Story Scraper (Community)", desc: "Stories via actor da comunidade — alternativa ao oficial", risk: "Médio", defaultId: "zuzka~instagram-story-scraper", assignTo: "storyScraper" as const },
                  ].map(actor => (
                    <div key={actor.key} className="rounded-md border px-4 py-3 space-y-2">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-xs font-medium">{actor.label}</p>
                          <p className="text-[10px] text-muted-foreground">{actor.desc}</p>
                        </div>
                        <Badge variant={actor.risk === "Baixo" ? "secondary" : "outline"} className="text-[10px]">
                          Risco: {actor.risk}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-2">
                        <Input
                          value={apifyActors[actor.key]}
                          onChange={(e) => setApifyActors(prev => ({ ...prev, [actor.key]: e.target.value }))}
                          placeholder={actor.defaultId}
                          className="text-xs h-7 font-mono flex-1"
                        />
                        {actor.assignTo && (
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-7 text-[10px] whitespace-nowrap"
                            onClick={() => {
                              setApifyActors(prev => ({ ...prev, [actor.assignTo!]: prev[actor.key] }))
                              toast.success(`Actor "${actor.label}" ativado como ${actor.assignTo === "postsScraper" ? "Posts/Reels" : actor.assignTo === "profileScraper" ? "Perfil" : "Stories"}`)
                            }}
                          >
                            Usar como {actor.assignTo === "postsScraper" ? "Posts" : actor.assignTo === "profileScraper" ? "Perfil" : "Stories"}
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
                <a href="https://apify.com/store?q=instagram" target="_blank" rel="noopener noreferrer" className="text-xs text-primary hover:underline mt-3 inline-flex items-center gap-1">
                  <ExternalLink className="h-3 w-3" /> Ver todos os actors no Apify Store
                </a>
              </Card>

              {/* Search & Input Config */}
              <Card className="p-5">
                <h4 className="font-semibold mb-4 flex items-center gap-2">
                  <Search className="h-4 w-4" /> Configuração de Busca (Instagram Scraper)
                </h4>
                <p className="text-[10px] text-muted-foreground mb-3">
                  O actor principal (shu8hvrXbJbY3Eb9W) suporta busca por keyword além de URLs diretas. Configure aqui os parâmetros de busca para hashtags, locais e perfis.
                </p>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label className="text-xs font-medium">Habilitar Busca por Keyword</Label>
                    <Switch
                      checked={apifyActors.searchEnabled}
                      onCheckedChange={(v) => setApifyActors(prev => ({ ...prev, searchEnabled: v }))}
                    />
                  </div>
                  {apifyActors.searchEnabled && (
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="space-y-1.5">
                        <Label className="text-xs font-medium">Keyword de Busca</Label>
                        <Input
                          value={apifyActors.searchKeyword}
                          onChange={(e) => setApifyActors(prev => ({ ...prev, searchKeyword: e.target.value }))}
                          placeholder="Ex: fitness, São Paulo, @perfil"
                          className="text-xs h-8"
                        />
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs font-medium">Tipo de Busca</Label>
                        <Select
                          value={apifyActors.searchType}
                          onValueChange={(v) => setApifyActors(prev => ({ ...prev, searchType: v }))}
                        >
                          <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="hashtag">#️⃣ Hashtag — Posts por hashtag</SelectItem>
                            <SelectItem value="place">📍 Local — Posts por localização</SelectItem>
                            <SelectItem value="user">👤 Usuário — Busca por perfis</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs font-medium">Tipo de Resultado</Label>
                        <Select
                          value={apifyActors.resultsType}
                          onValueChange={(v) => setApifyActors(prev => ({ ...prev, resultsType: v }))}
                        >
                          <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="posts">📝 Posts — Conteúdo publicado</SelectItem>
                            <SelectItem value="details">📊 Detalhes — Metadados do resultado</SelectItem>
                            <SelectItem value="comments">💬 Comentários — Comentários dos posts</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs font-medium">Limite de Buscas</Label>
                        <Input
                          type="number"
                          value={apifyActors.searchLimit}
                          onChange={(e) => setApifyActors(prev => ({ ...prev, searchLimit: parseInt(e.target.value) || 10 }))}
                          className="text-xs h-8"
                          min={1} max={100}
                        />
                        <p className="text-[10px] text-muted-foreground">Quantos resultados de busca processar</p>
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs font-medium">Limite de Resultados por Item</Label>
                        <Input
                          type="number"
                          value={apifyActors.resultsLimit}
                          onChange={(e) => setApifyActors(prev => ({ ...prev, resultsLimit: parseInt(e.target.value) || 100 }))}
                          className="text-xs h-8"
                          min={1} max={1000}
                        />
                        <p className="text-[10px] text-muted-foreground">Posts/comentários por resultado de busca</p>
                      </div>
                    </div>
                  )}
                </div>
              </Card>

              {/* Limits & Performance */}
              <Card className="p-5">
                <h4 className="font-semibold mb-4 flex items-center gap-2">
                  <Timer className="h-4 w-4" /> Limites & Performance
                </h4>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-1.5">
                    <Label className="text-xs font-medium">Limite de Posts por Competidor</Label>
                    <Input
                      type="number"
                      value={apifyActors.postsMaxItems}
                      onChange={(e) => setApifyActors(prev => ({ ...prev, postsMaxItems: parseInt(e.target.value) || 20 }))}
                      className="text-xs h-8"
                      min={1} max={100}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs font-medium">Limite de Stories por Competidor</Label>
                    <Input
                      type="number"
                      value={apifyActors.storyMaxItems}
                      onChange={(e) => setApifyActors(prev => ({ ...prev, storyMaxItems: parseInt(e.target.value) || 20 }))}
                      className="text-xs h-8"
                      min={1} max={50}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs font-medium">Delay entre Requisições (segundos)</Label>
                    <Input
                      type="number"
                      value={apifyActors.delayBetweenRequests}
                      onChange={(e) => setApifyActors(prev => ({ ...prev, delayBetweenRequests: parseInt(e.target.value) || 2 }))}
                      className="text-xs h-8"
                      min={0} max={60}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs font-medium">País do Proxy</Label>
                    <Select
                      value={apifyActors.proxyCountry}
                      onValueChange={(v) => setApifyActors(prev => ({ ...prev, proxyCountry: v }))}
                    >
                      <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="BR">🇧🇷 Brasil</SelectItem>
                        <SelectItem value="US">🇺🇸 Estados Unidos</SelectItem>
                        <SelectItem value="GB">🇬🇧 Reino Unido</SelectItem>
                        <SelectItem value="DE">🇩🇪 Alemanha</SelectItem>
                        <SelectItem value="NONE">🌍 Sem proxy</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </Card>
            </TabsContent>

            {/* Firecrawl Tab */}
            <TabsContent value="firecrawl" className="space-y-4 mt-4">
              <Card className="p-4 border-primary/20 bg-primary/5">
                <div className="flex items-start gap-3">
                  <Globe className="h-5 w-5 mt-0.5 text-primary" />
                  <div>
                    <h3 className="font-semibold text-sm">Configuração Firecrawl</h3>
                    <p className="text-xs text-muted-foreground mt-1">
                      Configure os parâmetros do Firecrawl para scraping de websites, extração de conteúdo e crawling. Usado como backup do Apify e para análise de páginas web.
                    </p>
                  </div>
                </div>
              </Card>

              {/* Scrape Settings */}
              <Card className="p-5">
                <h4 className="font-semibold mb-4 flex items-center gap-2">
                  <Settings2 className="h-4 w-4" /> Scrape — Extração de Conteúdo
                  <div className="ml-auto">
                    <Switch
                      checked={firecrawlConfig.scrapeEnabled}
                      onCheckedChange={(v) => setFirecrawlConfig(prev => ({ ...prev, scrapeEnabled: v }))}
                    />
                  </div>
                </h4>
                <p className="text-[10px] text-muted-foreground mb-3">Extrai conteúdo de uma URL em múltiplos formatos (markdown, HTML, screenshot, JSON, branding, summary)</p>
                <div className="space-y-4">
                  <div className="space-y-1.5">
                    <Label className="text-xs font-medium">Formatos de Extração</Label>
                    <div className="flex flex-wrap gap-2">
                      {["markdown", "html", "rawHtml", "links", "screenshot", "branding", "summary"].map(fmt => (
                        <label key={fmt} className="flex items-center gap-1.5 text-xs">
                          <Checkbox
                            checked={firecrawlConfig.formats.includes(fmt)}
                            onCheckedChange={(checked) => {
                              setFirecrawlConfig(prev => ({
                                ...prev,
                                formats: checked
                                  ? [...prev.formats, fmt]
                                  : prev.formats.filter(f => f !== fmt),
                              }))
                            }}
                          />
                          {fmt}
                        </label>
                      ))}
                    </div>
                  </div>
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-1.5">
                      <Label className="text-xs font-medium">Tempo de Espera (ms)</Label>
                      <Input
                        type="number"
                        value={firecrawlConfig.waitFor}
                        onChange={(e) => setFirecrawlConfig(prev => ({ ...prev, waitFor: parseInt(e.target.value) || 3000 }))}
                        className="text-xs h-8"
                        min={0} max={30000} step={500}
                      />
                      <p className="text-[10px] text-muted-foreground">Tempo para esperar conteúdo dinâmico</p>
                    </div>
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <Label className="text-xs font-medium">Apenas Conteúdo Principal</Label>
                        <Switch
                          checked={firecrawlConfig.onlyMainContent}
                          onCheckedChange={(v) => setFirecrawlConfig(prev => ({ ...prev, onlyMainContent: v }))}
                        />
                      </div>
                      <p className="text-[10px] text-muted-foreground">Remove headers, footers e sidebars</p>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Search Settings */}
              <Card className="p-5">
                <h4 className="font-semibold mb-4 flex items-center gap-2">
                  <Search className="h-4 w-4" /> Search — Busca na Web
                  <div className="ml-auto">
                    <Switch
                      checked={firecrawlConfig.searchEnabled}
                      onCheckedChange={(v) => setFirecrawlConfig(prev => ({ ...prev, searchEnabled: v }))}
                    />
                  </div>
                </h4>
                <p className="text-[10px] text-muted-foreground mb-3">Busca na web com scraping opcional dos resultados encontrados</p>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-1.5">
                    <Label className="text-xs font-medium">Limite de Resultados</Label>
                    <Input
                      type="number"
                      value={firecrawlConfig.searchLimit}
                      onChange={(e) => setFirecrawlConfig(prev => ({ ...prev, searchLimit: parseInt(e.target.value) || 10 }))}
                      className="text-xs h-8"
                      min={1} max={100}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs font-medium">Idioma</Label>
                    <Select
                      value={firecrawlConfig.searchLang}
                      onValueChange={(v) => setFirecrawlConfig(prev => ({ ...prev, searchLang: v }))}
                    >
                      <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pt-BR">🇧🇷 Português (BR)</SelectItem>
                        <SelectItem value="en">🇺🇸 English</SelectItem>
                        <SelectItem value="es">🇪🇸 Español</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs font-medium">País</Label>
                    <Select
                      value={firecrawlConfig.searchCountry}
                      onValueChange={(v) => setFirecrawlConfig(prev => ({ ...prev, searchCountry: v }))}
                    >
                      <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="BR">🇧🇷 Brasil</SelectItem>
                        <SelectItem value="US">🇺🇸 Estados Unidos</SelectItem>
                        <SelectItem value="GB">🇬🇧 Reino Unido</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs font-medium">Filtro Temporal</Label>
                    <Select
                      value={firecrawlConfig.searchTimeFilter}
                      onValueChange={(v) => setFirecrawlConfig(prev => ({ ...prev, searchTimeFilter: v }))}
                    >
                      <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Sem filtro" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">Sem filtro</SelectItem>
                        <SelectItem value="qdr:h">Última hora</SelectItem>
                        <SelectItem value="qdr:d">Último dia</SelectItem>
                        <SelectItem value="qdr:w">Última semana</SelectItem>
                        <SelectItem value="qdr:m">Último mês</SelectItem>
                        <SelectItem value="qdr:y">Último ano</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5 col-span-2">
                    <div className="flex items-center justify-between">
                      <Label className="text-xs font-medium">Scrape dos Resultados</Label>
                      <Switch
                        checked={firecrawlConfig.searchScrapeResults}
                        onCheckedChange={(v) => setFirecrawlConfig(prev => ({ ...prev, searchScrapeResults: v }))}
                      />
                    </div>
                    <p className="text-[10px] text-muted-foreground">Extrai conteúdo completo de cada resultado (mais lento, mais detalhado)</p>
                  </div>
                </div>
              </Card>

              {/* Map Settings */}
              <Card className="p-5">
                <h4 className="font-semibold mb-4 flex items-center gap-2">
                  🗺️ Map — Descoberta de URLs
                  <div className="ml-auto">
                    <Switch
                      checked={firecrawlConfig.mapEnabled}
                      onCheckedChange={(v) => setFirecrawlConfig(prev => ({ ...prev, mapEnabled: v }))}
                    />
                  </div>
                </h4>
                <p className="text-[10px] text-muted-foreground mb-3">Descobre rapidamente todas as URLs de um site (sitemap rápido)</p>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-1.5">
                    <Label className="text-xs font-medium">Limite de URLs</Label>
                    <Input
                      type="number"
                      value={firecrawlConfig.mapLimit}
                      onChange={(e) => setFirecrawlConfig(prev => ({ ...prev, mapLimit: parseInt(e.target.value) || 5000 }))}
                      className="text-xs h-8"
                      min={1} max={10000}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs font-medium">Filtro de Busca</Label>
                    <Input
                      value={firecrawlConfig.mapSearch}
                      onChange={(e) => setFirecrawlConfig(prev => ({ ...prev, mapSearch: e.target.value }))}
                      placeholder="Filtrar URLs por keyword"
                      className="text-xs h-8"
                    />
                    <p className="text-[10px] text-muted-foreground">URLs retornadas ordenadas por relevância</p>
                  </div>
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <Label className="text-xs font-medium">Incluir Subdomínios</Label>
                      <Switch
                        checked={firecrawlConfig.includeSubdomains}
                        onCheckedChange={(v) => setFirecrawlConfig(prev => ({ ...prev, includeSubdomains: v }))}
                      />
                    </div>
                  </div>
                </div>
              </Card>

              {/* Crawl Settings */}
              <Card className="p-5">
                <h4 className="font-semibold mb-4 flex items-center gap-2">
                  <Globe className="h-4 w-4" /> Crawl — Raspagem Recursiva
                  <div className="ml-auto">
                    <Switch
                      checked={firecrawlConfig.crawlEnabled}
                      onCheckedChange={(v) => setFirecrawlConfig(prev => ({ ...prev, crawlEnabled: v }))}
                    />
                  </div>
                </h4>
                <p className="text-[10px] text-muted-foreground mb-3">Raspa recursivamente todas as páginas de um site seguindo links</p>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-1.5">
                    <Label className="text-xs font-medium">Máximo de Páginas</Label>
                    <Input
                      type="number"
                      value={firecrawlConfig.maxCrawlPages}
                      onChange={(e) => setFirecrawlConfig(prev => ({ ...prev, maxCrawlPages: parseInt(e.target.value) || 100 }))}
                      className="text-xs h-8"
                      min={1} max={1000}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs font-medium">Profundidade Máxima</Label>
                    <Input
                      type="number"
                      value={firecrawlConfig.maxCrawlDepth}
                      onChange={(e) => setFirecrawlConfig(prev => ({ ...prev, maxCrawlDepth: parseInt(e.target.value) || 3 }))}
                      className="text-xs h-8"
                      min={1} max={10}
                    />
                    <p className="text-[10px] text-muted-foreground">Níveis de links a seguir</p>
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs font-medium">Include Paths</Label>
                    <Input
                      value={firecrawlConfig.crawlIncludePaths}
                      onChange={(e) => setFirecrawlConfig(prev => ({ ...prev, crawlIncludePaths: e.target.value }))}
                      placeholder="/blog/*, /docs/*"
                      className="text-xs h-8 font-mono"
                    />
                    <p className="text-[10px] text-muted-foreground">Padrões de URL a incluir (separados por vírgula)</p>
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs font-medium">Exclude Paths</Label>
                    <Input
                      value={firecrawlConfig.crawlExcludePaths}
                      onChange={(e) => setFirecrawlConfig(prev => ({ ...prev, crawlExcludePaths: e.target.value }))}
                      placeholder="/admin/*, /login/*"
                      className="text-xs h-8 font-mono"
                    />
                    <p className="text-[10px] text-muted-foreground">Padrões de URL a excluir (separados por vírgula)</p>
                  </div>
                </div>
              </Card>

              {/* JSON Extract */}
              <Card className="p-5">
                <h4 className="font-semibold mb-4 flex items-center gap-2">
                  {"{ }"} JSON Extract — Extração Estruturada
                  <div className="ml-auto">
                    <Switch
                      checked={firecrawlConfig.jsonExtractEnabled}
                      onCheckedChange={(v) => setFirecrawlConfig(prev => ({ ...prev, jsonExtractEnabled: v }))}
                    />
                  </div>
                </h4>
                <p className="text-[10px] text-muted-foreground mb-3">Extrai dados estruturados de páginas usando schema JSON ou prompt de IA</p>
                {firecrawlConfig.jsonExtractEnabled && (
                  <div className="space-y-4">
                    <div className="space-y-1.5">
                      <Label className="text-xs font-medium">Prompt de Extração</Label>
                      <Textarea
                        value={firecrawlConfig.jsonExtractPrompt}
                        onChange={(e) => setFirecrawlConfig(prev => ({ ...prev, jsonExtractPrompt: e.target.value }))}
                        placeholder="Extraia o nome do produto, preço e descrição desta página..."
                        className="text-xs min-h-[60px]"
                      />
                      <p className="text-[10px] text-muted-foreground">Descreva o que deseja extrair em linguagem natural</p>
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-xs font-medium">Schema JSON (opcional)</Label>
                      <Textarea
                        value={firecrawlConfig.jsonExtractSchema}
                        onChange={(e) => setFirecrawlConfig(prev => ({ ...prev, jsonExtractSchema: e.target.value }))}
                        placeholder={'{\n  "product_name": "string",\n  "price": "number",\n  "description": "string"\n}'}
                        className="text-xs min-h-[80px] font-mono"
                      />
                      <p className="text-[10px] text-muted-foreground">Define a estrutura dos dados a extrair</p>
                    </div>
                  </div>
                )}
              </Card>

              {/* Branding */}
              <Card className="p-5">
                <h4 className="font-semibold mb-4 flex items-center gap-2">
                  🎨 Branding — Identidade Visual
                  <div className="ml-auto">
                    <Switch
                      checked={firecrawlConfig.brandingEnabled}
                      onCheckedChange={(v) => setFirecrawlConfig(prev => ({ ...prev, brandingEnabled: v }))}
                    />
                  </div>
                </h4>
                <p className="text-[10px] text-muted-foreground">
                  {firecrawlConfig.brandingEnabled
                    ? "✅ Ativo — Extrai cores, fontes, tipografia, espaçamentos, componentes e logos de qualquer site"
                    : "Desativado — Ative para extrair identidade visual completa de websites dos competidores"
                  }
                </p>
              </Card>

              <a href="https://docs.firecrawl.dev" target="_blank" rel="noopener noreferrer" className="text-xs text-primary hover:underline inline-flex items-center gap-1">
                <ExternalLink className="h-3 w-3" /> Documentação do Firecrawl
              </a>
            </TabsContent>

            <div className="flex justify-end gap-3 pt-4 border-t mt-4">
              <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
              <Button onClick={handleSave} disabled={saving}>
                {saving ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Salvando...</> : "Salvar Configurações"}
              </Button>
            </div>
          </Tabs>
        )}
      </DialogContent>
    </Dialog>
  )
}
