import { useState } from "react"
import { CookieHelpModal } from "./cookie-help-modal"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  BarChart3,
  Lightbulb,
  Users,
  Film,
  Smartphone,
  Brain,
  Database,
  Send,
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  Video,
  Images,
  ImageIcon,
  Sparkles,
  PlaySquare,
  Sliders,
  Settings,
  History,
  Share2,
  ShieldCheck,
  GitBranch,
  FileText,
  PenLine,
  RefreshCw,
  Save,
  AlertTriangle,
  Tag,
  Search,
  Square,
  HelpCircle,
  Zap,
  TrendingUp,
  Mic,
  AlertCircle,
  Calendar,
} from "lucide-react"

interface DatabaseItem {
  id: string
  label: string
  icon: React.ReactNode
  count: number
}

interface SidebarProps {
  databases: DatabaseItem[]
  activeDatabase: string | null
  onDatabaseSelect: (id: string) => void
  onGenerateReport: () => void
  onGenerateIdeas: () => void
  onOpenIntegrations: () => void
  onGenerateVideo: () => void
  onGenerateReel: () => void
  onGenerateCarrossel: () => void
  onGeneratePost: () => void
  onGenerateStory: () => void
  onGenerateScript: () => void
  onGenerateCopy: () => void
  onOpenParameters: () => void
  onOpenAgentSettings: () => void
  onOpenHistory: () => void
  onOpenPublishQueue: () => void
  onOpenAllowedSenders: () => void
  onOpenWorkflowFlow: () => void
  onOpenArchitecture: () => void
  onOpenNicheSettings: () => void
  onPollDms: () => void
  onOpenPipeline: () => void
  onOpenViral: () => void
  onOpenAgentStudio: () => void
  onOpenToneOfVoice: () => void
  onOpenSherlock: () => void
  onOpenCheckpoints: () => void
  checkpointCount?: number
  onOpenPlanning: () => void
  onDeepScanDms: () => void
  onStopDeepScan: () => void
  onOpenDeepScanSettings: () => void
  onUpdateSessionId: (sessionId: string) => void
  pendingQueueCount?: number
  pollingDms?: boolean
  pipelineRunning?: boolean
  systemStatus: {
    minio: "online" | "offline" | "checking"
    n8n: "online" | "offline" | "checking"
    apis: "online" | "offline" | "checking"
    instagramDms: "online" | "offline" | "checking" | "expired"
  }
}

export function Sidebar({
  databases,
  activeDatabase,
  onDatabaseSelect,
  onGenerateReport,
  onGenerateIdeas,
  onOpenIntegrations,
  onGenerateVideo,
  onGenerateReel,
  onGenerateCarrossel,
  onGeneratePost,
  onGenerateStory,
  onGenerateScript,
  onGenerateCopy,
  onOpenParameters,
  onOpenAgentSettings,
  onOpenHistory,
  onOpenPublishQueue,
  onOpenAllowedSenders,
  onOpenWorkflowFlow,
  onOpenArchitecture,
  onOpenNicheSettings,
  onPollDms,
  onOpenPipeline,
  onOpenViral,
  onOpenAgentStudio,
  onOpenToneOfVoice,
  onOpenSherlock,
  onOpenCheckpoints,
  checkpointCount = 0,
  onOpenPlanning,
  onDeepScanDms,
  onStopDeepScan,
  onOpenDeepScanSettings,
  onUpdateSessionId,
  pendingQueueCount = 0,
  pollingDms = false,
  pipelineRunning = false,
  systemStatus,
}: SidebarProps) {
  const [sessionInput, setSessionInput] = useState("")
  const [showSessionField, setShowSessionField] = useState(false)
  const [collapsed, setCollapsed] = useState(false)
  const [cookieHelpOpen, setCookieHelpOpen] = useState(false)
  const getStatusColor = (status: "online" | "offline" | "checking" | "expired") => {
    switch (status) {
      case "online": return "bg-emerald-500"
      case "offline": return "bg-red-500"
      case "expired": return "bg-orange-500 animate-pulse"
      case "checking": return "bg-amber-500 animate-pulse"
    }
  }

  const getStatusText = (status: "online" | "offline" | "checking" | "expired") => {
    switch (status) {
      case "online": return "Online"
      case "offline": return "Offline"
      case "expired": return "Cookie Expirado"
      case "checking": return "Verificando..."
    }
  }

  const SidebarButton = ({ label, icon, onClick, className, badge, badgePulse }: { label: string; icon: React.ReactNode; onClick: () => void; className?: string; badge?: string; badgePulse?: boolean }) => {
    const btn = (
      <Button variant="ghost" className={cn("w-full justify-start gap-3 relative", collapsed && "justify-center px-2", className)} onClick={onClick}>
        {icon}
        {!collapsed && <span>{label}</span>}
        {badge && (
          <span className={cn("ml-auto inline-flex items-center rounded-full bg-primary/15 px-1.5 py-0.5 text-xs font-medium text-primary", badgePulse && "animate-pulse")}>
            {badge}
          </span>
        )}
        {badge && collapsed && (
          <span className={cn("absolute -top-0.5 -right-0.5 h-2.5 w-2.5 rounded-full bg-primary", badgePulse && "animate-pulse")} />
        )}
      </Button>
    );
    if (!collapsed) return btn;
    return (
      <Tooltip>
        <TooltipTrigger asChild>{btn}</TooltipTrigger>
        <TooltipContent side="right">{label} {badge ? `(${badge})` : ""}</TooltipContent>
      </Tooltip>
    );
  };

  const DbButton = ({ db }: { db: DatabaseItem }) => {
    const btn = (
      <Button
        variant={activeDatabase === db.id ? "secondary" : "ghost"}
        className={cn(
          "w-full justify-start gap-3",
          collapsed && "justify-center px-2",
          activeDatabase === db.id && "bg-sidebar-accent text-sidebar-accent-foreground"
        )}
        onClick={() => onDatabaseSelect(db.id)}
      >
        <span className="shrink-0">{db.icon}</span>
        {!collapsed && (
          <>
            <span className="flex-1 truncate text-left">{db.label}</span>
            <Badge variant="secondary" className="ml-auto">{db.count}</Badge>
          </>
        )}
      </Button>
    );
    if (!collapsed) return btn;
    return (
      <Tooltip>
        <TooltipTrigger asChild>{btn}</TooltipTrigger>
        <TooltipContent side="right">{db.label}</TooltipContent>
      </Tooltip>
    );
  };

  return (
    <TooltipProvider delayDuration={0}>
      <aside
        className={cn(
          "flex h-screen flex-col border-r border-border bg-sidebar text-sidebar-foreground transition-all duration-300",
          collapsed ? "w-16" : "w-64"
        )}
      >
        {/* Logo */}
        <div className="flex items-center gap-3 border-b border-sidebar-border p-4">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <span className="text-xl">🪓</span>
          </div>
          {!collapsed && (
            <div className="overflow-hidden">
              <h1 className="font-bold text-lg">IG OS v3</h1>
              <p className="text-xs text-muted-foreground">Instagram Analytics</p>
            </div>
          )}
          <Button
            variant="ghost"
            size="icon"
            className="ml-auto h-8 w-8 shrink-0"
            onClick={() => setCollapsed(!collapsed)}
          >
            {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
          </Button>
        </div>

        {/* Scrollable content */}
        <div className="flex-1 overflow-y-auto min-h-0">
          {/* Pipeline */}
          <div className="p-4">
            {!collapsed && (
              <h2 className="mb-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Pipeline
              </h2>
            )}
            <div className="space-y-1">
              <SidebarButton label="⚡ Pipeline" icon={<Zap className="h-4 w-4 shrink-0" />} onClick={onOpenPipeline} />
              <SidebarButton label="🔥 Ranking Viral" icon={<TrendingUp className="h-4 w-4 shrink-0" />} onClick={onOpenViral} />
              <div className="relative">
                <SidebarButton label="Fila de Publicação" icon={<Send className="h-4 w-4 shrink-0" />} onClick={onOpenPublishQueue} />
                {pendingQueueCount > 0 && (
                  <Badge className={cn(
                    "absolute top-1 bg-destructive text-destructive-foreground text-[10px] px-1.5 py-0 min-w-[18px] h-[18px] flex items-center justify-center",
                    collapsed ? "right-0.5" : "right-2"
                  )}>
                    {pendingQueueCount}
                  </Badge>
                )}
              </div>
              <div className="relative">
                <SidebarButton label="Checkpoints" icon={<AlertCircle className="h-4 w-4 shrink-0" />} onClick={onOpenCheckpoints} />
                {checkpointCount > 0 && (
                  <Badge className={cn(
                    "absolute top-1 bg-yellow-500 text-black text-[10px] px-1.5 py-0 min-w-[18px] h-[18px] flex items-center justify-center",
                    collapsed ? "right-0.5" : "right-2"
                  )}>
                    {checkpointCount}
                  </Badge>
                )}
              </div>
              <SidebarButton label="Gerar Relatorio" icon={<BarChart3 className="h-4 w-4 shrink-0" />} onClick={onGenerateReport} badge={pipelineRunning ? "⏳" : undefined} badgePulse={pipelineRunning} />
              <SidebarButton label="Gerar Ideias" icon={<Lightbulb className="h-4 w-4 shrink-0" />} onClick={onGenerateIdeas} />
            </div>
          </div>

          {/* Agentes & Config */}
          <div className="border-t border-sidebar-border p-4">
            {!collapsed && (
              <h2 className="mb-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Agentes & Config
              </h2>
            )}
            <div className="space-y-1">
              <SidebarButton label="🤖 Agent Studio" icon={<Brain className="h-4 w-4 shrink-0" />} onClick={onOpenAgentStudio} />
              <SidebarButton label="🎙️ Tom de Voz" icon={<Mic className="h-4 w-4 shrink-0" />} onClick={onOpenToneOfVoice} />
              <SidebarButton label="🔍 Sherlock" icon={<Search className="h-4 w-4 shrink-0" />} onClick={onOpenSherlock} />
              <SidebarButton label="Histórico IA" icon={<History className="h-4 w-4 shrink-0" />} onClick={onOpenHistory} />
              <SidebarButton label="Integrações" icon={<Share2 className="h-4 w-4 shrink-0" />} onClick={onOpenIntegrations} />
              <SidebarButton label="Config. de Nicho" icon={<Tag className="h-4 w-4 shrink-0" />} onClick={onOpenNicheSettings} />
              <SidebarButton label="Usuários Autorizados" icon={<ShieldCheck className="h-4 w-4 shrink-0" />} onClick={onOpenAllowedSenders} />
              <SidebarButton label="Fluxo" icon={<GitBranch className="h-4 w-4 shrink-0" />} onClick={onOpenWorkflowFlow} className="text-primary" />
              <SidebarButton label="Arquitetura" icon={<Database className="h-4 w-4 shrink-0" />} onClick={onOpenArchitecture} className="text-primary" />
            </div>
          </div>

          {/* Gerar com IA */}
          <div className="border-t border-sidebar-border p-4">
            {!collapsed && (
              <h2 className="mb-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Gerar com IA
              </h2>
            )}
            <div className="space-y-1">
              <SidebarButton label="Gerar Video" icon={<Video className="h-4 w-4 shrink-0" />} onClick={onGenerateVideo} />
              <SidebarButton label="Gerar Reel" icon={<PlaySquare className="h-4 w-4 shrink-0" />} onClick={onGenerateReel} />
              <SidebarButton label="Gerar Carrossel" icon={<Images className="h-4 w-4 shrink-0" />} onClick={onGenerateCarrossel} />
              <SidebarButton label="Gerar Post" icon={<ImageIcon className="h-4 w-4 shrink-0" />} onClick={onGeneratePost} />
              <SidebarButton label="Gerar Story" icon={<Sparkles className="h-4 w-4 shrink-0" />} onClick={onGenerateStory} />
              <SidebarButton label="Gerar Roteiro" icon={<FileText className="h-4 w-4 shrink-0" />} onClick={onGenerateScript} />
              <SidebarButton label="Gerar Copy" icon={<PenLine className="h-4 w-4 shrink-0" />} onClick={onGenerateCopy} />
              <div className="my-2 border-t border-sidebar-border" />
              <SidebarButton label="Parametros" icon={<Sliders className="h-4 w-4 shrink-0" />} onClick={onOpenParameters} className="text-primary" />
            </div>
          </div>

          {/* Databases */}
          <div className="border-t border-sidebar-border p-4">
            {!collapsed && (
              <h2 className="mb-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Databases
              </h2>
            )}
            <div className="space-y-1">
              {databases.map((db) => (
                <DbButton key={db.id} db={db} />
              ))}
            </div>
          </div>
        </div>
        <div className="border-t border-sidebar-border p-4">
          {!collapsed && (
            <h2 className="mb-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Status do Sistema
            </h2>
          )}
          <div className="space-y-2">
            {[
              { label: "MinIO", status: systemStatus.minio },
              { label: "N8N", status: systemStatus.n8n },
              { label: "APIs IA", status: systemStatus.apis },
            ].map((item) => {
              const statusDot = (
                <div key={item.label} className={cn("flex items-center justify-between", collapsed && "justify-center")}>
                  <div className="flex items-center gap-2">
                    <span className={cn("h-2 w-2 rounded-full", getStatusColor(item.status))} />
                    {!collapsed && <span className="text-sm">{item.label}</span>}
                  </div>
                  {!collapsed && (
                    <span className="text-xs text-muted-foreground">{getStatusText(item.status)}</span>
                  )}
                </div>
              );
              if (!collapsed) return statusDot;
              return (
                <Tooltip key={item.label}>
                  <TooltipTrigger asChild>{statusDot}</TooltipTrigger>
                  <TooltipContent side="right">{item.label}: {getStatusText(item.status)}</TooltipContent>
                </Tooltip>
              );
            })}

            {/* IG DMs interactive status */}
            <div className={cn("flex flex-col gap-1", collapsed && "items-center")}>
              <div className={cn("flex items-center justify-between", collapsed && "justify-center")}>
                <div className="flex items-center gap-2">
                  <span className={cn("h-2 w-2 rounded-full", getStatusColor(systemStatus.instagramDms))} />
                  {!collapsed && <span className="text-sm">IG DMs</span>}
                </div>
                {!collapsed && (
                  <div className="flex items-center gap-1">
                    <span className="text-xs text-muted-foreground">{getStatusText(systemStatus.instagramDms)}</span>
                    <Button variant="ghost" size="icon" className="h-5 w-5" onClick={onPollDms} disabled={pollingDms} title="Poll rápido">
                      <RefreshCw className={cn("h-3 w-3", pollingDms && "animate-spin")} />
                    </Button>
                    {pollingDms ? (
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button variant="destructive" size="icon" className="h-7 w-7" onClick={onStopDeepScan}>
                            <Square className="h-3.5 w-3.5" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent side="top" className="font-medium">
                          <p>⏹ Parar Deep Scan</p>
                        </TooltipContent>
                      </Tooltip>
                    ) : (
                      <>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button variant="outline" size="icon" className="h-7 w-7 border-primary/30 bg-primary/5 hover:bg-primary/10" onClick={onDeepScanDms} disabled={pollingDms}>
                              <Search className="h-4 w-4 text-primary" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent side="top" className="font-medium">
                            <p>🔍 Deep Scan</p>
                            <p className="text-xs text-muted-foreground">Busca TODAS as mensagens dos usuários autorizados</p>
                          </TooltipContent>
                        </Tooltip>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onOpenDeepScanSettings}>
                              <Settings className="h-3.5 w-3.5" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent side="top" className="font-medium">
                            <p>⚙️ Configurar Deep Scan</p>
                          </TooltipContent>
                        </Tooltip>
                      </>
                    )}
                  </div>
                )}
              </div>
              {!collapsed && (systemStatus.instagramDms === "expired" || systemStatus.instagramDms === "offline") && (
                <div className="space-y-1.5 mt-1">
                  <div className="flex items-center gap-1 text-[10px] text-destructive">
                    <AlertTriangle className="h-3 w-3" />
                    <span>Cookie expirado — cole os cookies completos</span>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-4 w-4 p-0 ml-0.5" onClick={() => setCookieHelpOpen(true)}>
                          <HelpCircle className="h-3 w-3 text-muted-foreground hover:text-primary" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent side="top">Como obter os cookies</TooltipContent>
                    </Tooltip>
                  </div>
                  {!showSessionField ? (
                    <Button variant="outline" size="sm" className="w-full h-6 text-[10px]" onClick={() => setShowSessionField(true)}>
                      Atualizar Cookies
                    </Button>
                  ) : (
                    <div className="flex gap-1">
                      <Input
                        value={sessionInput}
                        onChange={(e) => setSessionInput(e.target.value)}
                        placeholder="Cole TODOS os cookies aqui"
                        className="h-6 text-[10px] flex-1"
                        type="password"
                      />
                      <Button
                        variant="default"
                        size="icon"
                        className="h-6 w-6 shrink-0"
                        disabled={!sessionInput.trim()}
                        onClick={() => {
                          onUpdateSessionId(sessionInput.trim())
                          setSessionInput("")
                          setShowSessionField(false)
                        }}
                      >
                        <Save className="h-3 w-3" />
                      </Button>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
          {!collapsed && (
            <p className="mt-4 text-xs text-muted-foreground">
              Atualizado: {new Date().toLocaleTimeString("pt-BR")}
            </p>
          )}
        </div>
      </aside>
      <CookieHelpModal open={cookieHelpOpen} onOpenChange={setCookieHelpOpen} />
    </TooltipProvider>
  )
}

export const defaultDatabases: DatabaseItem[] = [
  { id: "competidores", label: "Lista de Competidores", icon: <Users className="h-4 w-4" />, count: 0 },
  { id: "reels-competidores", label: "Reels dos Competidores", icon: <Film className="h-4 w-4" />, count: 0 },
  { id: "meus-reels", label: "Meus Reels", icon: <Smartphone className="h-4 w-4" />, count: 0 },
  { id: "estrategia", label: "Estrategia de Conteudo", icon: <Brain className="h-4 w-4" />, count: 0 },
  { id: "conteudo", label: "Database de Conteudo", icon: <Database className="h-4 w-4" />, count: 0 },
]
