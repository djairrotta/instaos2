import { useState, useEffect } from "react"
import { supabase } from "@/integrations/supabase/client"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import { Loader2, CheckCircle2, RefreshCw, Save, Sparkles } from "lucide-react"

const SIX_TONES = [
  { id: "revelador",              name: "Revelador",              emoji: "💡", desc: "Dado surpresa → contexto → implicação → reflexão" },
  { id: "comparativo",            name: "Comparativo",            emoji: "⚖️",  desc: "Cenário A vs B → diferença concreta → o que fazer" },
  { id: "passo_a_passo",          name: "Passo a Passo",          emoji: "📋", desc: "Problema → N passos numerados → resultado → CTA" },
  { id: "pergunta_incomoda",      name: "Pergunta Incômoda",      emoji: "🤔", desc: "Pergunta dissonante → dados → nuance → nova perspectiva" },
  { id: "tendencia_oportunidade", name: "Tendência+Oportunidade", emoji: "📈", desc: "Evidência de mudança → velocidade → quem aproveita → ação" },
  { id: "checklist_diagnostico",  name: "Checklist/Diagnóstico",  emoji: "✅", desc: "Critérios → análise → diagnóstico → próximo passo" },
]

export function ToneOfVoiceSetup({ onSaved }: { onSaved?: () => void }) {
  const [form, setForm] = useState({
    profile_name: "@djairrotta",
    niche: "Advogado especialista em direito bancário. Público: adultos com dívidas e problemas com bancos.",
    tone_rules: "",
    vocabulary_use: "",
    vocabulary_avoid: "",
    approved_sample: "",
  })
  const [activeTones, setActiveTones] = useState(SIX_TONES.map(t => t.id))
  const [generating, setGenerating] = useState(false)
  const [samples, setSamples] = useState<any[]>([])
  const [topic, setTopic] = useState("juros abusivos no cartão de crédito")
  const [approvedToneId, setApprovedToneId] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => { loadExisting() }, [])

  async function loadExisting() {
    setLoading(true)
    const { data: { session } } = await supabase.auth.getSession()
    if (!session) { setLoading(false); return }
    try {
      const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/tone-of-voice`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session.access_token}` },
        body: JSON.stringify({ action: "get" }),
      })
      const d = await res.json()
      if (d.toneOfVoice) {
        const t = d.toneOfVoice
        setForm({
          profile_name: t.profile_name || "@djairrotta",
          niche: t.niche || "",
          tone_rules: t.tone_rules || "",
          vocabulary_use: t.vocabulary_use || "",
          vocabulary_avoid: t.vocabulary_avoid || "",
          approved_sample: t.approved_sample || "",
        })
        if (t.active_tones) setActiveTones(t.active_tones)
      }
    } finally { setLoading(false) }
  }

  async function generateSamples() {
    if (!topic.trim()) { toast.error("Digite um tema para gerar amostras"); return }
    setGenerating(true)
    setSamples([])
    const { data: { session } } = await supabase.auth.getSession()
    try {
      const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/tone-of-voice`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.access_token}` },
        body: JSON.stringify({ action: "generate_samples", topic, niche: form.niche, profileName: form.profile_name }),
      })
      const d = await res.json()
      if (d.success) { setSamples(d.samples); toast.success("Amostras geradas!") }
      else throw new Error(d.error)
    } catch (e: any) { toast.error(e.message) }
    finally { setGenerating(false) }
  }

  async function approveSample(toneId: string, sampleText: string) {
    const { data: { session } } = await supabase.auth.getSession()
    try {
      await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/tone-of-voice`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.access_token}` },
        body: JSON.stringify({ action: "approve_sample", toneId, approvedText: sampleText, topic }),
      })
      setApprovedToneId(toneId)
      setForm(p => ({ ...p, approved_sample: sampleText }))
      toast.success("Tom aprovado como referência!")
    } catch (e: any) { toast.error(e.message) }
  }

  async function save() {
    setSaving(true)
    const { data: { session } } = await supabase.auth.getSession()
    try {
      const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/tone-of-voice`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.access_token}` },
        body: JSON.stringify({ action: "save", ...form, activeTones }),
      })
      const d = await res.json()
      if (d.success) { toast.success("Tom de voz salvo!"); onSaved?.() }
      else throw new Error(d.error)
    } catch (e: any) { toast.error(e.message) }
    finally { setSaving(false) }
  }

  const set = (k: string) => (e: any) => setForm(p => ({ ...p, [k]: e.target.value }))

  if (loading) return <div className="flex items-center justify-center py-12"><Loader2 className="w-5 h-5 animate-spin text-yellow-400" /></div>

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h2 className="text-xl font-bold flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-yellow-400" />
          Tom de Voz
        </h2>
        <p className="text-sm text-muted-foreground mt-1">
          Defina o estilo de comunicação que será injetado em todos os agentes de geração
        </p>
      </div>

      {/* Profile */}
      <div className="grid grid-cols-2 gap-4 p-4 rounded-xl border border-border bg-card">
        <div>
          <Label className="text-xs mb-1 block">Perfil</Label>
          <Input value={form.profile_name} onChange={set("profile_name")} className="text-xs" placeholder="@djairrotta" />
        </div>
        <div>
          <Label className="text-xs mb-1 block">Nicho / Descrição</Label>
          <Input value={form.niche} onChange={set("niche")} className="text-xs" placeholder="Advogado especialista em..." />
        </div>
      </div>

      {/* Active tones */}
      <div>
        <Label className="text-xs mb-2 block">6 Tons Ativos (OpenSquad)</Label>
        <div className="grid grid-cols-2 gap-2">
          {SIX_TONES.map(t => (
            <button key={t.id} onClick={() => setActiveTones(p => p.includes(t.id) ? p.filter(x => x !== t.id) : [...p, t.id])}
              className={cn("flex items-start gap-2.5 p-2.5 rounded-lg border text-left transition-all text-xs",
                activeTones.includes(t.id) ? "border-yellow-500/50 bg-yellow-500/5 text-foreground" : "border-border text-muted-foreground hover:border-yellow-500/20"
              )}>
              <span className="text-base flex-shrink-0">{t.emoji}</span>
              <div>
                <div className="font-semibold">{t.name}</div>
                <div className="text-[10px] text-muted-foreground mt-0.5">{t.desc}</div>
              </div>
              {activeTones.includes(t.id) && <CheckCircle2 className="w-3.5 h-3.5 text-yellow-400 ml-auto flex-shrink-0 mt-0.5" />}
            </button>
          ))}
        </div>
      </div>

      {/* Sample generator */}
      <div className="p-4 rounded-xl border border-border bg-card space-y-3">
        <p className="text-sm font-semibold">Gerar Amostras por Tom</p>
        <p className="text-xs text-muted-foreground">A IA vai gerar um gancho para cada tom. Você aprova o que mais se parece com sua voz.</p>
        <div className="flex gap-2">
          <Input value={topic} onChange={e => setTopic(e.target.value)} placeholder="Tema: ex. juros abusivos no cartão" className="text-xs flex-1" />
          <Button onClick={generateSamples} disabled={generating} size="sm" variant="outline" className="gap-1.5 text-xs">
            {generating ? <Loader2 className="w-3 h-3 animate-spin" /> : <RefreshCw className="w-3 h-3" />}
            Gerar
          </Button>
        </div>

        {samples.length > 0 && (
          <div className="space-y-2 mt-2">
            {samples.map(s => {
              const tone = SIX_TONES.find(t => t.id === s.toneId)
              const isApproved = approvedToneId === s.toneId
              return (
                <div key={s.toneId} className={cn("rounded-lg border p-3 transition-all",
                  isApproved ? "border-green-500/40 bg-green-500/5" : "border-border bg-muted/10"
                )}>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-sm">{tone?.emoji}</span>
                    <span className="text-xs font-semibold">{s.toneName}</span>
                    {isApproved && <Badge variant="outline" className="text-[9px] text-green-400 border-green-500/30 ml-auto">✓ Aprovado</Badge>}
                  </div>
                  <p className="text-xs text-foreground/90 italic leading-relaxed mb-2">"{s.sample}"</p>
                  {!isApproved && (
                    <Button size="sm" variant="outline" onClick={() => approveSample(s.toneId, s.sample)}
                      className="text-[10px] h-6 px-2 border-yellow-500/30 hover:bg-yellow-500/10 hover:text-yellow-400">
                      ✓ Aprovar este tom
                    </Button>
                  )}
                </div>
              )
            })}
          </div>
        )}
      </div>

      {/* Approved sample */}
      <div>
        <Label className="text-xs mb-1 block">Amostra Aprovada (referência de qualidade)</Label>
        <p className="text-[10px] text-muted-foreground mb-1.5">Texto que será usado como padrão mínimo pelos agentes de geração</p>
        <Textarea value={form.approved_sample} onChange={set("approved_sample")} rows={4} className="text-xs"
          placeholder="Cole aqui um exemplo de conteúdo seu que você considera excelente..." />
      </div>

      {/* Rules */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label className="text-xs mb-1 block">Vocabulário — SEMPRE USE</Label>
          <Textarea value={form.vocabulary_use} onChange={set("vocabulary_use")} rows={3} className="text-xs"
            placeholder="Dados mostram... | Na prática: | O detalhe que muda tudo:" />
        </div>
        <div>
          <Label className="text-xs mb-1 block">Vocabulário — NUNCA USE</Label>
          <Textarea value={form.vocabulary_avoid} onChange={set("vocabulary_avoid")} rows={3} className="text-xs"
            placeholder="Incrível, fantástico | Todo mundo sabe que... | Neste carrossel vou te mostrar..." />
        </div>
      </div>

      <div>
        <Label className="text-xs mb-1 block">Regras de Tom Adicionais</Label>
        <Textarea value={form.tone_rules} onChange={set("tone_rules")} rows={3} className="text-xs"
          placeholder="1. Dado real com fonte sempre que possível&#10;2. Contexto revelador que surpreende&#10;3. Zero copy vazia..." />
      </div>

      <Button onClick={save} disabled={saving} className="w-full gap-2 bg-yellow-500 hover:bg-yellow-400 text-black font-semibold">
        {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
        Salvar Tom de Voz
      </Button>
    </div>
  )
}
