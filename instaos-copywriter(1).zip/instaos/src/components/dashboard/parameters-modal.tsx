import { useState, useCallback, useRef, useEffect } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Upload, X, FileText, Film, Music, User, Video, ImageIcon, Maximize2, Minimize2,
  Mic, MicOff, Play, Pause, Trash2, Loader2, CheckCircle2, Square, FileAudio, RefreshCw,
  Eye, Clapperboard
} from "lucide-react"
import { toast } from "sonner"
import { cn } from "@/lib/utils"
import { supabase } from "@/integrations/supabase/client"

interface ParametersModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

interface VoiceFile {
  id: string; name: string; size: number; duration?: number
  minioPath?: string; localUrl?: string; isUploading?: boolean; isFromMinio?: boolean
}

interface MediaFile {
  id: string; name: string; size: number; type: "image" | "video"
  category: "face" | "body" | "style" | "reference"
  minioPath?: string; localUrl?: string; isUploading?: boolean; isFromMinio?: boolean
}

type VisualCategory = "face" | "body" | "style" | "reference"
type ActiveTab = VisualCategory | "voice"

const VISUAL_CATEGORIES = {
  face: { icon: <User className="h-4 w-4" />, title: "Face / Rosto", description: "Fotos do rosto para avatar e lip-sync", accept: "image/*" },
  body: { icon: <ImageIcon className="h-4 w-4" />, title: "Corpo / Pose", description: "Fotos de corpo inteiro para animação", accept: "image/*" },
  style: { icon: <Video className="h-4 w-4" />, title: "Vídeos de Referência", description: "Vídeos para replicar estilo e movimentos", accept: "video/*" },
  reference: { icon: <Clapperboard className="h-4 w-4" />, title: "Referências Gerais", description: "Outros arquivos de referência visual", accept: "image/*,video/*" },
} as const

export function ParametersModal({ open, onOpenChange }: ParametersModalProps) {
  const [isMaximized, setIsMaximized] = useState(false)
  const [activeTab, setActiveTab] = useState<ActiveTab>("face")

  // Media files (animation agent)
  const [mediaFiles, setMediaFiles] = useState<MediaFile[]>([])
  const [loadingMedia, setLoadingMedia] = useState(false)
  const [previewFile, setPreviewFile] = useState<MediaFile | null>(null)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)
  const [previewLoading, setPreviewLoading] = useState(false)
  const mediaFileInputRef = useRef<HTMLInputElement>(null)

  // Voice state
  const [voiceFiles, setVoiceFiles] = useState<VoiceFile[]>([])
  const [isRecording, setIsRecording] = useState(false)
  const [recordingTime, setRecordingTime] = useState(0)
  const [playingId, setPlayingId] = useState<string | null>(null)
  const [loadingVoice, setLoadingVoice] = useState(false)
  const [voiceSubTab, setVoiceSubTab] = useState("record")
  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const chunksRef = useRef<Blob[]>([])
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const voiceFileInputRef = useRef<HTMLInputElement>(null)

  // Notes
  const [notes, setNotes] = useState("")

  // Load media + voice on open
  useEffect(() => {
    if (!open) return
    loadMediaFiles()
  }, [open])

  useEffect(() => {
    if (open && activeTab === "voice") loadVoiceFiles()
  }, [open, activeTab])

  // ─── Media (Animation) MinIO Logic ───────────────────────
  const loadMediaFiles = async () => {
    setLoadingMedia(true)
    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return
      const categories: VisualCategory[] = ["face", "body", "style", "reference"]
      const allFiles: MediaFile[] = []
      for (const cat of categories) {
        const { data } = await supabase.functions.invoke("save-to-minio", {
          body: { action: "list", path: `paradigmas/${user.id}/animacao/${cat}/` },
        })
        if (data?.success && data.files?.length > 0) {
          data.files.forEach((f: any) => {
            const name = f.key.split("/").pop() || f.key
            const isVideo = /\.(mp4|mov|webm|avi)$/i.test(name)
            allFiles.push({ id: f.key, name, size: f.size, type: isVideo ? "video" : "image", category: cat, minioPath: f.key, isFromMinio: true })
          })
        }
      }
      setMediaFiles(allFiles)
    } catch (e: any) {
      console.error("Error loading media files:", e)
    } finally {
      setLoadingMedia(false)
    }
  }

  const uploadMediaToMinio = async (file: MediaFile, blob: Blob) => {
    setMediaFiles(prev => prev.map(f => f.id === file.id ? { ...f, isUploading: true } : f))
    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) throw new Error("Não autenticado")
      const reader = new FileReader()
      reader.onload = async () => {
        const base64 = (reader.result as string).split(",")[1]
        const path = `paradigmas/${user.id}/animacao/${file.category}/${file.name}`
        const { data, error } = await supabase.functions.invoke("save-to-minio", { body: { action: "save", path, data: base64 } })
        if (error || !data?.success) throw new Error(data?.error || "Upload failed")
        setMediaFiles(prev => prev.map(f => f.id === file.id ? { ...f, isUploading: false, minioPath: path, isFromMinio: true } : f))
        toast.success("Arquivo salvo!", { description: file.name })
      }
      reader.readAsDataURL(blob)
    } catch (e: any) {
      setMediaFiles(prev => prev.map(f => f.id === file.id ? { ...f, isUploading: false } : f))
      toast.error("Erro ao salvar", { description: e.message })
    }
  }

  const handleMediaUpload = (files: File[]) => {
    const cat = activeTab as VisualCategory
    for (const file of files) {
      const isImage = file.type.startsWith("image/")
      const isVideo = file.type.startsWith("video/")
      if (!isImage && !isVideo) { toast.error(`${file.name}: formato não suportado`); continue }
      const url = URL.createObjectURL(file)
      const newFile: MediaFile = { id: Math.random().toString(36).substr(2, 9), name: file.name, size: file.size, type: isVideo ? "video" : "image", category: cat, localUrl: url }
      setMediaFiles(prev => [...prev, newFile])
      uploadMediaToMinio(newFile, file)
    }
  }

  const handleMediaDelete = async (file: MediaFile) => {
    if (file.minioPath) { try { await supabase.functions.invoke("save-to-minio", { body: { action: "delete", path: file.minioPath } }) } catch { /* ignore */ } }
    if (file.localUrl) URL.revokeObjectURL(file.localUrl)
    setMediaFiles(prev => prev.filter(f => f.id !== file.id))
    if (previewFile?.id === file.id) { setPreviewFile(null); setPreviewUrl(null) }
    toast.success("Arquivo removido")
  }

  const handleMediaPreview = async (file: MediaFile) => {
    if (file.localUrl) { setPreviewFile(file); setPreviewUrl(file.localUrl); return }
    if (file.minioPath) {
      setPreviewLoading(true); setPreviewFile(file)
      try {
        const { data, error } = await supabase.functions.invoke("save-to-minio", { body: { action: "get", path: file.minioPath } })
        if (error || !data?.success) throw new Error("Download failed")
        const mimeType = file.type === "video" ? "video/mp4" : "image/jpeg"
        setPreviewUrl(`data:${mimeType};base64,${data.content}`)
      } catch { toast.error("Erro ao carregar preview"); setPreviewFile(null) }
      finally { setPreviewLoading(false) }
    }
  }

  const getCategoryMediaFiles = (cat: VisualCategory) => mediaFiles.filter(f => f.category === cat)

  // ─── Voice MinIO Logic ───────────────────────────────────
  const loadVoiceFiles = async () => {
    setLoadingVoice(true)
    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return
      const { data, error } = await supabase.functions.invoke("save-to-minio", { body: { action: "list", path: `paradigmas/${user.id}/voz/` } })
      if (error) throw error
      if (data?.success && data.files?.length > 0) {
        setVoiceFiles(data.files.map((f: any) => ({ id: f.key, name: f.key.split("/").pop() || f.key, size: f.size, minioPath: f.key, isFromMinio: true })))
      }
    } catch (e: any) { console.error("Error loading voice files:", e) }
    finally { setLoadingVoice(false) }
  }

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mediaRecorder = new MediaRecorder(stream, { mimeType: "audio/webm" })
      mediaRecorderRef.current = mediaRecorder; chunksRef.current = []
      mediaRecorder.ondataavailable = (e) => { if (e.data.size > 0) chunksRef.current.push(e.data) }
      mediaRecorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: "audio/webm" })
        const url = URL.createObjectURL(blob)
        const fileName = `gravacao_${new Date().toISOString().replace(/[:.]/g, "-")}.webm`
        const newFile: VoiceFile = { id: Math.random().toString(36).substr(2, 9), name: fileName, size: blob.size, duration: recordingTime, localUrl: url }
        setVoiceFiles(prev => [...prev, newFile])
        uploadVoiceToMinio(newFile, blob)
        stream.getTracks().forEach(t => t.stop())
      }
      mediaRecorder.start(1000); setIsRecording(true); setRecordingTime(0)
      timerRef.current = setInterval(() => setRecordingTime(t => t + 1), 1000)
      toast.success("Gravação iniciada!")
    } catch (e: any) { toast.error("Erro ao acessar microfone", { description: e.message }) }
  }

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop(); setIsRecording(false)
      if (timerRef.current) clearInterval(timerRef.current)
      toast.success("Gravação salva!")
    }
  }

  const uploadVoiceToMinio = async (file: VoiceFile, blob: Blob) => {
    setVoiceFiles(prev => prev.map(f => f.id === file.id ? { ...f, isUploading: true } : f))
    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) throw new Error("Não autenticado")
      const reader = new FileReader()
      reader.onload = async () => {
        const base64 = (reader.result as string).split(",")[1]
        const path = `paradigmas/${user.id}/voz/${file.name}`
        const { data, error } = await supabase.functions.invoke("save-to-minio", { body: { action: "save", path, data: base64 } })
        if (error || !data?.success) throw new Error(data?.error || "Upload failed")
        setVoiceFiles(prev => prev.map(f => f.id === file.id ? { ...f, isUploading: false, minioPath: path, isFromMinio: true } : f))
        toast.success("Áudio salvo!", { description: file.name })
      }
      reader.readAsDataURL(blob)
    } catch (e: any) {
      setVoiceFiles(prev => prev.map(f => f.id === file.id ? { ...f, isUploading: false } : f))
      toast.error("Erro ao salvar áudio", { description: e.message })
    }
  }

  const handleVoiceFileUpload = (files: File[]) => {
    for (const file of files) {
      if (!file.type.startsWith("audio/")) { toast.error(`${file.name} não é um arquivo de áudio`); continue }
      const url = URL.createObjectURL(file)
      const newFile: VoiceFile = { id: Math.random().toString(36).substr(2, 9), name: file.name, size: file.size, localUrl: url }
      setVoiceFiles(prev => [...prev, newFile])
      uploadVoiceToMinio(newFile, file)
    }
  }

  const handleVoiceDelete = async (file: VoiceFile) => {
    if (file.minioPath) { try { await supabase.functions.invoke("save-to-minio", { body: { action: "delete", path: file.minioPath } }) } catch { /* ignore */ } }
    if (file.localUrl) URL.revokeObjectURL(file.localUrl)
    setVoiceFiles(prev => prev.filter(f => f.id !== file.id))
    toast.success("Áudio removido")
  }

  const handleVoicePlay = async (file: VoiceFile) => {
    if (playingId === file.id) { audioRef.current?.pause(); setPlayingId(null); return }
    let url = file.localUrl
    if (!url && file.minioPath) {
      try {
        const { data, error } = await supabase.functions.invoke("save-to-minio", { body: { action: "get", path: file.minioPath } })
        if (error || !data?.success) throw new Error("Download failed")
        url = `data:audio/webm;base64,${data.content}`
      } catch { toast.error("Erro ao carregar áudio"); return }
    }
    if (!url) return
    if (audioRef.current) audioRef.current.pause()
    const audio = new Audio(url); audioRef.current = audio
    audio.onended = () => setPlayingId(null); audio.play(); setPlayingId(file.id)
  }

  // ─── Helpers ─────────────────────────────────────────────
  const formatFileSize = (bytes: number) => {
    if (bytes >= 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + " MB"
    if (bytes >= 1024) return (bytes / 1024).toFixed(1) + " KB"
    return bytes + " B"
  }

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60).toString().padStart(2, "0")
    const s = (seconds % 60).toString().padStart(2, "0")
    return `${m}:${s}`
  }

  // ─── Visual category tab content ────────────────────────
  const renderVisualTab = (cat: VisualCategory) => {
    const config = VISUAL_CATEGORIES[cat]
    const files = getCategoryMediaFiles(cat)
    return (
      <TabsContent key={cat} value={cat} className="space-y-4 mt-4">
        <div className="flex items-start gap-3 p-4 bg-muted/50 rounded-lg">
          <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">{config.icon}</div>
          <div><h3 className="font-semibold">{config.title}</h3><p className="text-sm text-muted-foreground">{config.description}</p></div>
        </div>

        <div
          className="border-2 border-dashed rounded-lg p-8 text-center transition-colors cursor-pointer border-border hover:border-primary/50"
          onClick={() => mediaFileInputRef.current?.click()}
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => { e.preventDefault(); handleMediaUpload(Array.from(e.dataTransfer.files)) }}
        >
          <Upload className="h-10 w-10 mx-auto mb-3 text-muted-foreground" />
          <p className="text-sm font-medium mb-1">Arraste arquivos aqui ou clique</p>
          <p className="text-xs text-muted-foreground">{cat === "style" || cat === "reference" ? "Imagens e vídeos" : "Imagens (JPG, PNG, WebP)"}</p>
          <Button type="button" variant="outline" size="sm" className="mt-3">Selecionar Arquivos</Button>
          <input ref={mediaFileInputRef} type="file" multiple className="hidden" accept={config.accept} onChange={(e) => handleMediaUpload(Array.from(e.target.files || []))} />
        </div>

        {loadingMedia ? (
          <div className="flex items-center justify-center py-8"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
        ) : files.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {files.map((file) => (
              <Card key={file.id} className="overflow-hidden group relative">
                <div className="aspect-square bg-muted flex items-center justify-center relative">
                  {file.localUrl && file.type === "image" ? (
                    <img src={file.localUrl} alt={file.name} className="w-full h-full object-cover" />
                  ) : file.localUrl && file.type === "video" ? (
                    <video src={file.localUrl} className="w-full h-full object-cover" muted />
                  ) : (
                    <div className="flex flex-col items-center gap-1 text-muted-foreground">
                      {file.type === "video" ? <Film className="h-8 w-8" /> : <ImageIcon className="h-8 w-8" />}
                    </div>
                  )}
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                    <Button variant="secondary" size="icon" className="h-8 w-8" onClick={() => handleMediaPreview(file)}><Eye className="h-4 w-4" /></Button>
                    <Button variant="destructive" size="icon" className="h-8 w-8" onClick={() => handleMediaDelete(file)}><Trash2 className="h-4 w-4" /></Button>
                  </div>
                  {file.isUploading && (
                    <div className="absolute inset-0 bg-background/80 flex items-center justify-center"><Loader2 className="h-6 w-6 animate-spin" /></div>
                  )}
                  <Badge variant="secondary" className="absolute top-1 left-1 text-[10px] h-4 px-1">
                    {file.type === "video" ? <Film className="h-2.5 w-2.5 mr-0.5" /> : <ImageIcon className="h-2.5 w-2.5 mr-0.5" />}
                    {file.type}
                  </Badge>
                </div>
                <div className="p-2">
                  <p className="text-xs font-medium truncate">{file.name}</p>
                  <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
                    <span>{formatFileSize(file.size)}</span>
                    {file.isFromMinio && !file.isUploading && <CheckCircle2 className="h-2.5 w-2.5 text-emerald-500" />}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="p-8 text-center">
            {config.icon}
            <p className="text-sm font-medium mt-2">Nenhum arquivo em {config.title}</p>
            <p className="text-xs text-muted-foreground mt-1">Faça upload para começar</p>
          </Card>
        )}
      </TabsContent>
    )
  }

  // ─── Voice tab content ──────────────────────────────────
  const renderVoiceTab = () => (
    <TabsContent value="voice" className="space-y-4 mt-4">
      <div className="flex items-start gap-3 p-4 bg-muted/50 rounded-lg">
        <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0"><Music className="h-4 w-4" /></div>
        <div><h3 className="font-semibold">Voz / Áudio</h3><p className="text-sm text-muted-foreground">Grave, faça upload ou gerencie amostras de voz para clonagem e narração com IA</p></div>
      </div>

      <Tabs value={voiceSubTab} onValueChange={setVoiceSubTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="record" className="gap-2"><Mic className="h-4 w-4" /><span className="hidden sm:inline">Gravar</span></TabsTrigger>
          <TabsTrigger value="upload" className="gap-2"><Upload className="h-4 w-4" /><span className="hidden sm:inline">Upload</span></TabsTrigger>
          <TabsTrigger value="library" className="gap-2"><Music className="h-4 w-4" /><span className="hidden sm:inline">Biblioteca</span></TabsTrigger>
        </TabsList>

        <TabsContent value="record" className="space-y-4 mt-4">
          <Card className="p-6 flex flex-col items-center gap-4">
            <div className={cn("h-24 w-24 rounded-full flex items-center justify-center transition-all", isRecording ? "bg-destructive/10 border-2 border-destructive animate-pulse" : "bg-muted border-2 border-border")}>
              {isRecording ? <MicOff className="h-10 w-10 text-destructive" /> : <Mic className="h-10 w-10 text-muted-foreground" />}
            </div>
            {isRecording && (
              <div className="text-center">
                <p className="text-2xl font-mono font-bold">{formatTime(recordingTime)}</p>
                <div className="flex items-center gap-2 mt-1 justify-center"><div className="h-2 w-2 rounded-full bg-destructive animate-pulse" /><span className="text-xs text-destructive">REC</span></div>
              </div>
            )}
            <div className="flex gap-3">
              {!isRecording ? (
                <Button onClick={startRecording} className="gap-2"><Mic className="h-4 w-4" /> Iniciar Gravação</Button>
              ) : (
                <Button variant="destructive" onClick={stopRecording} className="gap-2"><Square className="h-4 w-4" /> Parar</Button>
              )}
            </div>
            <p className="text-xs text-muted-foreground text-center max-w-md">Grave amostras da sua voz. Recomendado: pelo menos 30s de áudio limpo.</p>
          </Card>
        </TabsContent>

        <TabsContent value="upload" className="space-y-4 mt-4">
          <div className="border-2 border-dashed rounded-lg p-8 text-center transition-colors cursor-pointer border-border hover:border-primary/50"
            onClick={() => voiceFileInputRef.current?.click()}
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => { e.preventDefault(); handleVoiceFileUpload(Array.from(e.dataTransfer.files)) }}
          >
            <FileAudio className="h-10 w-10 mx-auto mb-3 text-muted-foreground" />
            <p className="text-sm font-medium mb-1">Arraste arquivos de áudio aqui ou clique</p>
            <p className="text-xs text-muted-foreground mb-3">MP3, WAV, M4A, OGG, WebM</p>
            <Button type="button" variant="outline" size="sm">Selecionar Arquivos</Button>
            <input ref={voiceFileInputRef} type="file" multiple className="hidden" accept="audio/*" onChange={(e) => handleVoiceFileUpload(Array.from(e.target.files || []))} />
          </div>
        </TabsContent>

        <TabsContent value="library" className="space-y-4 mt-4">
          <div className="flex items-center justify-between">
            <div><h3 className="font-semibold text-sm">Suas Amostras de Voz</h3><p className="text-xs text-muted-foreground">{voiceFiles.length} arquivo(s)</p></div>
            <Button variant="outline" size="sm" onClick={loadVoiceFiles} disabled={loadingVoice} className="gap-1.5">
              {loadingVoice ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />} Atualizar
            </Button>
          </div>
          {loadingVoice ? (
            <div className="flex items-center justify-center py-8"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
          ) : voiceFiles.length === 0 ? (
            <Card className="p-6 text-center"><Music className="h-10 w-10 mx-auto mb-2 text-muted-foreground" /><p className="text-sm font-medium">Nenhuma amostra de voz</p><p className="text-xs text-muted-foreground mt-1">Grave ou faça upload de áudios</p></Card>
          ) : (
            <div className="space-y-2">
              {voiceFiles.map((file) => (
                <Card key={file.id} className="p-3">
                  <div className="flex items-center gap-3">
                    <Button variant="ghost" size="icon" className="h-9 w-9 shrink-0" onClick={() => handleVoicePlay(file)} disabled={file.isUploading}>
                      {playingId === file.id ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                    </Button>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{file.name}</p>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <span>{formatFileSize(file.size)}</span>
                        {file.duration && <span>• {formatTime(file.duration)}</span>}
                        {file.isUploading && <Badge variant="secondary" className="text-[10px] gap-1"><Loader2 className="h-2.5 w-2.5 animate-spin" /> Enviando...</Badge>}
                        {file.isFromMinio && !file.isUploading && <Badge variant="outline" className="text-[10px] gap-1"><CheckCircle2 className="h-2.5 w-2.5" /> MinIO</Badge>}
                      </div>
                    </div>
                    <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0 text-muted-foreground hover:text-destructive" onClick={() => handleVoiceDelete(file)}><Trash2 className="h-4 w-4" /></Button>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </TabsContent>
  )

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent showCloseButton={false} className="overflow-y-auto" style={isMaximized ? { maxWidth: '96vw', width: '96vw', height: '96vh', maxHeight: '96vh' } : { maxWidth: '64rem', maxHeight: '90vh' }}>
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle className="flex items-center gap-2 text-2xl"><Upload className="h-6 w-6" />Parâmetros de Geração</DialogTitle>
              <DialogDescription>Configure os paradigmas que a IA usará para criar conteúdo personalizado</DialogDescription>
            </div>
            <div className="flex items-center gap-1">
              <Button variant="ghost" size="icon" onClick={() => setIsMaximized(!isMaximized)}>{isMaximized ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}</Button>
              <Button variant="ghost" size="icon" onClick={() => onOpenChange(false)}><X className="h-4 w-4" /></Button>
            </div>
          </div>
        </DialogHeader>

        <div className="space-y-6 mt-4">
          <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as ActiveTab)}>
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="face" className="gap-2"><User className="h-4 w-4" /><span className="hidden sm:inline">Face</span></TabsTrigger>
              <TabsTrigger value="body" className="gap-2"><ImageIcon className="h-4 w-4" /><span className="hidden sm:inline">Corpo</span></TabsTrigger>
              <TabsTrigger value="voice" className="gap-2"><Music className="h-4 w-4" /><span className="hidden sm:inline">Voz</span></TabsTrigger>
              <TabsTrigger value="style" className="gap-2"><Video className="h-4 w-4" /><span className="hidden sm:inline">Estilo</span></TabsTrigger>
              <TabsTrigger value="reference" className="gap-2"><Clapperboard className="h-4 w-4" /><span className="hidden sm:inline">Refs</span></TabsTrigger>
            </TabsList>

            {(["face", "body", "style", "reference"] as VisualCategory[]).map(renderVisualTab)}
            {renderVoiceTab()}
          </Tabs>

          {/* Summary */}
          <div className="border rounded-lg p-4 bg-muted/30">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold">Resumo dos Paradigmas</h3>
              <Button variant="outline" size="sm" onClick={() => { loadMediaFiles(); if (activeTab === "voice") loadVoiceFiles() }} disabled={loadingMedia} className="gap-1.5">
                {loadingMedia ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />} Atualizar
              </Button>
            </div>
            <div className="grid grid-cols-5 gap-4 text-center">
              <div><p className="text-2xl font-bold">{getCategoryMediaFiles("face").length}</p><p className="text-xs text-muted-foreground">Face</p></div>
              <div><p className="text-2xl font-bold">{getCategoryMediaFiles("body").length}</p><p className="text-xs text-muted-foreground">Corpo</p></div>
              <div><p className="text-2xl font-bold">{voiceFiles.length}</p><p className="text-xs text-muted-foreground">Voz</p></div>
              <div><p className="text-2xl font-bold">{getCategoryMediaFiles("style").length}</p><p className="text-xs text-muted-foreground">Estilo</p></div>
              <div><p className="text-2xl font-bold">{getCategoryMediaFiles("reference").length}</p><p className="text-xs text-muted-foreground">Refs</p></div>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Instruções Adicionais (opcional)</Label>
            <Textarea placeholder="Ex: Sempre usar foto em alta resolução, manter tom calmo..." value={notes} onChange={(e) => setNotes(e.target.value)} rows={3} className="resize-none" />
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
            <Button onClick={() => { toast.success("Paradigmas salvos!"); onOpenChange(false) }}>Salvar Paradigmas</Button>
          </div>
        </div>

        {/* Preview Modal */}
        {previewFile && (
          <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-8" onClick={() => { setPreviewFile(null); setPreviewUrl(null) }}>
            <div className="max-w-4xl max-h-[80vh] relative" onClick={(e) => e.stopPropagation()}>
              <Button variant="ghost" size="icon" className="absolute -top-10 right-0 text-white hover:bg-white/20" onClick={() => { setPreviewFile(null); setPreviewUrl(null) }}><X className="h-5 w-5" /></Button>
              {previewLoading ? <Loader2 className="h-8 w-8 animate-spin text-white" /> : previewUrl ? (
                previewFile.type === "video" ? <video src={previewUrl} controls className="max-h-[80vh] rounded-lg" /> : <img src={previewUrl} alt={previewFile.name} className="max-h-[80vh] rounded-lg object-contain" />
              ) : null}
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
