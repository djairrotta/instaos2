import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Search, Globe, Map, Loader2, Copy, ExternalLink, Maximize2, Minimize2 } from "lucide-react"
import { toast } from "sonner"
import { supabase } from "@/integrations/supabase/client"
import ReactMarkdown from "react-markdown"

interface FirecrawlToolsModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

type ResultData = any

export function FirecrawlToolsModal({ open, onOpenChange }: FirecrawlToolsModalProps) {
  const [isMaximized, setIsMaximized] = useState(false)
  const [loading, setLoading] = useState(false)

  // Search state
  const [searchQuery, setSearchQuery] = useState("")
  const [searchLimit, setSearchLimit] = useState(5)
  const [searchLang, setSearchLang] = useState("pt-br")
  const [searchCountry, setSearchCountry] = useState("BR")
  const [searchScrape, setSearchScrape] = useState(false)
  const [searchResult, setSearchResult] = useState<ResultData>(null)

  // Map state
  const [mapUrl, setMapUrl] = useState("")
  const [mapSearch, setMapSearch] = useState("")
  const [mapLimit, setMapLimit] = useState(100)
  const [mapSubdomains, setMapSubdomains] = useState(false)
  const [mapResult, setMapResult] = useState<ResultData>(null)

  // Crawl state
  const [crawlUrl, setCrawlUrl] = useState("")
  const [crawlLimit, setCrawlLimit] = useState(10)
  const [crawlDepth, setCrawlDepth] = useState(2)
  const [crawlInclude, setCrawlInclude] = useState("")
  const [crawlExclude, setCrawlExclude] = useState("")
  const [crawlResult, setCrawlResult] = useState<ResultData>(null)

  const handleSearch = async () => {
    if (!searchQuery.trim()) return toast.error("Informe um termo de busca")
    setLoading(true)
    setSearchResult(null)
    try {
      const { data, error } = await supabase.functions.invoke("firecrawl-search", {
        body: {
          query: searchQuery,
          options: {
            limit: searchLimit,
            lang: searchLang,
            country: searchCountry,
            ...(searchScrape ? { scrapeOptions: { formats: ["markdown"] } } : {}),
          },
        },
      })
      if (error) throw error
      setSearchResult(data)
      toast.success(`Busca concluída — ${data?.data?.length || 0} resultados`)
    } catch (e: any) {
      toast.error("Erro na busca", { description: e.message })
    } finally {
      setLoading(false)
    }
  }

  const handleMap = async () => {
    if (!mapUrl.trim()) return toast.error("Informe uma URL")
    setLoading(true)
    setMapResult(null)
    try {
      const { data, error } = await supabase.functions.invoke("firecrawl-map", {
        body: {
          url: mapUrl,
          options: {
            limit: mapLimit,
            search: mapSearch || undefined,
            includeSubdomains: mapSubdomains,
          },
        },
      })
      if (error) throw error
      setMapResult(data)
      toast.success(`Map concluído — ${data?.links?.length || 0} URLs encontradas`)
    } catch (e: any) {
      toast.error("Erro no map", { description: e.message })
    } finally {
      setLoading(false)
    }
  }

  const handleCrawl = async () => {
    if (!crawlUrl.trim()) return toast.error("Informe uma URL")
    setLoading(true)
    setCrawlResult(null)
    try {
      const { data, error } = await supabase.functions.invoke("firecrawl-crawl", {
        body: {
          url: crawlUrl,
          options: {
            limit: crawlLimit,
            maxDepth: crawlDepth,
            ...(crawlInclude ? { includePaths: crawlInclude.split(",").map(s => s.trim()) } : {}),
            ...(crawlExclude ? { excludePaths: crawlExclude.split(",").map(s => s.trim()) } : {}),
          },
        },
      })
      if (error) throw error
      setCrawlResult(data)
      toast.success(`Crawl iniciado — ${data?.status || "processing"}`)
    } catch (e: any) {
      toast.error("Erro no crawl", { description: e.message })
    } finally {
      setLoading(false)
    }
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast.success("Copiado!")
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className={isMaximized ? "max-w-[95vw] h-[95vh]" : "max-w-3xl max-h-[85vh]"}>
        <DialogHeader>
          <div className="flex items-center justify-between pr-8">
            <DialogTitle className="flex items-center gap-2">
              🔥 Firecrawl Tools
            </DialogTitle>
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setIsMaximized(!isMaximized)}>
              {isMaximized ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
            </Button>
          </div>
        </DialogHeader>

        <Tabs defaultValue="search" className="flex-1">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="search" className="gap-1.5"><Search className="h-3.5 w-3.5" /> Search</TabsTrigger>
            <TabsTrigger value="map" className="gap-1.5"><Map className="h-3.5 w-3.5" /> Map</TabsTrigger>
            <TabsTrigger value="crawl" className="gap-1.5"><Globe className="h-3.5 w-3.5" /> Crawl</TabsTrigger>
          </TabsList>

          {/* SEARCH */}
          <TabsContent value="search" className="mt-4 space-y-4">
            <div className="grid gap-3 md:grid-cols-2">
              <div className="space-y-1.5 md:col-span-2">
                <Label className="text-xs">Termo de busca</Label>
                <Input value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder="Ex: melhores ferramentas de marketing digital 2026" className="text-sm" onKeyDown={e => e.key === "Enter" && handleSearch()} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Limite de resultados</Label>
                <Input type="number" value={searchLimit} onChange={e => setSearchLimit(+e.target.value || 5)} min={1} max={100} className="text-sm" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Idioma / País</Label>
                <div className="flex gap-2">
                  <Input value={searchLang} onChange={e => setSearchLang(e.target.value)} placeholder="pt-br" className="text-sm flex-1" />
                  <Input value={searchCountry} onChange={e => setSearchCountry(e.target.value)} placeholder="BR" className="text-sm w-20" />
                </div>
              </div>
              <div className="flex items-center gap-2 md:col-span-2">
                <Switch checked={searchScrape} onCheckedChange={setSearchScrape} />
                <Label className="text-xs">Scrape conteúdo dos resultados (retorna markdown completo)</Label>
              </div>
            </div>
            <Button onClick={handleSearch} disabled={loading} className="w-full">
              {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Search className="h-4 w-4 mr-2" />}
              Buscar
            </Button>

            {searchResult && (
              <ScrollArea className={isMaximized ? "h-[55vh]" : "h-[300px]"}>
                <div className="space-y-3">
                  {(searchResult.data || []).map((item: any, i: number) => (
                    <Card key={i} className="p-3 space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{item.title || "Sem título"}</p>
                          <p className="text-xs text-muted-foreground truncate">{item.url}</p>
                        </div>
                        <div className="flex gap-1 shrink-0">
                          <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => copyToClipboard(item.url)}>
                            <Copy className="h-3 w-3" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-6 w-6" asChild>
                            <a href={item.url} target="_blank" rel="noopener noreferrer"><ExternalLink className="h-3 w-3" /></a>
                          </Button>
                        </div>
                      </div>
                      {item.description && <p className="text-xs text-muted-foreground">{item.description}</p>}
                      {item.markdown && (
                        <details className="text-xs">
                          <summary className="cursor-pointer text-primary font-medium">Ver conteúdo</summary>
                          <div className="mt-2 prose prose-xs dark:prose-invert max-w-none max-h-40 overflow-y-auto rounded bg-muted p-2">
                            <ReactMarkdown>{item.markdown.slice(0, 3000)}</ReactMarkdown>
                          </div>
                        </details>
                      )}
                    </Card>
                  ))}
                  {(!searchResult.data || searchResult.data.length === 0) && (
                    <p className="text-sm text-center text-muted-foreground py-4">Nenhum resultado encontrado</p>
                  )}
                </div>
              </ScrollArea>
            )}
          </TabsContent>

          {/* MAP */}
          <TabsContent value="map" className="mt-4 space-y-4">
            <div className="grid gap-3 md:grid-cols-2">
              <div className="space-y-1.5 md:col-span-2">
                <Label className="text-xs">URL do site</Label>
                <Input value={mapUrl} onChange={e => setMapUrl(e.target.value)} placeholder="https://exemplo.com" className="text-sm" onKeyDown={e => e.key === "Enter" && handleMap()} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Filtrar por keyword</Label>
                <Input value={mapSearch} onChange={e => setMapSearch(e.target.value)} placeholder="blog, pricing..." className="text-sm" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Limite de URLs</Label>
                <Input type="number" value={mapLimit} onChange={e => setMapLimit(+e.target.value || 100)} min={1} max={5000} className="text-sm" />
              </div>
              <div className="flex items-center gap-2 md:col-span-2">
                <Switch checked={mapSubdomains} onCheckedChange={setMapSubdomains} />
                <Label className="text-xs">Incluir subdomínios</Label>
              </div>
            </div>
            <Button onClick={handleMap} disabled={loading} className="w-full">
              {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Map className="h-4 w-4 mr-2" />}
              Mapear Site
            </Button>

            {mapResult && (
              <ScrollArea className={isMaximized ? "h-[55vh]" : "h-[300px]"}>
                <div className="space-y-1">
                  <div className="flex items-center justify-between mb-2">
                    <Badge variant="secondary">{mapResult.links?.length || 0} URLs</Badge>
                    <Button variant="outline" size="sm" className="h-7 text-xs" onClick={() => copyToClipboard((mapResult.links || []).join("\n"))}>
                      <Copy className="h-3 w-3 mr-1" /> Copiar todas
                    </Button>
                  </div>
                  {(mapResult.links || []).map((url: string, i: number) => (
                    <div key={i} className="flex items-center gap-2 py-1 px-2 rounded hover:bg-muted text-xs group">
                      <span className="text-muted-foreground w-6 shrink-0">{i + 1}.</span>
                      <span className="truncate flex-1 font-mono">{url}</span>
                      <Button variant="ghost" size="icon" className="h-5 w-5 opacity-0 group-hover:opacity-100" onClick={() => copyToClipboard(url)}>
                        <Copy className="h-3 w-3" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-5 w-5 opacity-0 group-hover:opacity-100" asChild>
                        <a href={url} target="_blank" rel="noopener noreferrer"><ExternalLink className="h-3 w-3" /></a>
                      </Button>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            )}
          </TabsContent>

          {/* CRAWL */}
          <TabsContent value="crawl" className="mt-4 space-y-4">
            <div className="grid gap-3 md:grid-cols-2">
              <div className="space-y-1.5 md:col-span-2">
                <Label className="text-xs">URL para crawl</Label>
                <Input value={crawlUrl} onChange={e => setCrawlUrl(e.target.value)} placeholder="https://exemplo.com" className="text-sm" onKeyDown={e => e.key === "Enter" && handleCrawl()} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Limite de páginas</Label>
                <Input type="number" value={crawlLimit} onChange={e => setCrawlLimit(+e.target.value || 10)} min={1} max={500} className="text-sm" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Profundidade máxima</Label>
                <Input type="number" value={crawlDepth} onChange={e => setCrawlDepth(+e.target.value || 2)} min={1} max={10} className="text-sm" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Include paths (separados por vírgula)</Label>
                <Input value={crawlInclude} onChange={e => setCrawlInclude(e.target.value)} placeholder="/blog, /docs" className="text-sm" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Exclude paths (separados por vírgula)</Label>
                <Input value={crawlExclude} onChange={e => setCrawlExclude(e.target.value)} placeholder="/admin, /api" className="text-sm" />
              </div>
            </div>
            <Button onClick={handleCrawl} disabled={loading} className="w-full">
              {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Globe className="h-4 w-4 mr-2" />}
              Iniciar Crawl
            </Button>

            {crawlResult && (
              <ScrollArea className={isMaximized ? "h-[55vh]" : "h-[300px]"}>
                <div className="space-y-3">
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge variant="secondary">Status: {crawlResult.status || "processing"}</Badge>
                    {crawlResult.completed != null && <Badge variant="outline">{crawlResult.completed}/{crawlResult.total} páginas</Badge>}
                    {crawlResult.creditsUsed != null && <Badge variant="outline">{crawlResult.creditsUsed} créditos</Badge>}
                  </div>
                  {(crawlResult.data || []).map((page: any, i: number) => (
                    <Card key={i} className="p-3 space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{page.metadata?.title || `Página ${i + 1}`}</p>
                          <p className="text-xs text-muted-foreground truncate">{page.metadata?.sourceURL}</p>
                        </div>
                        <div className="flex gap-1 shrink-0">
                          {page.markdown && (
                            <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => copyToClipboard(page.markdown)}>
                              <Copy className="h-3 w-3" />
                            </Button>
                          )}
                          {page.metadata?.sourceURL && (
                            <Button variant="ghost" size="icon" className="h-6 w-6" asChild>
                              <a href={page.metadata.sourceURL} target="_blank" rel="noopener noreferrer"><ExternalLink className="h-3 w-3" /></a>
                            </Button>
                          )}
                        </div>
                      </div>
                      {page.markdown && (
                        <details className="text-xs">
                          <summary className="cursor-pointer text-primary font-medium">Ver conteúdo</summary>
                          <div className="mt-2 prose prose-xs dark:prose-invert max-w-none max-h-40 overflow-y-auto rounded bg-muted p-2">
                            <ReactMarkdown>{page.markdown.slice(0, 3000)}</ReactMarkdown>
                          </div>
                        </details>
                      )}
                    </Card>
                  ))}
                  {(!crawlResult.data || crawlResult.data.length === 0) && crawlResult.id && (
                    <p className="text-sm text-center text-muted-foreground py-4">
                      Crawl em andamento (ID: {crawlResult.id}). Os resultados estarão disponíveis quando o processo terminar.
                    </p>
                  )}
                </div>
              </ScrollArea>
            )}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
