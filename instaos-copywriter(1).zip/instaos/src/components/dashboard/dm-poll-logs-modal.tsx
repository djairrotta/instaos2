import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { Minimize2, Maximize2, X, MessageCircle, Link, Users, Brain, Lightbulb, Shield, BarChart3, RefreshCw, User } from "lucide-react"
import { useState, useEffect, useRef } from "react"

interface DmPollLog {
  message: string
  type: "info" | "success" | "error" | "warn" | "phase" | "counter"
  timestamp: Date
}

interface DmPollStats {
  messagesChecked: number
  linksProcessed: number
  profilesScraped: number
  reelsClassified: number
  reelsAnalyzed: number
  ideasGenerated: number
  strategyGenerated: boolean
}

interface DeepScanProgress {
  currentExecution: number
  currentProfile: string
  currentProfileIndex: number
  totalProfiles: number
  isAutoRetrying: boolean
}

interface DmPollLogsModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  logs: DmPollLog[]
  isRunning: boolean
  stats: DmPollStats | null
  deepScanProgress?: DeepScanProgress | null
}

function getLogStyle(type: DmPollLog["type"]) {
  switch (type) {
    case "phase": return "text-blue-400 bg-blue-500/10 border-blue-500/20 font-semibold"
    case "success": return "text-green-400 bg-green-500/10 border-green-500/20"
    case "error": return "text-red-400 bg-red-500/10 border-red-500/20"
    case "warn": return "text-yellow-400 bg-yellow-500/10 border-yellow-500/20"
    case "counter": return "text-purple-400 bg-purple-500/10 border-purple-500/20"
    default: return "text-muted-foreground bg-muted/30 border-border/50"
  }
}

function StatCard({ icon: Icon, label, value, highlight }: { icon: any; label: string; value: number | string; highlight?: boolean }) {
  return (
    <div className={`flex items-center gap-2 rounded-lg border px-3 py-2 text-sm ${highlight ? "border-primary/40 bg-primary/10" : "border-border bg-muted/30"}`}>
      <Icon className={`h-4 w-4 ${highlight ? "text-primary" : "text-muted-foreground"}`} />
      <div>
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className={`font-bold text-base ${highlight ? "text-primary" : "text-foreground"}`}>{value}</p>
      </div>
    </div>
  )
}

export function DmPollLogsModal({ open, onOpenChange, logs, isRunning, stats, deepScanProgress }: DmPollLogsModalProps) {
  const [isMaximized, setIsMaximized] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [logs])

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className={`${isMaximized ? "!max-w-[95vw] !max-h-[95vh] !w-[95vw] !h-[95vh]" : "max-w-2xl max-h-[80vh]"} flex flex-col gap-0 p-0 overflow-hidden`}
        showCloseButton={false}
      >
        <DialogHeader className="px-4 py-3 border-b border-border flex flex-row items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <DialogTitle className="text-base font-semibold">
              📬 Poll DMs — Log em Tempo Real
            </DialogTitle>
            {isRunning && (
              <Badge variant="outline" className="animate-pulse text-xs border-primary text-primary">
                ⏳ Processando...
              </Badge>
            )}
            {!isRunning && stats && (
              <Badge variant="outline" className="text-xs border-green-500 text-green-500">
                ✅ Concluído
              </Badge>
            )}
          </div>
          <div className="flex items-center gap-1">
            <button onClick={() => setIsMaximized(!isMaximized)} className="p-1.5 rounded-md hover:bg-muted">
              {isMaximized ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
            </button>
            <button onClick={() => onOpenChange(false)} className="p-1.5 rounded-md hover:bg-muted">
              <X className="h-4 w-4" />
            </button>
          </div>
        </DialogHeader>

        {/* Deep Scan Progress Indicator */}
        {deepScanProgress && isRunning && (
          <div className="px-4 py-2.5 border-b border-border bg-primary/5 shrink-0">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1.5">
                  <User className="h-4 w-4 text-primary" />
                  <span className="text-sm font-medium text-foreground">
                    @{deepScanProgress.currentProfile}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    (perfil {deepScanProgress.currentProfileIndex}/{deepScanProgress.totalProfiles})
                  </span>
                </div>
                {deepScanProgress.isAutoRetrying && (
                  <Badge variant="outline" className="text-xs border-amber-500/50 text-amber-500 gap-1">
                    <RefreshCw className="h-3 w-3 animate-spin" />
                    Auto-retry
                  </Badge>
                )}
              </div>
              <div className="flex items-center gap-2">
                <Badge className="bg-primary/20 text-primary border-primary/30 text-xs font-mono">
                  Execução {deepScanProgress.currentExecution}
                </Badge>
              </div>
            </div>
            {/* Progress bar */}
            <div className="mt-2 h-1.5 rounded-full bg-muted overflow-hidden">
              <div
                className="h-full rounded-full bg-primary transition-all duration-500"
                style={{ width: `${(deepScanProgress.currentProfileIndex / deepScanProgress.totalProfiles) * 100}%` }}
              />
            </div>
          </div>
        )}

        {/* Stats cards */}
        {stats && (
          <div className="px-4 py-3 border-b border-border bg-muted/20 shrink-0">
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
              <StatCard icon={MessageCircle} label="Mensagens" value={stats.messagesChecked} />
              <StatCard icon={Link} label="Links" value={stats.linksProcessed} highlight={stats.linksProcessed > 0} />
              <StatCard icon={Users} label="Perfis" value={stats.profilesScraped} />
              <StatCard icon={Shield} label="Classificados" value={stats.reelsClassified} />
              <StatCard icon={Brain} label="Analisados IA" value={stats.reelsAnalyzed} />
              <StatCard icon={Lightbulb} label="Ideias" value={stats.ideasGenerated} highlight={stats.ideasGenerated > 0} />
            </div>
            {stats.strategyGenerated && (
              <div className="mt-2 flex items-center gap-2 text-xs text-green-500">
                <BarChart3 className="h-3.5 w-3.5" />
                Relatório estratégico auto-gerado!
              </div>
            )}
          </div>
        )}

        {/* Running stats counter */}
        {isRunning && !stats && (
          <div className="px-4 py-2 border-b border-border bg-muted/20 shrink-0 flex items-center gap-4 text-xs text-muted-foreground">
            <span className="animate-pulse">Aguardando resultados do servidor...</span>
          </div>
        )}

        {/* Logs */}
        <ScrollArea className="flex-1 min-h-0" ref={scrollRef}>
          <div className="p-3 space-y-1 font-mono text-xs">
            {logs.length === 0 && isRunning && (
              <p className="text-muted-foreground text-center py-8 animate-pulse">📨 Conectando ao Instagram DMs...</p>
            )}
            {logs.map((log, i) => (
              <div key={i} className={`px-2.5 py-1.5 rounded border ${getLogStyle(log.type)} leading-relaxed`}>
                <span className="text-muted-foreground/50 mr-2 select-none">
                  {log.timestamp.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
                </span>
                {log.message}
              </div>
            ))}
            {isRunning && logs.length > 0 && (
              <div className="px-2.5 py-1.5 rounded border border-border/50 text-muted-foreground animate-pulse">
                ⏳ Processando...
              </div>
            )}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  )
}

export type { DmPollLog, DmPollStats, DeepScanProgress }
