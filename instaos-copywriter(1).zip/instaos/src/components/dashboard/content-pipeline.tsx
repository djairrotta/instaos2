import { useState, useEffect, useCallback } from "react"
import { supabase } from "@/integrations/supabase/client"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import { ViralAnalysisPanel } from "@/components/dashboard/viral-analysis-panel"
import {
  Zap, MessageCircle, RefreshCw, ChevronRight, Copy, Send, Clock,
  CheckCircle2, XCircle, Loader2, Eye, Film, Images, ImageIcon,
  ArrowRight, Sparkles, AlertCircle, ExternalLink, Calendar,
  Users, Brain, Play, BarChart3,
} from "lucide-react"

// ─── Types ─────────────────────────────────────────────────────────────────
type PostSource = "dm" | "scraping"
type PipelineStage = "inbox" | "analyzing" | "paraphrase" | "queue"

interface CompetitorPost {
  id: string
  owner_username: string
  caption: string
  content_type: string
  thumbnail_url?: string
  url?: string
  views: number
  likes: number
  comments: number
  viral_score?: number
  hook_type?: string
  hook_analysis?: string
  adapted_hook?: string
  viral_analysis?: any
  relevance_status: string
  source?: PostSource
  created_at: string
  // analysis state in pipeline
  pipelineStage?: PipelineStage
  isAnalyzing?: boolean
}

interface QueueItem {
  id: string
  content_type: string
  caption?: string
  status: string
  carousel_slides?: any[]
  reel_script?: any[]
  viral_score?: number
  created_at: string
  ig_permalink?: string
  metadata?: any
  scheduled_at?: string
}

interface ParaphraseResult {
  postId: string
  carousel: { title: string; caption: string; slides: any[] } | null
  reel: { title: string; caption: string; script: any[] } | null
  isGenerating: boolean
  selectedFormat?: "carousel" | "reel"
}

// ─── Helpers ───────────────────────────────────────────────────────────────
function fmtNum(n: number) {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + "M"
  if (n >= 1_000) return (n / 1_000).toFixed(1) + "K"
  return String(n || 0)
}
function scoreColor(s: number) {
  if (s >= 75) return "text-green-400"
  if (s >= 50) return "text-yellow-400"
  if (s >= 30) return "text-orange-400"
  return "text-muted-foreground"
}
const HOOK_EMOJI: Record<string, string> = {
  Curiosidade:"🤔", Dor:"😣", Promessa:"✨", Choque:"😮",
  "Prova Social":"👥", Tendência:"📈", Urgência:"⏰",
}
const CONTENT_ICON: Record<string, React.ReactNode> = {
  reel: <Film className="w-3.5 h-3.5" />,
  carousel: <Images className="w-3.5 h-3.5" />,
  carrossel: <Images className="w-3.5 h-3.5" />,
  post: <ImageIcon className="w-3.5 h-3.5" />,
}

// ─── Lane header ───────────────────────────────────────────────────────────
function LaneHeader({ icon, title, count, subtitle, color = "text-muted-foreground" }: {
  icon: React.ReactNode; title: string; count: number; subtitle: string; color?: string
}) {
  return (
    <div className="flex items-start gap-3 pb-3 border-b border-border mb-3">
      <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center bg-muted/30", color)}>
        {icon}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <h3 className="font-semibold text-sm text-foreground">{title}</h3>
          <span className={cn("text-xs font-mono font-bold px-1.5 py-0.5 rounded-full", color, "bg-current/10")}>{count}</span>
        </div>
        <p className="text-[10px] text-muted-foreground mt-0.5">{subtitle}</p>
      </div>
    </div>
  )
}

// ─── Competitor post card (Inbox lane) ─────────────────────────────────────
function InboxCard({ post, onAnalyze, analyzing, onOpenAnalysis }: {
  post: CompetitorPost
  onAnalyze: (post: CompetitorPost) => void
  analyzing: boolean
  onOpenAnalysis: (id: string) => void
}) {
  const score = post.viral_score || 0

  return (
    <div className={cn(
      "rounded-xl border bg-card transition-all group",
      score >= 75 ? "border-green-500/20" : score >= 50 ? "border-yellow-500/15" : "border-border"
    )}>
      {/* Source badge + thumb row */}
      <div className="flex gap-2.5 p-3">
        <div className="relative flex-shrink-0">
          <div className="w-11 h-11 rounded-lg overflow-hidden bg-muted/20 border border-border">
            {post.thumbnail_url
              ? <img src={post.thumbnail_url} className="w-full h-full object-cover" alt=""
                  onError={e => { (e.target as HTMLImageElement).style.display = "none" }} />
              : <div className="w-full h-full flex items-center justify-center text-lg opacity-30">
                  {post.content_type === "reel" ? "🎬" : post.content_type?.includes("carousel") ? "🎠" : "📸"}
                </div>
            }
          </div>
          {/* source dot */}
          <div className={cn(
            "absolute -top-1 -right-1 w-4 h-4 rounded-full border-2 border-background flex items-center justify-center text-[8px]",
            post.source === "dm" ? "bg-blue-500" : "bg-green-500"
          )}>
            {post.source === "dm" ? "💬" : "🔄"}
          </div>
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 mb-0.5">
            <span className="text-[11px] font-semibold text-foreground truncate">@{post.owner_username}</span>
            <span className="flex items-center gap-0.5 text-[10px] text-muted-foreground flex-shrink-0">
              {CONTENT_ICON[post.content_type] || CONTENT_ICON.post}
            </span>
          </div>
          <p className="text-[10px] text-muted-foreground line-clamp-2 leading-snug">{post.caption || "(sem legenda)"}</p>
          <div className="flex items-center gap-2.5 mt-1 text-[9px] text-muted-foreground/60">
            <span>👁 {fmtNum(post.views)}</span>
            <span>❤ {fmtNum(post.likes)}</span>
            <span>💬 {fmtNum(post.comments)}</span>
          </div>
        </div>

        {/* Score */}
        {score > 0 && (
          <div className={cn("text-xs font-bold font-mono flex-shrink-0", scoreColor(score))}>{score}</div>
        )}
      </div>

      {/* Hook preview if analyzed */}
      {post.adapted_hook && (
        <div className="px-3 pb-2">
          <div className="flex items-start gap-1.5 rounded-lg bg-yellow-500/5 border border-yellow-500/15 px-2.5 py-1.5">
            <span className="text-[10px] flex-shrink-0">🎯</span>
            <p className="text-[10px] text-yellow-300/80 italic leading-snug line-clamp-2">"{post.adapted_hook}"</p>
            <button onClick={() => { navigator.clipboard.writeText(post.adapted_hook!); toast.success("Copiado!") }}
              className="text-muted-foreground hover:text-yellow-400 flex-shrink-0 ml-auto">
              <Copy className="w-3 h-3" />
            </button>
          </div>
        </div>
      )}

      {/* Action row */}
      <div className="px-3 pb-3 flex gap-1.5">
        {!score ? (
          <Button size="sm" onClick={() => onAnalyze(post)} disabled={analyzing}
            className="flex-1 h-7 text-[10px] gap-1 bg-yellow-500/20 text-yellow-400 border border-yellow-500/30 hover:bg-yellow-500/30">
            {analyzing ? <Loader2 className="w-3 h-3 animate-spin" /> : <Zap className="w-3 h-3" />}
            {analyzing ? "Analisando..." : "Analisar"}
          </Button>
        ) : (
          <Button size="sm" onClick={() => onAnalyze(post)} disabled={analyzing}
            className="flex-1 h-7 text-[10px] gap-1 bg-green-500/10 text-green-400 border border-green-500/20 hover:bg-green-500/20">
            {analyzing ? <Loader2 className="w-3 h-3 animate-spin" /> : <Brain className="w-3 h-3" />}
            {analyzing ? "Criando..." : "Criar conteúdo →"}
          </Button>
        )}
        {post.url && (
          <a href={post.url} target="_blank" rel="noreferrer"
            className="h-7 w-7 flex items-center justify-center rounded-md border border-border text-muted-foreground hover:text-foreground">
            <ExternalLink className="w-3 h-3" />
          </a>
        )}
      </div>
    </div>
  )
}

// ─── Paraphrase card (Analysis lane) ───────────────────────────────────────
function ParaphraseCard({ post, result, onSelectFormat, onAddToQueue }: {
  post: CompetitorPost
  result: ParaphraseResult
  onSelectFormat: (postId: string, format: "carousel" | "reel") => void
  onAddToQueue: (postId: string, format: "carousel" | "reel") => void
}) {
  const va = post.viral_analysis

  return (
    <div className="rounded-xl border border-border bg-card overflow-hidden">
      {/* Header */}
      <div className="px-3.5 pt-3.5 pb-2.5 border-b border-border/50">
        <div className="flex items-center gap-2 mb-1.5">
          <span className="text-[11px] font-semibold">@{post.owner_username}</span>
          {post.hook_type && (
            <Badge variant="outline" className="text-[9px] px-1.5 py-0 text-yellow-400 border-yellow-500/30">
              {HOOK_EMOJI[post.hook_type] || "🎯"} {post.hook_type}
            </Badge>
          )}
        </div>
        {/* Viral analysis summary */}
        {va && (
          <div className="space-y-1.5">
            {va.hook && (
              <div className="text-[10px] text-muted-foreground">
                <span className="text-muted-foreground/50 mr-1">Gancho:</span>
                <span className="italic">"{va.hook?.slice(0, 100)}"</span>
              </div>
            )}
            {va.power_words?.length > 0 && (
              <div className="flex flex-wrap gap-1">
                {va.power_words.slice(0, 4).map((w: string, i: number) => (
                  <span key={i} className="text-[9px] px-1.5 py-0.5 rounded bg-yellow-500/10 text-yellow-400 border border-yellow-500/15">{w}</span>
                ))}
              </div>
            )}
            {va.why_viral && (
              <p className="text-[10px] text-muted-foreground leading-snug">{va.why_viral.slice(0, 120)}</p>
            )}
          </div>
        )}
      </div>

      {/* Agente Publicitário output */}
      {result.isGenerating ? (
        <div className="p-4 flex flex-col items-center gap-2">
          <div className="flex items-center gap-2 text-yellow-400">
            <Loader2 className="w-4 h-4 animate-spin" />
            <span className="text-xs font-medium">Agente Publicitário criando...</span>
          </div>
          <p className="text-[10px] text-muted-foreground">Parafraseando e adaptando para o seu perfil</p>
        </div>
      ) : (
        <div className="p-3 space-y-3">
          {/* Format selector */}
          <div>
            <p className="text-[9px] uppercase tracking-widest text-muted-foreground/40 mb-2">Escolha o formato</p>
            <div className="grid grid-cols-2 gap-1.5">
              {(["carousel", "reel"] as const).map(fmt => (
                <button key={fmt} onClick={() => onSelectFormat(post.id, fmt)}
                  className={cn(
                    "flex flex-col items-center gap-1 p-2.5 rounded-lg border text-xs font-medium transition-all",
                    result.selectedFormat === fmt
                      ? "border-yellow-500/50 bg-yellow-500/10 text-yellow-400"
                      : "border-border text-muted-foreground hover:border-yellow-500/20 hover:text-foreground"
                  )}>
                  <span className="text-lg">{fmt === "carousel" ? "🎠" : "🎬"}</span>
                  {fmt === "carousel" ? "Carrossel" : "Vídeo/Reel"}
                  {fmt === "carousel" && result.carousel && (
                    <span className="text-[9px] text-green-400">✓ pronto</span>
                  )}
                  {fmt === "reel" && result.reel && (
                    <span className="text-[9px] text-green-400">✓ pronto</span>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Preview selected format */}
          {result.selectedFormat === "carousel" && result.carousel && (
            <div className="rounded-lg bg-muted/10 border border-border p-2.5 space-y-2">
              <p className="text-[9px] uppercase tracking-widest text-muted-foreground/40">Preview — Carrossel</p>
              <p className="text-[10px] font-semibold text-foreground">{result.carousel.title}</p>
              <div className="flex gap-1 overflow-x-auto pb-1">
                {(result.carousel.slides || []).slice(0, 4).map((s: any, i: number) => (
                  <div key={i} className="flex-shrink-0 w-20 h-20 rounded bg-yellow-500/5 border border-yellow-500/15 p-1.5 flex flex-col">
                    <span className="text-[8px] text-yellow-400/60 font-mono">{i + 1}</span>
                    <p className="text-[8px] text-foreground/80 leading-tight line-clamp-4 mt-0.5">{s.text || s.headline || ""}</p>
                  </div>
                ))}
              </div>
              <p className="text-[10px] text-muted-foreground line-clamp-2 italic">{result.carousel.caption?.slice(0, 100)}</p>
            </div>
          )}

          {result.selectedFormat === "reel" && result.reel && (
            <div className="rounded-lg bg-muted/10 border border-border p-2.5 space-y-2">
              <p className="text-[9px] uppercase tracking-widest text-muted-foreground/40">Preview — Reel</p>
              <p className="text-[10px] font-semibold text-foreground">{result.reel.title}</p>
              {(result.reel.script || []).slice(0, 2).map((seg: any, i: number) => (
                <div key={i} className="flex gap-2 text-[9px]">
                  <span className="text-yellow-400/60 font-mono flex-shrink-0">{seg.time || `${i * 10}s`}</span>
                  <p className="text-muted-foreground line-clamp-2">{seg.fala || seg.script || ""}</p>
                </div>
              ))}
            </div>
          )}

          {/* Add to queue */}
          {result.selectedFormat && (
            <Button size="sm" onClick={() => onAddToQueue(post.id, result.selectedFormat!)}
              className="w-full h-7 text-[10px] gap-1.5 bg-green-600 hover:bg-green-500 text-white font-semibold">
              <ArrowRight className="w-3 h-3" />
              Enviar para Fila de Aprovação
            </Button>
          )}
        </div>
      )}
    </div>
  )
}

// ─── Queue card ─────────────────────────────────────────────────────────────
function QueueCard({ item, onApprove, onReject, onPublish, approving, publishing }: {
  item: QueueItem
  onApprove: () => void
  onReject: () => void
  onPublish: () => void
  approving: boolean
  publishing: boolean
}) {
  const slides = item.carousel_slides || []
  const status = item.status

  const statusCfg: Record<string, { label: string; dot: string; badge: string }> = {
    pending_approval: { label: "Aguardando aprovação", dot: "bg-yellow-400", badge: "text-yellow-400 border-yellow-500/30 bg-yellow-500/10" },
    approved:         { label: "Aprovado",             dot: "bg-green-400",  badge: "text-green-400 border-green-500/30 bg-green-500/10" },
    scheduled:        { label: "Agendado",             dot: "bg-blue-400",   badge: "text-blue-400 border-blue-500/30 bg-blue-500/10" },
    publishing:       { label: "Publicando...",        dot: "bg-blue-400 animate-pulse", badge: "text-blue-400 border-blue-500/30" },
    published:        { label: "Publicado ✓",          dot: "bg-green-500",  badge: "text-green-500 border-green-600/30 bg-green-600/10" },
    failed:           { label: "Falhou",               dot: "bg-red-400",    badge: "text-red-400 border-red-500/30 bg-red-500/10" },
    rejected:         { label: "Rejeitado",            dot: "bg-muted-foreground/40", badge: "text-muted-foreground border-border" },
  }
  const cfg = statusCfg[status] || statusCfg.pending_approval

  return (
    <div className={cn(
      "rounded-xl border bg-card overflow-hidden transition-all",
      status === "pending_approval" ? "border-yellow-500/20" :
      status === "approved" ? "border-green-500/20" :
      status === "published" ? "border-green-600/15" : "border-border"
    )}>
      <div className="p-3">
        {/* Status + type */}
        <div className="flex items-center gap-2 mb-2">
          <div className={cn("w-2 h-2 rounded-full flex-shrink-0", cfg.dot)} />
          <Badge variant="outline" className={cn("text-[9px] px-1.5 py-0", cfg.badge)}>{cfg.label}</Badge>
          <span className="ml-auto flex items-center gap-1 text-[10px] text-muted-foreground">
            {CONTENT_ICON[item.content_type] || CONTENT_ICON.post}
            {item.content_type}
          </span>
        </div>

        {/* Slide preview for carousels */}
        {slides.length > 0 && (
          <div className="flex gap-1 mb-2 overflow-x-auto pb-0.5">
            {slides.slice(0, 5).map((s: any, i: number) => (
              <div key={i} className={cn(
                "flex-shrink-0 w-14 h-14 rounded-lg border p-1.5 flex flex-col text-center",
                i === 0 ? "border-yellow-500/30 bg-yellow-500/5" :
                i === slides.length - 1 ? "border-green-500/20 bg-green-500/5" : "border-border bg-muted/10"
              )}>
                <span className="text-[7px] text-muted-foreground/50 font-mono">{i + 1}</span>
                <p className="text-[8px] text-foreground/70 leading-tight line-clamp-4 mt-0.5">{s.text || s.headline || ""}</p>
              </div>
            ))}
          </div>
        )}

        {/* Caption */}
        {item.caption && (
          <p className="text-[10px] text-muted-foreground line-clamp-2 leading-snug mb-2 italic">
            {item.caption.slice(0, 120)}
          </p>
        )}

        {/* Score */}
        {item.viral_score && item.viral_score > 0 && (
          <p className={cn("text-[10px] font-mono mb-2", scoreColor(item.viral_score))}>
            Score viral: {item.viral_score}
          </p>
        )}

        {/* Actions */}
        <div className="flex gap-1.5">
          {status === "pending_approval" && (
            <>
              <Button size="sm" onClick={onApprove} disabled={approving}
                className="flex-1 h-7 text-[10px] gap-1 bg-green-600 hover:bg-green-500 text-white">
                {approving ? <Loader2 className="w-3 h-3 animate-spin" /> : <CheckCircle2 className="w-3 h-3" />}
                Aprovar
              </Button>
              <Button size="sm" variant="outline" onClick={onReject}
                className="h-7 w-7 p-0 border-red-500/30 text-red-400 hover:bg-red-500/10">
                <XCircle className="w-3.5 h-3.5" />
              </Button>
            </>
          )}
          {status === "approved" && (
            <Button size="sm" onClick={onPublish} disabled={publishing}
              className="flex-1 h-7 text-[10px] gap-1 bg-yellow-500 hover:bg-yellow-400 text-black font-semibold">
              {publishing ? <Loader2 className="w-3 h-3 animate-spin" /> : <Send className="w-3 h-3" />}
              {publishing ? "Publicando..." : "Publicar no Instagram"}
            </Button>
          )}
          {status === "published" && item.ig_permalink && (
            <a href={item.ig_permalink} target="_blank" rel="noreferrer"
              className="flex-1 h-7 flex items-center justify-center gap-1 rounded-md border border-green-500/30 text-green-400 text-[10px] hover:bg-green-500/10">
              <ExternalLink className="w-3 h-3" />Ver no Instagram
            </a>
          )}
          {status === "failed" && (
            <Button size="sm" variant="outline" onClick={onPublish} disabled={publishing}
              className="flex-1 h-7 text-[10px] gap-1 border-red-500/30 text-red-400">
              <RefreshCw className="w-3 h-3" />Tentar novamente
            </Button>
          )}
        </div>
      </div>
    </div>
  )
}

// ─── Main ───────────────────────────────────────────────────────────────────
export function ContentPipeline() {
  const [competitorPosts, setCompetitorPosts] = useState<CompetitorPost[]>([])
  const [queue, setQueue] = useState<QueueItem[]>([])
  const [paraphrases, setParaphrases] = useState<Record<string, ParaphraseResult>>({})
  const [analyzingIds, setAnalyzingIds] = useState<Set<string>>(new Set())
  const [approvingId, setApprovingId] = useState<string | null>(null)
  const [publishingId, setPublishingId] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [analysisPostId, setAnalysisPostId] = useState<string | null>(null)
  const [activeInboxTab, setActiveInboxTab] = useState<"all" | "dm" | "scraping">("all")

  // Load data
  const load = useCallback(async () => {
    setLoading(true)
    try {
      // Load approved competitor posts (source: dm + scraping)
      const { data: posts } = await supabase
        .from("reels_competidores")
        .select("id,owner_username,caption,content_type,thumbnail_url,url,views,likes,comments,viral_score,hook_type,adapted_hook,hook_analysis,viral_analysis,relevance_status,created_at")
        .in("relevance_status", ["approved", "pending"])
        .order("created_at", { ascending: false })
        .limit(60)

      // Detect source: if from DM poll it has a flag, otherwise scraping
      const { data: dmReels } = await supabase
        .from("reels_competidores")
        .select("id")
        .eq("relevance_status", "approved")
        .not("hook_analysis", "is", null)
        .order("created_at", { ascending: false })
        .limit(100)

      const dmIds = new Set((dmReels || []).map((r: any) => r.id))

      setCompetitorPosts((posts || []).map((p: any) => ({
        ...p,
        source: dmIds.has(p.id) ? "dm" : "scraping" as PostSource,
      })))

      // Load publish queue
      const { data: queueItems } = await supabase
        .from("publish_queue")
        .select("id,content_type,caption,status,carousel_slides,reel_script,viral_score,created_at,ig_permalink,metadata,scheduled_at")
        .in("status", ["pending_approval", "approved", "publishing", "published", "failed"])
        .order("created_at", { ascending: false })
        .limit(30)

      setQueue(queueItems || [])
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { load() }, [load])

  // Realtime subscription for queue updates
  useEffect(() => {
    const channel = supabase
      .channel("pipeline-queue")
      .on("postgres_changes", { event: "*", schema: "public", table: "publish_queue" }, () => load())
      .subscribe()
    return () => { supabase.removeChannel(channel) }
  }, [load])

  // Analyze one post via viral-engine + then call Ad Agent
  async function analyzeAndParaphrase(post: CompetitorPost) {
    setAnalyzingIds(prev => new Set([...prev, post.id]))
    setParaphrases(prev => ({ ...prev, [post.id]: { postId: post.id, carousel: null, reel: null, isGenerating: true, selectedFormat: undefined } }))

    const { data: { session } } = await supabase.auth.getSession()

    try {
      // Step 1: Analyze via viral-engine if no score yet
      let analysisData = post.viral_analysis
      if (!post.viral_score || post.viral_score === 0) {
        const engineRes = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/viral-engine`, {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.access_token}` },
          body: JSON.stringify({ action: "analyze_one", postId: post.id }),
        })
        const engineData = await engineRes.json()
        if (engineData.success) {
          analysisData = engineData.result
          // Update local state with new analysis
          setCompetitorPosts(prev => prev.map(p =>
            p.id === post.id ? { ...p, viral_score: analysisData.viral_score, hook_type: analysisData.hook_type, adapted_hook: analysisData.adapted_hook, viral_analysis: analysisData } : p
          ))
        }
      }

      // Step 2: Ad Agent — paraphrase in parallel: carousel_planner + script_writer
      const supaUrl = import.meta.env.VITE_SUPABASE_URL
      const baseContext = `Você é o Agente Publicitário — especialista em adaptar conteúdo viral para o perfil @djairrotta (Advogado, direito bancário).

CONTEÚDO DE REFERÊNCIA (@${post.owner_username}):
Caption: ${(post.caption || "").slice(0, 400)}
${analysisData?.hook ? `Gancho identificado: "${analysisData.hook}"` : ""}
${analysisData?.hook_type ? `Tipo: ${analysisData.hook_type}` : ""}
${analysisData?.adapted_hook ? `Gancho adaptado: "${analysisData.adapted_hook}"` : ""}
${analysisData?.why_viral ? `Por que funciona: ${analysisData.why_viral}` : ""}
${analysisData?.power_words?.length ? `Power words: ${analysisData.power_words.join(", ")}` : ""}
${analysisData?.emotional_trigger ? `Gatilho: ${analysisData.emotional_trigger}` : ""}
${analysisData?.content_ideas?.length ? `Ideias: ${analysisData.content_ideas.join(" | ")}` : ""}

REGRAS:
- Preserve a ESTRUTURA PSICOLÓGICA do gancho — troque apenas o contexto para direito bancário
- Tom: educativo, direto, acessível — advogado falando com amigo endividado
- NUNCA copiar diretamente — parafrasear preservando o mecanismo viral
- Use dados reais quando possível (STJ, BACEN, percentuais reais)`

      const carouselPrompt = baseContext + `

Crie um CARROSSEL viral. Retorne SOMENTE JSON:
{
  "title": "título interno",
  "caption": "legenda completa com hashtags",
  "slides": [
    {"num": 1, "label": "CAPA", "text": "gancho (max 8 palavras)", "subtext": "subtítulo"},
    {"num": 2, "label": "PROBLEMA", "text": "...", "subtext": "..."},
    {"num": 3, "label": "DADO", "text": "...", "subtext": "..."},
    {"num": 4, "label": "SOLUÇÃO", "text": "...", "subtext": "..."},
    {"num": 5, "label": "REFLEXÃO", "text": "...", "subtext": "..."},
    {"num": 6, "label": "CTA", "text": "...", "subtext": "..."}
  ]
}`

      const reelPrompt = baseContext + `

Crie um ROTEIRO DE REEL viral. Retorne SOMENTE JSON:
{
  "title": "título interno",
  "caption": "legenda com hashtags",
  "script": [
    {"time": "0-3s",  "label": "GANCHO",        "fala": "texto exato de abertura",      "visual": "descrição"},
    {"time": "3-8s",  "label": "PROBLEMA",       "fala": "...",                          "visual": "..."},
    {"time": "8-25s", "label": "DESENVOLVIMENTO","fala": "...",                          "visual": "..."},
    {"time": "25-40s","label": "SOLUÇÃO",         "fala": "...",                          "visual": "..."},
    {"time": "40-50s","label": "CTA",             "fala": "...",                          "visual": "..."}
  ]
}`

      const makeCall = (agent: string, ctx: string, fmt?: string) =>
        fetch(`${supaUrl}/functions/v1/generate-content`, {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.access_token}` },
          body: JSON.stringify({ agent, context: ctx, provider: "openrouter", model: "google/gemini-2.5-flash-preview-05-20", ...(fmt && { format: fmt }) }),
        }).then(r => r.json())

      // Run both agents in parallel
      const [carouselRes, reelRes] = await Promise.all([
        makeCall("carousel_planner", carouselPrompt, "instagram-feed"),
        makeCall("script_writer", reelPrompt, "instagram-reels"),
      ])

      const parseJ = (raw: string) => { try { return JSON.parse(raw.replace(/```json|```/g, "").trim()) } catch { return null } }
      const carouselData = parseJ(carouselRes.result || "")
      const reelData     = parseJ(reelRes.result || "")

      setParaphrases(prev => ({
        ...prev,
        [post.id]: {
          postId: post.id,
          carousel: carouselData,
          reel: reelData,
          isGenerating: false,
          selectedFormat: undefined,
        },
      }))

      toast.success("Agente Publicitário concluiu — escolha o formato!")
    } catch (e: any) {
      toast.error("Erro na análise: " + e.message)
      setParaphrases(prev => {
        const next = { ...prev }
        delete next[post.id]
        return next
      })
    } finally {
      setAnalyzingIds(prev => { const n = new Set(prev); n.delete(post.id); return n })
    }
  }

  function selectFormat(postId: string, format: "carousel" | "reel") {
    setParaphrases(prev => ({ ...prev, [postId]: { ...prev[postId], selectedFormat: format } }))
  }

  async function addToQueue(postId: string, format: "carousel" | "reel") {
    const result = paraphrases[postId]
    const post = competitorPosts.find(p => p.id === postId)
    if (!result || !post) return

    const content = format === "carousel" ? result.carousel : result.reel
    if (!content) { toast.error("Gere o conteúdo primeiro"); return }

    try {
      await supabase.from("publish_queue").insert({
        content_type: format === "carousel" ? "carousel" : "reel",
        caption: content.caption,
        carousel_slides: format === "carousel" ? (result.carousel as any)?.slides : null,
        reel_script: format === "reel" ? (result.reel as any)?.script : null,
        viral_score: post.viral_score || 0,
        source_reel_id: postId,
        status: "pending_approval",
        metadata: { title: content.title, source: post.owner_username, format },
      })
      toast.success("Adicionado à fila de aprovação!")
      // Remove from paraphrase state
      setParaphrases(prev => { const n = { ...prev }; delete n[postId]; return n })
      load()
    } catch (e: any) { toast.error(e.message) }
  }

  async function approveItem(id: string) {
    setApprovingId(id)
    try {
      await supabase.from("publish_queue").update({ status: "approved" }).eq("id", id)
      setQueue(prev => prev.map(q => q.id === id ? { ...q, status: "approved" } : q))
      toast.success("Aprovado!")
    } finally { setApprovingId(null) }
  }

  async function rejectItem(id: string) {
    await supabase.from("publish_queue").update({ status: "rejected" }).eq("id", id)
    setQueue(prev => prev.filter(q => q.id !== id))
    toast("Rejeitado.")
  }

  async function publishItem(id: string) {
    setPublishingId(id)
    const { data: { session } } = await supabase.auth.getSession()
    try {
      const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/publish-carousel`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.access_token}` },
        body: JSON.stringify({ action: "publish", queueId: id }),
      })
      const d = await res.json()
      if (!d.success) throw new Error(d.error)
      toast.success("Publicado no Instagram! 🎉")
      load()
    } catch (e: any) { toast.error("Erro ao publicar: " + e.message) }
    finally { setPublishingId(null) }
  }

  // Derived data
  const inboxPosts = competitorPosts.filter(p => !paraphrases[p.id])
  const analyzingPosts = competitorPosts.filter(p => !!paraphrases[p.id])

  const filteredInbox = activeInboxTab === "all" ? inboxPosts :
    inboxPosts.filter(p => p.source === activeInboxTab)

  const pendingQueue = queue.filter(q => ["pending_approval", "approved"].includes(q.status))
  const publishedQueue = queue.filter(q => ["published", "scheduled"].includes(q.status))

  return (
    <>
    <div className="h-full flex flex-col">
      {/* Top bar */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-border flex-shrink-0">
        <div>
          <h1 className="text-lg font-bold flex items-center gap-2">
            <Zap className="w-5 h-5 text-yellow-400" />
            Pipeline de Conteúdo
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            Posts dos competidores → Análise IA + Agente Publicitário → Fila de Aprovação → Instagram
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={load} disabled={loading} className="gap-1.5 text-xs h-8">
          <RefreshCw className={cn("w-3.5 h-3.5", loading && "animate-spin")} />
          Atualizar
        </Button>
      </div>

      {/* 3-column pipeline */}
      <div className="flex-1 overflow-hidden grid grid-cols-3 divide-x divide-border">

        {/* ── LANE 1: Inbox ─────────────────────────────────────────── */}
        <div className="flex flex-col overflow-hidden">
          <div className="px-4 pt-4 pb-0 flex-shrink-0">
            <LaneHeader
              icon={<Users className="w-4 h-4" />}
              title="Posts de Referência"
              count={inboxPosts.length}
              subtitle="Via DM + scraping diário"
              color="text-blue-400"
            />
            {/* Source filter */}
            <div className="flex gap-1 mb-3">
              {([
                { id: "all", label: "Todos" },
                { id: "dm", label: "💬 DM" },
                { id: "scraping", label: "🔄 Scraping" },
              ] as const).map(f => (
                <button key={f.id} onClick={() => setActiveInboxTab(f.id)}
                  className={cn("px-2 py-1 text-[10px] rounded-md border transition-colors",
                    activeInboxTab === f.id ? "border-blue-500/40 bg-blue-500/10 text-blue-400" : "border-border text-muted-foreground hover:text-foreground"
                  )}>
                  {f.label}
                </button>
              ))}
            </div>
          </div>
          <div className="flex-1 overflow-y-auto px-4 pb-4 space-y-2">
            {loading ? (
              Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="h-28 rounded-xl bg-muted/20 animate-pulse" />
              ))
            ) : filteredInbox.length === 0 ? (
              <div className="text-center py-10 text-muted-foreground">
                <Users className="w-8 h-8 opacity-20 mx-auto mb-2" />
                <p className="text-xs">Nenhum post de referência</p>
                <p className="text-[10px] mt-1">Execute o pipeline ou aguarde o cron diário</p>
              </div>
            ) : filteredInbox.map(post => (
              <InboxCard
                key={post.id}
                post={post}
                onAnalyze={analyzeAndParaphrase}
                analyzing={analyzingIds.has(post.id)}
                onOpenAnalysis={setAnalysisPostId}
              />
            ))}
          </div>
        </div>

        {/* ── LANE 2: Analysis + Paraphrase ─────────────────────────── */}
        <div className="flex flex-col overflow-hidden">
          <div className="px-4 pt-4 pb-0 flex-shrink-0">
            <LaneHeader
              icon={<Brain className="w-4 h-4" />}
              title="Agente Publicitário"
              count={analyzingPosts.length}
              subtitle="Análise viral + paráfrase adaptada"
              color="text-yellow-400"
            />
            <div className="mb-3 rounded-lg bg-yellow-500/5 border border-yellow-500/15 px-3 py-2">
              <p className="text-[10px] text-yellow-300/80 leading-snug">
                <strong>Fluxo:</strong> Transcrição → Extração de gancho → Análise psicológica → Paráfrase adaptada → Você escolhe carrossel ou reel
              </p>
            </div>
          </div>
          <div className="flex-1 overflow-y-auto px-4 pb-4 space-y-3">
            {analyzingPosts.length === 0 ? (
              <div className="text-center py-10 text-muted-foreground">
                <Brain className="w-8 h-8 opacity-20 mx-auto mb-2" />
                <p className="text-xs">Nenhum post em análise</p>
                <p className="text-[10px] mt-1">Clique em "Analisar" ou "Criar conteúdo" em um post da esquerda</p>
              </div>
            ) : analyzingPosts.map(post => {
              const result = paraphrases[post.id]
              if (!result) return null
              return (
                <ParaphraseCard
                  key={post.id}
                  post={post}
                  result={result}
                  onSelectFormat={selectFormat}
                  onAddToQueue={addToQueue}
                />
              )
            })}
          </div>
        </div>

        {/* ── LANE 3: Approval Queue ────────────────────────────────── */}
        <div className="flex flex-col overflow-hidden">
          <div className="px-4 pt-4 pb-0 flex-shrink-0">
            <LaneHeader
              icon={<Send className="w-4 h-4" />}
              title="Fila de Publicação"
              count={pendingQueue.length}
              subtitle="Aguardando aprovação ou agendamento"
              color="text-green-400"
            />
            {pendingQueue.length > 0 && (
              <div className="mb-3 flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-yellow-400 animate-pulse" />
                <p className="text-[10px] text-muted-foreground">
                  {pendingQueue.filter(q => q.status === "pending_approval").length} aguardando aprovação
                </p>
              </div>
            )}
          </div>
          <div className="flex-1 overflow-y-auto px-4 pb-4 space-y-2">
            {loading ? (
              Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="h-32 rounded-xl bg-muted/20 animate-pulse" />
              ))
            ) : pendingQueue.length === 0 && publishedQueue.length === 0 ? (
              <div className="text-center py-10 text-muted-foreground">
                <Send className="w-8 h-8 opacity-20 mx-auto mb-2" />
                <p className="text-xs">Fila vazia</p>
                <p className="text-[10px] mt-1">Aprove um conteúdo na coluna anterior</p>
              </div>
            ) : (
              <>
                {pendingQueue.map(item => (
                  <QueueCard
                    key={item.id}
                    item={item}
                    onApprove={() => approveItem(item.id)}
                    onReject={() => rejectItem(item.id)}
                    onPublish={() => publishItem(item.id)}
                    approving={approvingId === item.id}
                    publishing={publishingId === item.id}
                  />
                ))}
                {publishedQueue.length > 0 && (
                  <>
                    <div className="flex items-center gap-2 py-1">
                      <div className="flex-1 h-px bg-border" />
                      <span className="text-[9px] text-muted-foreground/50 uppercase tracking-wider">Publicados</span>
                      <div className="flex-1 h-px bg-border" />
                    </div>
                    {publishedQueue.map(item => (
                      <QueueCard
                        key={item.id}
                        item={item}
                        onApprove={() => {}}
                        onReject={() => {}}
                        onPublish={() => publishItem(item.id)}
                        approving={false}
                        publishing={publishingId === item.id}
                      />
                    ))}
                  </>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>

    {/* ── Viral Analysis Panel modal ────────────────── */}
    {analysisPostId && (
      <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center p-0 sm:p-4"
        onClick={e => { if (e.target === e.currentTarget) setAnalysisPostId(null) }}>
        <div className="bg-background border border-border rounded-t-2xl sm:rounded-2xl w-full sm:max-w-lg h-[85vh] sm:h-[80vh] flex flex-col overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3 border-b border-border flex-shrink-0">
            <div>
              <h3 className="text-sm font-bold">Análise Viral + Copywriter</h3>
              <p className="text-[10px] text-muted-foreground">OpenSquad · Eugene Schwartz Framework</p>
            </div>
            <button onClick={() => setAnalysisPostId(null)}
              className="text-muted-foreground hover:text-foreground w-7 h-7 rounded-lg hover:bg-accent flex items-center justify-center">
              ✕
            </button>
          </div>
          <div className="flex-1 overflow-hidden">
            <ViralAnalysisPanel postId={analysisPostId} onClose={() => setAnalysisPostId(null)} />
          </div>
        </div>
      </div>
    )}
    </>
  )
}
