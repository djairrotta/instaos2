import { useState, useEffect, useCallback } from "react"
import { supabase } from "@/integrations/supabase/client"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import { Loader2, Search, Lightbulb, RefreshCw, ChevronDown, ChevronUp, TrendingUp, Copy } from "lucide-react"

interface Angle {
  name: string
  hook: string
  lifecycle: string
  score: number
}

interface Brief {
  id: string
  topic: string
  niche: string
  brief: string
  angles: Angle[]
  created_at: string
}

export function ResearchPanel({
  onAngleSelect,
}: {
  onAngleSelect?: (angle: Angle, brief: string) => void
}) {
  const [topic, setTopic] = useState("")
  const [niche, setNiche] = useState("direito bancário e advocacia")
  const [depth, setDepth] = useState<"light"|"medium"|"deep">("medium")
  const [researching, setResearching] = useState(false)
  const [loadingSuggestions, setLoadingSuggestions] = useState(false)
  const [suggestions, setSuggestions] = useState<any[]>([])
  const [briefs, setBriefs] = useState<Brief[]>([])
  const [expandedId, setExpandedId] = useState<string | null>(null)
  const [loadingBriefs, setLoadingBriefs] = useState(true)
  const SUPA_URL = import.meta.env.VITE_SUPABASE_URL

  async function getToken() {
    const { data: { session } } = await supabase.auth.getSession()
    return session?.access_token
  }

  const loadBriefs = useCallback(async () => {
    setLoadingBriefs(true)
    try {
      const token = await getToken()
      const res = await fetch(`${SUPA_URL}/functions/v1/research-agent`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ action: "list" }),
      })
      const d = await res.json()
      setBriefs(d.briefs || [])
    } finally { setLoadingBriefs(false) }
  }, [])

  useEffect(() => { loadBriefs() }, [loadBriefs])

  async function suggestTopics() {
    setLoadingSuggestions(true)
    try {
      const token = await getToken()
      const res = await fetch(`${SUPA_URL}/functions/v1/research-agent`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ action: "suggest_topics", niche }),
      })
      const d = await res.json()
      setSuggestions(d.topics || [])
    } catch (e: any) { toast.error(e.message) }
    finally { setLoadingSuggestions(false) }
  }

  async function research() {
    if (!topic.trim()) { toast.error("Digite um tema para pesquisar"); return }
    setResearching(true)
    try {
      const token = await getToken()
      const res = await fetch(`${SUPA_URL}/functions/v1/research-agent`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ action: "research", topic, niche, depth }),
      })
      const d = await res.json()
      if (!d.success) throw new Error(d.error)
      toast.success(`Research brief criado! ${d.angles?.length || 0} ângulos identificados.`)
      setTopic("")
      setSuggestions([])
      loadBriefs()
    } catch (e: any) { toast.error(e.message) }
    finally { setResearching(false) }
  }

  const lifecycleColor = (lc: string) => ({
    emergente: "text-green-400 bg-green-500/10 border-green-500/20",
    crescimento: "text-yellow-400 bg-yellow-500/10 border-yellow-500/20",
    maduro: "text-blue-400 bg-blue-500/10 border-blue-500/20",
    declinando: "text-muted-foreground bg-muted/20 border-border",
  }[lc] || "text-muted-foreground bg-muted/20 border-border")

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-bold text-base flex items-center gap-2">
            <Search className="w-4 h-4 text-yellow-400" />
            Research Agent
          </h3>
          <p className="text-xs text-muted-foreground mt-0.5">
            Pesquisa de domínio com source verification e ângulos virais identificados
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={loadBriefs} className="h-7 w-7 p-0">
          <RefreshCw className={cn("w-3.5 h-3.5", loadingBriefs && "animate-spin")} />
        </Button>
      </div>

      {/* New research form */}
      <div className="rounded-xl border border-border bg-card p-4 space-y-3">
        <p className="text-xs font-semibold text-muted-foreground">Nova Pesquisa</p>
        <Input value={topic} onChange={e => setTopic(e.target.value)}
          placeholder="Ex: juros abusivos no cartão de crédito, STJ decisão recente..."
          className="text-xs"
          onKeyDown={e => e.key === "Enter" && research()}
        />
        <div className="flex gap-2">
          <Input value={niche} onChange={e => setNiche(e.target.value)}
            placeholder="Nicho" className="text-xs flex-1" />
          <div className="flex rounded-lg border border-border overflow-hidden">
            {(["light","medium","deep"] as const).map(d => (
              <button key={d} onClick={() => setDepth(d)}
                className={cn("px-2.5 py-1.5 text-xs transition-colors",
                  depth === d ? "bg-yellow-500/20 text-yellow-400" : "text-muted-foreground hover:text-foreground"
                )}>
                {d === "light" ? "Rápido" : d === "medium" ? "Médio" : "Profundo"}
              </button>
            ))}
          </div>
        </div>
        <div className="flex gap-2">
          <Button onClick={research} disabled={researching || !topic.trim()}
            className="flex-1 gap-1.5 text-xs bg-yellow-500 hover:bg-yellow-400 text-black font-semibold h-8">
            {researching ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Search className="w-3.5 h-3.5" />}
            {researching ? "Pesquisando..." : "Pesquisar"}
          </Button>
          <Button onClick={suggestTopics} disabled={loadingSuggestions} variant="outline" size="sm"
            className="gap-1 text-xs h-8">
            {loadingSuggestions ? <Loader2 className="w-3 h-3 animate-spin" /> : <Lightbulb className="w-3 h-3" />}
            Sugestões
          </Button>
        </div>
      </div>

      {/* Topic suggestions */}
      {suggestions.length > 0 && (
        <div className="space-y-1.5">
          <p className="text-[10px] uppercase tracking-wider text-muted-foreground/50">Tópicos Sugeridos</p>
          {suggestions.map((s, i) => (
            <button key={i} onClick={() => setTopic(s.topic)}
              className="w-full text-left rounded-lg border border-border bg-card/50 hover:border-yellow-500/30 p-2.5 transition-all">
              <div className="flex items-start gap-2">
                <span className="text-base flex-shrink-0">
                  {s.format_suggestion === "reel" ? "🎬" : s.format_suggestion === "post" ? "📸" : "🎠"}
                </span>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-foreground">{s.topic}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">{s.hook_hint}</p>
                </div>
                <Badge variant="outline" className={cn("text-[9px] flex-shrink-0",
                  s.urgency === "alta" ? "text-red-400 border-red-500/30" :
                  s.urgency === "média" ? "text-yellow-400 border-yellow-500/30" :
                  "text-muted-foreground"
                )}>
                  {s.urgency}
                </Badge>
              </div>
            </button>
          ))}
        </div>
      )}

      {/* Past briefs */}
      {briefs.length > 0 && (
        <div className="space-y-2">
          <p className="text-[10px] uppercase tracking-wider text-muted-foreground/50">Pesquisas Anteriores</p>
          {briefs.map(brief => (
            <div key={brief.id} className="rounded-xl border border-border bg-card overflow-hidden">
              {/* Brief header */}
              <button
                onClick={() => setExpandedId(expandedId === brief.id ? null : brief.id)}
                className="w-full flex items-center gap-3 px-3.5 py-3 text-left hover:bg-accent/20 transition-colors"
              >
                <Search className="w-3.5 h-3.5 text-muted-foreground/50 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold truncate">{brief.topic}</p>
                  <p className="text-[10px] text-muted-foreground">{brief.niche}</p>
                </div>
                <span className="text-[10px] text-muted-foreground/50 flex-shrink-0">
                  {new Date(brief.created_at).toLocaleDateString("pt-BR", { day: "2-digit", month: "short" })}
                </span>
                {expandedId === brief.id ? <ChevronUp className="w-3.5 h-3.5 flex-shrink-0" /> : <ChevronDown className="w-3.5 h-3.5 flex-shrink-0" />}
              </button>

              {/* Expanded: angles */}
              {expandedId === brief.id && (
                <div className="px-3.5 pb-3.5 border-t border-border/50 pt-2.5 space-y-2.5">
                  {/* Trending angles */}
                  {brief.angles && brief.angles.length > 0 && (
                    <div>
                      <p className="text-[9px] uppercase tracking-wider text-muted-foreground/40 mb-1.5">Ângulos Identificados</p>
                      <div className="space-y-1.5">
                        {brief.angles.map((angle, i) => (
                          <div key={i} className="rounded-lg border border-border bg-muted/10 p-2.5">
                            <div className="flex items-start gap-2 mb-1">
                              <TrendingUp className="w-3 h-3 text-yellow-400 mt-0.5 flex-shrink-0" />
                              <p className="text-xs font-medium flex-1">{angle.name}</p>
                              <Badge variant="outline" className={cn("text-[9px] px-1.5 py-0 flex-shrink-0", lifecycleColor(angle.lifecycle))}>
                                {angle.lifecycle}
                              </Badge>
                            </div>
                            {angle.hook && (
                              <p className="text-[10px] text-muted-foreground italic ml-5">"{angle.hook}"</p>
                            )}
                            {onAngleSelect && (
                              <button
                                onClick={() => onAngleSelect(angle, brief.brief || "")}
                                className="ml-5 mt-1.5 text-[10px] text-yellow-400 hover:text-yellow-300"
                              >
                                Usar este ângulo →
                              </button>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Full brief copy button */}
                  {brief.brief && (
                    <button
                      onClick={() => { navigator.clipboard.writeText(brief.brief); toast.success("Brief copiado!") }}
                      className="flex items-center gap-1.5 text-[10px] text-muted-foreground hover:text-foreground"
                    >
                      <Copy className="w-3 h-3" /> Copiar brief completo
                    </button>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {!loadingBriefs && briefs.length === 0 && suggestions.length === 0 && (
        <div className="text-center py-8 text-muted-foreground">
          <Search className="w-8 h-8 opacity-20 mx-auto mb-2" />
          <p className="text-xs">Nenhuma pesquisa ainda</p>
          <p className="text-[10px] mt-1">Use "Sugestões" para ver tópicos recomendados</p>
        </div>
      )}
    </div>
  )
}
