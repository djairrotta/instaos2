import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Maximize2, Minimize2, X, Eye, EyeOff, Check, Loader2, AlertCircle, CheckCircle2,
  Database, Instagram, Youtube, Twitter, Facebook, Unplug, ExternalLink, Info, Save,
  HardDrive, Share2, FolderOpen, FileJson, FileVideo, File, Trash2, Download, RefreshCw,
  ChevronRight, ArrowLeft, Mail, MessageSquare, Bot, Search, Globe, Wrench,
} from "lucide-react"
import { toast } from "sonner"
import { supabase } from "@/integrations/supabase/client"

interface IntegrationsModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

interface IntegrationStatus {
  minio: boolean
  instagram: boolean
  tiktok: boolean
  youtube: boolean
  twitter: boolean
  facebook: boolean
  firecrawl: boolean
  apify: boolean
}

export function IntegrationsModal({ open, onOpenChange }: IntegrationsModalProps) {
  const [isMaximized, setIsMaximized] = useState(false)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState<string | null>(null)
  const [showKeys, setShowKeys] = useState<Record<string, boolean>>({})
  const [statuses, setStatuses] = useState<IntegrationStatus>({
    minio: false, instagram: false, tiktok: false, youtube: false, twitter: false, facebook: false, firecrawl: false, apify: false,
  })

  // MinIO
  const [minioTesting, setMinioTesting] = useState(false)

  // MinIO File Browser
  const [minioFiles, setMinioFiles] = useState<Array<{ key: string; size: number; lastModified: string }>>([])
  const [minioFilesLoading, setMinioFilesLoading] = useState(false)
  const [minioCurrentPrefix, setMinioCurrentPrefix] = useState("")
  const [minioFilePreview, setMinioFilePreview] = useState<{ path: string; content: string } | null>(null)
  const [minioPreviewLoading, setMinioPreviewLoading] = useState(false)
  const [minioDeleting, setMinioDeleting] = useState<string | null>(null)
  const [minioBrowserOpen, setMinioBrowserOpen] = useState(false)

  // Instagram
  const [igConnected, setIgConnected] = useState(false)
  const [igAccount, setIgAccount] = useState<{ username: string; profilePicUrl?: string; followersCount?: number } | null>(null)
  const [igToken, setIgToken] = useState("")
  const [igLoading, setIgLoading] = useState(false)

  const [minioInfo, setMinioInfo] = useState<{ endpoint: string; bucket: string; fileCount: number | null }>({ endpoint: "", bucket: "", fileCount: null })

  // Resend / WhatsApp / AI
  const [resendKey, setResendKey] = useState("")
  const [whatsappUrl, setWhatsappUrl] = useState("")
  const [whatsappKey, setWhatsappKey] = useState("")
  const [whatsappNumber, setWhatsappNumber] = useState("")
  const [whatsappSaving, setWhatsappSaving] = useState(false)
  const [whatsappTesting, setWhatsappTesting] = useState(false)
  const [whatsappConnected, setWhatsappConnected] = useState(false)

  useEffect(() => {
    if (!open) return
    const load = async () => {
      setLoading(true)
      try {
        // Check MinIO status + get info
        const [minioRes, minioListRes, igRes, whatsappKeysRes, apiKeysRes] = await Promise.all([
          supabase.functions.invoke("check-api-keys").catch(() => null),
          supabase.functions.invoke("save-to-minio", { body: { action: "list", path: "" } }).catch(() => null),
          supabase.functions.invoke("publish-instagram", { body: { action: "get_status" } }).catch(() => null),
          supabase.from("user_api_keys").select("*").in("provider", ["evolution_api_url", "evolution_api_key", "whatsapp_notify_number"]).eq("is_active", true).then(r => r.data ?? null),
          supabase.functions.invoke("check-api-keys").catch(() => null),
        ])

        const systemKeys = minioRes?.data?.configured || {}
        const minioConnected = minioListRes?.data?.success === true

        // Check Firecrawl and Apify from system secrets
        const firecrawlConnected = !!systemKeys.firecrawl_configured
        const apifyConnected = !!systemKeys.apify_configured

        setStatuses(prev => ({
          ...prev,
          minio: minioConnected || !!systemKeys.minio_configured,
          instagram: igRes?.data?.connected || false,
          firecrawl: firecrawlConnected,
          apify: apifyConnected,
        }))

        // Store MinIO config info from secrets
        setMinioInfo({
          endpoint: systemKeys.minio_endpoint || "",
          bucket: systemKeys.minio_bucket || "",
          fileCount: minioListRes?.data?.files?.length ?? null,
        })

        if (igRes?.data?.connected && igRes?.data?.account) {
          setIgConnected(true)
          setIgAccount(igRes.data.account)
        }

        // Load WhatsApp config
        if (whatsappKeysRes && Array.isArray(whatsappKeysRes)) {
          const url = whatsappKeysRes.find((k: any) => k.provider === "evolution_api_url")?.api_key
          const key = whatsappKeysRes.find((k: any) => k.provider === "evolution_api_key")?.api_key
          const num = whatsappKeysRes.find((k: any) => k.provider === "whatsapp_notify_number")?.api_key
          if (url) setWhatsappUrl(url)
          if (key) setWhatsappKey(key)
          if (num) setWhatsappNumber(num)
          if (url && key) setWhatsappConnected(true)
        }
      } catch { /* ignore */ }
      setLoading(false)
    }
    load()
  }, [open])

  const loadMinioFiles = async (prefix = "") => {
    setMinioFilesLoading(true)
    setMinioFilePreview(null)
    try {
      const res = await supabase.functions.invoke("save-to-minio", {
        body: { action: "list", path: prefix },
      })
      if (res.data?.success) {
        setMinioFiles(res.data.files || [])
        setMinioCurrentPrefix(prefix)
      } else {
        toast.error("Erro ao listar arquivos", { description: res.data?.error })
      }
    } catch (e: any) {
      toast.error("Erro ao listar MinIO", { description: e.message })
    } finally {
      setMinioFilesLoading(false)
    }
  }

  const handleMinioDownload = async (filePath: string) => {
    setMinioPreviewLoading(true)
    try {
      const res = await supabase.functions.invoke("save-to-minio", {
        body: { action: "get", path: filePath },
      })
      if (!res.data?.success) throw new Error(res.data?.error)

      if (filePath.endsWith(".json")) {
        setMinioFilePreview({ path: filePath, content: res.data.content })
      } else {
        // Binary file - trigger download
        const byteChars = atob(res.data.content)
        const byteArray = new Uint8Array(byteChars.length)
        for (let i = 0; i < byteChars.length; i++) byteArray[i] = byteChars.charCodeAt(i)
        const blob = new Blob([byteArray], { type: res.data.contentType })
        const url = URL.createObjectURL(blob)
        const a = document.createElement("a")
        a.href = url
        a.download = filePath.split("/").pop() || "download"
        a.click()
        URL.revokeObjectURL(url)
        toast.success("Download iniciado")
      }
    } catch (e: any) {
      toast.error("Erro ao baixar arquivo", { description: e.message })
    } finally {
      setMinioPreviewLoading(false)
    }
  }

  const handleMinioDelete = async (filePath: string) => {
    setMinioDeleting(filePath)
    try {
      const res = await supabase.functions.invoke("save-to-minio", {
        body: { action: "delete", path: filePath },
      })
      if (res.data?.success) {
        toast.success("Arquivo deletado", { description: filePath })
        setMinioFiles(prev => prev.filter(f => f.key !== filePath))
        if (minioFilePreview?.path === filePath) setMinioFilePreview(null)
      } else {
        throw new Error(res.data?.error)
      }
    } catch (e: any) {
      toast.error("Erro ao deletar", { description: e.message })
    } finally {
      setMinioDeleting(null)
    }
  }

  const formatFileSize = (bytes: number) => {
    if (bytes >= 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + " MB"
    if (bytes >= 1024) return (bytes / 1024).toFixed(1) + " KB"
    return bytes + " B"
  }

  const getFileIcon = (key: string) => {
    if (key.endsWith(".json")) return <FileJson className="h-4 w-4 text-amber-500" />
    if (key.endsWith(".mp4") || key.endsWith(".mov") || key.endsWith(".webm")) return <FileVideo className="h-4 w-4 text-blue-500" />
    return <File className="h-4 w-4 text-muted-foreground" />
  }

  // Derive folders from flat file list
  const getFilesAndFolders = () => {
    const prefix = minioCurrentPrefix
    const folders = new Set<string>()
    const directFiles: typeof minioFiles = []

    for (const f of minioFiles) {
      const relative = f.key.startsWith(prefix) ? f.key.slice(prefix.length) : f.key
      const slashIndex = relative.indexOf("/")
      if (slashIndex > 0 && slashIndex < relative.length - 1) {
        folders.add(prefix + relative.slice(0, slashIndex + 1))
      } else {
        directFiles.push(f)
      }
    }
    return { folders: [...folders].sort(), files: directFiles }
  }

  const testMinioConnection = async () => {
    setMinioTesting(true)
    try {
      const res = await supabase.functions.invoke("save-to-minio", {
        body: { action: "list", path: "" },
      })
      if (res.data?.success) {
        toast.success("MinIO conectado com sucesso!", { description: `${res.data.files?.length || 0} arquivos encontrados` })
        setStatuses(prev => ({ ...prev, minio: true }))
      } else {
        toast.error("Falha na conexão MinIO", { description: res.data?.error })
        setStatuses(prev => ({ ...prev, minio: false }))
      }
    } catch (e: any) {
      toast.error("Erro ao testar MinIO", { description: e.message })
    } finally {
      setMinioTesting(false)
    }
  }

  const handleConnectInstagram = async () => {
    if (!igToken.trim()) return toast.error("Cole o Access Token")
    setIgLoading(true)
    try {
      const { data, error } = await supabase.functions.invoke("publish-instagram", {
        body: { action: "verify_token", accessToken: igToken.trim() },
      })
      if (error) throw error
      if (!data?.success) throw new Error(data?.error || "Falha na verificação")
      setIgConnected(true)
      setIgAccount(data.account)
      setIgToken("")
      setStatuses(prev => ({ ...prev, instagram: true }))
      toast.success(`Instagram conectado! @${data.account.username}`)
    } catch (e: any) {
      toast.error("Erro ao conectar Instagram", { description: e.message })
    } finally {
      setIgLoading(false)
    }
  }

  const handleDisconnectInstagram = async () => {
    setIgLoading(true)
    try {
      await supabase.functions.invoke("publish-instagram", { body: { action: "disconnect" } })
      setIgConnected(false)
      setIgAccount(null)
      setStatuses(prev => ({ ...prev, instagram: false }))
      toast.success("Instagram desconectado")
    } catch (e: any) {
      toast.error("Erro", { description: e.message })
    } finally {
      setIgLoading(false)
    }
  }

  const handleSaveWhatsapp = async () => {
    if (!whatsappUrl.trim() || !whatsappKey.trim()) return toast.error("Preencha URL e API Key")
    setWhatsappSaving(true)
    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) throw new Error("Faça login primeiro")

      const entries = [
        { provider: "evolution_api_url", api_key: whatsappUrl.trim() },
        { provider: "evolution_api_key", api_key: whatsappKey.trim() },
        ...(whatsappNumber.trim() ? [{ provider: "whatsapp_notify_number", api_key: whatsappNumber.trim() }] : []),
      ]

      for (const entry of entries) {
        const { data: existing } = await supabase
          .from("user_api_keys")
          .select("id")
          .eq("user_id", user.id)
          .eq("provider", entry.provider)
          .maybeSingle()

        if (existing) {
          await supabase.from("user_api_keys").update({ api_key: entry.api_key, is_active: true }).eq("id", existing.id)
        } else {
          await supabase.from("user_api_keys").insert({ user_id: user.id, provider: entry.provider, api_key: entry.api_key })
        }
      }

      setWhatsappConnected(true)
      toast.success("Configuração WhatsApp salva!")
    } catch (e: any) {
      toast.error("Erro ao salvar", { description: e.message })
    } finally {
      setWhatsappSaving(false)
    }
  }

  const handleTestWhatsapp = async () => {
    setWhatsappTesting(true)
    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) throw new Error("Faça login primeiro")

      const { data, error } = await supabase.functions.invoke("send-whatsapp-notification", {
        body: { action: "test", userId: user.id },
      })
      if (error) throw error
      if (data?.success) {
        toast.success("Evolution API conectada!", { description: `${data.instances} instância(s) encontrada(s)` })
        setWhatsappConnected(true)
      } else {
        toast.error("Falha na conexão", { description: data?.error })
        setWhatsappConnected(false)
      }
    } catch (e: any) {
      toast.error("Erro ao testar", { description: e.message })
    } finally {
      setWhatsappTesting(false)
    }
  }

  const toggleKey = (key: string) => setShowKeys(p => ({ ...p, [key]: !p[key] }))

  const StatusBadge = ({ connected }: { connected: boolean }) => connected
    ? <Badge className="text-xs gap-1 bg-emerald-500/10 text-emerald-600 border-emerald-500/20"><CheckCircle2 className="h-3 w-3" /> Conectado</Badge>
    : <Badge variant="outline" className="text-xs gap-1"><AlertCircle className="h-3 w-3" /> Não conectado</Badge>

  const ComingSoonBadge = () => <Badge variant="secondary" className="text-xs">Em breve</Badge>

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className="overflow-y-auto"
        style={isMaximized
          ? { maxWidth: "96vw", width: "96vw", height: "96vh", maxHeight: "96vh" }
          : { maxWidth: "56rem", maxHeight: "90vh" }
        }
      >
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle className="flex items-center gap-2 text-2xl">
                <Share2 className="h-6 w-6" /> Integrações
              </DialogTitle>
              <DialogDescription>
                Gerencie suas conexões com serviços externos: armazenamento, redes sociais e APIs.
              </DialogDescription>
            </div>
            <div className="flex items-center gap-1">
              <Button variant="ghost" size="icon" onClick={() => setIsMaximized(!isMaximized)}>
                {isMaximized ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
              </Button>
              <Button variant="ghost" size="icon" onClick={() => onOpenChange(false)}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </DialogHeader>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <Tabs defaultValue="storage" className="mt-4">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="storage" className="gap-2"><HardDrive className="h-4 w-4" /> <span className="hidden sm:inline">Storage</span></TabsTrigger>
              <TabsTrigger value="tools" className="gap-2"><Wrench className="h-4 w-4" /> <span className="hidden sm:inline">Ferramentas</span></TabsTrigger>
              <TabsTrigger value="social" className="gap-2"><Share2 className="h-4 w-4" /> <span className="hidden sm:inline">Social</span></TabsTrigger>
              <TabsTrigger value="messaging" className="gap-2"><MessageSquare className="h-4 w-4" /> <span className="hidden sm:inline">Mensageria</span></TabsTrigger>
              <TabsTrigger value="email" className="gap-2"><Mail className="h-4 w-4" /> <span className="hidden sm:inline">Email</span></TabsTrigger>
            </TabsList>

            {/* Storage Tab */}
            <TabsContent value="storage" className="space-y-4 mt-4">
              <Card className="p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-lg bg-red-500/10 flex items-center justify-center">
                      <Database className="h-5 w-5 text-red-500" />
                    </div>
                    <div>
                      <h3 className="font-semibold flex items-center gap-2">MinIO Object Storage <StatusBadge connected={statuses.minio} /></h3>
                      <p className="text-xs text-muted-foreground">Armazenamento S3-compatible para downloads de vídeos</p>
                    </div>
                  </div>
                </div>

                {statuses.minio && (
                  <div className="rounded-lg border border-emerald-500/20 bg-emerald-500/5 p-3 flex items-center gap-3">
                    <CheckCircle2 className="h-5 w-5 text-emerald-500 shrink-0" />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-emerald-700 dark:text-emerald-400">MinIO operando normalmente</p>
                      <p className="text-xs text-muted-foreground">
                        Conexão ativa • {minioInfo.fileCount !== null ? `${minioInfo.fileCount} arquivo(s) no bucket` : "Verificando..."}
                      </p>
                    </div>
                  </div>
                )}

                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="space-y-1.5">
                    <Label className="text-xs">Endpoint URL</Label>
                    <Input readOnly value={minioInfo.endpoint || "Configurado via secrets"} className="h-8 text-xs bg-muted/50 cursor-default" />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs">Bucket</Label>
                    <Input readOnly value={minioInfo.bucket || "Configurado via secrets"} className="h-8 text-xs bg-muted/50 cursor-default" />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs">Access Key</Label>
                    <Input readOnly type="password" value="••••••••••••" className="h-8 text-xs bg-muted/50 cursor-default" />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs">Secret Key</Label>
                    <Input readOnly type="password" value="••••••••••••" className="h-8 text-xs bg-muted/50 cursor-default" />
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={testMinioConnection} disabled={minioTesting} className="gap-1.5">
                    {minioTesting ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
                    Testar Conexão
                  </Button>
                </div>

                <div className="rounded-md border bg-muted/30 p-3">
                  <p className="text-xs text-muted-foreground flex items-start gap-2">
                    <Info className="h-4 w-4 shrink-0 mt-0.5 text-primary" />
                    <span>As credenciais do MinIO estão salvas como secrets no backend (MINIO_ENDPOINT, MINIO_ACCESS_KEY, MINIO_SECRET_KEY, MINIO_BUCKET). Vídeos de reels são baixados automaticamente para o MinIO durante o pipeline.</span>
                  </p>
                </div>
              </Card>

              {/* MinIO File Browser */}
              <Card className="p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <FolderOpen className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Explorador de Arquivos</h3>
                      <p className="text-xs text-muted-foreground">Navegue, baixe e gerencie arquivos no MinIO</p>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    className="gap-1.5"
                    onClick={() => { setMinioBrowserOpen(!minioBrowserOpen); if (!minioBrowserOpen) loadMinioFiles(""); }}
                  >
                    {minioBrowserOpen ? <Minimize2 className="h-3.5 w-3.5" /> : <FolderOpen className="h-3.5 w-3.5" />}
                    {minioBrowserOpen ? "Fechar" : "Abrir"}
                  </Button>
                </div>

                {minioBrowserOpen && (
                  <div className="space-y-3">
                    {/* Breadcrumb + Refresh */}
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-1 text-xs flex-1 min-w-0">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-6 px-2 text-xs"
                          onClick={() => loadMinioFiles("")}
                          disabled={!minioCurrentPrefix}
                        >
                          🪣 bucket
                        </Button>
                        {minioCurrentPrefix.split("/").filter(Boolean).map((seg, i, arr) => {
                          const prefixUpTo = arr.slice(0, i + 1).join("/") + "/"
                          return (
                            <span key={i} className="flex items-center gap-0.5">
                              <ChevronRight className="h-3 w-3 text-muted-foreground" />
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-6 px-2 text-xs"
                                onClick={() => loadMinioFiles(prefixUpTo)}
                              >
                                {seg}
                              </Button>
                            </span>
                          )
                        })}
                      </div>
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => loadMinioFiles(minioCurrentPrefix)} disabled={minioFilesLoading}>
                        <RefreshCw className={`h-3.5 w-3.5 ${minioFilesLoading ? "animate-spin" : ""}`} />
                      </Button>
                    </div>

                    {/* Back button */}
                    {minioCurrentPrefix && (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-7 gap-1.5 text-xs"
                        onClick={() => {
                          const parts = minioCurrentPrefix.replace(/\/$/, "").split("/")
                          parts.pop()
                          loadMinioFiles(parts.length ? parts.join("/") + "/" : "")
                        }}
                      >
                        <ArrowLeft className="h-3 w-3" /> Voltar
                      </Button>
                    )}

                    {minioFilesLoading ? (
                      <div className="flex items-center justify-center py-8">
                        <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                      </div>
                    ) : (
                      <div className="rounded-lg border border-border/50 divide-y divide-border/50 max-h-[400px] overflow-y-auto">
                        {(() => {
                          const { folders, files } = getFilesAndFolders()
                          if (folders.length === 0 && files.length === 0) {
                            return (
                              <div className="p-6 text-center text-sm text-muted-foreground">
                                Nenhum arquivo encontrado neste diretório
                              </div>
                            )
                          }
                          return (
                            <>
                              {folders.map(folder => (
                                <button
                                  key={folder}
                                  className="w-full flex items-center gap-3 px-3 py-2.5 hover:bg-muted/50 transition-colors text-left"
                                  onClick={() => loadMinioFiles(folder)}
                                >
                                  <FolderOpen className="h-4 w-4 text-amber-500 shrink-0" />
                                  <span className="text-sm font-medium truncate flex-1">
                                    {folder.replace(minioCurrentPrefix, "").replace(/\/$/, "")}
                                  </span>
                                  <ChevronRight className="h-3.5 w-3.5 text-muted-foreground" />
                                </button>
                              ))}
                              {files.map(file => (
                                <div
                                  key={file.key}
                                  className="flex items-center gap-3 px-3 py-2.5 hover:bg-muted/30 transition-colors group"
                                >
                                  {getFileIcon(file.key)}
                                  <div className="flex-1 min-w-0">
                                    <p className="text-sm truncate">{file.key.split("/").pop()}</p>
                                    <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
                                      <span>{formatFileSize(file.size)}</span>
                                      {file.lastModified && (
                                        <span>{new Date(file.lastModified).toLocaleDateString("pt-BR", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}</span>
                                      )}
                                    </div>
                                  </div>
                                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="h-7 w-7"
                                      onClick={() => handleMinioDownload(file.key)}
                                      disabled={minioPreviewLoading}
                                      title={file.key.endsWith(".json") ? "Visualizar" : "Baixar"}
                                    >
                                      {minioPreviewLoading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Download className="h-3.5 w-3.5" />}
                                    </Button>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="h-7 w-7 text-destructive hover:text-destructive"
                                      onClick={() => handleMinioDelete(file.key)}
                                      disabled={minioDeleting === file.key}
                                      title="Deletar"
                                    >
                                      {minioDeleting === file.key ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Trash2 className="h-3.5 w-3.5" />}
                                    </Button>
                                  </div>
                                </div>
                              ))}
                            </>
                          )
                        })()}
                      </div>
                    )}

                    {/* JSON Preview */}
                    {minioFilePreview && (
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <p className="text-xs font-medium flex items-center gap-1.5">
                            <FileJson className="h-3.5 w-3.5 text-amber-500" />
                            {minioFilePreview.path.split("/").pop()}
                          </p>
                          <div className="flex items-center gap-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-6 text-xs gap-1"
                              onClick={() => {
                                const blob = new Blob([minioFilePreview.content], { type: "application/json" })
                                const url = URL.createObjectURL(blob)
                                const a = document.createElement("a")
                                a.href = url
                                a.download = minioFilePreview.path.split("/").pop() || "file.json"
                                a.click()
                                URL.revokeObjectURL(url)
                              }}
                            >
                              <Download className="h-3 w-3" /> Baixar
                            </Button>
                            <Button variant="ghost" size="sm" className="h-6 text-xs" onClick={() => setMinioFilePreview(null)}>
                              <X className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                        <pre className="rounded-lg border bg-muted/30 p-3 text-[11px] font-mono max-h-[300px] overflow-auto whitespace-pre-wrap break-all">
                          {(() => {
                            try { return JSON.stringify(JSON.parse(minioFilePreview.content), null, 2) }
                            catch { return minioFilePreview.content }
                          })()}
                        </pre>
                      </div>
                    )}

                    <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
                      <Info className="h-3 w-3" />
                      <span>{minioFiles.length} arquivo(s) no total • Clique em pastas para navegar</span>
                    </div>
                  </div>
                )}
              </Card>
            </TabsContent>

            {/* Ferramentas Tab */}
            <TabsContent value="tools" className="space-y-4 mt-4">
              {/* Firecrawl */}
              <Card className="p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-lg bg-orange-500/10 flex items-center justify-center">
                      <Globe className="h-5 w-5 text-orange-500" />
                    </div>
                    <div>
                      <h3 className="font-semibold flex items-center gap-2">Firecrawl <StatusBadge connected={statuses.firecrawl} /></h3>
                      <p className="text-xs text-muted-foreground">Web scraping, busca e extração de dados com IA</p>
                    </div>
                  </div>
                </div>

                {statuses.firecrawl ? (
                  <div className="rounded-lg border border-emerald-500/20 bg-emerald-500/5 p-3 flex items-center gap-3">
                    <CheckCircle2 className="h-5 w-5 text-emerald-500 shrink-0" />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-emerald-700 dark:text-emerald-400">Firecrawl operando normalmente</p>
                      <p className="text-xs text-muted-foreground">
                        API Key configurada via connector • Scrape, Search, Map e Crawl disponíveis
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="rounded-lg border border-amber-500/20 bg-amber-500/5 p-3 flex items-center gap-3">
                    <AlertCircle className="h-5 w-5 text-amber-500 shrink-0" />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-amber-700 dark:text-amber-400">Firecrawl não configurado</p>
                      <p className="text-xs text-muted-foreground">
                        Configure o connector Firecrawl nas configurações do projeto para habilitar scraping.
                      </p>
                    </div>
                  </div>
                )}

                <div className="rounded-md border bg-muted/30 p-3">
                  <p className="text-xs text-muted-foreground flex items-start gap-2">
                    <Info className="h-4 w-4 shrink-0 mt-0.5 text-primary" />
                    <span>O Firecrawl é usado para scraping de perfis, extração de dados de páginas web e busca de conteúdo. A API Key é gerenciada automaticamente via connector. Funcionalidades: <strong>Scrape</strong> (extrair página), <strong>Search</strong> (buscar na web), <strong>Map</strong> (sitemap), <strong>Crawl</strong> (rastrear site).</span>
                  </p>
                </div>
              </Card>

              {/* Apify */}
              <Card className="p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-lg bg-teal-500/10 flex items-center justify-center">
                      <Search className="h-5 w-5 text-teal-500" />
                    </div>
                    <div>
                      <h3 className="font-semibold flex items-center gap-2">Apify <StatusBadge connected={statuses.apify} /></h3>
                      <p className="text-xs text-muted-foreground">Scraping de reels, perfis e dados do Instagram</p>
                    </div>
                  </div>
                </div>

                {statuses.apify ? (
                  <div className="rounded-lg border border-emerald-500/20 bg-emerald-500/5 p-3 flex items-center gap-3">
                    <CheckCircle2 className="h-5 w-5 text-emerald-500 shrink-0" />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-emerald-700 dark:text-emerald-400">Apify operando normalmente</p>
                      <p className="text-xs text-muted-foreground">
                        API Key configurada • Scraping de reels e perfis disponível
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="rounded-lg border border-amber-500/20 bg-amber-500/5 p-3 flex items-center gap-3">
                    <AlertCircle className="h-5 w-5 text-amber-500 shrink-0" />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-amber-700 dark:text-amber-400">Apify não configurado</p>
                      <p className="text-xs text-muted-foreground">
                        Configure o secret APIFY_API_KEY no backend para habilitar scraping de Instagram.
                      </p>
                    </div>
                  </div>
                )}

                <div className="rounded-md border bg-muted/30 p-3">
                  <p className="text-xs text-muted-foreground flex items-start gap-2">
                    <Info className="h-4 w-4 shrink-0 mt-0.5 text-primary" />
                    <span>O Apify é o provider principal de scraping de reels do Instagram. Usado no pipeline para coletar reels de competidores e seus próprios reels, incluindo download de vídeos, thumbnails, legendas e métricas de engajamento. Obtenha sua API Key em <a href="https://apify.com" target="_blank" rel="noopener noreferrer" className="text-primary underline inline-flex items-center gap-0.5">apify.com <ExternalLink className="h-2.5 w-2.5" /></a></span>
                  </p>
                </div>
              </Card>
            </TabsContent>

            {/* Social Networks Tab */}
            <TabsContent value="social" className="space-y-4 mt-4">
              {/* Instagram */}
              <Card className="p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-purple-500/20 to-pink-500/20 flex items-center justify-center">
                      <Instagram className="h-5 w-5 text-pink-500" />
                    </div>
                    <div>
                      <h3 className="font-semibold flex items-center gap-2">Instagram <StatusBadge connected={statuses.instagram} /></h3>
                      <p className="text-xs text-muted-foreground">Publicação automática via Instagram Graph API</p>
                    </div>
                  </div>
                </div>

                {igConnected && igAccount ? (
                  <div className="rounded-lg border border-emerald-500/20 bg-emerald-500/5 p-3">
                    <div className="flex items-center gap-3">
                      {igAccount.profilePicUrl ? (
                        <img src={igAccount.profilePicUrl} alt={igAccount.username} className="h-10 w-10 rounded-full border-2 border-emerald-500/30" />
                      ) : (
                        <div className="h-10 w-10 rounded-full bg-muted flex items-center justify-center"><Instagram className="h-4 w-4" /></div>
                      )}
                      <div>
                        <p className="font-medium text-sm">@{igAccount.username}</p>
                        {igAccount.followersCount && <p className="text-xs text-muted-foreground">{igAccount.followersCount.toLocaleString("pt-BR")} seguidores</p>}
                      </div>
                      <Button variant="destructive" size="sm" className="ml-auto gap-1.5" onClick={handleDisconnectInstagram} disabled={igLoading}>
                        {igLoading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Unplug className="h-3.5 w-3.5" />}
                        Desconectar
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className="rounded-md border bg-muted/30 p-3">
                      <ol className="text-xs text-muted-foreground space-y-1.5 ml-4 list-decimal">
                        <li>Acesse o <a href="https://developers.facebook.com" target="_blank" rel="noopener noreferrer" className="text-primary underline inline-flex items-center gap-0.5">Meta for Developers <ExternalLink className="h-2.5 w-2.5" /></a> e crie um App "Business"</li>
                        <li>Adicione <strong>Instagram Graph API</strong> ao App</li>
                        <li>Gere um <strong>Long-Lived Token</strong> com permissões: <code className="text-[10px]">pages_show_list, instagram_basic, instagram_content_publish</code></li>
                        <li>Cole o token abaixo</li>
                      </ol>
                    </div>
                    <div className="flex gap-2">
                      <div className="relative flex-1">
                        <Input type={showKeys.igToken ? "text" : "password"} placeholder="EAAxxxxxxxx..." value={igToken} onChange={e => setIgToken(e.target.value)} className="h-8 text-xs pr-8" />
                        <Button variant="ghost" size="icon" className="absolute right-0 top-0 h-8 w-8" onClick={() => toggleKey("igToken")}>
                          {showKeys.igToken ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
                        </Button>
                      </div>
                      <Button size="sm" onClick={handleConnectInstagram} disabled={igLoading || !igToken.trim()} className="gap-1.5">
                        {igLoading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Instagram className="h-3.5 w-3.5" />}
                        Conectar
                      </Button>
                    </div>
                  </div>
                )}
              </Card>

              {/* TikTok */}
              <Card className="p-4 opacity-60">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-lg bg-foreground/5 flex items-center justify-center">
                    <svg className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor"><path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.5 2.89 2.89 0 0 1-2.88-2.88 2.89 2.89 0 0 1 2.88-2.88c.3 0 .58.04.86.1v-3.5a6.37 6.37 0 0 0-.86-.06C5.81 8.95 3 11.76 3 15.44A6.5 6.5 0 0 0 9.49 22a6.5 6.5 0 0 0 6.49-6.56V8.77a8.18 8.18 0 0 0 4.83 1.56V6.89a4.84 4.84 0 0 1-1.22-.2z" /></svg>
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold flex items-center gap-2">TikTok <ComingSoonBadge /></h3>
                    <p className="text-xs text-muted-foreground">Publicação e análise de conteúdo TikTok</p>
                  </div>
                </div>
              </Card>

              {/* YouTube */}
              <Card className="p-4 opacity-60">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-lg bg-red-500/10 flex items-center justify-center">
                    <Youtube className="h-5 w-5 text-red-500" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold flex items-center gap-2">YouTube <ComingSoonBadge /></h3>
                    <p className="text-xs text-muted-foreground">YouTube Shorts e análise de canal</p>
                  </div>
                </div>
              </Card>

              {/* Twitter/X */}
              <Card className="p-4 opacity-60">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-lg bg-foreground/5 flex items-center justify-center">
                    <Twitter className="h-5 w-5" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold flex items-center gap-2">X (Twitter) <ComingSoonBadge /></h3>
                    <p className="text-xs text-muted-foreground">Publicação e monitoramento de tweets</p>
                  </div>
                </div>
              </Card>

              {/* Facebook */}
              <Card className="p-4 opacity-60">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
                    <Facebook className="h-5 w-5 text-blue-500" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold flex items-center gap-2">Facebook <ComingSoonBadge /></h3>
                    <p className="text-xs text-muted-foreground">Páginas e Reels do Facebook</p>
                  </div>
                </div>
              </Card>
            </TabsContent>

            {/* Messaging Tab */}
            <TabsContent value="messaging" className="space-y-4 mt-4">
              <Card className="p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                      <MessageSquare className="h-5 w-5 text-emerald-500" />
                    </div>
                    <div>
                      <h3 className="font-semibold flex items-center gap-2">WhatsApp Evolution API <StatusBadge connected={whatsappConnected} /></h3>
                      <p className="text-xs text-muted-foreground">Notificações automáticas de publicações via WhatsApp</p>
                    </div>
                  </div>
                </div>

                {whatsappConnected && (
                  <div className="rounded-lg border border-emerald-500/20 bg-emerald-500/5 p-3 flex items-center gap-3">
                    <CheckCircle2 className="h-5 w-5 text-emerald-500 shrink-0" />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-emerald-700 dark:text-emerald-400">WhatsApp configurado</p>
                      <p className="text-xs text-muted-foreground">
                        Notificações serão enviadas quando publicações agendadas forem realizadas ou falharem.
                      </p>
                    </div>
                  </div>
                )}

                <div className="grid gap-3">
                  <div className="space-y-1.5">
                    <Label className="text-xs">URL da API</Label>
                    <Input placeholder="https://sua-api.evolution.com" value={whatsappUrl} onChange={e => setWhatsappUrl(e.target.value)} className="h-8 text-xs" />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs">API Key</Label>
                    <div className="relative">
                      <Input type={showKeys.whatsapp ? "text" : "password"} placeholder="Sua chave de API" value={whatsappKey} onChange={e => setWhatsappKey(e.target.value)} className="h-8 text-xs pr-8" />
                      <Button variant="ghost" size="icon" className="absolute right-0 top-0 h-8 w-8" onClick={() => toggleKey("whatsapp")}>
                        {showKeys.whatsapp ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
                      </Button>
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs">Número para Notificações</Label>
                    <Input placeholder="5511999999999" value={whatsappNumber} onChange={e => setWhatsappNumber(e.target.value)} className="h-8 text-xs" />
                    <p className="text-[10px] text-muted-foreground">Número com código do país (sem +). Ex: 5511999999999</p>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={handleTestWhatsapp} disabled={whatsappTesting || !whatsappUrl || !whatsappKey} className="gap-1.5">
                    {whatsappTesting ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
                    Testar Conexão
                  </Button>
                  <Button size="sm" onClick={handleSaveWhatsapp} disabled={whatsappSaving || !whatsappUrl || !whatsappKey} className="gap-1.5">
                    {whatsappSaving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
                    Salvar
                  </Button>
                </div>

                <div className="rounded-md border bg-muted/30 p-3">
                  <p className="text-xs text-muted-foreground flex items-start gap-2">
                    <Info className="h-4 w-4 shrink-0 mt-0.5 text-primary" />
                    <span>Configure a Evolution API para receber notificações automáticas quando publicações agendadas forem realizadas com sucesso ou falharem. As credenciais são salvas de forma segura no seu perfil.</span>
                  </p>
                </div>
              </Card>
            </TabsContent>

            {/* Email Tab */}
            <TabsContent value="email" className="space-y-4 mt-4">
              <Card className="p-5 space-y-4">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Mail className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Resend API</h3>
                    <p className="text-xs text-muted-foreground">Envio de emails transacionais e notificações</p>
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">API Key</Label>
                  <div className="relative">
                    <Input type={showKeys.resend ? "text" : "password"} placeholder="re_xxxxxxxxxxxx" value={resendKey} onChange={e => setResendKey(e.target.value)} className="h-8 text-xs pr-8" />
                    <Button variant="ghost" size="icon" className="absolute right-0 top-0 h-8 w-8" onClick={() => toggleKey("resend")}>
                      {showKeys.resend ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
                    </Button>
                  </div>
                </div>
                <div className="rounded-md border bg-muted/30 p-3">
                  <p className="text-xs text-muted-foreground flex items-start gap-2">
                    <Info className="h-4 w-4 shrink-0 mt-0.5 text-primary" />
                    <span>Configure o Resend para enviar relatórios por email, alertas de pipeline e notificações de publicação. Obtenha sua chave em <a href="https://resend.com" target="_blank" rel="noopener noreferrer" className="text-primary underline inline-flex items-center gap-0.5">resend.com <ExternalLink className="h-2.5 w-2.5" /></a></span>
                  </p>
                </div>
              </Card>
            </TabsContent>
          </Tabs>
        )}
      </DialogContent>
    </Dialog>
  )
}
