import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Database, HardDrive, Cloud, ArrowRight, Server, Lock, FileText, Image, Music, Video, Users, Film, Smartphone, Brain, Send, Settings, Shield, Tag, Bot } from "lucide-react"

interface ArchitectureModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

const supabaseTables = [
  { name: "competidores", desc: "Perfis dos competidores monitorados", icon: <Users className="h-3.5 w-3.5" /> },
  { name: "reels_competidores", desc: "Reels raspados dos competidores", icon: <Film className="h-3.5 w-3.5" /> },
  { name: "meus_reels", desc: "Seus reels analisados", icon: <Smartphone className="h-3.5 w-3.5" /> },
  { name: "estrategias", desc: "Relatórios semanais de estratégia", icon: <Brain className="h-3.5 w-3.5" /> },
  { name: "generated_content", desc: "Histórico de conteúdo gerado por IA", icon: <FileText className="h-3.5 w-3.5" /> },
  { name: "publish_queue", desc: "Fila de publicação no Instagram", icon: <Send className="h-3.5 w-3.5" /> },
  { name: "agent_configs", desc: "Configurações dos agentes de IA", icon: <Bot className="h-3.5 w-3.5" /> },
  { name: "pipeline_config", desc: "Config. do pipeline de automação", icon: <Settings className="h-3.5 w-3.5" /> },
  { name: "profiles", desc: "Perfis de usuários do sistema", icon: <Users className="h-3.5 w-3.5" /> },
  { name: "instagram_credentials", desc: "Tokens de acesso ao Instagram", icon: <Lock className="h-3.5 w-3.5" /> },
  { name: "user_api_keys", desc: "Chaves de API dos provedores de IA", icon: <Shield className="h-3.5 w-3.5" /> },
  { name: "allowed_senders", desc: "Usuários autorizados para DMs", icon: <Shield className="h-3.5 w-3.5" /> },
  { name: "system_config", desc: "Configurações de nicho e sistema", icon: <Tag className="h-3.5 w-3.5" /> },
  { name: "ai_providers", desc: "Status dos provedores de IA", icon: <Bot className="h-3.5 w-3.5" /> },
  { name: "dm_poll_state", desc: "Estado do polling de DMs", icon: <Settings className="h-3.5 w-3.5" /> },
]

const minioFolders = [
  { name: "paradigmas/face/", desc: "Referências faciais para avatar/animação", icon: <Image className="h-3.5 w-3.5" /> },
  { name: "paradigmas/corpo/", desc: "Referências corporais para animação", icon: <Image className="h-3.5 w-3.5" /> },
  { name: "paradigmas/voz/", desc: "Amostras de áudio para voiceover", icon: <Music className="h-3.5 w-3.5" /> },
  { name: "paradigmas/estilo/", desc: "Referências de estilo visual", icon: <Image className="h-3.5 w-3.5" /> },
  { name: "paradigmas/referencias/", desc: "Referências gerais de conteúdo", icon: <Image className="h-3.5 w-3.5" /> },
  { name: "kanban/{userId}/", desc: "Estado do quadro Kanban (board.json)", icon: <FileText className="h-3.5 w-3.5" /> },
  { name: "ideas/{userId}/", desc: "Banco de ideias (ideas.json)", icon: <FileText className="h-3.5 w-3.5" /> },
  { name: "backups/", desc: "Backups de análises pesadas", icon: <HardDrive className="h-3.5 w-3.5" /> },
  { name: "videos/", desc: "Vídeos gerados e mídia pesada", icon: <Video className="h-3.5 w-3.5" /> },
]

const edgeFunctions = [
  { name: "run-pipeline", desc: "Orquestra scraping + análise completa" },
  { name: "generate-content", desc: "Gera conteúdo via agentes de IA" },
  { name: "ai-chat", desc: "Chatbot assistente de estratégia" },
  { name: "scrape-reels", desc: "Raspagem de reels via Apify" },
  { name: "analyze-content", desc: "Análise multimodal de conteúdo" },
  { name: "weekly-strategy-report", desc: "Relatório semanal automático" },
  { name: "publish-instagram", desc: "Publica conteúdo no Instagram" },
  { name: "poll-instagram-dms", desc: "Captura links de DMs" },
  { name: "save-to-minio", desc: "Proxy para upload/download no MinIO" },
  { name: "scheduled-publish", desc: "Publicação agendada (CRON)" },
  { name: "cron-pipeline", desc: "Pipeline automático diário" },
]

export function ArchitectureModal({ open, onOpenChange }: ArchitectureModalProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-lg">
            <Server className="h-5 w-5 text-primary" />
            Arquitetura do Sistema — O que está em cada lugar
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 text-sm">
          {/* Overview */}
          <div className="rounded-lg border border-primary/20 bg-primary/5 p-4">
            <p className="text-muted-foreground leading-relaxed">
              O IG OS v3 usa uma <strong>arquitetura híbrida</strong>: o banco de dados relacional (Lovable Cloud) gerencia dados estruturados com segurança por usuário (RLS), 
              enquanto o MinIO externo armazena arquivos de mídia e objetos de esquema flexível. As Edge Functions conectam tudo.
            </p>
          </div>

          {/* 3-column layout */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            
            {/* Supabase / Lovable Cloud */}
            <div className="rounded-lg border bg-card p-4 space-y-3">
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-500/10">
                  <Database className="h-4 w-4 text-blue-500" />
                </div>
                <div>
                  <h3 className="font-semibold text-sm">Lovable Cloud</h3>
                  <p className="text-[10px] text-muted-foreground">Banco Relacional + Auth + RLS</p>
                </div>
              </div>
              <Separator />
              <p className="text-xs text-muted-foreground">
                Dados estruturados com queries, filtros e segurança por usuário (Row Level Security).
              </p>
              <div className="space-y-1.5 max-h-[280px] overflow-y-auto pr-1">
                {supabaseTables.map(t => (
                  <div key={t.name} className="flex items-start gap-2 rounded-md bg-muted/50 px-2 py-1.5">
                    <span className="shrink-0 mt-0.5 text-blue-500">{t.icon}</span>
                    <div className="min-w-0">
                      <p className="font-mono text-[11px] font-medium truncate">{t.name}</p>
                      <p className="text-[10px] text-muted-foreground leading-tight">{t.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex flex-wrap gap-1 pt-1">
                <Badge variant="outline" className="text-[10px]">PostgreSQL</Badge>
                <Badge variant="outline" className="text-[10px]">RLS por user_id</Badge>
                <Badge variant="outline" className="text-[10px]">Auth JWT</Badge>
              </div>
            </div>

            {/* MinIO */}
            <div className="rounded-lg border bg-card p-4 space-y-3">
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-500/10">
                  <HardDrive className="h-4 w-4 text-amber-500" />
                </div>
                <div>
                  <h3 className="font-semibold text-sm">MinIO</h3>
                  <p className="text-[10px] text-muted-foreground">Object Storage (S3 API · porta 19000)</p>
                </div>
              </div>
              <Separator />
              <p className="text-xs text-muted-foreground">
                Arquivos de mídia, JSONs flexíveis e blobs pesados. Acessado via Edge Function <code className="text-[10px] bg-muted px-1 rounded">save-to-minio</code>.
              </p>
              <div className="space-y-1.5 max-h-[280px] overflow-y-auto pr-1">
                {minioFolders.map(f => (
                  <div key={f.name} className="flex items-start gap-2 rounded-md bg-muted/50 px-2 py-1.5">
                    <span className="shrink-0 mt-0.5 text-amber-500">{f.icon}</span>
                    <div className="min-w-0">
                      <p className="font-mono text-[11px] font-medium truncate">{f.name}</p>
                      <p className="text-[10px] text-muted-foreground leading-tight">{f.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex flex-wrap gap-1 pt-1">
                <Badge variant="outline" className="text-[10px]">S3-Compatible</Badge>
                <Badge variant="outline" className="text-[10px]">Blobs/Mídia</Badge>
                <Badge variant="outline" className="text-[10px]">JSON flexível</Badge>
              </div>
            </div>

            {/* Edge Functions */}
            <div className="rounded-lg border bg-card p-4 space-y-3">
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-500/10">
                  <Cloud className="h-4 w-4 text-emerald-500" />
                </div>
                <div>
                  <h3 className="font-semibold text-sm">Edge Functions</h3>
                  <p className="text-[10px] text-muted-foreground">Backend serverless (Deno)</p>
                </div>
              </div>
              <Separator />
              <p className="text-xs text-muted-foreground">
                Lógica de negócios, integrações com APIs externas (OpenRouter, Apify, Instagram) e orquestração.
              </p>
              <div className="space-y-1.5 max-h-[280px] overflow-y-auto pr-1">
                {edgeFunctions.map(fn => (
                  <div key={fn.name} className="flex items-start gap-2 rounded-md bg-muted/50 px-2 py-1.5">
                    <ArrowRight className="h-3 w-3 shrink-0 mt-1 text-emerald-500" />
                    <div className="min-w-0">
                      <p className="font-mono text-[11px] font-medium truncate">{fn.name}</p>
                      <p className="text-[10px] text-muted-foreground leading-tight">{fn.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex flex-wrap gap-1 pt-1">
                <Badge variant="outline" className="text-[10px]">Deno Runtime</Badge>
                <Badge variant="outline" className="text-[10px]">Serverless</Badge>
                <Badge variant="outline" className="text-[10px]">Auto-deploy</Badge>
              </div>
            </div>
          </div>

          {/* Why hybrid */}
          <div className="rounded-lg border border-muted bg-muted/30 p-4 space-y-2">
            <h4 className="font-semibold text-sm flex items-center gap-2">
              <span>💡</span> Por que a arquitetura é híbrida?
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-muted-foreground">
              <div className="space-y-1">
                <p><strong className="text-foreground">Lovable Cloud (banco relacional)</strong></p>
                <ul className="list-disc pl-4 space-y-0.5">
                  <li>Queries SQL complexas (filtros, joins, ordenação)</li>
                  <li>Segurança por usuário via RLS automático</li>
                  <li>Autenticação JWT integrada</li>
                  <li>Tipagem forte (TypeScript auto-gerado)</li>
                  <li>Ideal para: metadados, configs, credenciais, filas</li>
                </ul>
              </div>
              <div className="space-y-1">
                <p><strong className="text-foreground">MinIO (object storage)</strong></p>
                <ul className="list-disc pl-4 space-y-0.5">
                  <li>Armazenamento barato de arquivos grandes</li>
                  <li>API S3 compatível (upload/download direto)</li>
                  <li>Esquema flexível (JSON sem schema fixo)</li>
                  <li>Ideal para: imagens, vídeos, áudios, backups</li>
                  <li>Kanban/Ideias como JSON (sem migração de schema)</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
