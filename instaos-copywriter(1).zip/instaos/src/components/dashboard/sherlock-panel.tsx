import { useState, useEffect } from "react"
import { supabase } from "@/integrations/supabase/client"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import { Loader2, Search, Plus, X, CheckCircle2, Clock, AlertCircle, RefreshCw } from "lucide-react"

interface Investigation {
  id: string
  profile_urls: string[]
  mode: string
  status: string
  consolidated: string | null
  completed_at: string | null
  created_at: string
  profiles: any
}

export function SherlockPanel({ onConsolidatedReady }: { onConsolidatedReady?: (text: string) => void }) {
  const [urls, setUrls] = useState<string[]>([""])
  const [mode, setMode] = useState("profile_5_10")
  const [running, setRunning] = useState(false)
  const [investigations, setInvestigations] = useState<Investigation[]>([])
  const [pollingId, setPollingId] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => { loadInvestigations() }, [])

  useEffect(() => {
    if (!pollingId) return
    const iv = setInterval(async () => {
      const { data: { session } } = await supabase.auth.getSession()
      const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/sherlock-investigator`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.access_token}` },
        body: JSON.stringify({ action: "get_results", investigationId: pollingId }),
      })
      const d = await res.json()
      if (d.investigation?.status === "completed") {
        clearInterval(iv)
        setPollingId(null)
        loadInvestigations()
        toast.success("Investigação concluída!")
        if (d.investigation.consolidated) onConsolidatedReady?.(d.investigation.consolidated)
      } else if (d.investigation?.status === "failed") {
        clearInterval(iv)
        setPollingId(null)
        toast.error("Investigação falhou: " + (d.investigation.error || "erro desconhecido"))
        loadInvestigations()
      }
    }, 8000)
    return () => clearInterval(iv)
  }, [pollingId])

  async function loadInvestigations() {
    setLoading(true)
    const { data: { session } } = await supabase.auth.getSession()
    try {
      const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/sherlock-investigator`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.access_token}` },
        body: JSON.stringify({ action: "get_consolidated" }),
      })
      const d = await res.json()
      setInvestigations(d.investigations || [])
    } finally { setLoading(false) }
  }

  async function run() {
    const validUrls = urls.map(u => u.trim()).filter(Boolean).map(u =>
      u.startsWith("http") ? u : `https://instagram.com/${u.replace("@", "")}`
    )
    if (!validUrls.length) { toast.error("Adicione pelo menos um perfil"); return }
    setRunning(true)
    const { data: { session } } = await supabase.auth.getSession()
    try {
      const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/sherlock-investigator`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.access_token}` },
        body: JSON.stringify({ action: "investigate", profileUrls: validUrls, mode }),
      })
      const d = await res.json()
      if (!d.success) throw new Error(d.error)
      toast.success(d.message)
      setPollingId(d.investigationId)
      loadInvestigations()
    } catch (e: any) { toast.error(e.message) }
    finally { setRunning(false) }
  }

  return (
    <div className="space-y-5">
      <div>
        <h3 className="font-bold text-base flex items-center gap-2">
          <Search className="w-4 h-4 text-yellow-400" />
          Sherlock — Investigar Perfis Reais
        </h3>
        <p className="text-xs text-muted-foreground mt-1">
          Analisa perfis reais do Instagram via Apify, extrai padrões, hooks e estruturas que funcionam no seu nicho
        </p>
      </div>

      {/* URL inputs */}
      <div className="space-y-2">
        <p className="text-xs text-muted-foreground">Perfis a investigar (1-5 perfis)</p>
        {urls.map((url, i) => (
          <div key={i} className="flex gap-2">
            <Input value={url} onChange={e => setUrls(p => { const n = [...p]; n[i] = e.target.value; return n })}
              placeholder="@djairrotta ou https://instagram.com/djairrotta" className="text-xs" />
            {urls.length > 1 && (
              <button onClick={() => setUrls(p => p.filter((_, j) => j !== i))} className="text-muted-foreground hover:text-red-400">
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        ))}
        {urls.length < 5 && (
          <button onClick={() => setUrls(p => [...p, ""])} className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground">
            <Plus className="w-3 h-3" />Adicionar perfil
          </button>
        )}
      </div>

      {/* Mode */}
      <div className="flex gap-2">
        {[
          { id: "profile_1", label: "1 post", desc: "~2-3 min" },
          { id: "profile_5_10", label: "5-10 posts", desc: "~5-10 min" },
        ].map(m => (
          <button key={m.id} onClick={() => setMode(m.id)}
            className={cn("flex-1 rounded-lg border py-2 px-3 text-xs font-medium transition-all",
              mode === m.id ? "border-yellow-500/50 bg-yellow-500/10 text-yellow-400" : "border-border text-muted-foreground hover:border-yellow-500/20"
            )}>
            {m.label} <span className="text-[10px] opacity-60">({m.desc})</span>
          </button>
        ))}
      </div>

      <Button onClick={run} disabled={running || !!pollingId} className="w-full gap-2 bg-yellow-500 hover:bg-yellow-400 text-black font-semibold">
        {running || pollingId ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
        {pollingId ? "Investigando... (pode levar 5-10 min)" : "Iniciar Investigação"}
      </Button>

      {/* History */}
      {investigations.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-2">
            <p className="text-xs text-muted-foreground font-medium">Investigações anteriores</p>
            <button onClick={loadInvestigations} className="text-muted-foreground hover:text-foreground">
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="space-y-2">
            {investigations.slice(0, 5).map(inv => (
              <div key={inv.id} className="rounded-lg border border-border bg-card p-3">
                <div className="flex items-center gap-2 mb-1.5">
                  {inv.status === "completed" ? <CheckCircle2 className="w-3.5 h-3.5 text-green-400" /> :
                   inv.status === "running" ? <Loader2 className="w-3.5 h-3.5 text-yellow-400 animate-spin" /> :
                   <AlertCircle className="w-3.5 h-3.5 text-red-400" />}
                  <span className="text-xs font-medium">{inv.profile_urls.map(u => "@" + u.split("/").filter(Boolean).pop()).join(", ")}</span>
                  <span className="text-[10px] text-muted-foreground ml-auto flex items-center gap-1">
                    <Clock className="w-2.5 h-2.5" />
                    {new Date(inv.created_at).toLocaleDateString("pt-BR", { day: "2-digit", month: "short" })}
                  </span>
                </div>
                {inv.consolidated && (
                  <div>
                    <p className="text-[10px] text-muted-foreground line-clamp-2">{inv.consolidated.slice(0, 200)}...</p>
                    <button onClick={() => onConsolidatedReady?.(inv.consolidated!)}
                      className="text-[10px] text-yellow-400 hover:text-yellow-300 mt-1">
                      Usar esta análise →
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
