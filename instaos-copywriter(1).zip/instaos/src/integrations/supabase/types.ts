export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      agent_configs: {
        Row: {
          agent_type: string
          created_at: string
          custom_prompt: string | null
          custom_prompt_2: string | null
          custom_prompt_3: string | null
          id: string
          is_active: boolean
          model: string
          provider: string
          updated_at: string
          user_id: string
        }
        Insert: {
          agent_type: string
          created_at?: string
          custom_prompt?: string | null
          custom_prompt_2?: string | null
          custom_prompt_3?: string | null
          id?: string
          is_active?: boolean
          model?: string
          provider?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          agent_type?: string
          created_at?: string
          custom_prompt?: string | null
          custom_prompt_2?: string | null
          custom_prompt_3?: string | null
          id?: string
          is_active?: boolean
          model?: string
          provider?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      ai_providers: {
        Row: {
          created_at: string
          display_name: string
          id: string
          is_configured: boolean
          provider_name: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          display_name: string
          id?: string
          is_configured?: boolean
          provider_name: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          display_name?: string
          id?: string
          is_configured?: boolean
          provider_name?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      allowed_senders: {
        Row: {
          created_at: string
          id: string
          ig_username: string
          is_active: boolean
          note: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          ig_username: string
          is_active?: boolean
          note?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          ig_username?: string
          is_active?: boolean
          note?: string | null
          user_id?: string
        }
        Relationships: []
      }
      competidores: {
        Row: {
          avg_posts_per_week: number | null
          bio: string | null
          created_at: string
          followers_count: number | null
          following_count: number | null
          id: string
          last_profile_update: string | null
          name: string
          niche: string | null
          page_url: string
          posts_count: number | null
          predominant_content_type: string | null
          profile_pic_url: string | null
          status: boolean
          updated_at: string
          user_id: string | null
        }
        Insert: {
          avg_posts_per_week?: number | null
          bio?: string | null
          created_at?: string
          followers_count?: number | null
          following_count?: number | null
          id?: string
          last_profile_update?: string | null
          name: string
          niche?: string | null
          page_url: string
          posts_count?: number | null
          predominant_content_type?: string | null
          profile_pic_url?: string | null
          status?: boolean
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          avg_posts_per_week?: number | null
          bio?: string | null
          created_at?: string
          followers_count?: number | null
          following_count?: number | null
          id?: string
          last_profile_update?: string | null
          name?: string
          niche?: string | null
          page_url?: string
          posts_count?: number | null
          predominant_content_type?: string | null
          profile_pic_url?: string | null
          status?: boolean
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      dm_poll_state: {
        Row: {
          created_at: string
          id: string
          last_cursor: string | null
          last_poll_at: string | null
          processed_thread_ids: string[] | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          last_cursor?: string | null
          last_poll_at?: string | null
          processed_thread_ids?: string[] | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          last_cursor?: string | null
          last_poll_at?: string | null
          processed_thread_ids?: string[] | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      estrategias: {
        Row: {
          created_at: string
          hook_ideas: Json | null
          id: string
          key_takeaway: string | null
          raw_report: string | null
          title: string
          top_videos: Json | null
          user_id: string | null
          winning_patterns: Json | null
        }
        Insert: {
          created_at?: string
          hook_ideas?: Json | null
          id?: string
          key_takeaway?: string | null
          raw_report?: string | null
          title: string
          top_videos?: Json | null
          user_id?: string | null
          winning_patterns?: Json | null
        }
        Update: {
          created_at?: string
          hook_ideas?: Json | null
          id?: string
          key_takeaway?: string | null
          raw_report?: string | null
          title?: string
          top_videos?: Json | null
          user_id?: string | null
          winning_patterns?: Json | null
        }
        Relationships: []
      }
      generated_content: {
        Row: {
          agent_type: string
          created_at: string
          generation_type: string
          id: string
          model: string
          prompt: string
          provider: string
          result: string
          user_id: string
        }
        Insert: {
          agent_type: string
          created_at?: string
          generation_type: string
          id?: string
          model: string
          prompt: string
          provider: string
          result: string
          user_id: string
        }
        Update: {
          agent_type?: string
          created_at?: string
          generation_type?: string
          id?: string
          model?: string
          prompt?: string
          provider?: string
          result?: string
          user_id?: string
        }
        Relationships: []
      }
      instagram_credentials: {
        Row: {
          access_token: string
          created_at: string
          id: string
          ig_user_id: string | null
          ig_username: string | null
          is_connected: boolean | null
          last_verified_at: string | null
          page_id: string | null
          permissions: string[] | null
          token_expires_at: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          access_token: string
          created_at?: string
          id?: string
          ig_user_id?: string | null
          ig_username?: string | null
          is_connected?: boolean | null
          last_verified_at?: string | null
          page_id?: string | null
          permissions?: string[] | null
          token_expires_at?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          access_token?: string
          created_at?: string
          id?: string
          ig_user_id?: string | null
          ig_username?: string | null
          is_connected?: boolean | null
          last_verified_at?: string | null
          page_id?: string | null
          permissions?: string[] | null
          token_expires_at?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      meus_reels: {
        Row: {
          caption: string | null
          comments: number | null
          content_type: string
          created_at: string
          eng_rate: number | null
          hook_analysis: string | null
          id: string
          image_urls: Json | null
          likes: number | null
          owner_username: string | null
          post_date: string | null
          psychological_triggers: string | null
          relevance_reason: string | null
          relevance_score: number | null
          relevance_status: string
          thumbnail_url: string | null
          transcript: string | null
          url: string | null
          user_id: string | null
          video_url: string | null
          views: number | null
          viral_points: string | null
        }
        Insert: {
          caption?: string | null
          comments?: number | null
          content_type?: string
          created_at?: string
          eng_rate?: number | null
          hook_analysis?: string | null
          id?: string
          image_urls?: Json | null
          likes?: number | null
          owner_username?: string | null
          post_date?: string | null
          psychological_triggers?: string | null
          relevance_reason?: string | null
          relevance_score?: number | null
          relevance_status?: string
          thumbnail_url?: string | null
          transcript?: string | null
          url?: string | null
          user_id?: string | null
          video_url?: string | null
          views?: number | null
          viral_points?: string | null
        }
        Update: {
          caption?: string | null
          comments?: number | null
          content_type?: string
          created_at?: string
          eng_rate?: number | null
          hook_analysis?: string | null
          id?: string
          image_urls?: Json | null
          likes?: number | null
          owner_username?: string | null
          post_date?: string | null
          psychological_triggers?: string | null
          relevance_reason?: string | null
          relevance_score?: number | null
          relevance_status?: string
          thumbnail_url?: string | null
          transcript?: string | null
          url?: string | null
          user_id?: string | null
          video_url?: string | null
          views?: number | null
          viral_points?: string | null
        }
        Relationships: []
      }
      pipeline_config: {
        Row: {
          ai_model: string
          competitor_reels_limit: number
          competitor_weeks_filter: number
          created_at: string
          cron_enabled: boolean
          cron_job_id: number | null
          cron_last_run: string | null
          cron_schedule: string
          id: string
          instagram_username: string
          my_reels_limit: number
          my_reels_months_filter: number
          scrape_provider: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          ai_model?: string
          competitor_reels_limit?: number
          competitor_weeks_filter?: number
          created_at?: string
          cron_enabled?: boolean
          cron_job_id?: number | null
          cron_last_run?: string | null
          cron_schedule?: string
          id?: string
          instagram_username?: string
          my_reels_limit?: number
          my_reels_months_filter?: number
          scrape_provider?: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          ai_model?: string
          competitor_reels_limit?: number
          competitor_weeks_filter?: number
          created_at?: string
          cron_enabled?: boolean
          cron_job_id?: number | null
          cron_last_run?: string | null
          cron_schedule?: string
          id?: string
          instagram_username?: string
          my_reels_limit?: number
          my_reels_months_filter?: number
          scrape_provider?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      processed_content_log: {
        Row: {
          content_type: string | null
          created_at: string
          id: string
          shortcode: string
          source_url: string | null
          user_id: string
        }
        Insert: {
          content_type?: string | null
          created_at?: string
          id?: string
          shortcode: string
          source_url?: string | null
          user_id: string
        }
        Update: {
          content_type?: string | null
          created_at?: string
          id?: string
          shortcode?: string
          source_url?: string | null
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          display_name: string | null
          id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          display_name?: string | null
          id?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          display_name?: string | null
          id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      publish_queue: {
        Row: {
          caption: string | null
          content_type: string
          created_at: string
          error_message: string | null
          id: string
          ig_media_id: string | null
          ig_permalink: string | null
          media_urls: Json | null
          published_at: string | null
          scheduled_at: string | null
          source_content_id: string | null
          status: string
          updated_at: string
          user_id: string
          video_url: string | null
        }
        Insert: {
          caption?: string | null
          content_type?: string
          created_at?: string
          error_message?: string | null
          id?: string
          ig_media_id?: string | null
          ig_permalink?: string | null
          media_urls?: Json | null
          published_at?: string | null
          scheduled_at?: string | null
          source_content_id?: string | null
          status?: string
          updated_at?: string
          user_id: string
          video_url?: string | null
        }
        Update: {
          caption?: string | null
          content_type?: string
          created_at?: string
          error_message?: string | null
          id?: string
          ig_media_id?: string | null
          ig_permalink?: string | null
          media_urls?: Json | null
          published_at?: string | null
          scheduled_at?: string | null
          source_content_id?: string | null
          status?: string
          updated_at?: string
          user_id?: string
          video_url?: string | null
        }
        Relationships: []
      }
      reels_competidores: {
        Row: {
          caption: string | null
          comments: number | null
          competidor_id: string | null
          content_type: string
          created_at: string
          eng_rate: number | null
          hook_analysis: string | null
          id: string
          image_urls: Json | null
          likes: number | null
          owner_username: string | null
          post_date: string | null
          psychological_triggers: string | null
          relevance_reason: string | null
          relevance_score: number | null
          relevance_status: string
          thumbnail_url: string | null
          transcript: string | null
          url: string | null
          user_id: string | null
          video_url: string | null
          views: number | null
          viral_points: string | null
        }
        Insert: {
          caption?: string | null
          comments?: number | null
          competidor_id?: string | null
          content_type?: string
          created_at?: string
          eng_rate?: number | null
          hook_analysis?: string | null
          id?: string
          image_urls?: Json | null
          likes?: number | null
          owner_username?: string | null
          post_date?: string | null
          psychological_triggers?: string | null
          relevance_reason?: string | null
          relevance_score?: number | null
          relevance_status?: string
          thumbnail_url?: string | null
          transcript?: string | null
          url?: string | null
          user_id?: string | null
          video_url?: string | null
          views?: number | null
          viral_points?: string | null
        }
        Update: {
          caption?: string | null
          comments?: number | null
          competidor_id?: string | null
          content_type?: string
          created_at?: string
          eng_rate?: number | null
          hook_analysis?: string | null
          id?: string
          image_urls?: Json | null
          likes?: number | null
          owner_username?: string | null
          post_date?: string | null
          psychological_triggers?: string | null
          relevance_reason?: string | null
          relevance_score?: number | null
          relevance_status?: string
          thumbnail_url?: string | null
          transcript?: string | null
          url?: string | null
          user_id?: string | null
          video_url?: string | null
          views?: number | null
          viral_points?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "reels_competidores_competidor_id_fkey"
            columns: ["competidor_id"]
            isOneToOne: false
            referencedRelation: "competidores"
            referencedColumns: ["id"]
          },
        ]
      }
      system_config: {
        Row: {
          config_key: string
          config_value: string
          created_at: string
          id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          config_key: string
          config_value: string
          created_at?: string
          id?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          config_key?: string
          config_value?: string
          created_at?: string
          id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_api_keys: {
        Row: {
          api_key: string
          created_at: string
          id: string
          is_active: boolean
          provider: string
          updated_at: string
          user_id: string
        }
        Insert: {
          api_key: string
          created_at?: string
          id?: string
          is_active?: boolean
          provider: string
          updated_at?: string
          user_id: string
        }
        Update: {
          api_key?: string
          created_at?: string
          id?: string
          is_active?: boolean
          provider?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
