import { useState, useCallback, useEffect } from "react"
import { Sidebar, defaultDatabases } from "@/components/dashboard/sidebar"
import { DataTable, type CompetitorRow, type ReelRow, type StrategyRow } from "@/components/dashboard/data-table"
import { KanbanBoard, type KanbanItem, type KanbanStatus } from "@/components/dashboard/kanban-board"
import { QuickAnalysis } from "@/components/dashboard/quick-analysis"
import { ThemeToggle } from "@/components/dashboard/theme-toggle"

import { DatabaseModal, type DatabaseType } from "@/components/dashboard/database-modal"
import { AiGenerationModal, type GenerationType } from "@/components/dashboard/ai-generation-modal"
import { ParametersModal } from "@/components/dashboard/parameters-modal"
import { AgentSettingsModal } from "@/components/dashboard/agent-settings-modal"
import { ContentHistoryModal } from "@/components/dashboard/content-history-modal"
import { PublishQueue } from "@/components/dashboard/publish-queue"
import { IntegrationsModal } from "@/components/dashboard/integrations-modal"
import { AllowedSendersModal } from "@/components/dashboard/allowed-senders-modal"
import { WorkflowFlowModal } from "@/components/dashboard/workflow-flow-modal"
import { PipelineLogsModal } from "@/components/dashboard/pipeline-logs-modal"
import { IdeasModal } from "@/components/dashboard/ideas-modal"
import { NicheSettingsModal } from "@/components/dashboard/niche-settings-modal"
import { DeepScanSettingsModal } from "@/components/dashboard/deep-scan-settings-modal"
import { ArchitectureModal } from "@/components/dashboard/architecture-modal"
import { PipelineSettingsModal, type PipelineSettings } from "@/components/dashboard/pipeline-settings-modal"
import { DmPollLogsModal, type DmPollLog, type DmPollStats, type DeepScanProgress } from "@/components/dashboard/dm-poll-logs-modal"
import { FirecrawlToolsModal } from "@/components/dashboard/firecrawl-tools-modal"

import { AiChatbot } from "@/components/dashboard/ai-chatbot"
import { CompetitorComparison } from "@/components/dashboard/competitor-comparison"
import { CompetitorAnalysis } from "@/components/dashboard/competitor-analysis"
import { StrategyReportViewer } from "@/components/dashboard/strategy-report-viewer"
import { TriggerInsights } from "@/components/dashboard/trigger-insights"
import { HashtagDiscovery } from "@/components/dashboard/hashtag-discovery"
import { ContentPipeline } from "@/components/dashboard/content-pipeline"
import { ContentPlanner } from "@/components/dashboard/content-planner"
import { ViralDashboard } from "@/components/dashboard/viral-dashboard"
import { AgentStudioV2 } from "@/components/dashboard/agent-studio-v2"
import { ArchitectChat } from "@/components/dashboard/architect-chat"
import { ResearchPanel } from "@/components/dashboard/research-panel"
import { CheckpointModal, CheckpointBadge } from "@/components/dashboard/checkpoint-modal"
import { ToneOfVoiceSetup } from "@/components/dashboard/tone-of-voice-setup"
import { SherlockPanel } from "@/components/dashboard/sherlock-panel"
import { toast, Toaster } from "sonner"
import { supabase } from "@/integrations/supabase/client"
import { useNavigate } from "react-router-dom"
import { cn } from "@/lib/utils"

export default function Dashboard() {
  const navigate = useNavigate()
  const [activeDatabase, setActiveDatabase] = useState<string | null>("competidores")
  const [activeView, setActiveView] = useState<"dashboard" | "pipeline" | "viral" | "agents" | "planning">("dashboard")
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [isPipelineRunning, setIsPipelineRunning] = useState(false)
  const [kanbanItems, setKanbanItems] = useState<KanbanItem[]>([])
  const [competitorData, setCompetitorData] = useState<CompetitorRow[]>([])
  const [meusReelsData, setMeusReelsData] = useState<ReelRow[]>([])
  const [reelsCompetidoresData, setReelsCompetidoresData] = useState<ReelRow[]>([])
  const [strategyData, setStrategyData] = useState<StrategyRow[]>([])
  const [parametersOpen, setParametersOpen] = useState(false)
  const [databaseModalOpen, setDatabaseModalOpen] = useState(false)
  const [selectedDatabase, setSelectedDatabase] = useState<DatabaseType | null>(null)
  const [aiModalOpen, setAiModalOpen] = useState(false)
  const [selectedGenerationType, setSelectedGenerationType] = useState<GenerationType | null>(null)
  const [reelPrefilledData, setReelPrefilledData] = useState<{ hookAnalysis?: string; transcript?: string } | undefined>()
  const [dbCounts, setDbCounts] = useState({ competidores: 0, reelsCompetidores: 0, meusReels: 0, estrategia: 0, conteudo: 0 })
  const [agentSettingsOpen, setAgentSettingsOpen] = useState(false)
  const [historyOpen, setHistoryOpen] = useState(false)
  const [publishQueueOpen, setPublishQueueOpen] = useState(false)
  const [integrationsOpen, setIntegrationsOpen] = useState(false)
  const [allowedSendersOpen, setAllowedSendersOpen] = useState(false)
  const [workflowFlowOpen, setWorkflowFlowOpen] = useState(false)
  const [pendingQueueCount, setPendingQueueCount] = useState(0)
  const [pipelineLogs, setPipelineLogs] = useState<string[]>([])
  const [pipelineLogsOpen, setPipelineLogsOpen] = useState(false)
  const [ideasOpen, setIdeasOpen] = useState(false)
  const [pollingDms, setPollingDms] = useState(false)
  const [nicheSettingsOpen, setNicheSettingsOpen] = useState(false)
  const [importingProfile, setImportingProfile] = useState(false)
  const [deepScanSettingsOpen, setDeepScanSettingsOpen] = useState(false)
  const [architectureOpen, setArchitectureOpen] = useState(false)
  const [pipelineSettingsOpen, setPipelineSettingsOpen] = useState(false)
  const [dmPollLogsOpen, setDmPollLogsOpen] = useState(false)
  const [dmPollLogs, setDmPollLogs] = useState<DmPollLog[]>([])
  const [dmPollStats, setDmPollStats] = useState<DmPollStats | null>(null)
  const [deepScanProgress, setDeepScanProgress] = useState<DeepScanProgress | null>(null)
  const [firecrawlToolsOpen, setFirecrawlToolsOpen] = useState(false)
  const [checkpointOpen, setCheckpointOpen] = useState(false)
  const [toneOfVoiceOpen, setToneOfVoiceOpen] = useState(false)
  const [sherlockOpen, setSherlockOpen] = useState(false)
  const [checkpointCount, setCheckpointCount] = useState(0)

  // Checkpoint count real-time
  useEffect(() => {
    async function loadCount() {
      const { count } = await supabase
        .from("checkpoint_queue")
        .select("id", { count: "exact", head: true })
        .eq("status", "pending")
      setCheckpointCount(count || 0)
    }
    loadCount()
    const ch = supabase.channel("cp-badge")
      .on("postgres_changes", { event: "*", schema: "public", table: "checkpoint_queue" }, loadCount)
      .subscribe()
    return () => { supabase.removeChannel(ch) }
  }, [])

  // Real system status
  const [systemStatus, setSystemStatus] = useState<{
    minio: "online" | "offline" | "checking"
    n8n: "online" | "offline" | "checking"
    apis: "online" | "offline" | "checking"
    instagramDms: "online" | "offline" | "checking" | "expired"
  }>({ minio: "checking", n8n: "checking", apis: "checking", instagramDms: "checking" })

  // Check real system status
  const checkSystemStatus = useCallback(async () => {
    setSystemStatus({ minio: "checking", n8n: "checking", apis: "checking", instagramDms: "checking" })

    // Check MinIO
    const minioCheck = supabase.functions.invoke("save-to-minio", {
      body: { action: "list", path: "" },
    }).then(res => res.data?.success ? "online" as const : "offline" as const)
      .catch(() => "offline" as const)

    // Check API keys (AI providers)
    const apiCheck = supabase.functions.invoke("check-api-keys")
      .then(res => {
        const cfg = res.data?.configured || {}
        const hasAI = cfg.groq || cfg.openrouter || cfg.lovable || cfg.openai || cfg.anthropic || cfg.google
        return hasAI ? "online" as const : "offline" as const
      })
      .catch(() => "offline" as const)

    // Check scraping tools
    const toolsCheck = supabase.functions.invoke("check-api-keys")
      .then(res => {
        const cfg = res.data?.configured || {}
        return (cfg.apify_configured || cfg.firecrawl_configured) ? "online" as const : "offline" as const
      })
      .catch(() => "offline" as const)

    // Check Instagram DMs - try a real poll call to validate session
    const dmCheck = (async (): Promise<"online" | "offline" | "expired"> => {
      try {
        // Check poll state for recency
        const { data: pollState } = await supabase
          .from("dm_poll_state")
          .select("last_poll_at")
          .limit(1)
          .maybeSingle()

        // Also check if there are recently captured reels (last 30 min)
        const thirtyMinAgo = new Date(Date.now() - 30 * 60 * 1000).toISOString()
        const { count: recentReels } = await supabase
          .from("reels_competidores")
          .select("*", { count: "exact", head: true })
          .gte("created_at", thirtyMinAgo)

        // If we have recent reels or recent poll, it's online
        if ((recentReels || 0) > 0) return "online"

        if (pollState?.last_poll_at) {
          const lastPoll = new Date(pollState.last_poll_at)
          const diffMinutes = (Date.now() - lastPoll.getTime()) / 1000 / 60
          if (diffMinutes <= 15) return "online"
          if (diffMinutes > 30) return "expired"
          return "online"
        }

        // Check system_config for cookie presence
        const { data: cookieConfig } = await supabase
          .from("system_config")
          .select("config_value")
          .eq("config_key", "instagram_session_id")
          .maybeSingle()

        if (cookieConfig?.config_value) return "online"

        return "offline"
      } catch {
        return "offline"
      }
    })()

    const [minio, apis, n8n, instagramDms] = await Promise.all([minioCheck, apiCheck, toolsCheck, dmCheck])
    setSystemStatus({ minio, apis, n8n, instagramDms })

    // Auto-alert if Instagram cookie expired
    if (instagramDms === "expired") {
      toast.error("⚠️ Cookie do Instagram expirou!", {
        description: "A captura de DMs está parada. Atualize o INSTAGRAM_SESSION_ID nas configurações de integrações.",
        duration: 10000,
      })
    }
  }, [])

  // Kanban persistence via MinIO
  const getKanbanPath = useCallback(async () => {
    const { data: { user } } = await supabase.auth.getUser()
    return user ? `kanban/${user.id}/board.json` : null
  }, [])

  const loadKanban = useCallback(async () => {
    try {
      const path = await getKanbanPath()
      if (!path) return
      const { data } = await supabase.functions.invoke("save-to-minio", {
        body: { action: "get", path },
      })
      if (data?.success && data.content) {
        const parsed = JSON.parse(data.content)
        if (Array.isArray(parsed) && parsed.length > 0) {
          setKanbanItems(parsed)
        }
      }
    } catch {
      // No kanban data yet - OK
    }
  }, [getKanbanPath])

  const saveKanban = useCallback(async (items: KanbanItem[]) => {
    try {
      const path = await getKanbanPath()
      if (!path) return
      await supabase.functions.invoke("save-to-minio", {
        body: { action: "save", path, data: items },
      })
    } catch (e) {
      console.error("Kanban save error:", e)
    }
  }, [getKanbanPath])

  // Load data from database
  const loadData = useCallback(async () => {
    try {
      const [compRes, myReelsRes, compReelsRes, stratRes, contentRes, queueRes] = await Promise.all([
        supabase.from("competidores").select("*").order("created_at", { ascending: false }),
        supabase.from("meus_reels").select("*").order("created_at", { ascending: false }),
        supabase.from("reels_competidores").select("*").order("created_at", { ascending: false }),
        supabase.from("estrategias").select("*").order("created_at", { ascending: false }),
        supabase.from("generated_content").select("*", { count: "exact", head: true }),
        supabase.from("publish_queue").select("*", { count: "exact", head: true }).eq("status", "pending_approval"),
      ])

      if (compRes.data) {
        setCompetitorData(compRes.data.map(c => ({
          id: c.id, name: c.name, pageUrl: c.page_url, niche: c.niche || "", status: c.status,
          bio: c.bio || undefined, followersCount: c.followers_count || undefined,
          followingCount: c.following_count || undefined, postsCount: c.posts_count || undefined,
          profilePicUrl: c.profile_pic_url || undefined,
          predominantContentType: c.predominant_content_type || undefined,
          avgPostsPerWeek: c.avg_posts_per_week ? Number(c.avg_posts_per_week) : undefined,
        })))
      }

      const parseTextList = (raw: string | null | undefined): string[] => {
        if (!raw) return [];
        let text = raw.trim();
        // Handle JSON-wrapped content like {"viral_points": "..."}
        try {
          const parsed = JSON.parse(text);
          if (typeof parsed === "string") {
            text = parsed;
          } else if (typeof parsed === "object" && parsed !== null) {
            text = Object.values(parsed).filter(v => typeof v === "string").join("\n");
          }
        } catch {
          // JSON might be truncated - try to extract the value manually
          const jsonValueMatch = text.match(/"(?:viral_points|psychological_triggers)":\s*"([\s\S]*)$/);
          if (jsonValueMatch) {
            // Remove trailing incomplete JSON artifacts
            text = jsonValueMatch[1].replace(/"\s*\}?\s*$/, "");
          }
        }
        // Replace literal \n sequences
        text = text.replace(/\\n/g, "\n");
        // Clean up markdown bold markers
        text = text.replace(/\*\*/g, "");
        return text.split("\n").map((s: string) => s.replace(/^[•\-\s*]+/, "").trim()).filter(Boolean);
      };

      const mapReels = (data: any[]) => data.map(r => ({
        id: r.id, user: r.owner_username || "", caption: r.caption || "", url: r.url || "",
        hookAnalysis: r.hook_analysis || "", transcript: r.transcript || "",
        views: r.views || 0, likes: r.likes || 0,
        comments: r.comments || 0, engRate: Number(r.eng_rate) || 0,
        postDate: r.post_date ? new Date(r.post_date).toLocaleDateString("pt-BR") : "",
        contentType: (r as any).content_type || "reel",
        imageUrls: Array.isArray((r as any).image_urls) ? (r as any).image_urls : [],
        videoUrl: (r as any).video_url || undefined,
        viralPoints: parseTextList((r as any).viral_points),
        psychTriggers: parseTextList((r as any).psychological_triggers),
        relevanceStatus: (r as any).relevance_status || "pending",
        relevanceScore: Number((r as any).relevance_score) || 0,
        relevanceReason: (r as any).relevance_reason || "",
      }))

      if (myReelsRes.data) setMeusReelsData(mapReels(myReelsRes.data))
      if (compReelsRes.data) setReelsCompetidoresData(mapReels(compReelsRes.data))

      if (stratRes.data) {
        setStrategyData(stratRes.data.map(s => ({
          id: s.id, topic: s.title, format: "Relatório", hook: s.key_takeaway || "",
          status: "Completo", priority: "Alta",
          rawReport: s.raw_report || undefined, createdAt: s.created_at,
        })))
      }

      setDbCounts({
        competidores: compRes.data?.length || 0,
        reelsCompetidores: compReelsRes.data?.length || 0,
        meusReels: myReelsRes.data?.length || 0,
        estrategia: stratRes.data?.length || 0,
        conteudo: contentRes.count || 0,
      })
      setPendingQueueCount(queueRes.count || 0)
    } catch (error) {
      console.error("Error loading data:", error)
    }
  }, [])

  // Auto-sync reels_competidores into Kanban "ideia" column
  const syncReelsToKanban = useCallback(async (reels: typeof reelsCompetidoresData, currentKanban: KanbanItem[]) => {
    // Build set of valid (existing + not rejected) reel IDs
    const validReelIds = new Set(reels.filter(r => r.relevanceStatus !== "rejected").map(r => r.id))
    const rejectedIds = new Set(reels.filter(r => r.relevanceStatus === "rejected").map(r => r.id))

    // Remove kanban cards linked to rejected OR deleted reels (linkedReelId not in DB anymore)
    const cleanedKanban = currentKanban.filter(item => {
      if (!item.linkedReelId) return true // manual cards stay
      if (rejectedIds.has(item.linkedReelId)) return false // rejected = remove
      if (!validReelIds.has(item.linkedReelId)) return false // deleted from DB = remove
      return true
    })
    const removed = currentKanban.length - cleanedKanban.length

    const existingLinkedIds = new Set(cleanedKanban.filter(i => i.linkedReelId).map(i => i.linkedReelId))
    const newItems: KanbanItem[] = reels
      .filter(r => !existingLinkedIds.has(r.id) && r.relevanceStatus !== "rejected")
      .map(r => ({
        id: `reel-${r.id}`,
        title: r.caption ? r.caption.slice(0, 80) + (r.caption.length > 80 ? "..." : "") : `@${r.user} - ${r.contentType || "reel"}`,
        description: r.hookAnalysis || r.caption || "",
        tags: [r.contentType || "reel", `@${r.user}`],
        date: r.postDate || new Date().toLocaleDateString("pt-BR"),
        status: "ideia" as KanbanStatus,
        hook: r.hookAnalysis?.split("\n")[0] || undefined,
        format: r.contentType === "carousel" ? "carousel" : r.contentType === "post" ? "post" : "reel",
        source: "auto-pipeline",
        linkedReelId: r.id,
      }))

    if (newItems.length > 0 || removed > 0) {
      const merged = [...cleanedKanban, ...newItems]
      setKanbanItems(merged)
      await saveKanban(merged)
      if (removed > 0) console.log(`🗑️ Removed ${removed} orphan/rejected reel cards from Kanban`)
    }
  }, [saveKanban])

  useEffect(() => {
    loadData()
    loadKanban()
    checkSystemStatus()
  }, [loadData, loadKanban, checkSystemStatus])

  // Sync reels to kanban after both are loaded
  useEffect(() => {
    if (reelsCompetidoresData.length > 0 && kanbanItems !== undefined) {
      syncReelsToKanban(reelsCompetidoresData, kanbanItems)
    }
  // Only run when reelsCompetidoresData changes, not kanbanItems (to avoid infinite loop)
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reelsCompetidoresData])

  const handleAnalyze = useCallback(async (urls: string[]) => {
    setIsAnalyzing(true)
    try {
      for (const url of urls) {
        const username = url.replace("https://www.instagram.com/", "").replace("/", "").replace("@", "")
        const { data, error } = await supabase.functions.invoke("scrape-reels", {
          body: { username, limit: 15, provider: "apify" },
        })
        if (error) throw error
        if (data?.success && data.reels?.length > 0) {
          await supabase.from("meus_reels").insert(data.reels)
        }
      }
      await loadData()
      toast.success("Análise concluída!", { description: `${urls.length} ${urls.length === 1 ? 'reel analisado' : 'reels analisados'}` })
    } catch (error: any) {
      toast.error("Erro na análise", { description: error.message })
    } finally {
      setIsAnalyzing(false)
    }
  }, [loadData])

  const handleAddCompetitorUrls = useCallback(async (urls: string[]) => {
    try {
      const { data: { user } } = await supabase.auth.getUser()
      const newCompetitors = urls.map(url => ({
        name: url.replace("https://www.instagram.com/", "").replace("/", "").replace("@", ""),
        page_url: url.startsWith("http") ? url : `https://www.instagram.com/${url.replace("@", "")}/`,
        niche: "",
        status: true,
        user_id: user?.id,
      }))

      // Check for duplicates against existing competitors
      const existingNames = competitorData.map(c => c.name.toLowerCase())
      const duplicates = newCompetitors.filter(c => existingNames.includes(c.name.toLowerCase()))
      const unique = newCompetitors.filter(c => !existingNames.includes(c.name.toLowerCase()))

      if (duplicates.length > 0) {
        toast.warning("Competidores duplicados ignorados", {
          description: duplicates.map(d => `@${d.name}`).join(", ") + " já existe(m)",
        })
      }

      if (unique.length === 0) return

      const { error } = await supabase.from("competidores").insert(unique)
      if (error) throw error
      await loadData()
      toast.success("Competidores adicionados!", { description: `${unique.length} competidor(es) adicionado(s)` })
    } catch (error: any) {
      toast.error("Erro ao adicionar", { description: error.message })
    }
  }, [loadData, competitorData])

  const handleLogout = useCallback(async () => {
    await supabase.auth.signOut()
    navigate("/auth")
  }, [navigate])

  const handleRunPipeline = useCallback(async (settings?: PipelineSettings) => {
    if (isPipelineRunning) {
      toast.warning("⚠️ Pipeline já está em execução!", { 
        description: "Aguarde a execução atual terminar antes de iniciar outra. Você pode minimizar o modal de logs enquanto espera." 
      })
      setPipelineLogsOpen(true)
      return
    }
    setIsPipelineRunning(true)
    setPipelineLogs([])
    setPipelineLogsOpen(true)
    toast.info("Pipeline iniciando... acompanhe os logs em tempo real ☕")
    try {
      const body: any = {};
      if (settings) {
        body.settings = settings;
      }
      const { data, error } = await supabase.functions.invoke("run-pipeline", { body })
      if (error) throw error
      if (data?.logs) {
        setPipelineLogs(data.logs)
      }
      if (data?.success) {
        await loadData()
        toast.success("Pipeline concluído! 🎉", { description: `${data.logs?.length || 0} etapas processadas` })
      } else {
        throw new Error(data?.error || "Pipeline failed")
      }
    } catch (error: any) {
      toast.error("Erro no pipeline", { description: error.message })
    } finally {
      setIsPipelineRunning(false)
    }
  }, [isPipelineRunning, loadData])

  const handleItemMove = useCallback((itemId: string, newStatus: KanbanStatus) => {
    setKanbanItems((items) => {
      const updated = items.map((item) => (item.id === itemId ? { ...item, status: newStatus } : item))
      saveKanban(updated)
      return updated
    })
    toast.success("Item movido!")
  }, [saveKanban])

  const handleAddItem = useCallback(() => {
    const newItem: KanbanItem = {
      id: `k${Date.now()}`, title: "Novo Conteudo", description: "Descricao do novo conteudo",
      tags: ["novo"], date: new Date().toLocaleDateString("pt-BR", { day: "2-digit", month: "short" }), status: "ideia",
    }
    setKanbanItems((items) => {
      const updated = [...items, newItem]
      saveKanban(updated)
      return updated
    })
    toast.success("Item adicionado!")
  }, [saveKanban])

  const handleItemUpdate = useCallback((updatedItem: KanbanItem) => {
    setKanbanItems((items) => {
      const updated = items.map((item) => (item.id === updatedItem.id ? updatedItem : item))
      saveKanban(updated)
      return updated
    })
    toast.success("Item atualizado!")
  }, [saveKanban])

  const handleItemDelete = useCallback((itemId: string) => {
    setKanbanItems((items) => {
      const updated = items.filter((item) => item.id !== itemId)
      saveKanban(updated)
      return updated
    })
    toast.success("Item excluído!")
  }, [saveKanban])

  const handleItemDuplicate = useCallback((item: KanbanItem) => {
    const duplicate: KanbanItem = {
      ...item,
      id: `k${Date.now()}`,
      title: `${item.title} (cópia)`,
      date: new Date().toLocaleDateString("pt-BR", { day: "2-digit", month: "short" }),
      status: "ideia",
    }
    setKanbanItems((items) => {
      const updated = [...items, duplicate]
      saveKanban(updated)
      return updated
    })
    toast.success("Item duplicado na coluna Ideia!")
  }, [saveKanban])

  const openAiModal = useCallback((type: GenerationType) => {
    setSelectedGenerationType(type)
    setReelPrefilledData(undefined)
    setAiModalOpen(true)
  }, [])

  const handleCopyReelWithAI = useCallback((data: { hookAnalysis: string; transcript: string; caption?: string; viralPoints?: string; psychTriggers?: string; relevanceReason?: string; ownerUsername?: string; contentType?: string; url?: string }, generationType?: string) => {
    const validType = (generationType || "reel") as any
    setSelectedGenerationType(validType)
    setReelPrefilledData(data)
    setAiModalOpen(true)
    setDatabaseModalOpen(false)
    toast.success("Dados do conteúdo carregados para geração!")
  }, [])

  const handleDatabaseSelect = useCallback((databaseId: string) => {
    setActiveDatabase(databaseId)
    setSelectedDatabase(databaseId as DatabaseType)
    setDatabaseModalOpen(true)
  }, [])

  const databases = defaultDatabases.map(db => ({
    ...db,
    count: db.id === "competidores" ? dbCounts.competidores
      : db.id === "reels-competidores" ? dbCounts.reelsCompetidores
      : db.id === "meus-reels" ? dbCounts.meusReels
      : db.id === "estrategia" ? dbCounts.estrategia
      : db.id === "conteudo" ? dbCounts.conteudo : 0,
  }))

  const addDmLog = useCallback((message: string, type: DmPollLog["type"] = "info") => {
    setDmPollLogs(prev => [...prev, { message, type, timestamp: new Date() }])
  }, [])

  const handlePollDms = useCallback(async () => {
    setPollingDms(true)
    setDmPollLogs([])
    setDmPollStats(null)
    setDmPollLogsOpen(true)
    addDmLog("📨 Iniciando poll de DMs do Instagram...", "phase")
    addDmLog("🔐 Autenticando com cookies do Instagram...", "info")
    addDmLog("📬 Buscando threads da inbox...", "info")
    try {
      const { data, error } = await supabase.functions.invoke("poll-instagram-dms", { body: {} })
      if (error) throw error
      if (data?.success) {
        const stats: DmPollStats = {
          messagesChecked: data.messages_checked || 0,
          linksProcessed: data.links_processed || 0,
          profilesScraped: data.profiles_scraped || 0,
          reelsClassified: data.reels_classified || 0,
          reelsAnalyzed: data.reels_analyzed || 0,
          ideasGenerated: data.ideas_generated || 0,
          strategyGenerated: data.strategy_generated || false,
        }
        setDmPollStats(stats)

        addDmLog(`📊 ${stats.messagesChecked} mensagens verificadas`, "counter")
        if (stats.linksProcessed > 0) addDmLog(`🔗 ${stats.linksProcessed} links novos processados`, "success")
        else addDmLog("🔗 Nenhum link novo encontrado", "info")
        if (stats.profilesScraped > 0) addDmLog(`👤 ${stats.profilesScraped} perfis de competidores extraídos`, "success")
        if (stats.reelsClassified > 0) addDmLog(`🏷️ ${stats.reelsClassified} reels classificados por relevância`, "success")
        if (stats.reelsAnalyzed > 0) addDmLog(`🤖 ${stats.reelsAnalyzed} reels analisados com IA`, "success")
        if (stats.ideasGenerated > 0) addDmLog(`💡 ${stats.ideasGenerated} ideias auto-geradas`, "success")
        if (stats.strategyGenerated) addDmLog("📊 Relatório estratégico auto-gerado!", "success")
        if (data.stopped_early) addDmLog("🛑 Poll interrompido antecipadamente", "warn")

        // Log individual results
        if (data.results?.length > 0) {
          addDmLog(`📋 Detalhes dos ${data.results.length} links:`, "phase")
          for (const r of data.results) {
            if (r.error) {
              addDmLog(`❌ ${r.type}: ${r.link} — ${r.error}`, "error")
            } else {
              addDmLog(`✅ ${r.type}: ${r.link} — ${r.action || "ok"}`, "success")
            }
          }
        }

        addDmLog("✅ Poll concluído com sucesso!", "success")

        const parts = []
        if (stats.linksProcessed) parts.push(`${stats.linksProcessed} links`)
        if (stats.profilesScraped) parts.push(`${stats.profilesScraped} perfis`)
        if (stats.reelsClassified) parts.push(`${stats.reelsClassified} classificados`)
        if (stats.reelsAnalyzed) parts.push(`${stats.reelsAnalyzed} analisados`)
        if (stats.ideasGenerated) parts.push(`${stats.ideasGenerated} ideias`)
        if (stats.strategyGenerated) parts.push("estratégia gerada")
        toast.success(`Poll concluído! ${parts.join(", ") || "Nenhum link novo."}`)

        await checkSystemStatus()
        await loadData()
      } else {
        addDmLog(`❌ ${data?.error || "Falha no poll"}`, "error")
        throw new Error(data?.error || "Falha no poll")
      }
    } catch (e: any) {
      addDmLog(`❌ Erro: ${e.message}`, "error")
      toast.error("Erro no poll de DMs", { description: e.message })
      await checkSystemStatus()
    } finally {
      setPollingDms(false)
    }
  }, [checkSystemStatus, loadData, addDmLog])

  const handleStopDeepScan = useCallback(async () => {
    try {
      // Set stop flag in system_config
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return
      await supabase.from("system_config").upsert({
        user_id: user.id,
        config_key: "deep_scan_stop",
        config_value: "true",
      }, { onConflict: "user_id,config_key" })
      toast.info("🛑 Solicitação de parada enviada. O Deep Scan será interrompido em breve...")
    } catch (e) {
      console.error("Error stopping deep scan:", e)
    }
  }, [])

  const handleDeepScanDms = useCallback(async () => {
    setPollingDms(true)
    setDmPollLogs([])
    setDmPollStats(null)
    setDmPollLogsOpen(true)
    try {
      // Clear stop flag before starting
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) throw new Error("Login necessário")

      await supabase.from("system_config").upsert({
        user_id: user.id,
        config_key: "deep_scan_stop",
        config_value: "false",
      }, { onConflict: "user_id,config_key" })

      // Fetch target usernames from allowed_senders
      const { data: senders, error: sendersError } = await supabase
        .from("allowed_senders")
        .select("ig_username")
        .eq("is_active", true)

      if (sendersError) throw sendersError
      const targetUsernames = (senders || []).map(s => s.ig_username).filter(Boolean)

      if (targetUsernames.length === 0) {
        toast.warning("Nenhum usuário autorizado configurado. Adicione usuários no menu 'Usuários Autorizados' antes de fazer o Deep Scan.")
        setPollingDms(false)
        return
      }

      // Load deep scan settings for delay between profiles
      const { data: dsConfig } = await supabase
        .from("system_config")
        .select("config_value")
        .eq("user_id", user.id)
        .eq("config_key", "deep_scan_settings")
        .maybeSingle()

      let delayBetweenProfilesMin = 30
      let delayBetweenProfilesMax = 60
      let maxRetries = 20
      if (dsConfig?.config_value) {
        try {
          const parsed = JSON.parse(dsConfig.config_value)
          delayBetweenProfilesMin = parsed.delay_between_profiles_min ?? 30
          delayBetweenProfilesMax = parsed.delay_between_profiles_max ?? 60
          maxRetries = parsed.max_retries ?? 20
        } catch {}
      }

      addDmLog(`🔍 Deep Scan sequencial: ${targetUsernames.length} perfil(is) — ${targetUsernames.map(u => `@${u}`).join(", ")}`, "phase")
      toast.info(`Deep Scan sequencial: ${targetUsernames.length} perfil(is). Use ⏹ para parar.`, { duration: 10000 })

      let totalMessages = 0, totalLinks = 0, totalProfiles = 0, totalClassified = 0, totalAnalyzed = 0, strategyGen = false
      let stoppedEarly = false

      for (let i = 0; i < targetUsernames.length; i++) {
        // Check stop flag
        const { data: stopFlag } = await supabase.from("system_config")
          .select("config_value")
          .eq("user_id", user.id)
          .eq("config_key", "deep_scan_stop")
          .maybeSingle()
        if (stopFlag?.config_value === "true") {
          stoppedEarly = true
          addDmLog("🛑 Deep Scan parado pelo usuário.", "warn")
          toast.info("Deep Scan parado pelo usuário.")
          break
        }

        const username = targetUsernames[i]
        let executionCount = 0

        // Wait between profiles (except first)
        if (i > 0) {
          const waitSec = delayBetweenProfilesMin + Math.random() * (delayBetweenProfilesMax - delayBetweenProfilesMin)
          addDmLog(`⏳ Aguardando ${Math.round(waitSec)}s antes do próximo perfil...`, "info")
          toast.info(`⏳ Aguardando ${Math.round(waitSec)}s antes do próximo perfil...`, { duration: Math.round(waitSec) * 1000 })
          await new Promise(r => setTimeout(r, waitSec * 1000))
        }

        // Auto-retry loop for this profile
        let keepRetrying = true
        while (keepRetrying) {
          executionCount++
          if (executionCount > maxRetries) {
            addDmLog(`⛔ @${username} — limite de ${maxRetries} retries atingido`, "warn")
            break
          }
          keepRetrying = false

          setDeepScanProgress({
            currentExecution: executionCount,
            currentProfile: username,
            currentProfileIndex: i + 1,
            totalProfiles: targetUsernames.length,
            isAutoRetrying: executionCount > 1,
          })

          addDmLog(`🔍 @${username} — Execução ${executionCount}${executionCount > 1 ? " (auto-retry)" : ""}`, "phase")

          try {
            const { data, error } = await supabase.functions.invoke("poll-instagram-dms", {
              body: {
                deep_scan: true,
                target_usernames: [username],
              }
            })
            if (error) throw error
            if (data?.success) {
              totalMessages += data.messages_checked || 0
              totalLinks += data.links_processed || 0
              totalProfiles += data.profiles_scraped || 0
              totalClassified += data.reels_classified || 0
              totalAnalyzed += data.reels_analyzed || 0
              if (data.strategy_generated) strategyGen = true

              // Show cache fallback warning
              if (data.cache_fallback) {
                addDmLog("🔄 Cache de threads expirado — fallback automático para paginação do inbox", "warn")
              }

              // Update stats in real-time
              setDmPollStats({
                messagesChecked: totalMessages,
                linksProcessed: totalLinks,
                profilesScraped: totalProfiles,
                reelsClassified: totalClassified,
                reelsAnalyzed: totalAnalyzed,
                ideasGenerated: 0,
                strategyGenerated: strategyGen,
              })

              addDmLog(`📊 Execução ${executionCount}: ${data.messages_checked || 0} msgs, ${data.links_processed || 0} links`, "counter")

              if (data.auto_retry_triggered) {
                addDmLog(`🔄 Time limit atingido (exec ${executionCount}/${maxRetries}) — continuando...`, "warn")
                keepRetrying = true // Client will re-invoke the edge function
              }

              if (data.stopped_early && !data.auto_retry_triggered) {
                addDmLog("🛑 Parado antecipadamente", "warn")
                stoppedEarly = true
                break
              }

              if (!data.stopped_early) {
                addDmLog(`✅ @${username} — varredura completa!`, "success")
              }
            } else {
              addDmLog(`❌ @${username}: ${data?.error || "falha"}`, "error")
              toast.error(`❌ @${username}: ${data?.error || "falha"}`)
            }
          } catch (e: any) {
            const msg = e.message || ""
            if (msg.includes("CHECKPOINT_REQUIRED") || msg.includes("checkpoint_required")) {
              addDmLog("⚠️ Verificação do Instagram necessária!", "error")
              toast.error("⚠️ Verificação do Instagram necessária. Abra o Instagram no navegador e complete a verificação.", { duration: 15000 })
              stoppedEarly = true
              break
            }
            // If timeout, the server may still be running — check if auto-retry was triggered
            if (msg.includes("Failed to send") || msg.includes("FunctionsFetchError") || msg.includes("timeout")) {
              addDmLog(`⚠️ Timeout na conexão — o servidor pode estar processando em background`, "warn")
              // Wait a bit and check if data appeared
              await new Promise(r => setTimeout(r, 5000))
              await loadData()
            } else {
              addDmLog(`❌ @${username}: ${msg}`, "error")
              toast.error(`❌ @${username}: ${msg}`)
            }
          }
        }

        if (stoppedEarly) break

        // Reload data after each profile
        await loadData()
      }

      setDeepScanProgress(null)

      const parts = []
      if (totalMessages) parts.push(`${totalMessages} mensagens`)
      if (totalLinks) parts.push(`${totalLinks} links`)
      if (totalProfiles) parts.push(`${totalProfiles} perfis`)
      if (totalClassified) parts.push(`${totalClassified} classificados`)
      if (totalAnalyzed) parts.push(`${totalAnalyzed} analisados`)
      if (strategyGen) parts.push("estratégia gerada")
      const stoppedText = stoppedEarly ? " (parado)" : ""
      toast.success(`Deep Scan finalizado${stoppedText}! ${parts.join(", ") || "Nenhum link novo."}`, { duration: 10000 })
      await checkSystemStatus()
      await loadData()
    } catch (e: any) {
      toast.error("Erro no Deep Scan", { description: e.message })
      await checkSystemStatus()
      await loadData()
    } finally {
      setPollingDms(false)
    }
  }, [checkSystemStatus, loadData, addDmLog])

  const handleUpdateSessionId = useCallback(async (sessionId: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) throw new Error("Faça login primeiro")

      const { error } = await supabase.from("system_config").upsert({
        user_id: user.id,
        config_key: "instagram_session_id",
        config_value: sessionId,
      }, { onConflict: "user_id,config_key" })

      if (error) throw error
      toast.success("Session ID atualizado! Executando poll...")
      await handlePollDms()
    } catch (e: any) {
      toast.error("Erro ao atualizar", { description: e.message })
    }
  }, [handlePollDms])

  const handleImportMyProfile = useCallback(async (manualUsername?: string) => {
    setImportingProfile(true)
    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) throw new Error("Faça login primeiro")

      let username = manualUsername
      let provider = "apify"

      if (!username) {
        // Get instagram username from pipeline_config
        const { data: config } = await supabase.from("pipeline_config")
          .select("instagram_username, scrape_provider")
          .eq("user_id", user.id)
          .maybeSingle()

        username = config?.instagram_username
        provider = config?.scrape_provider || "apify"
      }

      if (!username) {
        toast.error("Username não configurado", {
          description: "Clique no ícone 👤 ao lado do botão para digitar o @username manualmente.",
          duration: 8000,
        })
        setImportingProfile(false)
        return
      }

      toast.info(`Importando reels de @${username}... Isso pode levar alguns minutos.`, { duration: 10000 })

      const { data, error } = await supabase.functions.invoke("scrape-reels", {
        body: {
          username,
          limit: 30,
          provider: provider,
          contentTypes: ["reel", "post", "carousel"],
        },
      })

      if (error) throw error
      if (!data?.success) throw new Error(data?.error || "Falha ao importar")

      const reels = data.reels || []
      if (reels.length === 0) {
        toast.warning("Nenhum conteúdo encontrado para esse perfil.")
        setImportingProfile(false)
        return
      }

      // Check existing URLs to avoid duplicates
      const { data: existing } = await supabase.from("meus_reels").select("url").eq("user_id", user.id)
      const existingUrls = new Set((existing || []).map((r: any) => r.url).filter(Boolean))

      const newReels = reels.filter((r: any) => r.url && !existingUrls.has(r.url))

      if (newReels.length === 0) {
        toast.info("Todos os reels já foram importados anteriormente!")
        setImportingProfile(false)
        return
      }

      // Insert into meus_reels
      const rows = newReels.map((r: any) => ({
        user_id: user.id,
        owner_username: r.owner_username || username,
        caption: r.caption || null,
        url: r.url,
        thumbnail_url: r.thumbnail_url || null,
        video_url: r.video_url || null,
        views: r.views || 0,
        likes: r.likes || 0,
        comments: r.comments || 0,
        eng_rate: r.eng_rate || 0,
        post_date: r.post_date || null,
        content_type: r.content_type || "reel",
        image_urls: r.image_urls || [],
        relevance_status: "approved",
      }))

      const { error: insertError } = await supabase.from("meus_reels").insert(rows)
      if (insertError) throw insertError

      toast.success(`✅ ${newReels.length} conteúdos importados de @${username}!`, { duration: 8000 })
      await loadData()
    } catch (e: any) {
      toast.error("Erro ao importar perfil", { description: e.message })
    } finally {
      setImportingProfile(false)
    }
  }, [loadData])

  const handleReelRelevanceUpdate = useCallback(async (id: string, status: string, table: "meus_reels" | "reels_competidores") => {
    try {
      const { error } = await supabase.from(table).update({
        relevance_status: status,
        relevance_reason: status === "approved" ? "Aprovado manualmente" : "Rejeitado manualmente",
      }).eq("id", id)
      if (error) throw error
      
      const updateFn = (items: any[]) => items.map(item => item.id === id ? { ...item, relevanceStatus: status, relevanceReason: status === "approved" ? "Aprovado manualmente" : "Rejeitado manualmente" } : item)
      if (table === "meus_reels") setMeusReelsData(updateFn)
      else setReelsCompetidoresData(updateFn)

      // If rejected, also remove the linked Kanban card
      if (status === "rejected" && kanbanItems) {
        const filtered = kanbanItems.filter(item => item.linkedReelId !== id)
        if (filtered.length < kanbanItems.length) {
          setKanbanItems(filtered)
          await saveKanban(filtered)
          console.log(`🗑️ Removed Kanban card linked to rejected reel ${id}`)
        }
      }
      
      toast.success(status === "approved" ? "✅ Marcado como relevante" : "❌ Marcado como irrelevante")
    } catch (e: any) {
      toast.error("Erro ao atualizar relevância", { description: e.message })
    }
  }, [kanbanItems, saveKanban])

  const handleCleanOrphans = useCallback(async () => {
    if (!kanbanItems) return
    const validReelIds = new Set(reelsCompetidoresData.filter(r => r.relevanceStatus !== "rejected").map(r => r.id))
    const cleaned = kanbanItems.filter(item => {
      if (!item.linkedReelId) return true
      return validReelIds.has(item.linkedReelId)
    })
    const removed = kanbanItems.length - cleaned.length
    if (removed === 0) {
      toast.info("Nenhum card irrelevante encontrado")
      return
    }
    setKanbanItems(cleaned)
    await saveKanban(cleaned)
    toast.success(`🗑️ ${removed} card(s) irrelevante(s) removido(s) do Kanban`)
  }, [kanbanItems, reelsCompetidoresData, saveKanban])

  // ── Agents view with sub-tabs ─────────────────────────────────────────
  function AgentsView() {
    const [agentTab, setAgentTab] = useState<"studio"|"architect"|"research">("studio")
    return (
      <div className="flex-1 overflow-hidden flex flex-col">
        <div className="flex items-center gap-1 px-6 py-2 border-b border-border bg-muted/10">
          {([
            { id: "studio",    label: "🤖 Agentes", desc: "Configure cada agente" },
            { id: "architect", label: "🧠 Arquiteto", desc: "Crie squads com IA" },
            { id: "research",  label: "🔍 Research", desc: "Pesquisa de domínio" },
          ] as const).map(t => (
            <button key={t.id} onClick={() => setAgentTab(t.id)}
              className={cn("px-3 py-1.5 rounded-md text-xs font-medium transition-all",
                agentTab === t.id ? "bg-background text-foreground shadow-sm border border-border" : "text-muted-foreground hover:text-foreground"
              )}>
              {t.label}
            </button>
          ))}
        </div>
        <div className="flex-1 overflow-y-auto">
          {agentTab === "studio"    && <AgentStudioV2 />}
          {agentTab === "architect" && (
            <div className="p-6 max-w-2xl mx-auto h-full flex flex-col">
              <div className="mb-4">
                <h2 className="text-xl font-bold">🧠 Arquiteto de Squads</h2>
                <p className="text-sm text-muted-foreground mt-1">Crie um squad personalizado respondendo 4 perguntas</p>
              </div>
              <div className="flex-1 rounded-xl border border-border bg-card overflow-hidden">
                <ArchitectChat onSquadCreated={() => setAgentTab("studio")} />
              </div>
            </div>
          )}
          {agentTab === "research" && (
            <div className="p-6 max-w-2xl mx-auto">
              <ResearchPanel />
            </div>
          )}
        </div>
      </div>
    )
  }

  return (
    <div className="flex h-screen overflow-hidden bg-background text-foreground">
      <Sidebar
        databases={databases} activeDatabase={activeDatabase} onDatabaseSelect={handleDatabaseSelect}
        onGenerateReport={handleRunPipeline} onGenerateIdeas={() => setIdeasOpen(true)}
        onOpenIntegrations={() => setIntegrationsOpen(true)} onGenerateVideo={() => openAiModal("video")}
        onGenerateReel={() => openAiModal("reel")} onGenerateCarrossel={() => openAiModal("carrossel")}
        onGeneratePost={() => openAiModal("post")} onGenerateStory={() => openAiModal("story")}
        onGenerateScript={() => openAiModal("script")} onGenerateCopy={() => openAiModal("copy")}
        onOpenParameters={() => setParametersOpen(true)} systemStatus={systemStatus}
        onOpenAgentSettings={() => setActiveView("agents")}
        onOpenHistory={() => setHistoryOpen(true)}
        onOpenPublishQueue={() => setPublishQueueOpen(true)}
        pendingQueueCount={pendingQueueCount}
        onOpenAllowedSenders={() => setAllowedSendersOpen(true)}
        onOpenWorkflowFlow={() => setWorkflowFlowOpen(true)}
        onOpenArchitecture={() => setArchitectureOpen(true)}
        onOpenNicheSettings={() => setNicheSettingsOpen(true)}
        onPollDms={handlePollDms}
        onDeepScanDms={handleDeepScanDms}
        onStopDeepScan={handleStopDeepScan}
        onOpenDeepScanSettings={() => setDeepScanSettingsOpen(true)}
        onUpdateSessionId={handleUpdateSessionId}
        pollingDms={pollingDms}
        pipelineRunning={isPipelineRunning}
        onOpenPipeline={() => setActiveView("pipeline")}
        onOpenViral={() => setActiveView("viral")}
        onOpenAgentStudio={() => setActiveView("agents")}
        onOpenToneOfVoice={() => setToneOfVoiceOpen(true)}
        onOpenSherlock={() => setSherlockOpen(true)}
        onOpenCheckpoints={() => setCheckpointOpen(true)}
        onOpenPlanning={() => setActiveView("planning")}
        checkpointCount={checkpointCount}
      />

      <main className="flex-1 overflow-hidden flex flex-col">
        {/* ── View tabs ─────────────────────────────────── */}
        <div className="flex items-center justify-between px-6 py-3 border-b border-border flex-shrink-0 bg-background/95 backdrop-blur sticky top-0 z-10">
          <div className="flex items-center gap-1 bg-muted/30 rounded-lg p-1">
            <button
              onClick={() => setActiveView("dashboard")}
              className={cn("px-3 py-1.5 rounded-md text-xs font-medium transition-all",
                activeView === "dashboard" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
              )}
            >📊 Análise</button>
            <button
              onClick={() => setActiveView("pipeline")}
              className={cn("px-3 py-1.5 rounded-md text-xs font-medium transition-all flex items-center gap-1.5",
                activeView === "pipeline" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
              )}
            >
              ⚡ Pipeline
              {pendingQueueCount > 0 && (
                <span className="bg-yellow-500 text-black text-[9px] font-bold px-1.5 py-0.5 rounded-full min-w-[18px] text-center">
                  {pendingQueueCount}
                </span>
              )}
            </button>
            <button
              onClick={() => setActiveView("viral")}
              className={cn("px-3 py-1.5 rounded-md text-xs font-medium transition-all",
                activeView === "viral" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
              )}
            >
              🔥 Viral
            </button>
            <button
              onClick={() => setActiveView("agents")}
              className={cn("px-3 py-1.5 rounded-md text-xs font-medium transition-all",
                activeView === "agents" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
              )}
            >
              🤖 Agentes
            </button>
            <button
              onClick={() => setActiveView("planning")}
              className={cn("px-3 py-1.5 rounded-md text-xs font-medium transition-all",
                activeView === "planning" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
              )}
            >
              📅 Planejamento
            </button>
          </div>
          <CheckpointBadge onClick={() => setCheckpointOpen(true)} />
          <div className="flex items-center gap-2">
            <button onClick={() => handleRunPipeline()} disabled={isPipelineRunning}
              className="inline-flex items-center gap-1.5 rounded-md bg-primary px-3 py-1.5 text-xs font-medium text-primary-foreground hover:bg-primary/90 disabled:opacity-50">
              {isPipelineRunning ? "⏳ Executando..." : "🚀 Pipeline"}
            </button>
            <button onClick={() => setPipelineSettingsOpen(true)} disabled={isPipelineRunning}
              className="inline-flex items-center justify-center rounded-md border border-input bg-background p-1.5 text-xs text-muted-foreground hover:bg-accent"
              title="Configurar Pipeline">⚙️</button>
            <button onClick={() => setFirecrawlToolsOpen(true)}
              className="inline-flex items-center gap-1.5 rounded-md border border-input bg-background px-2.5 py-1.5 text-xs text-muted-foreground hover:bg-accent"
              title="Firecrawl Tools">🔥</button>
            <button onClick={handleLogout}
              className="inline-flex items-center gap-1.5 rounded-md bg-secondary px-2.5 py-1.5 text-xs font-medium text-secondary-foreground hover:bg-secondary/80">
              Sair
            </button>
            <ThemeToggle />
          </div>
        </div>

        {/* ── Pipeline view ─────────────────────────────── */}
        {activeView === "pipeline" && (
          <div className="flex-1 overflow-hidden">
            <ContentPipeline />
          </div>
        )}

        {/* ── Viral ranking view ────────────────────────── */}
        {activeView === "viral" && (
          <div className="flex-1 overflow-y-auto">
            <ViralDashboard onUsePost={() => setActiveView("pipeline")} />
          </div>
        )}

        {/* ── Agent Studio view ─────────────────────────── */}
        {activeView === "agents" && (
          <AgentsView />
        )}

        {/* ── Planning view ─────────────────────────────── */}
        {activeView === "planning" && (
          <div className="flex-1 overflow-hidden">
            <ContentPlanner />
          </div>
        )}

        {/* ── Dashboard view ────────────────────────────── */}
        {activeView === "dashboard" && (
          <div className="flex-1 overflow-y-auto">
            <div className="p-6 lg:p-8">

              <div className="mb-8"><KanbanBoard items={kanbanItems} onItemMove={handleItemMove} onAddItem={handleAddItem} onItemUpdate={handleItemUpdate} onItemDelete={handleItemDelete} onItemDuplicate={handleItemDuplicate} onCleanOrphans={handleCleanOrphans} reelsData={reelsCompetidoresData} /></div>
              <div className="mb-8"><QuickAnalysis onAnalyze={handleAnalyze} onAddCompetitor={handleAddCompetitorUrls} isLoading={isAnalyzing} /></div>
              <div className="mb-8">
                <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">🧠 Análise de Competidores com IA</h2>
                <CompetitorAnalysis
                  competitors={competitorData.map(c => ({
                    id: c.id, name: c.name, bio: c.bio, followersCount: c.followersCount,
                    followingCount: c.followingCount, postsCount: c.postsCount,
                    profilePicUrl: c.profilePicUrl, predominantContentType: c.predominantContentType,
                    avgPostsPerWeek: c.avgPostsPerWeek, niche: c.niche,
                  }))}
                  onRefreshData={loadData}
                />
              </div>
              <div className="mb-8">
                <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">📊 Comparação de Competidores</h2>
                <CompetitorComparison
                  myUsername=""
                  competitors={competitorData.map(c => ({
                    id: c.id, name: c.name, bio: c.bio, followersCount: c.followersCount,
                    followingCount: c.followingCount, postsCount: c.postsCount,
                    profilePicUrl: c.profilePicUrl, predominantContentType: c.predominantContentType,
                    avgPostsPerWeek: c.avgPostsPerWeek,
                  }))}
                  reelsData={reelsCompetidoresData.map(r => ({
                    user: r.user, contentType: r.contentType, engRate: r.engRate,
                    views: r.views, likes: r.likes, comments: r.comments, postDate: r.postDate,
                    caption: r.caption, url: r.url, hookAnalysis: r.hookAnalysis,
                    viralPoints: r.viralPoints, psychTriggers: r.psychTriggers,
                    relevanceScore: r.relevanceScore,
                  }))}
                  onDeleteCompetitors={async (ids) => {
                    try {
                      for (const id of ids) {
                        const { error } = await supabase.from("competidores").delete().eq("id", id)
                        if (error) throw error
                      }
                      toast.success(`${ids.length} competidor${ids.length > 1 ? "es" : ""} removido${ids.length > 1 ? "s" : ""}`)
                      await loadData()
                    } catch (e: any) {
                      toast.error("Erro ao excluir", { description: e.message })
                    }
                  }}
                />
              </div>
              <div className="mb-8">
                <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">📋 Relatório Estratégico</h2>
                <StrategyReportViewer />
              </div>
              <div className="mb-8">
                <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">#️⃣ Descoberta por Hashtags</h2>
                <HashtagDiscovery onRelevanceUpdate={(id, status) => handleReelRelevanceUpdate(id, status, "reels_competidores")} onRefresh={loadData} />
              </div>
              <div className="mb-8">
                <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">🧠 Insights de Gatilhos Psicológicos</h2>
                <TriggerInsights meusReels={meusReelsData} competitorReels={reelsCompetidoresData} />
              </div>
              <div className="mb-8"><DataTable competitorData={competitorData} meusReelsData={meusReelsData} reelsCompetidoresData={reelsCompetidoresData} strategyData={strategyData} onReelRelevanceUpdate={handleReelRelevanceUpdate} onCopyReelWithAI={handleCopyReelWithAI} onRefreshData={loadData} onImportMyProfile={handleImportMyProfile} importingProfile={importingProfile} /></div>

            </div>
          </div>
        )}
      </main>

      <CheckpointModal open={checkpointOpen} onOpenChange={setCheckpointOpen} pendingCount={pendingQueueCount} onResolved={() => {}} />
      {/* Tone of Voice modal */}
      {toneOfVoiceOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={e => { if (e.target === e.currentTarget) setToneOfVoiceOpen(false) }}>
          <div className="bg-background border border-border rounded-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold">🎙️ Tom de Voz</h2>
              <button onClick={() => setToneOfVoiceOpen(false)} className="text-muted-foreground hover:text-foreground">✕</button>
            </div>
            <ToneOfVoiceSetup onSaved={() => setToneOfVoiceOpen(false)} />
          </div>
        </div>
      )}
      {/* Sherlock modal */}
      {sherlockOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={e => { if (e.target === e.currentTarget) setSherlockOpen(false) }}>
          <div className="bg-background border border-border rounded-2xl w-full max-w-2xl max-h-[85vh] overflow-y-auto p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold">🔍 Sherlock — Investigar Perfis</h2>
              <button onClick={() => setSherlockOpen(false)} className="text-muted-foreground hover:text-foreground">✕</button>
            </div>
            <SherlockPanel onConsolidatedReady={() => { setSherlockOpen(false); toast.success("Análise salva — disponível nos agentes") }} />
          </div>
        </div>
      )}
      <Toaster position="bottom-right" richColors />
      
      <DatabaseModal open={databaseModalOpen} onOpenChange={setDatabaseModalOpen} databaseType={selectedDatabase} onCopyReelWithAI={handleCopyReelWithAI} />
      <AiGenerationModal open={aiModalOpen} onOpenChange={setAiModalOpen} generationType={selectedGenerationType} prefilledData={reelPrefilledData} />
      <ParametersModal open={parametersOpen} onOpenChange={setParametersOpen} />
      <AgentSettingsModal open={agentSettingsOpen} onOpenChange={setAgentSettingsOpen} />
      <ContentHistoryModal open={historyOpen} onOpenChange={setHistoryOpen} />
      <PublishQueue open={publishQueueOpen} onOpenChange={setPublishQueueOpen} />
      <IntegrationsModal open={integrationsOpen} onOpenChange={setIntegrationsOpen} />
      <AllowedSendersModal open={allowedSendersOpen} onOpenChange={setAllowedSendersOpen} />
      <WorkflowFlowModal open={workflowFlowOpen} onOpenChange={setWorkflowFlowOpen} />
      <PipelineLogsModal open={pipelineLogsOpen} onOpenChange={setPipelineLogsOpen} logs={pipelineLogs} isRunning={isPipelineRunning} />
      <IdeasModal open={ideasOpen} onOpenChange={setIdeasOpen} />
      <NicheSettingsModal open={nicheSettingsOpen} onOpenChange={setNicheSettingsOpen} />
      <DeepScanSettingsModal open={deepScanSettingsOpen} onOpenChange={setDeepScanSettingsOpen} />
      <ArchitectureModal open={architectureOpen} onOpenChange={setArchitectureOpen} />
      <PipelineSettingsModal open={pipelineSettingsOpen} onOpenChange={setPipelineSettingsOpen} onRunPipeline={handleRunPipeline} isRunning={isPipelineRunning} />
      <DmPollLogsModal open={dmPollLogsOpen} onOpenChange={setDmPollLogsOpen} logs={dmPollLogs} isRunning={pollingDms} stats={dmPollStats} deepScanProgress={deepScanProgress} />
      <FirecrawlToolsModal open={firecrawlToolsOpen} onOpenChange={setFirecrawlToolsOpen} />
      <AiChatbot />
    </div>
  )
}
