import { useCallback } from "react";
import { useNavigate } from "react-router-dom";

const SUPABASE_URL = "https://hlmjfhvsfwykxyomrsqq.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhsbWpmaHZzZnd5a3h5b21yc3FxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzE0NjMxODMsImV4cCI6MjA4NzAzOTE4M30.XEb8Njyya0vDWdY5cMxPUiOPIdMbqwwjnfahCBoDBQY";
const USER_ID = "50190295-a86e-41a4-9225-58641ffea67c";

// ==========================================
// WORKFLOW 1: Captura de DMs (perfil, reel, post, carrossel, story)
// Recebe webhooks do Instagram → extrai links → envia para edge function
// ==========================================
const DM_WORKFLOW = {
  name: "IG OS v3 - Captura de DMs",
  nodes: [
    // Instagram Trigger nativo do n8n (OAuth — sem Meta Developer Portal)
    {
      parameters: {
        event: "message",
        options: {}
      },
      id: "ig-trigger", name: "Instagram Trigger",
      type: "n8n-nodes-base.instagramTrigger", typeVersion: 1, position: [250, 300],
      credentials: { instagramOAuth2Api: { id: "CONFIGURE_NO_N8N", name: "Instagram Account" } }
    },
    // Busca lista de remetentes autorizados do Supabase
    {
      parameters: {
        method: "GET",
        url: `${SUPABASE_URL}/rest/v1/allowed_senders?user_id=eq.${USER_ID}&is_active=eq.true&select=ig_username`,
        sendHeaders: true,
        headerParameters: {
          parameters: [
            { name: "apikey", value: SUPABASE_ANON_KEY },
            { name: "Authorization", value: `Bearer ${SUPABASE_ANON_KEY}` }
          ]
        },
        options: {}
      },
      id: "get-allowed", name: "Get Allowed Senders",
      type: "n8n-nodes-base.httpRequest", typeVersion: 4.2, position: [480, 300],
      executeOnce: true
    },
    {
      parameters: {
        jsCode: `// Extrai links das DMs recebidas via Instagram Trigger
// Filtra apenas remetentes autorizados (allowed_senders)
// Suporta: perfil, reel, post, carrossel, story

const message = $('Instagram Trigger').first().json;
const allowedSenders = $('Get Allowed Senders').all().map(i => i.json.ig_username?.toLowerCase());

const results = [];
const senderUsername = (message.from?.username || message.sender?.username || "").toLowerCase();
const senderId = message.from?.id || message.sender?.id || "";
const text = message.text || message.message?.text || "";
const attachments = message.attachments || message.message?.attachments || [];

// Verifica se é self-sent ou remetente autorizado
const isSelfSent = message.is_echo || false;
const isAllowed = allowedSenders.includes(senderUsername);

if (!isSelfSent && !isAllowed && senderUsername) {
  return [{ json: { skip: true, reason: "unauthorized_sender", sender: senderUsername } }];
}

// Extrair links do texto
const urlRegex = /https?:\\/\\/(?:www\\.)?instagram\\.com\\/[^\\s]+/gi;
const links = text.match(urlRegex) || [];

for (const link of links) {
  let type = "profile";
  if (link.includes("/reel/") || link.includes("/reels/")) type = "reel";
  else if (link.includes("/p/")) type = "post";
  else if (link.includes("/stories/")) type = "story";
  results.push({ url: link, type, sender_id: senderId, sender_username: senderUsername });
}

// Extrair links de attachments (compartilhamentos)
for (const att of attachments) {
  if (att.type === "share" && att.payload?.url) {
    const u = att.payload.url;
    if (u.includes("instagram.com")) {
      let type = "profile";
      if (u.includes("/reel/") || u.includes("/reels/")) type = "reel";
      else if (u.includes("/p/")) type = "post";
      else if (u.includes("/stories/")) type = "story";
      results.push({ url: u, type, sender_id: senderId, sender_username: senderUsername });
    }
  }
  // Mídia enviada diretamente (foto/vídeo)
  if ((att.type === "image" || att.type === "video") && att.payload?.url) {
    results.push({
      url: att.payload.url,
      type: att.type === "video" ? "reel" : "post",
      sender_id: senderId,
      sender_username: senderUsername,
      is_media: true
    });
  }
}

return results.length > 0
  ? results.map(r => ({ json: r }))
  : [{ json: { skip: true } }];`,
      },
      id: "extract", name: "Extract & Filter Links",
      type: "n8n-nodes-base.code", typeVersion: 2, position: [700, 300],
    },
    {
      parameters: {
        conditions: {
          options: { caseSensitive: true },
          conditions: [{
            leftValue: "={{ $json.skip }}",
            rightValue: "true",
            operator: { type: "string", operation: "notEquals" }
          }]
        },
      },
      id: "filter", name: "Has Links?",
      type: "n8n-nodes-base.if", typeVersion: 2, position: [920, 300],
    },
    {
      parameters: {
        method: "POST",
        url: `${SUPABASE_URL}/functions/v1/process-instagram-link`,
        sendHeaders: true,
        headerParameters: {
          parameters: [
            { name: "apikey", value: SUPABASE_ANON_KEY },
            { name: "Authorization", value: `Bearer ${SUPABASE_ANON_KEY}` },
            { name: "Content-Type", value: "application/json" }
          ]
        },
        sendBody: true,
        specifyBody: "json",
        jsonBody: `={\n  "url": "{{ $json.url }}",\n  "type": "{{ $json.type }}",\n  "user_id": "${USER_ID}",\n  "sender_id": "{{ $json.sender_id }}",\n  "sender_username": "{{ $json.sender_username }}",\n  "is_media": {{ $json.is_media || false }}\n}`,
      },
      id: "process", name: "Process Instagram Link",
      type: "n8n-nodes-base.httpRequest", typeVersion: 4.2, position: [1140, 200],
      retryOnFail: true,
      onError: "continueRegularOutput"
    },
    {
      parameters: {
        content: `## Captura de DMs 📩\n\n**Usa Instagram Trigger nativo do n8n**\n(conecte sua conta Instagram no n8n via OAuth)\n\n**Segurança:** Só processa mensagens de:\n✅ Usuários na lista de Autorizados (allowed_senders)\n✅ Mensagens self-sent (enviadas por você)\n\n**Tipos suportados:**\n👤 Perfis | 🎬 Reels | 📸 Posts\n🎠 Carrosséis | 📱 Stories | 🖼️ Mídia direta\n\n**Configuração:**\n1. Conecte o Instagram no n8n (credenciais OAuth)\n2. Adicione usuários autorizados no app (sidebar)`,
        height: 340, width: 380, color: 5
      },
      type: "n8n-nodes-base.stickyNote",
      typeVersion: 1,
      position: [250, 480],
      id: "note-dm",
      name: "Info DMs"
    }
  ],
  connections: {
    "Instagram Trigger": { main: [[{ node: "Get Allowed Senders", type: "main", index: 0 }]] },
    "Get Allowed Senders": { main: [[{ node: "Extract & Filter Links", type: "main", index: 0 }]] },
    "Extract & Filter Links": { main: [[{ node: "Has Links?", type: "main", index: 0 }]] },
    "Has Links?": { main: [[{ node: "Process Instagram Link", type: "main", index: 0 }], []] },
  },
  pinData: {},
  settings: { executionOrder: "v1" },
};

// ==========================================
// WORKFLOW 2: Postagens Automáticas
// Cron → lista itens aprovados → publica via Meta Graph API
// ==========================================
const PUBLISH_WORKFLOW = {
  name: "IG OS v3 - Postagens Automáticas",
  nodes: [
    {
      parameters: { rule: { interval: [{ field: "minutes", minutesInterval: 15 }] } },
      id: "cron", name: "Cron 15min",
      type: "n8n-nodes-base.scheduleTrigger", typeVersion: 1.2, position: [250, 300],
    },
    {
      parameters: {
        method: "POST",
        url: `${SUPABASE_URL}/functions/v1/n8n-publish`,
        sendHeaders: true,
        headerParameters: {
          parameters: [
            { name: "apikey", value: SUPABASE_ANON_KEY },
            { name: "Content-Type", value: "application/json" }
          ]
        },
        sendBody: true,
        specifyBody: "json",
        jsonBody: `{\n  "action": "list_ready",\n  "user_id": "${USER_ID}"\n}`,
      },
      id: "list", name: "List Ready Posts",
      type: "n8n-nodes-base.httpRequest", typeVersion: 4.2, position: [480, 300],
    },
    {
      parameters: {
        conditions: {
          options: { caseSensitive: true },
          conditions: [{
            leftValue: "={{ $json.items.length }}",
            rightValue: "0",
            operator: { type: "number", operation: "gt" }
          }]
        },
      },
      id: "check", name: "Has Items?",
      type: "n8n-nodes-base.if", typeVersion: 2, position: [700, 300],
    },
    {
      parameters: { fieldToSplitOut: "items" },
      id: "split", name: "Split Items",
      type: "n8n-nodes-base.splitOut", typeVersion: 1, position: [920, 200],
    },
    {
      parameters: {
        method: "POST",
        url: `${SUPABASE_URL}/functions/v1/n8n-publish`,
        sendHeaders: true,
        headerParameters: {
          parameters: [
            { name: "apikey", value: SUPABASE_ANON_KEY },
            { name: "Content-Type", value: "application/json" }
          ]
        },
        sendBody: true,
        specifyBody: "json",
        jsonBody: `={\n  "action": "publish",\n  "queue_id": "{{ $json.id }}",\n  "user_id": "${USER_ID}"\n}`,
      },
      id: "publish", name: "Publish Post",
      type: "n8n-nodes-base.httpRequest", typeVersion: 4.2, position: [1140, 200],
      retryOnFail: true
    },
    {
      parameters: {
        content: `## Postagens Automáticas 📤\n\nA cada 15 minutos verifica itens aprovados/agendados\nna fila de publicação e publica via Meta Graph API.\n\n**Fluxo:**\nCron → list_ready → split → publish cada item\n\n**Pré-requisito:**\nInstagram conectado no app (token configurado).`,
        height: 240, width: 340, color: 6
      },
      type: "n8n-nodes-base.stickyNote",
      typeVersion: 1,
      position: [250, 420],
      id: "note-pub",
      name: "Info Publish"
    }
  ],
  connections: {
    "Cron 15min": { main: [[{ node: "List Ready Posts", type: "main", index: 0 }]] },
    "List Ready Posts": { main: [[{ node: "Has Items?", type: "main", index: 0 }]] },
    "Has Items?": { main: [[{ node: "Split Items", type: "main", index: 0 }], []] },
    "Split Items": { main: [[{ node: "Publish Post", type: "main", index: 0 }]] },
  },
  pinData: {},
  settings: { executionOrder: "v1" },
};

// ==========================================
// UI
// ==========================================
const WORKFLOW_MAP = {
  dm: { data: DM_WORKFLOW, filename: "n8n-captura-dm" },
  publish: { data: PUBLISH_WORKFLOW, filename: "n8n-postagens-automaticas" },
} as const;

export default function N8nWorkflows() {
  const navigate = useNavigate();

  const downloadJson = useCallback((type: keyof typeof WORKFLOW_MAP) => {
    const { data, filename } = WORKFLOW_MAP[type];
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${filename}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }, []);

  const items = [
    {
      key: "dm" as const,
      title: "1. Captura de DMs",
      desc: "Webhook Meta → extrai perfis, reels, posts, carrosséis, stories e mídia direta → process-instagram-link",
      icon: "📩",
      highlight: true
    },
    {
      key: "publish" as const,
      title: "2. Postagens Automáticas",
      desc: "Cron 15min → lista itens aprovados/agendados → publica via n8n-publish",
      icon: "📤"
    },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground p-8">
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">📄 Workflows n8n</h1>
          <button onClick={() => navigate("/")} className="text-sm text-muted-foreground hover:text-foreground underline">
            ← Voltar
          </button>
        </div>

        <p className="text-sm text-muted-foreground">
          Apenas os workflows que <strong>precisam do n8n</strong> como middleware. Pipeline, análise e estratégia rodam direto no app.
        </p>

        <div className="grid gap-4">
          {items.map(({ key, title, desc, icon, highlight }) => (
            <div
              key={key}
              className={`flex items-start gap-4 rounded-lg border p-4 ${highlight ? 'border-2 border-primary/50 bg-primary/5' : 'border-border bg-card'}`}
            >
              <span className="text-2xl">{icon}</span>
              <div className="flex-1">
                <p className="font-semibold">{title}</p>
                <p className="text-sm text-muted-foreground">{desc}</p>
              </div>
              <button
                onClick={() => downloadJson(key)}
                className="rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90"
              >
                ⬇ JSON
              </button>
            </div>
          ))}
        </div>

        <div className="rounded-lg border border-border bg-card p-4 text-sm text-muted-foreground space-y-2">
          <p className="font-semibold text-foreground">⚙️ Configuração necessária:</p>
          <ul className="list-disc list-inside space-y-1">
            <li><strong>Captura de DMs:</strong> Configure o webhook do Instagram no Meta Developer Portal apontando para <code className="bg-muted px-1 rounded">https://SEU-N8N/webhook/instagram-webhook</code></li>
            <li><strong>Postagens:</strong> Conecte o Instagram no app (token de acesso)</li>
          </ul>
          <p className="mt-2 text-xs">Nenhuma credencial de IA (Apify, Gemini, etc.) é necessária no n8n — tudo já está nas edge functions do app.</p>
        </div>
      </div>
    </div>
  );
}
